# SDTM Clinical Integrity Suite — Changelog

## v17.0 — 2026-04-05

### New Checks (23)

**GCP Cross-Domain**
- GCP001 CRITICAL — PR record before RFICDTC (ICH E6 consent violation)
- GCP002 ERROR — DTHDTC in DM but no DEATH record in DS
- GCP003 ERROR — DSDECOD=DEATH in DS but DTHDTC missing in DM
- GCP004 ERROR — EX dosing after DS discontinuation date
- GCP005 ERROR — AEACN=DRUG WITHDRAWN with no DS discontinuation record

**Medical Signals**
- MED001 WARNING — Abnormal LB with no AE within ±7 days
- MED002 ERROR — AEOUT=FATAL but AEENDTC != DTHDTC
- MED003 WARNING — AEOUT=RECOVERED/RESOLVED but AEENDTC missing
- MED004 WARNING — Ocular AE missing AELAT laterality

**Data Integrity**
- DAT008 WARNING — Record date after last SV visit date
- DAT009 WARNING — Partial date with year+day known, month missing

**Oncology / RECIST**
- ONC006 ERROR — TR response inconsistent with RS overall response
- ONC007 ERROR — TRSTRESN missing for LDIAM target lesion

**Questionnaire**
- QS001 ERROR — QSSTAT=NOT DONE but QSSTRESC not null
- QS002 ERROR — QSDTC after DTHDTC (post-mortem PRO)
- QS003 WARNING — Duplicate QS records
- QS004 WARNING — QSSTAT=NOT DONE but QSREASND missing

**Analysis / Metadata**
- ANL001 ERROR — Randomized subject missing stratification factor
- ANL002 ERROR — TS missing MedDRA version (TSPARMCD=MEDDRA)
- ANL003 ERROR — TS missing WHODrug version (TSPARMCD=WHODRUG)
- META001 ERROR — SUPP QORIG inconsistent with Define-XML Origin
- META002 ERROR — CT value not in declared CDISC CT package version
- META003 WARNING — Drug variable not following FDA TCG naming convention

### Bug Fixes / Improvements
- REMOVED: st_aggrid dependency fully eliminated. Tab 7 "AgGrid Review" renamed
  to "Findings Table" and rebuilt with native st.dataframe + st.column_config.
  Eliminates MarshallComponentException permanently.
- ADDED: Partial date policy in study_config.yaml (allowed_patterns, reject_patterns,
  action_on_reject)
- ADDED: Date parser configuration block in study_config.yaml
- UPDATED: documentation.html rebuilt for v17 (159 checks, all new check details,
  partial date policy, date parser rules, AgGrid removal notes)
- Total checks: 159 (was 136)

---

## v16.0 — 2026-03-31

### Bug Fixes
- B01 Fixed: MarshallComponentException in AgGrid — JsCode cell styles removed;
  allow_unsafe_jscode=False; compatible with all st-aggrid versions
- B02 Fixed: Regulatory mode showed as Python dict literal in header

### Features
- Gantt SVG Timeline in Subject Narrative tab
- SUPP structural checks S016–S018 (QNAM conflicts, reserved names, QORIG)
- AE014: Serious AE without SAE flag

---

## v15.0 — 2026-02-14

- Temporal Integrity checks DATE001–DATE007
- Hidden Integrity checks INT001–INT005
- SUPP back-merge with audit log
- Subject Narrative tab
- Waiver management system

---

## v14.0 — 2025-12-01

- 136 checks at launch
- Waiver management
- Excel and HTML report export
- SAS code generation
- Study config hot-reload
- Demo mode for all checks

---
