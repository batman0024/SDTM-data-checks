"""
modules/engine.py
SUG-002: Pandas-vectorized checks.
SUG-004: Cross-domain dependency pre-check.
v7.0: INT001-INT005 (Hidden Integrity) + DATE001-DATE006 (Temporal Integrity)
"""

import re
import time
import hashlib
import datetime
import pandas as pd
from modules.registry import get_checks, get_check, CHECK_REQUIRES


def _fingerprint(domain: str, check_id: str, usubjid: str, detail: str) -> str:
    """Return a stable 8-char MD5 fingerprint for an issue (IMP005)."""
    raw = f"{domain}|{check_id}|{usubjid}|{detail}"
    return "F" + hashlib.md5(raw.encode("utf-8")).hexdigest()[:7].upper()


# ---------------------------------------------------------------------------
# SAS CODE GENERATOR  (v14 — multi-domain JOIN templates for cross-domain checks)
# ---------------------------------------------------------------------------

_CROSS_DOMAIN_SQL = {
    "AE005": {
        "domains": ["AE","DS"],
        "desc": "AE record exists after subject death date",
        "sql": (
            "PROC SQL;\n"
            "  /* AE005: AE record after subject death date */\n"
            "  SELECT a.USUBJID, a.AEDECOD, a.AESTDTC,\n"
            "         d.DSSTDTC AS DEATH_DATE\n"
            "  FROM   SDTM.AE a\n"
            "  INNER JOIN (\n"
            "    SELECT USUBJID, MIN(DSSTDTC) AS DSSTDTC\n"
            "    FROM   SDTM.DS\n"
            "    WHERE  UPCASE(DSDECOD) IN (\'DEATH\',\'DIED\',\'DEAD\')\n"
            "    GROUP BY USUBJID\n"
            "  ) d ON a.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(a.AESTDTC,1,10) > SUBSTR(d.DSSTDTC,1,10){ws};\n"
            "QUIT;"
        ),
    },
    "AE015": {"domains":["AE","LB"],"desc":"Grade 3/4 lab with no AE within +/-7 days",
        "sql":(
            "PROC SQL;\n"
            "  /* AE015: Grade 3/4 lab value with no AE within +/-7 days */\n"
            "  SELECT l.USUBJID, l.LBTESTCD, l.LBSTRESN, l.LBDTC AS LAB_DATE\n"
            "  FROM   SDTM.LB l\n"
            "  WHERE  INPUT(l.LBSTRESN,?? BEST12.) > 3 * INPUT(l.LBORNRHI,?? BEST12.)\n"
            "    AND  l.LBORNRHI NE \'\'{ws}\n"
            "    AND  NOT EXISTS (\n"
            "           SELECT 1 FROM SDTM.AE a\n"
            "           WHERE  a.USUBJID = l.USUBJID\n"
            "           AND    ABS(INPUT(SUBSTR(a.AESTDTC,1,10),?? YYMMDD10.)\n"
            "                    - INPUT(SUBSTR(l.LBDTC,1,10),?? YYMMDD10.)) <= 7\n"
            "         );\n"
            "QUIT;"
        )},
    "AE016": {"domains":["AE","CM"],"desc":"Severe AE with no CM within +/-14 days",
        "sql":(
            "PROC SQL;\n"
            "  /* AE016: Severe AE with no concomitant medication */\n"
            "  SELECT a.USUBJID, a.AEDECOD, a.AESEV, a.AESTDTC\n"
            "  FROM   SDTM.AE a\n"
            "  WHERE  UPCASE(a.AESEV) = \'SEVERE\'{ws}\n"
            "    AND  NOT EXISTS (\n"
            "           SELECT 1 FROM SDTM.CM c WHERE c.USUBJID = a.USUBJID\n"
            "           AND ABS(INPUT(SUBSTR(c.CMSTDTC,1,10),?? YYMMDD10.)\n"
            "                 - INPUT(SUBSTR(a.AESTDTC,1,10),?? YYMMDD10.)) <= 14\n"
            "         );\n"
            "QUIT;"
        )},
    "DS006": {"domains":["DS","AE","LB","VS"],"desc":"Clinical activity after death date",
        "sql":(
            "PROC SQL;\n"
            "  CREATE TABLE _death AS\n"
            "  SELECT USUBJID, MIN(DSSTDTC) AS DEATH_DTC FROM SDTM.DS\n"
            "  WHERE  UPCASE(DSDECOD) IN (\'DEATH\',\'DIED\',\'DEAD\') GROUP BY USUBJID;\n\n"
            "  SELECT a.USUBJID, \'AE\' AS DOMAIN, a.AESTDTC, d.DEATH_DTC\n"
            "  FROM   SDTM.AE a INNER JOIN _death d ON a.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(a.AESTDTC,1,10) > SUBSTR(d.DEATH_DTC,1,10){ws};\n\n"
            "  DROP TABLE _death;\n"
            "QUIT;"
        )},
    "DM001": {"domains":["DM","EX"],"desc":"ARM vs ACTARM mismatch",
        "sql":(
            "PROC SQL;\n"
            "  /* DM001: ARM != ACTARM */\n"
            "  SELECT d.USUBJID, d.ARM, d.ACTARM, COUNT(e.USUBJID) AS N_EX\n"
            "  FROM   SDTM.DM d LEFT JOIN SDTM.EX e ON d.USUBJID = e.USUBJID\n"
            "  WHERE  d.ARM NE d.ACTARM\n"
            "    AND  UPCASE(d.ARM) NOT CONTAINS \'SCRNFAIL\'{ws}\n"
            "  GROUP BY d.USUBJID, d.ARM, d.ACTARM;\n"
            "QUIT;"
        )},
    "INT001": {"domains":["DM","AE","LB"],"desc":"Orphan USUBJID not in DM",
        "sql":(
            "PROC SQL;\n"
            "  /* INT001: Orphan subjects - observation domain not in DM */\n"
            "  SELECT DISTINCT a.USUBJID, \'AE\' AS DOMAIN FROM SDTM.AE a\n"
            "  WHERE  a.USUBJID NOT IN (SELECT USUBJID FROM SDTM.DM){ws}\n"
            "  UNION ALL\n"
            "  SELECT DISTINCT l.USUBJID, \'LB\' FROM SDTM.LB l\n"
            "  WHERE  l.USUBJID NOT IN (SELECT USUBJID FROM SDTM.DM){ws};\n"
            "QUIT;"
        )},
    "INT002": {"domains":["DM","LB"],"desc":"Baseline flag after first dose (RFSTDTC)",
        "sql":(
            "PROC SQL;\n"
            "  /* INT002: Baseline flag set after first dose */\n"
            "  SELECT l.USUBJID, l.LBTESTCD, l.LBDTC, l.LBBLFL, d.RFSTDTC\n"
            "  FROM   SDTM.LB l INNER JOIN SDTM.DM d ON l.USUBJID = d.USUBJID\n"
            "  WHERE  UPCASE(l.LBBLFL) = \'Y\'\n"
            "    AND  SUBSTR(l.LBDTC,1,10) > SUBSTR(d.RFSTDTC,1,10){ws};\n"
            "QUIT;"
        )},
    "INT003": {"domains":["DS","EX"],"desc":"Study activity but no DS disposition",
        "sql":(
            "PROC SQL;\n"
            "  /* INT003: Subject has EX records but no DS disposition event */\n"
            "  SELECT DISTINCT e.USUBJID FROM SDTM.EX e\n"
            "  WHERE  e.USUBJID NOT IN (\n"
            "    SELECT USUBJID FROM SDTM.DS\n"
            "    WHERE  UPCASE(DSCAT) IN (\'DISPOSITION EVENT\',\'DISPOSITION\')){ws};\n"
            "QUIT;"
        )},
    "INT005": {"domains":["DM","LB"],"desc":"Assessment before informed consent (RFICDTC)",
        "sql":(
            "PROC SQL;\n"
            "  /* INT005: Assessment before informed consent */\n"
            "  SELECT l.USUBJID, l.LBTESTCD, l.LBDTC, d.RFICDTC AS CONSENT_DATE\n"
            "  FROM   SDTM.LB l INNER JOIN SDTM.DM d ON l.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(l.LBDTC,1,10) < SUBSTR(d.RFICDTC,1,10){ws};\n"
            "QUIT;"
        )},
    "DATE002": {"domains":["DS","AE"],"desc":"Post-mortem clinical activity",
        "sql":(
            "PROC SQL;\n"
            "  CREATE TABLE _death AS\n"
            "  SELECT USUBJID, MIN(DSSTDTC) AS DEATH_DTC FROM SDTM.DS\n"
            "  WHERE  UPCASE(DSDECOD) IN (\'DEATH\',\'DIED\',\'DEAD\') GROUP BY USUBJID;\n\n"
            "  SELECT a.USUBJID, \'AE\' AS DOMAIN, a.AESTDTC, d.DEATH_DTC\n"
            "  FROM   SDTM.AE a INNER JOIN _death d ON a.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(a.AESTDTC,1,10) > SUBSTR(d.DEATH_DTC,1,10){ws};\n\n"
            "  DROP TABLE _death;\n"
            "QUIT;"
        )},
    "DATE005": {"domains":["EX","DM"],"desc":"First treatment before informed consent",
        "sql":(
            "PROC SQL;\n"
            "  /* DATE005: First dose before informed consent */\n"
            "  SELECT e.USUBJID, e.EXTRT, e.EXSTDTC, d.RFICDTC AS CONSENT_DATE\n"
            "  FROM   SDTM.EX e INNER JOIN SDTM.DM d ON e.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(e.EXSTDTC,1,10) < SUBSTR(d.RFICDTC,1,10){ws};\n"
            "QUIT;"
        )},
    "DATE006": {"domains":["EX","DS"],"desc":"Dosing after study discontinuation",
        "sql":(
            "PROC SQL;\n"
            "  /* DATE006: Dosing after study discontinuation */\n"
            "  SELECT e.USUBJID, e.EXTRT, e.EXENDTC, d.DSSTDTC AS DISC_DATE\n"
            "  FROM   SDTM.EX e\n"
            "  INNER JOIN (\n"
            "    SELECT USUBJID, MIN(DSSTDTC) AS DSSTDTC FROM SDTM.DS\n"
            "    WHERE  UPCASE(DSCAT) IN (\'DISPOSITION EVENT\',\'DISPOSITION\')\n"
            "    GROUP BY USUBJID\n"
            "  ) d ON e.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(e.EXENDTC,1,10) > SUBSTR(d.DSSTDTC,1,10){ws};\n"
            "QUIT;"
        )},
    "LB011": {"domains":["LB"],"desc":"Hys Law: ALT>3xULN and TBili>2xULN within 30 days",
        "sql":(
            "PROC SQL;\n"
            "  /* LB011: Hys Law signal - concurrent ALT and TBili elevations */\n"
            "  SELECT a.USUBJID,\n"
            "         a.LBSTRESN AS ALT_VAL, a.LBORNRHI AS ALT_ULN, a.LBDTC AS ALT_DTC,\n"
            "         b.LBSTRESN AS BILI_VAL, b.LBORNRHI AS BILI_ULN, b.LBDTC AS BILI_DTC\n"
            "  FROM   SDTM.LB a INNER JOIN SDTM.LB b ON a.USUBJID = b.USUBJID\n"
            "  WHERE  UPCASE(a.LBTESTCD) IN (\'ALT\',\'ALAT\')\n"
            "    AND  UPCASE(b.LBTESTCD) IN (\'BILI\',\'TBILI\',\'BILIRUBIN\')\n"
            "    AND  INPUT(a.LBSTRESN,?? BEST12.) > 3 * INPUT(a.LBORNRHI,?? BEST12.)\n"
            "    AND  INPUT(b.LBSTRESN,?? BEST12.) > 2 * INPUT(b.LBORNRHI,?? BEST12.)\n"
            "    AND  ABS(INPUT(SUBSTR(a.LBDTC,1,10),?? YYMMDD10.)\n"
            "           - INPUT(SUBSTR(b.LBDTC,1,10),?? YYMMDD10.)) <= 30{ws};\n"
            "QUIT;"
        )},
    "LB009": {"domains":["LB","EX"],"desc":"LB pre-dose sample collected after first dose",
        "sql":(
            "PROC SQL;\n"
            "  /* LB009: Lab marked pre-dose but collected after first dose */\n"
            "  SELECT l.USUBJID, l.LBTESTCD, l.LBDTC, l.LBTPT,\n"
            "         MIN(e.EXSTDTC) AS FIRST_DOSE_DTC\n"
            "  FROM   SDTM.LB l INNER JOIN SDTM.EX e ON l.USUBJID = e.USUBJID\n"
            "  WHERE  UPCASE(l.LBTPT) CONTAINS \'PRE\'{ws}\n"
            "  GROUP BY l.USUBJID, l.LBTESTCD, l.LBDTC, l.LBTPT\n"
            "  HAVING SUBSTR(l.LBDTC,1,10) > SUBSTR(MIN(e.EXSTDTC),1,10);\n"
            "QUIT;"
        )},
    "DS008": {"domains":["DS","LB","DM"],"desc":"LB draw before informed consent",
        "sql":(
            "PROC SQL;\n"
            "  /* DS008: Lab draw before consent date */\n"
            "  SELECT l.USUBJID, l.LBTESTCD, l.LBDTC, d.RFICDTC AS CONSENT_DATE\n"
            "  FROM   SDTM.LB l INNER JOIN SDTM.DM d ON l.USUBJID = d.USUBJID\n"
            "  WHERE  SUBSTR(l.LBDTC,1,10) < SUBSTR(d.RFICDTC,1,10){ws};\n"
            "QUIT;"
        )},
}


def _sas_code(domain: str, check_id: str, usubjid: str, detail: str) -> str:
    """Generate PROC SQL to reproduce the finding.
    Cross-domain checks use multi-table JOIN templates; single-domain get filtered SELECT."""
    subj_clause = ""
    if usubjid and usubjid not in ("ALL", "N/A", "?", "GLOBAL"):
        safe = usubjid.replace("'", "''")
        subj_clause = f"\n    AND  USUBJID = '{safe}'"

    if check_id in _CROSS_DOMAIN_SQL:
        entry  = _CROSS_DOMAIN_SQL[check_id]
        sql    = entry["sql"].replace("{ws}", subj_clause)
        hdr    = (f"/* CIS {check_id}: {entry['desc']} */\n"
                  f"/* Domains: {', '.join(entry['domains'])} */\n")
        return hdr + sql

    dom = domain.split("/")[0].strip().upper() if domain else "DOMAIN"
    date_clause = ""
    dm2 = re.search(r"([A-Z]{2,8}DTC)\s*=\s*'?([\d\-T:]+)'?", detail)
    if dm2:
        dcol, dval = dm2.group(1), dm2.group(2)[:10]
        date_clause = f"\n    AND  {dcol} = '{dval}'"
    test_clause = ""
    tm2 = re.search(r"(LB|VS|EG)TESTCD\s*=\s*'([^']+)'", detail)
    if tm2:
        test_clause = f"\n    AND  {tm2.group(1)}TESTCD = '{tm2.group(2)}'"
    safe_detail = detail[:100].replace("/*", "/ *").replace("*/", "* /")
    return (f"/* CIS {check_id}: {safe_detail} */\n"
            f"PROC SQL;\n"
            f"  SELECT *\n"
            f"  FROM   SDTM.{dom}\n"
            f"  WHERE  1=1{subj_clause}{date_clause}{test_clause};\n"
            f"QUIT;")


# ---------------------------------------------------------------------------
# DEMO POOL
# ---------------------------------------------------------------------------
DEMO_POOL = [
    {"checkId":"DS006","subj":"001-007","domain":"VS","detail":"VS.SYSBP on 2024-09-14 - 3 days after DS death (DSSTDTC=2024-09-11)","root":"Missing DS death propagation"},
    {"checkId":"DS006","subj":"001-031","domain":"LB","detail":"LB.ALT on 2024-11-02 - 7 days after death (DSSTDTC=2024-10-26)","root":"Missing DS death propagation"},
    {"checkId":"AE005","subj":"001-007","domain":"AE","detail":"AE Pneumonia AESTDTC=2024-09-12 - 1 day after death 2024-09-11","root":"Missing DS death propagation"},
    {"checkId":"DS003","subj":"001-007","domain":"DS","detail":"DS contains 2 death dates: 2024-09-11 and 2024-09-13 (non-matching)","root":"Missing DS death propagation"},
    {"checkId":"DS008","subj":"001-004","domain":"LB","detail":"LB draw LBDTC=2024-01-10 precedes consent RFICDTC=2024-01-12 by 2 days","root":None},
    {"checkId":"DS008","subj":"002-003","domain":"VS","detail":"VS measurement 2024-02-08 before RFICDTC=2024-02-10","root":None},
    {"checkId":"DS007","subj":"001-019","domain":"LB","detail":"LB record 2024-08-05 is 8 days after DM.RFPENDTC=2024-07-28","root":None},
    {"checkId":"AE015","subj":"001-012","domain":"LB/AE","detail":"LB ALT Grade 4 (>10xULN) on 2024-06-15 - no AE within +/-7 days","root":"Possible under-reporting"},
    {"checkId":"AE015","subj":"001-028","domain":"LB/AE","detail":"LB POTASSIUM 8.1 mEq/L Grade 3 2024-09-03 - no corresponding AE","root":"Possible under-reporting"},
    {"checkId":"LB011","subj":"001-012","domain":"LB","detail":"ALT 480 U/L (>3xULN) + TBili 2.1xULN at Visit 6 - Hys Law signal","root":"Possible under-reporting"},
    {"checkId":"AE016","subj":"001-022","domain":"AE/CM","detail":"AE Hypertension AESEV=SEVERE (2024-04-18) - no anti-hypertensive in CM +/-14d","root":None},
    {"checkId":"VS001","subj":"002-003","domain":"VS","detail":"Visit 8 (2024-07-22): DIABP=92 > SYSBP=88 mmHg - impossible physiology","root":None},
    {"checkId":"VS001","subj":"001-041","domain":"VS","detail":"Screening 2024-02-05: DIABP=110 > SYSBP=105 mmHg","root":None},
    {"checkId":"VS003","subj":"002-016","domain":"VS","detail":"Weight 82 kg (Wk4) to 61 kg (Wk5) = 25.6 pct drop in 7 days","root":None},
    {"checkId":"VS004","subj":"002-027","domain":"VS","detail":"Height 178 cm (BL) to 162 cm (Month 6) = 16 cm decrease","root":None},
    {"checkId":"DS005","subj":"001-055","domain":"DS/EX","detail":"DSDECOD=Screen Failure but 2 EX dosing records exist (2024-01-14, 2024-01-21)","root":None},
    {"checkId":"BL001","subj":"002-008","domain":"LB","detail":"LB GLUC --BLFL=Y at 08:30; first dose at 07:00 same day - post-dose baseline","root":None},
    {"checkId":"TD006","subj":"001-033","domain":"SE","detail":"Screening SEENDTC=2024-03-15; Treatment SESTDTC=2024-03-17 - 1-day gap","root":None},
    {"checkId":"BL002","subj":"ALL","domain":"ALL","detail":"14 LB records LBTESTCD=POTASSM - not in CDISC CT; expected POTASSIUM","root":"Systematic CT error"},
    {"checkId":"AE012","subj":"001-044","domain":"AE","detail":"AETRTEM=Y but AE start 2024-10-30 is 59 days after last dose 2024-09-01","root":None},
    {"checkId":"DM001","subj":"002-017","domain":"DM","detail":"DM.ARMCD=PLACEBO but EXTRT=Drug A 100mg in 2 EX records","root":None},
    {"checkId":"SV003","subj":"001-038","domain":"ALL/TV","detail":"Visit 4 VISITDY=28; actual VSDY=35 - 7-day deviation exceeds +/-3d window","root":None},
    {"checkId":"CM005","subj":"001-033","domain":"CM","detail":"CM record shows Warfarin - excluded per protocol Section 5.3","root":None},
    {"checkId":"LB009","subj":"001-012","domain":"LB/EX","detail":"LB pre-dose LBDTM=2024-06-15T09:45 but EXSTDTC=2024-06-15T08:00 - post-infusion","root":None},
    {"checkId":"EG002","subj":"002-011","domain":"EG","detail":"QTcF=530 ms at Visit 4 - no cardiac AE within +/-3 days","root":None},
    {"checkId":"EG003","subj":"002-019","domain":"EG","detail":"QTcF increased from 390ms (BL) to 465ms (Wk4) = 75ms increase without TEAE","root":None},
    {"checkId":"PK003","subj":"ALL","domain":"PP","detail":"PP RELREC missing for 8 subjects - Cmax/AUC not traceable to PC concentrations","root":None},
    {"checkId":"QS003","subj":"002-015","domain":"QS","detail":"SF-36 Physical Score total=82 but sum of components=61 (21-pt discrepancy)","root":None},
    {"checkId":"ONC003","subj":"002-016","domain":"TU","detail":"TU new lesion 2024-07-10 but RS.RSORRES=PR (not PD) at same timepoint","root":None},
    {"checkId":"ONC005","subj":"003-001","domain":"TR","detail":"RECIST sum of diameters=68mm but sum of TRSTRESN values=52mm","root":None},
    {"checkId":"TD001","subj":"ALL","domain":"TS","detail":"TS missing TSPARMCD=PCLAS (Pharmacological Class) - FDA Desired parameter absent","root":None},
    {"checkId":"TD002","subj":"ALL","domain":"TS","detail":"TS TSPARMCD=DOSE TSVAL=100 mg - unit in DOSE field (should be DOSU record)","root":None},
    {"checkId":"DM008","subj":"003-006","domain":"DM","detail":"SDTM AGE=16 (AGEU=YEARS) in adult Phase III trial - possible paediatric patient","root":None},
    {"checkId":"IE002","subj":"001-009","domain":"IE","detail":"IE exclusion criterion 3 failure but DSDECOD=ENROLLED for same subject","root":None},
    {"checkId":"S008","subj":"ALL","domain":"ALL","detail":"LBTESTCD=SODIUM maps to Sodium Serum and Serum Sodium - 1:1 violation","root":"Systematic CT error"},
    {"checkId":"LB012","subj":"003-012","domain":"LB","detail":"LBTESTCD=ALT LBDTC=2024-05-10 appears 3 times - possible double entry","root":None},
    {"checkId":"VS005","subj":"002-033","domain":"VS","detail":"VSTESTCD=PULSE VSSTRESN=8 BPM at Visit 3 - physiologically implausible","root":None},
    {"checkId":"EX007","subj":"001-018","domain":"EX","detail":"Subject received 2400mg cumulative vs. protocol maximum of 1800mg","root":None},
    {"checkId":"PK004","subj":"003-004","domain":"PP","detail":"PPTESTCD=CMAX=0.2 ng/mL but all PC concentrations > 15 ng/mL","root":None},
    {"checkId":"DV001","subj":"001-025","domain":"DV","detail":"DVTERM=Protocol deviation - unblinding but no DS discontinuation record","root":None},
    # v7 demo entries
    {"checkId":"INT001","subj":"ALL","domain":"LB/DM","detail":"USUBJID 003-099 found in LB (8 records) but absent from DM - orphan subject","root":"Missing DM record"},
    {"checkId":"INT001","subj":"ALL","domain":"AE/DM","detail":"USUBJID 003-100 found in AE (3 records) but absent from DM - orphan subject","root":"Missing DM record"},
    {"checkId":"INT002","subj":"002-008","domain":"LB","detail":"LB GLUC BLFL=Y at 2024-05-10 but DM RFSTDTC=2024-05-08 (2 days post-dose)","root":"Baseline flag error"},
    {"checkId":"INT002","subj":"002-014","domain":"VS","detail":"VS WEIGHT BLFL=Y at 2024-06-12 but DM RFSTDTC=2024-06-10 (post-dose baseline)","root":"Baseline flag error"},
    {"checkId":"INT003","subj":"001-044","domain":"DS","detail":"Subject has 6 EX records and 12 LB records but no DS DISPOSITION EVENT record","root":None},
    {"checkId":"INT003","subj":"002-031","domain":"DS","detail":"Subject has 3 AE records but no End of Study disposition in DS domain","root":None},
    {"checkId":"INT004","subj":"003-007","domain":"LB/DM","detail":"DM.SEX=M but LB contains LBTESTCD=PREG result (2024-07-15) - gender mismatch","root":None},
    {"checkId":"INT005","subj":"001-019","domain":"LB/DM","detail":"LB draw LBDTC=2024-01-09 is 3 days before RFICDTC=2024-01-12 (consent date)","root":"Pre-consent assessment"},
    {"checkId":"INT005","subj":"002-005","domain":"VS/DM","detail":"VS SYSBP measurement 2024-02-07 is 5 days before RFICDTC=2024-02-12","root":"Pre-consent assessment"},
    {"checkId":"DATE001","subj":"001-033","domain":"AE","detail":"AE AESTDTC=2024-08-20 > AEENDTC=2024-08-15 (start after end) - 5-day reversal","root":None},
    {"checkId":"DATE001","subj":"002-018","domain":"CM","detail":"CM CMSTDTC=2024-09-01 > CMENDTC=2024-08-25 (start after end)","root":None},
    {"checkId":"DATE002","subj":"001-007","domain":"EG","detail":"EG record EGDTC=2024-09-15 found after death date 2024-09-11 (4 days post-mortem)","root":"Post-mortem clinical activity"},
    {"checkId":"DATE002","subj":"001-007","domain":"CM","detail":"CM dosing record CMSTDTC=2024-09-13 found 2 days after death DSSTDTC=2024-09-11","root":"Post-mortem clinical activity"},
    {"checkId":"DATE003","subj":"002-055","domain":"LB","detail":"LB LBDTC=2026-08-20 is 8 months in the future relative to data snapshot date","root":None},
    {"checkId":"DATE003","subj":"003-011","domain":"AE","detail":"AE AESTDTC=2027-01-01 is 1+ year in future - likely data entry error","root":None},
    {"checkId":"DATE004","subj":"003-004","domain":"DM","detail":"BRTHDTC=2024-03-15 is after RFSTDTC=2024-01-10 - subject born after study start","root":None},
    {"checkId":"DATE005","subj":"001-002","domain":"EX/DM","detail":"EXSTDTC=2024-01-08 is 4 days before RFICDTC=2024-01-12 - dosed before consent","root":"GCP violation"},
    {"checkId":"DATE005","subj":"002-007","domain":"EX/DM","detail":"EXSTDTC=2024-02-05 is 2 days before RFICDTC=2024-02-07 - dosed before consent","root":"GCP violation"},
    {"checkId":"DATE006","subj":"001-021","domain":"EX/DS","detail":"EX EXENDTC=2024-06-18; DS DSSTDTC=2024-06-15 (discontinued 3 days prior)","root":None},
]

_DEMO_MAP: dict = {}
for _e in DEMO_POOL:
    _DEMO_MAP.setdefault(_e["checkId"], []).append(_e)


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def _to_df(rows: list) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    for col in df.columns:
        df[col] = df[col].fillna("").astype(str).str.strip()
    return df

def _col(df: pd.DataFrame, name: str) -> pd.Series:
    if name in df.columns:
        return df[name]
    return pd.Series([""] * len(df), index=df.index)

def _date_str(s: str) -> str:
    """Return first 10 chars (YYYY-MM-DD) of a datetime string, or ''."""
    return s[:10] if s and len(s) >= 10 else ""

def _today() -> str:
    return datetime.date.today().isoformat()   # YYYY-MM-DD


# ---------------------------------------------------------------------------
# PRE-BUILT LOOKUP INDEXES  (built once, shared across all checks)
# ---------------------------------------------------------------------------
def _build_lookups(dd: dict) -> dict:
    """Build vectorised lookup Series from DM and DS.
    All are pd.Series indexed by USUBJID for O(1) lookups.
    """
    lkp = {}
    dm = dd.get("DM", pd.DataFrame())
    ds = dd.get("DS", pd.DataFrame())

    if not dm.empty and "USUBJID" in dm.columns:
        dm2 = dm.drop_duplicates("USUBJID").set_index("USUBJID")
        for col in ["RFICDTC","RFSTDTC","RFENDTC","DTHDTC","SEX","ARM","ACTARM",
                    "AGE","AGEU","BRTHDTC","RFPENDTC","DTHFL"]:
            if col in dm2.columns:
                lkp[f"dm_{col.lower()}"] = dm2[col].str[:10] if col.endswith("DTC") else dm2[col]
        lkp["dm_subjs"] = set(dm2.index) - {"","ALL"}

    if not ds.empty and "USUBJID" in ds.columns and "DSDECOD" in ds.columns:
        death_mask = _col(ds,"DSDECOD").str.upper().isin(["DEATH","DIED","DEAD"])
        death_rows = ds[death_mask].copy()
        if not death_rows.empty and "DSSTDTC" in death_rows.columns:
            death_rows["_d"] = death_rows["DSSTDTC"].str[:10]
            lkp["death_dates"] = (death_rows.sort_values("_d")
                                  .drop_duplicates("USUBJID",keep="first")
                                  .set_index("USUBJID")["_d"])
        disp_mask = _col(ds,"DSCAT").str.upper().isin(
            ["DISPOSITION EVENT","DISPOSITION","COMPLETION"])
        disp_rows = ds[disp_mask].copy()
        if not disp_rows.empty and "DSSTDTC" in disp_rows.columns:
            disp_rows["_d"] = disp_rows["DSSTDTC"].str[:10]
            lkp["disp_dates"] = (disp_rows.sort_values("_d")
                                 .drop_duplicates("USUBJID",keep="first")
                                 .set_index("USUBJID")["_d"])
    return lkp


# ---------------------------------------------------------------------------
# VALIDATION ENGINE
# ---------------------------------------------------------------------------
class ValidationEngine:

    def __init__(self, files_meta: dict, enabled_ids: set):
        self.files_meta  = files_meta
        self.enabled_ids = set(enabled_ids)
        self._seq        = 0

    # ---------------------------------------------------------------- run
    def run(self, progress_cb=None) -> list:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        checks  = [c for c in get_checks() if c["id"] in self.enabled_ids]
        total   = max(len(checks), 1)

        dd_rows = self._map_domains()
        dd_df   = {dom: _to_df(rows) for dom, rows in dd_rows.items()}
        dep_w   = self._dependency_warnings(dd_rows)
        # Store loaded domains for per-finding confidence calculation
        self._loaded_doms = set(dd_df.keys())
        # Expose SUPP merge log so UI can display merge summary
        self.supp_merge_log = getattr(self, "_supp_merge_log", [])

        # Pre-build shared lookup indexes ONCE - reused by all checks
        self._lkp = _build_lookups(dd_df)

        # Separate dep-warned checks from runnable checks
        runnable = [c for c in checks if c["id"] not in dep_w]
        dep_list = [dep_w[c["id"]] for c in checks if c["id"] in dep_w]

        # Progress: report every ~5% or every 10 checks, not every check
        _prog_interval = max(1, total // 20)
        if progress_cb:
            progress_cb(2, f"Loaded {len(dd_df)} domains, running {len(runnable)} checks...")

        # Use ThreadPoolExecutor - safe for pandas (read-only DataFrames)
        # Each check gets its own _seq namespace to avoid race on self._seq
        workers = min(8, len(runnable)) if runnable else 1
        findings_by_check = {}

        def _run_one(check, idx):
            result = []
            result.extend(self._run_actual(check, dd_df))
            result.extend(self._run_demo(check, dd_rows))
            return idx, check["id"], result

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(_run_one, c, i): i
                       for i, c in enumerate(runnable)}
            done_count = 0
            for fut in as_completed(futures):
                idx, cid, result = fut.result()
                findings_by_check[idx] = result
                done_count += 1
                if progress_cb and done_count % _prog_interval == 0:
                    pct = int(done_count / max(len(runnable), 1) * 94) + 2
                    progress_cb(pct, f"{done_count}/{len(runnable)} checks done...")

        # Reassemble in original order, assign fingerprint fids
        findings: list = list(dep_list)
        seen_fids: set = set()
        for idx in range(len(runnable)):
            for f in findings_by_check.get(idx, []):
                self._seq += 1
                # Ensure fid is set (actual findings already have it from _new;
                # demo findings get a sequential id here)
                if not f.get("fid"):
                    f["fid"] = f"F{self._seq:04d}"
                fid = f["fid"]
                # De-duplicate: skip if an identical fingerprint already added this run
                if fid in seen_fids:
                    continue
                seen_fids.add(fid)
                findings.append(f)

        if progress_cb:
            actual_n = sum(1 for f in findings if f.get("actual"))
            progress_cb(100, f"Complete - {len(findings)} findings ({actual_n} actual)")
        return findings

    # ---------------------------------------- SUG-004 dependency warnings
    def _dependency_warnings(self, dd_rows: dict) -> dict:
        warnings = {}
        loaded   = set(dd_rows.keys())
        for check in get_checks():
            if check["id"] not in self.enabled_ids:
                continue
            required = CHECK_REQUIRES.get(check["id"])
            if required is None or not required:
                continue
            if all(d not in loaded for d in required):
                self._seq += 1
                warnings[check["id"]] = {
                    "fid":         f"W{self._seq:04d}",
                    "checkId":     check["id"],
                    "label":       check["label"],
                    "layer":       check["layer"],
                    "cat":         check["cat"],
                    "domain":      check["domain"],
                    "sev":         "NOTICE",
                    "risk":        "advisory",
                    "source":      "Dependency Pre-Check (SUG-004)",
                    "subj":        "N/A",
                    "detail":      (
                        f"Skipped: required domain(s) {required} not loaded. "
                        f"Upload {', '.join(required)} to enable this check."
                    ),
                    "root":        None,
                    "actual":      False,
                    "waived":      False,
                    "waiver_note": "",
                    "ts":          datetime.datetime.now().isoformat(),
                    "dep_warning": True,
                }
        return warnings

    # ---------------------------------------------- domain mapping
    def _map_domains(self) -> dict:
        DOM_CODES = [
            "AE","CM","DM","DS","EG","EX","LB","MH","PR","QS",
            "TR","TU","RS","SE","SV","SS","VS","TS","TA","TE",
            "TV","TI","IE","PC","PP","DV","FA","SU","SC","DD",
        ]
        DOM_CODES_SORTED = sorted(DOM_CODES, key=len, reverse=True)
        SUPP_PREFIX = "SUPP"

        def _match_domain(base: str):
            if base.startswith(SUPP_PREFIX) and len(base) > len(SUPP_PREFIX):
                return None  # handled separately as SUPP
            if base in DOM_CODES:
                return base
            for dom in DOM_CODES_SORTED:
                if base.startswith(dom + "_"):
                    return dom
            for dom in DOM_CODES_SORTED:
                if base.endswith("_" + dom):
                    return dom
            for dom in DOM_CODES_SORTED:
                if base.endswith(dom) and len(base) > len(dom):
                    return dom
            import re as _re
            for dom in DOM_CODES_SORTED:
                if _re.search(r'(^|[^A-Z])' + dom + r'([^A-Z]|$)', base):
                    return dom
            return None

        def _is_supp(base: str) -> bool:
            return base.startswith(SUPP_PREFIX) and len(base) > len(SUPP_PREFIX)

        def _supp_parent(base: str) -> str:
            """Extract parent domain from SUPP filename: SUPPAE -> AE, SUPPDM -> DM."""
            candidate = base[len(SUPP_PREFIX):]  # strip leading SUPP
            for dom in DOM_CODES_SORTED:
                if candidate.startswith(dom):
                    return dom
            return candidate[:2] if len(candidate) >= 2 else ""

        # ── Pass 1: collect parent domain rows + raw SUPP rows ──────────────
        result: dict = {}          # dom -> list[dict]  (parent domain rows)
        supp_raw: dict = {}        # parent_dom -> list[dict]  (raw SUPP rows)
        assigned: dict = {}

        for fname, meta in self.files_meta.items():
            data = meta.get("data", [])
            if not data:
                continue
            base = fname.upper()
            for ext in [".XPT",".SAS7BDAT",".CSV",".XLSX",".XLS",".JSON"]:
                base = base.replace(ext, "")
            base = base.split("/")[-1].split("\\")[-1].strip()

            if _is_supp(base):
                # Determine parent from filename first, then RDOMAIN column
                parent = _supp_parent(base)
                if not parent and data and isinstance(data[0], dict):
                    parent = str(data[0].get("RDOMAIN","")).strip().upper()
                if parent and parent in DOM_CODES:
                    supp_raw.setdefault(parent, []).extend(data)
                    assigned[fname] = f"SUPP_{parent}"
                continue

            dom = _match_domain(base)
            if dom:
                result.setdefault(dom, []).extend(data)
                assigned[fname] = dom
                continue

            # Fallback: use DOMAIN column value
            if fname not in assigned and data and isinstance(data[0], dict):
                dv = str(data[0].get("DOMAIN","")).strip().upper()
                if dv in DOM_CODES:
                    result.setdefault(dv, []).extend(data)
                    assigned[fname] = dv

        # ── Pass 2: back-merge SUPP into parent domain rows ─────────────────
        # SDTMIG SUPP structure:
        #   STUDYID, RDOMAIN, USUBJID, IDVAR, IDVARVAL, QNAM, QLABEL, QVAL, QORIG, QEVAL
        # Join key: parent record where IDVAR column == IDVARVAL value
        # e.g. IDVAR="AESEQ", IDVARVAL="3" -> join onto AE row where AESEQ=="3"
        self._supp_merge_log: list = []   # expose for S016/S017/S018 checks

        for parent_dom, supp_rows in supp_raw.items():
            if not supp_rows:
                continue

            parent_rows = result.get(parent_dom, [])

            # Build enriched parent rows dict keyed by (USUBJID, IDVAR_value)
            # Strategy: pivot SUPP to wide (one col per QNAM) then left-join to parent
            supp_df  = _to_df(supp_rows)
            required = {"USUBJID","IDVAR","IDVARVAL","QNAM","QVAL"}
            missing  = required - set(supp_df.columns)
            if missing:
                self._supp_merge_log.append({
                    "domain": parent_dom,
                    "issue":  f"SUPP missing columns: {missing}",
                    "rows":   len(supp_rows),
                })
                continue

            # ── S017 check: RDOMAIN must match parent_dom ───────────────────
            if "RDOMAIN" in supp_df.columns:
                bad_rdomain = supp_df[
                    _col(supp_df,"RDOMAIN").str.upper().str.strip() != parent_dom
                ]
                if not bad_rdomain.empty:
                    self._supp_merge_log.append({
                        "domain": parent_dom,
                        "issue":  f"S017: {len(bad_rdomain)} rows have RDOMAIN != {parent_dom}",
                        "rows":   len(bad_rdomain),
                        "check":  "S017",
                    })

            # ── S016 check: QNAM must not collide with reserved SDTM vars ───
            RESERVED = {
                "STUDYID","DOMAIN","USUBJID","SUBJID","SITEID","INVID","INVNAM",
                "BRTHDTC","AGE","AGEU","SEX","RACE","ETHNIC","ARMCD","ARM",
                "ACTARMCD","ACTARM","COUNTRY","DMDTC","DMDY",
            }
            bad_qnam = _col(supp_df,"QNAM").str.upper().isin(RESERVED)
            if bad_qnam.any():
                bad_vals = list(_col(supp_df[bad_qnam],"QNAM").unique()[:5])
                self._supp_merge_log.append({
                    "domain": parent_dom,
                    "issue":  f"S016: Reserved QNAM(s) used: {bad_vals}",
                    "check":  "S016",
                })

            # ── Pivot SUPP wide ─────────────────────────────────────────────
            # Handle duplicate QNAM per (USUBJID, IDVARVAL) by taking first value
            try:
                supp_wide = (
                    supp_df
                    .assign(
                        _uid  = _col(supp_df,"USUBJID").str.strip(),
                        _idv  = _col(supp_df,"IDVAR").str.strip().str.upper(),
                        _idvv = _col(supp_df,"IDVARVAL").str.strip(),
                        _qnam = _col(supp_df,"QNAM").str.strip().str.upper(),
                        _qval = _col(supp_df,"QVAL").fillna(""),
                    )
                    .pivot_table(
                        index=["_uid","_idv","_idvv"],
                        columns="_qnam",
                        values="_qval",
                        aggfunc="first",
                    )
                    .reset_index()
                )
                supp_wide.columns.name = None
            except Exception as e:
                self._supp_merge_log.append({
                    "domain": parent_dom,
                    "issue":  f"SUPP pivot failed: {e}",
                })
                continue

            if not parent_rows:
                # No parent rows loaded — store SUPP wide standalone
                # so at minimum SUPP-only checks can run
                result[f"SUPP_{parent_dom}"] = supp_rows
                continue

            parent_df = _to_df(parent_rows)

            # ── S018 check: IDVARVAL must resolve to an existing parent record ──
            if "IDVAR" in supp_df.columns and "IDVARVAL" in supp_df.columns:
                for idvar_val, grp in supp_df.groupby(_col(supp_df,"IDVAR").str.upper()):
                    if not idvar_val or idvar_val not in parent_df.columns:
                        continue
                    parent_vals = set(_col(parent_df, idvar_val).astype(str).str.strip())
                    orphan_idvarvals = set(
                        grp[~_col(grp,"IDVARVAL").str.strip().isin(parent_vals)]["IDVARVAL"]
                    )
                    if orphan_idvarvals:
                        self._supp_merge_log.append({
                            "domain": parent_dom,
                            "issue":  f"S018: {len(orphan_idvarvals)} IDVARVAL(s) not in parent {idvar_val}: {list(orphan_idvarvals)[:3]}",
                            "check":  "S018",
                        })

            # ── Join wide SUPP onto parent rows ─────────────────────────────
            # Determine the IDVAR column name used in parent (e.g. AESEQ for AE)
            # supp_wide has _uid, _idv, _idvv columns; join by USUBJID + seq value
            try:
                # Most common IDVAR = --SEQ (e.g. AESEQ)
                # Build a helper: for each row in parent, get its seq value and join
                seq_col = f"{parent_dom}SEQ"

                if seq_col in parent_df.columns:
                    parent_df["_uid"]  = _col(parent_df,"USUBJID").str.strip()
                    parent_df["_idvv"] = _col(parent_df, seq_col).str.strip()
                    merge_key = ["_uid","_idvv"]
                    supp_join = supp_wide[supp_wide["_idv"] == seq_col][
                        [c for c in supp_wide.columns if c not in ("_idv",)]
                    ].copy()
                    if not supp_join.empty:
                        merged = parent_df.merge(supp_join, on=merge_key, how="left")
                        # Drop helper cols
                        merged = merged.drop(columns=["_uid","_idvv"], errors="ignore")
                        result[parent_dom] = merged.to_dict("records")
                    else:
                        result[parent_dom] = parent_rows
                else:
                    # No --SEQ column: join on USUBJID only (less precise but better than nothing)
                    supp_by_subj = (
                        supp_df
                        .assign(_uid=_col(supp_df,"USUBJID").str.strip(),
                                _qnam=_col(supp_df,"QNAM").str.upper())
                        .pivot_table(index="_uid", columns="_qnam",
                                     values="QVAL", aggfunc="first")
                        .reset_index()
                    )
                    supp_by_subj.columns.name = None
                    parent_df["_uid"] = _col(parent_df,"USUBJID").str.strip()
                    merged = parent_df.merge(supp_by_subj, on="_uid", how="left")
                    merged = merged.drop(columns=["_uid"], errors="ignore")
                    result[parent_dom] = merged.to_dict("records")

            except Exception as e:
                self._supp_merge_log.append({
                    "domain": parent_dom,
                    "issue":  f"SUPP join failed: {e}",
                })
                result[parent_dom] = parent_rows  # fall back to unmerged

        return result

    # ---------------------------------------------- finding factory
    def _new(self, check: dict, subj: str, detail: str,
             root=None, actual: bool = True, confidence: str = "High") -> dict:
        from modules.registry import get_outcome_class, CLINICAL_NOTES
        self._seq += 1
        fid = _fingerprint(check.get("domain","ALL"), check["id"], subj, detail)
        cid = check["id"]
        # Confidence degrades when required domains are missing
        loaded_doms = set(getattr(self, "_loaded_doms", []))
        missing_deps = []
        from modules.registry import CHECK_REQUIRES
        required = CHECK_REQUIRES.get(cid, [])
        if required:
            missing_deps = [d for d in required if d not in loaded_doms]
            if missing_deps:
                confidence = "Low" if len(missing_deps) >= len(required) else "Medium"
        return {
            "fid":           fid,
            "checkId":       cid,
            "label":         check["label"],
            "layer":         check["layer"],
            "cat":           check["cat"],
            "domain":        check["domain"],
            "sev":           check["sev"],
            "risk":          check["risk"],
            "source":        check["source"],
            "subj":          subj,
            "detail":        detail,
            "root":          root,
            "actual":        actual,
            "waived":        False,
            "waiver_note":   "",
            "ts":            datetime.datetime.now().isoformat(),
            "sas_code":      _sas_code(check.get("domain","ALL"), cid, subj, detail),
            "outcome_class": get_outcome_class(cid),
            "clinical_note": CLINICAL_NOTES.get(cid, ""),
            "confidence":    confidence,
            "missing_deps":  missing_deps,
        }

    # ---------------------------------------------- dispatcher
    def _run_actual(self, check: dict, dd: dict) -> list:
        cid = check["id"]
        out: list = []
        try:
            # original v6 checks
            if   cid == "DM001":  out = self._chk_DM001(check, dd)
            elif cid == "DM003":  out = self._chk_DM003(check, dd)
            elif cid == "DM004":  out = self._chk_DM004(check, dd)
            elif cid == "DM007":  out = self._chk_DM007(check, dd)
            elif cid == "DM008":  out = self._chk_DM008(check, dd)
            elif cid == "AE001":  out = self._chk_AE001(check, dd)
            elif cid == "AE004":  out = self._chk_AE004(check, dd)
            elif cid == "AE006":  out = self._chk_AE006(check, dd)
            elif cid == "AE008":  out = self._chk_AE008(check, dd)
            elif cid == "EX001":  out = self._chk_EX001(check, dd)
            elif cid == "EX002":  out = self._chk_EX002(check, dd)
            elif cid == "EX003":  out = self._chk_EX003(check, dd)
            elif cid == "LB003":  out = self._chk_LB003(check, dd)
            elif cid == "LB004":  out = self._chk_LB004(check, dd)
            elif cid == "LB007":  out = self._chk_LB007(check, dd)
            elif cid == "LB011":  out = self._chk_LB011(check, dd)
            elif cid == "LB012":  out = self._chk_LB012(check, dd)
            elif cid == "VS001":  out = self._chk_VS001(check, dd)
            elif cid == "VS005":  out = self._chk_VS005(check, dd)
            elif cid == "VS007":  out = self._chk_VS007(check, dd)
            elif cid == "CM001":  out = self._chk_CM001(check, dd)
            elif cid == "CM003":  out = self._chk_CM003(check, dd)
            elif cid == "CM004":  out = self._chk_CM004(check, dd)
            elif cid == "S010":   out = self._chk_S010(check, dd)
            # v7 new checks
            elif cid == "INT001": out = self._chk_INT001(check, dd)
            elif cid == "INT002": out = self._chk_INT002(check, dd)
            elif cid == "INT003": out = self._chk_INT003(check, dd)
            elif cid == "INT004": out = self._chk_INT004(check, dd)
            elif cid == "INT005": out = self._chk_INT005(check, dd)
            elif cid == "DATE001":out = self._chk_DATE001(check, dd)
            elif cid == "DATE002":out = self._chk_DATE002(check, dd)
            elif cid == "DATE003":out = self._chk_DATE003(check, dd)
            elif cid == "DATE004":out = self._chk_DATE004(check, dd)
            elif cid == "DATE005":out = self._chk_DATE005(check, dd)
            elif cid == "DATE006":out = self._chk_DATE006(check, dd)
            elif cid == "DATE007":out = self._chk_DATE007(check, dd)
            # SUPP structural checks (v14)
            elif cid == "S016":   out = self._chk_S016(check, dd)
            elif cid == "S017":   out = self._chk_S017(check, dd)
            elif cid == "S018":   out = self._chk_S018(check, dd)
            elif cid == "AE014":  out = self._chk_AE014(check, dd)
            # v17 GCP cross-domain
            elif cid == "GCP001": out = self._chk_GCP001(check, dd)
            elif cid == "GCP002": out = self._chk_GCP002(check, dd)
            elif cid == "GCP003": out = self._chk_GCP003(check, dd)
            elif cid == "GCP004": out = self._chk_GCP004(check, dd)
            elif cid == "GCP005": out = self._chk_GCP005(check, dd)
            # v17 Medical signals
            elif cid == "MED001": out = self._chk_MED001(check, dd)
            elif cid == "MED002": out = self._chk_MED002(check, dd)
            elif cid == "MED003": out = self._chk_MED003(check, dd)
            elif cid == "MED004": out = self._chk_MED004(check, dd)
            # v17 Data integrity
            elif cid == "DAT008": out = self._chk_DAT008(check, dd)
            elif cid == "DAT009": out = self._chk_DAT009(check, dd)
            # v17 Oncology
            elif cid == "ONC006": out = self._chk_ONC006(check, dd)
            elif cid == "ONC007": out = self._chk_ONC007(check, dd)
            # v17 Questionnaire
            elif cid == "QS001":  out = self._chk_QS001(check, dd)
            elif cid == "QS002":  out = self._chk_QS002(check, dd)
            elif cid == "QS003":  out = self._chk_QS003(check, dd)
            elif cid == "QS004":  out = self._chk_QS004(check, dd)
            # v17 Analysis / Metadata
            elif cid == "ANL001": out = self._chk_ANL001(check, dd)
            elif cid == "ANL002": out = self._chk_ANL002(check, dd)
            elif cid == "ANL003": out = self._chk_ANL003(check, dd)
            elif cid == "META001":out = self._chk_META001(check, dd)
            elif cid == "META002":out = self._chk_META002(check, dd)
            elif cid == "META003":out = self._chk_META003(check, dd)
        except Exception:
            pass
        return out

    # ==================================================================
    # EXISTING CHECKS (v6, unchanged)
    # ==================================================================
    def _chk_DM001(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty: return []
        arm, act = _col(df,"ARM"), _col(df,"ACTARM")
        mask = (arm != "") & (act != "") & (arm != act) & ~arm.str.upper().str.contains("SCRNFAIL", na=False)
        return [self._new(c, r["USUBJID"], f"ARM='{r['ARM']}' vs ACTARM='{r['ACTARM']}'")
                for _, r in df[mask].iterrows()]

    def _chk_DM003(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty: return []
        fl, dtc = _col(df,"DTHFL").str.upper(), _col(df,"DTHDTC")
        out = ([self._new(c, r["USUBJID"], "DTHFL=Y but DTHDTC missing")
                for _, r in df[(fl == "Y") & (dtc == "")].iterrows()] +
               [self._new(c, r["USUBJID"], f"DTHDTC='{r['DTHDTC']}' present but DTHFL != Y")
                for _, r in df[(dtc != "") & (fl != "Y")].iterrows()])
        return out

    def _chk_DM004(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "USUBJID" not in df.columns: return []
        dupes = df[df.duplicated("USUBJID", keep=False)]["USUBJID"].unique()
        return [self._new(c, s, f"Duplicate USUBJID='{s}' in DM") for s in dupes]

    def _chk_DM007(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "AGE" not in df.columns: return []
        age  = pd.to_numeric(df["AGE"], errors="coerce")
        mask = (age < 0) | (age > 120)
        return [self._new(c, r["USUBJID"], f"AGE={r['AGE']} is implausible (must be 0-120)")
                for _, r in df[mask.fillna(False)].iterrows()]

    def _chk_DM008(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "AGE" not in df.columns: return []
        age  = pd.to_numeric(df["AGE"], errors="coerce")
        unit = _col(df,"AGEU").str.upper()
        mask = (age < 18) & (unit == "YEARS")
        return [self._new(c, r["USUBJID"], f"AGE={r['AGE']} AGEU=YEARS in adult trial")
                for _, r in df[mask.fillna(False)].iterrows()]

    def _chk_AE001(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        mask = _col(df,"AEDECOD") == ""
        return [self._new(c, r["USUBJID"], f"AEDECOD missing for AETERM='{r.get('AETERM','?')}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE004(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        st = _col(df,"AESTDTC").str[:10]
        en = _col(df,"AEENDTC").str[:10]
        mask = (st != "") & (en != "") & (st.str.len() >= 10) & (en.str.len() >= 10) & (st > en)
        return [self._new(c, r["USUBJID"], f"AESTDTC='{r['AESTDTC']}' after AEENDTC='{r['AEENDTC']}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE006(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"AESEV") == "") & (_col(df,"AETOXGR") == "")
        return [self._new(c, r["USUBJID"], f"Both AESEV and AETOXGR missing for AETERM='{r.get('AETERM','?')}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE008(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        key = [k for k in ["USUBJID","AEDECOD","AESTDTC"] if k in df.columns]
        if not key: return []
        sub = df[_col(df,"AEDECOD") != ""] if "AEDECOD" in df.columns else df
        if sub.empty: return []
        counts = sub.groupby(key, sort=False).size().reset_index(name="_n")
        dupes  = counts[counts["_n"] > 1]
        out = []
        for _, r in dupes.iterrows():
            subj = r.get("USUBJID","?")
            out.append(self._new(c, subj,
                f"Duplicate AE: AEDECOD='{r.get('AEDECOD','')}' "
                f"AESTDTC='{r.get('AESTDTC','')}' appears {int(r['_n'])} times"))
        return out

    def _chk_EX001(self, c, dd):
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        key   = [k for k in ["USUBJID","EXTRT","EXSTDTC","EXDOSE"] if k in df.columns]
        if not key: return []
        sub   = df[df["EXTRT"] != ""] if "EXTRT" in df.columns else df
        dupes = sub[sub.duplicated(key, keep=False)]
        seen, out = set(), []
        for _, r in dupes.iterrows():
            k = (r.get("USUBJID",""), r.get("EXTRT",""), r.get("EXSTDTC",""))
            if k not in seen:
                seen.add(k)
                out.append(self._new(c, r["USUBJID"],
                    f"Duplicate EX: EXTRT='{r.get('EXTRT','')}' EXSTDTC='{r.get('EXSTDTC','')}' EXDOSE='{r.get('EXDOSE','')}'"))
        return out

    def _chk_EX002(self, c, dd):
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"EXOCCUR").str.upper() == "Y") & (_col(df,"EXDOSE") == "")
        return [self._new(c, r["USUBJID"], f"EXOCCUR=Y but EXDOSE missing for EXTRT='{r.get('EXTRT','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_EX003(self, c, dd):
        """EXOCCUR explicitly N/NO but dose > 0   contradictory record.
        Blank EXOCCUR is skipped (field often unpopulated in interim data)."""
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        occur = _col(df,"EXOCCUR").str.strip().str.upper()
        dose  = pd.to_numeric(_col(df,"EXDOSE"), errors="coerce").fillna(0)
        # Only flag when EXOCCUR is explicitly a non-Y value (N, NO, MISSED, etc.)
        # NOT when it is blank or missing
        mask  = (occur.isin(["N","NO","NOT DONE","MISSED","SKIPPED"])) & (dose > 0)
        return [self._new(c, r["USUBJID"], f"EXOCCUR='{r.get('EXOCCUR','')}' but EXDOSE={r.get('EXDOSE','')}>0")
                for _, r in df[mask].iterrows()]

    def _chk_LB003(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"LBSTRESN") != "") & (_col(df,"LBORNRLO") == "") & (_col(df,"LBORNRHI") == "")
        hits = df[mask]
        if hits.empty: return []
        # Deduplicate: one finding per (USUBJID, LBTESTCD) pair to avoid row-level explosion
        key_cols = [k for k in ["USUBJID","LBTESTCD"] if k in hits.columns]
        seen: set = set()
        out = []
        for _, r in hits.iterrows():
            key = tuple(r.get(k,"") for k in key_cols)
            if key not in seen:
                seen.add(key)
                out.append(self._new(c, r["USUBJID"],
                    f"LBTESTCD='{r.get('LBTESTCD','')}' LBSTRESN={r.get('LBSTRESN','')} but ref range missing"))
        return out

    def _chk_LB004(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        orres  = _col(df,"LBORRES")
        starts = orres.str.startswith(">") | orres.str.startswith("<")
        mask   = starts & (_col(df,"LBSTRESN") == "") & (orres != "")
        return [self._new(c, r["USUBJID"], f"LBORRES='{r.get('LBORRES','')}' starts with >/< but LBSTRESN missing")
                for _, r in df[mask].iterrows()]

    def _chk_LB007(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        dtc  = _col(df,"LBDTC")
        out  = []
        for _, r in df[dtc.str.match(r"^\d{4}$") & (dtc != "")].iterrows():
            out.append(self._new(c, r["USUBJID"], f"LBDTC='{r['LBDTC']}' - year only, missing month and day"))
        for _, r in df[dtc.str.match(r"^\d{4}-\d{2}$") & (dtc != "")].iterrows():
            out.append(self._new(c, r["USUBJID"], f"LBDTC='{r['LBDTC']}' - missing day component"))
        return out

    def _chk_LB011(self, c, dd):
        """Hys Law: ALT>3xULN AND TBili>2xULN in same subject within 30-day window."""
        df = dd.get("LB", pd.DataFrame())
        if df.empty or "LBTESTCD" not in df.columns: return []
        alt  = df[_col(df,"LBTESTCD").isin(["ALT","ALAT"])].copy()
        bili = df[_col(df,"LBTESTCD").isin(["BILI","TBILI","BILIRUBIN"])].copy()
        if alt.empty or bili.empty: return []
        an = pd.to_numeric(_col(alt,"LBSTRESN"),errors="coerce")
        ah = pd.to_numeric(_col(alt,"LBORNRHI"),errors="coerce")
        bn = pd.to_numeric(_col(bili,"LBSTRESN"),errors="coerce")
        bh = pd.to_numeric(_col(bili,"LBORNRHI"),errors="coerce")
        alt_elevated  = alt[(an>0)&(ah>0)&(an>3*ah)].copy()
        bili_elevated = bili[(bn>0)&(bh>0)&(bn>2*bh)].copy()
        if alt_elevated.empty or bili_elevated.empty: return []

        # Require temporal co-occurrence: both elevations within 30 days of each other
        alt_elevated["_dtc"]  = pd.to_datetime(_col(alt_elevated,"LBDTC").str[:10], errors="coerce")
        bili_elevated["_dtc"] = pd.to_datetime(_col(bili_elevated,"LBDTC").str[:10], errors="coerce")

        out = []
        for subj in set(_col(alt_elevated,"USUBJID")) & set(_col(bili_elevated,"USUBJID")):
            a_dates = alt_elevated[_col(alt_elevated,"USUBJID")==subj]["_dtc"].dropna()
            b_dates = bili_elevated[_col(bili_elevated,"USUBJID")==subj]["_dtc"].dropna()
            # Check if any alt date is within 30 days of any bili date
            concurrent = any(
                abs((ad - bd).days) <= 30
                for ad in a_dates for bd in b_dates
            )
            if concurrent:
                out.append(self._new(c, subj,
                    "Hys Law signal: ALT>3xULN and TBili>2xULN within 30-day window"))
        return out

    def _chk_LB012(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        key   = [k for k in ["USUBJID","LBTESTCD","LBDTC"] if k in df.columns]
        if len(key) < 2: return []
        dupes = df[df.duplicated(key, keep=False)]
        seen, out = set(), []
        for _, r in dupes.iterrows():
            k = (r.get("USUBJID",""), r.get("LBTESTCD",""), r.get("LBDTC",""))
            if k not in seen:
                seen.add(k)
                out.append(self._new(c, r["USUBJID"],
                    f"LBTESTCD='{r.get('LBTESTCD','')}' LBDTC='{r.get('LBDTC','')}' appears multiple times"))
        return out

    def _chk_VS001(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        bp = df[_col(df,"VSTESTCD").isin(["SYSBP","DIABP"])].copy()
        if bp.empty: return []
        bp["_n"]   = pd.to_numeric(_col(bp,"VSSTRESN"), errors="coerce")
        # Normalise VISITNUM: strip trailing .0 to unify '2.0' and '2'
        visitnum_norm = pd.to_numeric(_col(bp,"VISITNUM"), errors="coerce")
        visit_str = visitnum_norm.apply(
            lambda v: str(int(v)) if pd.notna(v) else ""
        )
        # Fall back to VISIT text when VISITNUM absent/blank
        visit_fallback = _col(bp,"VISIT").fillna("")
        bp["_key"] = _col(bp,"USUBJID") + "|" + visit_str.where(visit_str != "", visit_fallback)
        wide = bp.pivot_table(index="_key", columns="VSTESTCD", values="_n", aggfunc="first")
        if "SYSBP" not in wide.columns or "DIABP" not in wide.columns: return []
        hits = wide[wide["DIABP"] > wide["SYSBP"]].dropna(subset=["SYSBP","DIABP"])
        out  = []
        for vk, row in hits.iterrows():
            subj  = vk.split("|")[0]
            visit = vk.split("|")[1]
            out.append(self._new(c, subj, f"DIABP={row['DIABP']:.0f} > SYSBP={row['SYSBP']:.0f} at VISIT='{visit}'"))
        return out

    def _chk_VS005(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        p  = df[_col(df,"VSTESTCD") == "PULSE"].copy()
        if p.empty: return []
        v  = pd.to_numeric(_col(p,"VSSTRESN"), errors="coerce")
        return [self._new(c, r["USUBJID"], f"PULSE={r.get('VSSTRESN','')} BPM - implausible (must be 20-300)")
                for _, r in p[((v<20)|(v>300)) & v.notna()].iterrows()]

    def _chk_VS007(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        s  = df[_col(df,"VSTESTCD") == "SYSBP"].copy()
        if s.empty: return []
        v  = pd.to_numeric(_col(s,"VSSTRESN"), errors="coerce")
        return [self._new(c, r["USUBJID"], f"SYSBP={r.get('VSSTRESN','')} mmHg - out of physiological range")
                for _, r in s[((v<40)|(v>300)) & v.notna()].iterrows()]

    def _chk_CM001(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        mask = _col(df,"CMDECOD") == ""
        return [self._new(c, r["USUBJID"], f"CMDECOD missing for CMTRT='{r.get('CMTRT','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_CM003(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        out = []
        yr  = re.compile(r"^\d{4}$")
        for col in ["CMSTDTC","CMENDTC"]:
            dtc  = _col(df, col)
            mask = dtc.str.match(yr) & (dtc != "")
            for _, r in df[mask].iterrows():
                out.append(self._new(c, r["USUBJID"], f"{col}='{r[col]}' - year only, missing month"))
        return out

    def _chk_CM004(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        st = _col(df,"CMSTDTC").str[:10]
        en = _col(df,"CMENDTC").str[:10]
        mask = (st != "") & (en != "") & (en < st)
        return [self._new(c, r["USUBJID"], f"CMENDTC='{r.get('CMENDTC','')}' before CMSTDTC='{r.get('CMSTDTC','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_S010(self, c, dd):
        pat = re.compile(r"^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2})?)?)?)?$")
        out = []
        for dom, df in dd.items():
            if df.empty: continue
            for col in [x for x in df.columns if x.endswith("DTC")]:
                vals    = _col(df, col)
                invalid = df[(vals != "") & ~vals.str.match(pat)]
                for _, r in invalid.head(10).iterrows():
                    out.append(self._new(c, r.get("USUBJID","?"),
                        f"{dom}.{col}='{r[col]}' - invalid ISO 8601 format"))
        return out

    # ==================================================================
    # v7 NEW CHECKS: INT001-INT005
    # ==================================================================

    def _chk_INT001(self, c, dd):
        """Orphan records: USUBJID found in any domain but not in DM. Vectorized."""
        dm_subjs = self._lkp.get("dm_subjs", set()) if hasattr(self,"_lkp") else set()
        if not dm_subjs:
            dm = dd.get("DM", pd.DataFrame())
            if dm.empty or "USUBJID" not in dm.columns: return []
            dm_subjs = set(_col(dm,"USUBJID").unique()) - {"","ALL"}

        skip = {"DM","TS","TA","TE","TV","TI","RELREC","SUPP"}
        out  = []
        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            vc       = _col(df,"USUBJID").value_counts()
            orphans  = vc[~vc.index.isin(dm_subjs | {"","ALL"})]
            for subj, n_rec in orphans.items():
                out.append(self._new(c, subj,
                    f"USUBJID '{subj}' exists in {dom} ({n_rec} records) but not in DM",
                    root="Orphan subject"))
        return out

    def _chk_INT002(self, c, dd):
        """Baseline flag after first dose: --BLFL=Y but record date > DM.RFSTDTC. Vectorized."""
        rfst_s = (self._lkp.get("dm_rfstdtc") if hasattr(self,"_lkp") else None)
        if rfst_s is None:
            dm = dd.get("DM", pd.DataFrame())
            if dm.empty or "USUBJID" not in dm.columns: return []
            dm2    = dm.drop_duplicates("USUBJID").set_index("USUBJID")
            rfst_s = dm2.get("RFSTDTC", pd.Series(dtype=str)).str[:10]

        skip = {"DM","TS","TA","TE","TV","TI","DS","MH"}
        out  = []
        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            blfl_cols = [col for col in df.columns if col.endswith("BLFL") and col != "ABLFL"]
            # Use all start-date DTC columns (e.g. LBDTC, EXSTDTC) — not just the first
            dtc_cols  = [col for col in df.columns
                         if col.endswith("DTC") and not col.endswith("ENDTC")]
            if not blfl_cols or not dtc_cols:
                continue
            for blfl_col in blfl_cols:
                blfl_mask = _col(df, blfl_col).str.upper() == "Y"
                sub = df[blfl_mask].copy()
                if sub.empty: continue
                # Pick the most domain-appropriate DTC column (prefer exact match e.g. LBDTC for LB)
                dtc_col = next(
                    (c for c in dtc_cols if c.startswith(dom)),
                    dtc_cols[0]
                )
                sub["_dtc"]   = _col(sub, dtc_col).str[:10]
                sub["_rfst"]  = sub["USUBJID"].map(rfst_s)
                hits = sub[(sub["_dtc"] != "") & (sub["_rfst"].notna()) &
                           (sub["_dtc"] > sub["_rfst"])]
                for _, r in hits.iterrows():
                    out.append(self._new(c, r["USUBJID"],
                        f"{dom}.{blfl_col}=Y at {dtc_col}='{r['_dtc']}' but RFSTDTC='{r['_rfst']}'"
                        " (baseline record is AFTER first dose)",
                        root="Post-dose baseline flag"))
        return out

    def _chk_INT003(self, c, dd):
        """Missing disposition: subject has activity in EX/LB/AE but no DS record.
        Excludes orphan subjects (not in DM) - INT001 covers those separately."""
        ds = dd.get("DS", pd.DataFrame())
        ds_subjs: set = set()
        if not ds.empty and "USUBJID" in ds.columns:
            ds_subjs = set(_col(ds, "USUBJID").unique()) - {"","ALL"}

        # Get DM subjects to exclude orphans from INT003 scope
        dm_subjs = self._lkp.get("dm_subjs", set()) if hasattr(self,"_lkp") else set()
        if not dm_subjs:
            dm = dd.get("DM", pd.DataFrame())
            if not dm.empty and "USUBJID" in dm.columns:
                dm_subjs = set(_col(dm,"USUBJID").unique()) - {"","ALL"}

        activity_domains = ["EX","LB","AE","VS","CM","EG"]
        out = []
        seen: set = set()
        for dom in activity_domains:
            df = dd.get(dom, pd.DataFrame())
            if df.empty or "USUBJID" not in df.columns:
                continue
            active_subjs = set(_col(df,"USUBJID").unique()) - {"","ALL"}
            # Only flag subjects who ARE in DM but have no DS (orphans handled by INT001)
            in_dm_no_ds = (active_subjs & dm_subjs) - ds_subjs
            for subj in sorted(in_dm_no_ds):
                if subj not in seen:
                    seen.add(subj)
                    n = int((df["USUBJID"] == subj).sum())
                    out.append(self._new(c, subj,
                        f"Subject has {n} {dom} record(s) but no DS disposition event found",
                        root="Missing disposition"))
        return out

    def _chk_INT004(self, c, dd):
        """Gender-inappropriate tests: PREG/HCG/BHCG for male subjects."""
        dm = dd.get("DM", pd.DataFrame())
        lb = dd.get("LB", pd.DataFrame())
        if dm.empty or lb.empty: return []
        if "USUBJID" not in dm.columns or "LBTESTCD" not in lb.columns:
            return []

        # Build male subject set
        sex_col  = _col(dm,"SEX").str.upper()
        male_set = set(dm[sex_col == "M"]["USUBJID"].unique()) - {""}

        # Pregnancy / HCG tests
        preg_tests = {"PREG","HCG","BHCG","PREGNEG","PREGTEST","HCG QUAL",
                      "HCGQL","B-HCG","BETAHCG"}
        lb_tests   = _col(lb,"LBTESTCD").str.upper()
        preg_mask  = lb_tests.isin(preg_tests)
        preg_recs  = lb[preg_mask]

        out = []
        for _, r in preg_recs.iterrows():
            subj = str(r.get("USUBJID","?"))
            if subj in male_set:
                out.append(self._new(c, subj,
                    f"LBTESTCD='{r.get('LBTESTCD','')}' (pregnancy test) found for DM.SEX=M "
                    f"at LBDTC='{r.get('LBDTC','')}' - gender-inappropriate test"))
        return out

    def _chk_INT005(self, c, dd):
        """Pre-consent assessment: any domain date < DM.RFICDTC (excl. MH)."""
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty or "USUBJID" not in dm.columns:
            return []

        # Use pre-built lookup or build from DM
        if hasattr(self,"_lkp") and "dm_rficdtc" in self._lkp:
            consent_s = self._lkp["dm_rficdtc"].dropna()
        else:
            dm2 = dm.drop_duplicates("USUBJID").set_index("USUBJID")
            consent_s = dm2.get("RFICDTC", pd.Series(dtype=str)).str[:10].dropna()
        consent = consent_s.to_dict()

        if not consent:
            return []

        skip_domains = {"DM","MH","TS","TA","TE","TV","TI","DS","SV","SE"}
        out = []
        for dom, df in dd.items():
            if dom in skip_domains or df.empty or "USUBJID" not in df.columns:
                continue
            dtc_cols = [col for col in df.columns
                        if col.endswith("DTC") and not col.endswith("ENDTC")][:1]
            if not dtc_cols: continue
            dtc_col = dtc_cols[0]
            sub = df[["USUBJID", dtc_col]].copy()
            sub["_dtc"] = sub[dtc_col].str[:10]
            sub["_con"] = sub["USUBJID"].map(consent_s)
            hits = sub[(sub["_dtc"].str.len() == 10) &
                       (sub["_con"].notna()) &
                       (sub["_dtc"] < sub["_con"])]
            seen_subjs: set = set()
            for _, r in hits.iterrows():
                subj = str(r["USUBJID"])
                if subj not in seen_subjs:
                    seen_subjs.add(subj)
                    out.append(self._new(c, subj,
                        f"{dom}.{dtc_col}='{r['_dtc']}' is before RFICDTC='{r['_con']}' "
                        "(assessment precedes informed consent)",
                        root="Pre-consent activity"))
        return out

    # ==================================================================
    # v7 NEW CHECKS: DATE001-DATE006
    # ==================================================================

    def _chk_DATE001(self, c, dd):
        """Start date after end date across all loaded domains (--STDTC > --ENDTC)."""
        # Map of standard start/end date pairs
        domain_pairs = {
            "AE": ("AESTDTC","AEENDTC"),
            "CM": ("CMSTDTC","CMENDTC"),
            "EX": ("EXSTDTC","EXENDTC"),
            "DS": ("DSSTDTC",None),
            "MH": ("MHSTDTC","MHENDTC"),
            "PR": ("PRSTDTC","PRENDTC"),
            "QS": ("QSSTDTC",None),
            "LB": ("LBDTC",None),
        }
        out = []
        for dom, df in dd.items():
            if df.empty: continue
            # Use known pairs if available, else scan for any --STDTC/--ENDTC pair
            pair = domain_pairs.get(dom)
            if pair:
                st_col, en_col = pair
                if st_col and en_col and st_col in df.columns and en_col in df.columns:
                    st = _col(df, st_col).str[:10]
                    en = _col(df, en_col).str[:10]
                    mask = (st != "") & (en != "") & (st.str.len() == 10) & (en.str.len() == 10) & (st > en)
                    for _, r in df[mask].iterrows():
                        out.append(self._new(c, r.get("USUBJID","?"),
                            f"{dom}: {st_col}='{r.get(st_col,'')}' > {en_col}='{r.get(en_col,'')}'"
                            f" (start after end)"))
            else:
                # Generic scan for any --STDTC / --ENDTC pairing
                stdtc_cols = [col for col in df.columns if col.endswith("STDTC")]
                for st_col in stdtc_cols:
                    en_col = st_col.replace("STDTC","ENDTC")
                    if en_col in df.columns:
                        st = _col(df, st_col).str[:10]
                        en = _col(df, en_col).str[:10]
                        mask = (st != "") & (en != "") & (st.str.len() == 10) & (en.str.len() == 10) & (st > en)
                        for _, r in df[mask].iterrows():
                            out.append(self._new(c, r.get("USUBJID","?"),
                                f"{dom}: {st_col}='{r.get(st_col,'')}' > {en_col}='{r.get(en_col,'')}'"
                                f" (start after end)"))
        return out

    def _chk_DATE002(self, c, dd):
        """Post-mortem activity: any clinical domain record after DS death date."""
        ds = dd.get("DS", pd.DataFrame())
        if ds.empty: return []

        # Extract death dates per subject
        death_dates: dict = {}
        if "DSDECOD" in ds.columns and "DSSTDTC" in ds.columns:
            death_mask = _col(ds,"DSDECOD").str.upper().isin(["DEATH","DIED","DEAD"])
            for _, r in ds[death_mask].iterrows():
                subj  = str(r.get("USUBJID",""))
                ddtc  = _date_str(str(r.get("DSSTDTC","")))
                if subj and ddtc:
                    # Keep earliest death date
                    if subj not in death_dates or ddtc < death_dates[subj]:
                        death_dates[subj] = ddtc

        if not death_dates:
            return []

        # DM contains administrative dates (RFSTDTC, RFENDTC) that are planned dates,
        # not clinical events. These would always exceed death date if planned > actual.
        skip = {"DS","DM","TS","TA","TE","TV","TI","MH","SE","SV","SS"}
        out  = []
        # Use pre-built lookup
        if hasattr(self,"_lkp") and "death_dates" in self._lkp:
            death_s = self._lkp["death_dates"]
        else:
            death_s = pd.Series(death_dates) if death_dates else pd.Series(dtype=str)
        if death_s.empty: return []

        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            dtc_cols = [col for col in df.columns if col.endswith("DTC") and not col.endswith("ENDTC")][:2]
            for dtc_col in dtc_cols:
                sub = df[["USUBJID", dtc_col]].copy()
                sub["_dtc"]  = sub[dtc_col].str[:10]
                sub["_dth"]  = sub["USUBJID"].map(death_s)
                hits = sub[(sub["_dtc"].str.len() == 10) &
                           (sub["_dth"].notna()) &
                           (sub["_dtc"] > sub["_dth"])]
                seen_k: set = set()
                for _, r in hits.iterrows():
                    subj = str(r["USUBJID"])
                    k = (subj, dtc_col)
                    if k not in seen_k:
                        seen_k.add(k)
                        out.append(self._new(c, subj,
                            f"{dom}.{dtc_col}='{r['_dtc']}' found after death date '{r['_dth']}'"
                            " (post-mortem activity)",
                            root="Post-mortem clinical activity"))
        return out

    def _chk_DATE003(self, c, dd):
        """Future date: any --DTC column value after today's date."""
        today = _today()   # YYYY-MM-DD
        skip  = {"TS","TA","TE","TV","TI"}
        out   = []
        seen  : set = set()
        for dom, df in dd.items():
            if dom in skip or df.empty: continue
            dtc_cols = [col for col in df.columns if col.endswith("DTC")]
            for col in dtc_cols:
                vals    = _col(df, col).str[:10]
                future  = df[(vals.str.len() == 10) & (vals > today)]
                for _, r in future.iterrows():
                    subj = str(r.get("USUBJID","?"))
                    val  = str(r.get(col,""))[:10]
                    key  = (subj, dom, col, val)
                    if key not in seen:
                        seen.add(key)
                        out.append(self._new(c, subj,
                            f"{dom}.{col}='{val}' is in the future (today={today}). "
                            f"Possible data entry typo."))
        return out

    def _chk_DATE004(self, c, dd):
        """Birth date after study start: DM.BRTHDTC > DM.RFSTDTC."""
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty: return []
        brthdtc = _col(dm,"BRTHDTC").str[:10]
        rfstdtc = _col(dm,"RFSTDTC").str[:10]
        mask    = (brthdtc != "") & (rfstdtc != "") & \
                  (brthdtc.str.len() == 10) & (rfstdtc.str.len() == 10) & \
                  (brthdtc > rfstdtc)
        return [self._new(c, r["USUBJID"],
                    f"BRTHDTC='{r.get('BRTHDTC','')}' is after RFSTDTC='{r.get('RFSTDTC','')}' "
                    f"(born after study start - possible dummy or erroneous record)")
                for _, r in dm[mask].iterrows()]

    def _chk_DATE005(self, c, dd):
        """First treatment before informed consent: EX.EXSTDTC < DM.RFICDTC."""
        dm = dd.get("DM", pd.DataFrame())
        ex = dd.get("EX", pd.DataFrame())
        if dm.empty or ex.empty: return []
        if "USUBJID" not in dm.columns or "EXSTDTC" not in ex.columns:
            return []

        # Build consent map
        consent: dict = {}
        for _, r in dm.iterrows():
            s = str(r.get("USUBJID",""))
            d = _date_str(str(r.get("RFICDTC","")))
            if s and d:
                consent[s] = d

        out = []
        seen: set = set()
        for _, r in ex.iterrows():
            subj    = str(r.get("USUBJID","?"))
            exstdtc = _date_str(str(r.get("EXSTDTC","")))
            con_dtc = consent.get(subj,"")
            if exstdtc and con_dtc and exstdtc < con_dtc and subj not in seen:
                seen.add(subj)
                out.append(self._new(c, subj,
                    f"EXSTDTC='{exstdtc}' is before RFICDTC='{con_dtc}' "
                    f"(first dose before informed consent - GCP violation)",
                    root="Pre-consent dosing"))
        return out

    def _chk_DATE006(self, c, dd):
        """Dosing after discontinuation: EX.EXENDTC > DS disposition DSSTDTC."""
        ds = dd.get("DS", pd.DataFrame())
        ex = dd.get("EX", pd.DataFrame())
        if ds.empty or ex.empty: return []
        if "USUBJID" not in ds.columns or "EXENDTC" not in ex.columns:
            return []

        # Use pre-built lookup
        if hasattr(self,"_lkp") and "disp_dates" in self._lkp:
            disp_s = self._lkp["disp_dates"]
        else:
            dscat_col = _col(ds,"DSCAT").str.upper()
            disp_mask = dscat_col.isin(["DISPOSITION EVENT","DISPOSITION","COMPLETION"])
            disp_rows = ds[disp_mask].copy()
            if disp_rows.empty or "DSSTDTC" not in disp_rows.columns:
                return []
            disp_rows["_d"] = disp_rows["DSSTDTC"].str[:10]
            disp_s = (disp_rows.sort_values("_d")
                      .drop_duplicates("USUBJID",keep="first")
                      .set_index("USUBJID")["_d"])
        if disp_s.empty:
            return []
        disp_dates = disp_s.to_dict()

        out  = []
        seen: set = set()
        for _, r in ex.iterrows():
            subj    = str(r.get("USUBJID","?"))
            exendtc = _date_str(str(r.get("EXENDTC","")))
            dispdtc = disp_dates.get(subj,"")
            if exendtc and dispdtc and exendtc > dispdtc and subj not in seen:
                seen.add(subj)
                out.append(self._new(c, subj,
                    f"EX.EXENDTC='{exendtc}' is after DS disposition date '{dispdtc}' "
                    f"(dosing continued after study discontinuation)"))
        return out

    def _chk_DATE007(self, c, dd):
        """DATE007: GCP-critical dates have partial precision.
        RFICDTC, RFSTDTC (Critical), DTHDTC (High medical importance).
        Per v8.0 §2 / v8.1 §4 context-aware partial date framework.
        """
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty: return []

        # Define critical date columns and their regulatory context
        critical_cols = {
            "RFICDTC": ("GCP-critical: Informed consent date is partial", "Critical"),
            "RFSTDTC": ("GCP-critical: First dose date is partial", "Critical"),
            "DTHDTC":  ("High medical importance: Death date is partial", "High"),
        }

        out = []
        for col, (ctx_msg, severity_label) in critical_cols.items():
            if col not in dm.columns:
                continue
            vals = _col(dm, col)
            # Partial date: present but not full YYYY-MM-DD (length < 10 or no day component)
            partial_mask = (
                (vals != "") &
                (vals.str.len() < 10) &
                (vals.str.len() >= 4)   # has at least a year
            )
            for _, r in dm[partial_mask].iterrows():
                out.append(self._new(
                    c, r.get("USUBJID","?"),
                    f"{col}='{r.get(col,'')}' is a partial date — {ctx_msg}. "
                    f"Full precision required for regulatory traceability.",
                    confidence="High"
                ))
        return out

    # ==================================================================
    # SUPP STRUCTURAL CHECKS (v14)
    # ==================================================================

    def _chk_S016(self, c, dd):
        """S016: QNAM in SUPP-- uses a reserved standard SDTM variable name."""
        out = []
        log = getattr(self, "_supp_merge_log", [])
        seen: set = set()
        for entry in log:
            if entry.get("check") == "S016":
                dom = entry.get("domain","SUPP")
                key = (dom, entry["issue"])
                if key not in seen:
                    seen.add(key)
                    out.append(self._new(c, "ALL",
                        f"SUPP{dom}: {entry['issue']}"))
        return out

    def _chk_S017(self, c, dd):
        """S017: SUPP-- RDOMAIN does not match parent domain code."""
        out = []
        log = getattr(self, "_supp_merge_log", [])
        seen: set = set()
        for entry in log:
            if entry.get("check") == "S017":
                dom = entry.get("domain","SUPP")
                key = (dom, entry["issue"])
                if key not in seen:
                    seen.add(key)
                    out.append(self._new(c, "ALL",
                        f"SUPP{dom}: {entry['issue']}"))
        return out

    def _chk_S018(self, c, dd):
        """S018: SUPP-- IDVAR/IDVARVAL does not resolve to existing parent record."""
        out = []
        log = getattr(self, "_supp_merge_log", [])
        seen: set = set()
        for entry in log:
            if entry.get("check") == "S018":
                dom = entry.get("domain","SUPP")
                key = (dom, entry["issue"][:80])
                if key not in seen:
                    seen.add(key)
                    out.append(self._new(c, "ALL",
                        f"SUPP{dom}: {entry['issue']}"))
        return out

    def _chk_AE014(self, c, dd):
        """AE014: AESER=Y but SAE narrative (SUPPAE.SAENARR) missing.
        Relies on SUPPAE being back-merged into AE (v14 SUPP merge)."""
        ae = dd.get("AE", pd.DataFrame())
        if ae.empty: return []
        ser = _col(ae,"AESER").str.upper()
        serious = ae[ser == "Y"].copy()
        if serious.empty: return []
        # After back-merge, SAENARR should be a column in AE
        if "SAENARR" not in ae.columns:
            # SUPPAE not loaded / not merged — emit advisory
            return [self._new(c, "ALL",
                "SUPPAE not loaded or SAENARR column absent — cannot validate SAE narratives",
                actual=False)]
        narr = _col(serious,"SAENARR").str.strip()
        missing_narr = serious[narr == ""]
        return [
            self._new(c, r["USUBJID"],
                f"AESER=Y (AETERM='{r.get('AETERM','')}') but SAENARR is blank/missing in SUPPAE")
            for _, r in missing_narr.iterrows()
        ]

    # ================================================ demo fallback
    def _run_demo(self, check: dict, dd_rows: dict) -> list:
        dom_parts = [d for d in check["domain"].split("/")
                     if d not in ("ALL","DEFINE","SUPP","RELREC")]
        # If ANY required domain is loaded with actual data, skip demo entirely
        if any(d in dd_rows and dd_rows[d] for d in dom_parts):
            return []
        # If files are uploaded at all but domain simply not present, still skip demo
        # to avoid mixing dummy issues into real validation runs
        if self.files_meta:
            return []
        out = []
        for entry in _DEMO_MAP.get(check["id"], []):
            c = get_check(check["id"])
            if c:
                self._seq += 1
                fid = _fingerprint(entry["domain"], c["id"], entry["subj"], entry["detail"])
                out.append({
                    "fid":         fid,
                    "checkId":     c["id"],
                    "label":       c["label"],
                    "layer":       c["layer"],
                    "cat":         c["cat"],
                    "domain":      entry["domain"],
                    "sev":         c["sev"],
                    "risk":        c["risk"],
                    "source":      c["source"],
                    "subj":        entry["subj"],
                    "detail":      entry["detail"],
                    "root":        entry.get("root"),
                    "actual":      False,
                    "waived":      False,
                    "waiver_note": "",
                    "ts":          datetime.datetime.now().isoformat(),
                })
        return out

    # ==================================================================
    # v17 NEW CHECKS — GCP, Medical, Data, Oncology, QS, Analysis, Meta
    # ==================================================================

    def _chk_GCP001(self, c, dd):
        """GCP001: PR record before informed consent (RFICDTC) — ICH E6 violation."""
        pr = dd.get("PR", pd.DataFrame())
        dm = dd.get("DM", pd.DataFrame())
        if pr.empty or dm.empty: return []
        if "PRSTDTC" not in pr.columns or "RFICDTC" not in dm.columns: return []
        icdt = {r["USUBJID"]: r["RFICDTC"] for _, r in dm.iterrows()
                if r.get("RFICDTC","") and len(str(r.get("RFICDTC",""))) >= 10}
        out = []
        for _, r in pr.iterrows():
            subj = r.get("USUBJID","?")
            pdt  = str(r.get("PRSTDTC",""))
            ic   = icdt.get(subj,"")
            if ic and len(pdt) >= 10 and pdt[:10] < ic[:10]:
                out.append(self._new(c, subj,
                    f"PRSTDTC={pdt[:10]} precedes RFICDTC={ic[:10]} — ICH E6 consent violation",
                    confidence="High"))
        return out

    def _chk_GCP002(self, c, dd):
        """GCP002: DTHDTC in DM but no DEATH record in DS."""
        dm = dd.get("DM", pd.DataFrame())
        ds = dd.get("DS", pd.DataFrame())
        if dm.empty: return []
        out = []
        death_subjs = set()
        if not ds.empty and "DSDECOD" in ds.columns and "USUBJID" in ds.columns:
            death_subjs = set(ds[ds["DSDECOD"].str.upper().str.strip() == "DEATH"]["USUBJID"].tolist())
        for _, r in dm.iterrows():
            dthdtc = str(r.get("DTHDTC","")).strip()
            subj   = r.get("USUBJID","?")
            if dthdtc and dthdtc not in ("","nan") and subj not in death_subjs:
                out.append(self._new(c, subj,
                    f"DTHDTC={dthdtc} in DM but DSDECOD=DEATH absent from DS",
                    confidence="High"))
        return out

    def _chk_GCP003(self, c, dd):
        """GCP003: DSDECOD=DEATH in DS but DTHDTC missing in DM."""
        dm = dd.get("DM", pd.DataFrame())
        ds = dd.get("DS", pd.DataFrame())
        if ds.empty or dm.empty: return []
        if "DSDECOD" not in ds.columns: return []
        dm_dth = {r["USUBJID"]: str(r.get("DTHDTC","")).strip()
                  for _, r in dm.iterrows()}
        out = []
        for _, r in ds[ds["DSDECOD"].str.upper().str.strip() == "DEATH"].iterrows():
            subj = r.get("USUBJID","?")
            dthd = dm_dth.get(subj,"")
            if not dthd or dthd in ("nan",""):
                out.append(self._new(c, subj,
                    f"DSDECOD=DEATH in DS (DSSTDTC={r.get('DSSTDTC','?')}) but DTHDTC missing in DM",
                    confidence="High"))
        return out

    def _chk_GCP004(self, c, dd):
        """GCP004: EX dosing after DS study discontinuation date."""
        ex = dd.get("EX", pd.DataFrame())
        ds = dd.get("DS", pd.DataFrame())
        if ex.empty or ds.empty: return []
        if "EXSTDTC" not in ex.columns or "DSSTDTC" not in ds.columns: return []
        disc_kw = {"DISCONTINUED","WITHDRAWAL BY SUBJECT","ADVERSE EVENT","PHYSICIAN DECISION"}
        if "DSDECOD" in ds.columns:
            disc_ds = ds[ds["DSDECOD"].str.upper().str.strip().isin(disc_kw)]
        else:
            disc_ds = ds
        disc_dt = {}
        for _, r in disc_ds.iterrows():
            s = r.get("USUBJID","?")
            d = str(r.get("DSSTDTC",""))[:10]
            if d and len(d) == 10:
                if s not in disc_dt or d < disc_dt[s]:
                    disc_dt[s] = d
        out = []
        for _, r in ex.iterrows():
            subj = r.get("USUBJID","?")
            exdt = str(r.get("EXSTDTC",""))[:10]
            disc = disc_dt.get(subj,"")
            if disc and len(exdt) == 10 and exdt > disc:
                out.append(self._new(c, subj,
                    f"EXSTDTC={exdt} after discontinuation date {disc} in DS",
                    confidence="High"))
        return out

    def _chk_GCP005(self, c, dd):
        """GCP005: AEACN=DRUG WITHDRAWN with no DS DISCONTINUATION record."""
        ae = dd.get("AE", pd.DataFrame())
        ds = dd.get("DS", pd.DataFrame())
        if ae.empty: return []
        if "AEACN" not in ae.columns: return []
        withdrawn_subjs = set(
            ae[ae["AEACN"].str.upper().str.strip() == "DRUG WITHDRAWN"]["USUBJID"].tolist())
        disc_subjs: set = set()
        if not ds.empty and "DSDECOD" in ds.columns:
            disc_subjs = set(ds[ds["DSDECOD"].str.upper().str.strip().str.contains(
                "DISCONTINU|WITHDRAWN", na=False)]["USUBJID"].tolist())
        out = []
        for subj in withdrawn_subjs - disc_subjs:
            out.append(self._new(c, subj,
                "AEACN=DRUG WITHDRAWN in AE but no discontinuation record found in DS",
                confidence="High"))
        return out

    def _chk_MED001(self, c, dd):
        """MED001: Abnormal LB with no AE within ±7 days."""
        lb = dd.get("LB", pd.DataFrame())
        ae = dd.get("AE", pd.DataFrame())
        if lb.empty: return []
        if "LBNRIND" not in lb.columns or "LBDTC" not in lb.columns: return []
        abn = lb[lb["LBNRIND"].str.upper().str.strip().isin(
            {"HIGH","LOW","ABNORMAL","CLINICALLY SIGNIFICANT","CS","H","L"})]
        out = []
        for _, r in abn.iterrows():
            subj = r.get("USUBJID","?")
            lbdt = str(r.get("LBDTC",""))[:10]
            if len(lbdt) < 10: continue
            try:
                lbd = pd.Timestamp(lbdt)
            except Exception:
                continue
            matched = False
            if not ae.empty and "AESTDTC" in ae.columns:
                subj_ae = ae[ae["USUBJID"] == subj]
                for _, ar in subj_ae.iterrows():
                    try:
                        aed = pd.Timestamp(str(ar.get("AESTDTC",""))[:10])
                        if abs((lbd - aed).days) <= 7:
                            matched = True
                            break
                    except Exception:
                        pass
            if not matched:
                out.append(self._new(c, subj,
                    f"LBTESTCD={r.get('LBTESTCD','?')} LBNRIND={r.get('LBNRIND','?')} "
                    f"on {lbdt} — no AE within ±7 days",
                    confidence="Medium"))
        return out

    def _chk_MED002(self, c, dd):
        """MED002: AEOUT=FATAL but AEENDTC != DTHDTC."""
        ae = dd.get("AE", pd.DataFrame())
        dm = dd.get("DM", pd.DataFrame())
        if ae.empty or dm.empty: return []
        if "AEOUT" not in ae.columns: return []
        dth_map = {r["USUBJID"]: str(r.get("DTHDTC",""))[:10]
                   for _, r in dm.iterrows()}
        out = []
        for _, r in ae[ae["AEOUT"].str.upper().str.strip() == "FATAL"].iterrows():
            subj  = r.get("USUBJID","?")
            aeend = str(r.get("AEENDTC",""))[:10]
            dthdtc = dth_map.get(subj,"")
            if dthdtc and aeend and aeend != dthdtc:
                out.append(self._new(c, subj,
                    f"AETERM={r.get('AETERM','?')} AEOUT=FATAL: AEENDTC={aeend} != DTHDTC={dthdtc}",
                    confidence="High"))
        return out

    def _chk_MED003(self, c, dd):
        """MED003: AEOUT=RECOVERED/RESOLVED but AEENDTC missing."""
        ae = dd.get("AE", pd.DataFrame())
        if ae.empty or "AEOUT" not in ae.columns: return []
        resolved_vals = {"RECOVERED/RESOLVED","RECOVERED","RESOLVED"}
        out = []
        for _, r in ae[ae["AEOUT"].str.upper().str.strip().isin(resolved_vals)].iterrows():
            aeend = str(r.get("AEENDTC","")).strip()
            if not aeend or aeend == "nan":
                out.append(self._new(c, r.get("USUBJID","?"),
                    f"AETERM={r.get('AETERM','?')} AEOUT={r.get('AEOUT','?')} "
                    f"but AEENDTC is missing — AE duration cannot be calculated",
                    confidence="Medium"))
        return out

    def _chk_MED004(self, c, dd):
        """MED004: Ocular AE with missing AELAT."""
        ae = dd.get("AE", pd.DataFrame())
        if ae.empty: return []
        if "AEBODSYS" not in ae.columns: return []
        eye_kw = {"EYE","OCULAR","OPHTHALM","VISUAL","RETINAL","CORNEAL","LENS"}
        def _is_eye(s):
            s = str(s).upper()
            return any(k in s for k in eye_kw)
        out = []
        for _, r in ae[ae["AEBODSYS"].apply(_is_eye)].iterrows():
            lat = str(r.get("AELAT","")).strip()
            if not lat or lat in ("nan",""):
                out.append(self._new(c, r.get("USUBJID","?"),
                    f"AETERM={r.get('AETERM','?')} AEBODSYS={r.get('AEBODSYS','?')} "
                    f"— AELAT (laterality) missing for ocular AE",
                    confidence="Medium"))
        return out

    def _chk_DAT008(self, c, dd):
        """DAT008: Record date after last SV visit date."""
        sv = dd.get("SV", pd.DataFrame())
        if sv.empty or "SVSTDTC" not in sv.columns: return []
        last_visit = {}
        for _, r in sv.iterrows():
            s  = r.get("USUBJID","?")
            dt = str(r.get("SVSTDTC",""))[:10]
            if len(dt) == 10:
                if s not in last_visit or dt > last_visit[s]:
                    last_visit[s] = dt
        check_domains = [("EG","EGDTC"),("EX","EXSTDTC"),("LB","LBDTC"),
                         ("RS","RSDTC"),("TU","TUDTC")]
        out = []
        for dom, dtcol in check_domains:
            df = dd.get(dom, pd.DataFrame())
            if df.empty or dtcol not in df.columns: continue
            for _, r in df.iterrows():
                subj = r.get("USUBJID","?")
                rdt  = str(r.get(dtcol,""))[:10]
                lv   = last_visit.get(subj,"")
                if lv and len(rdt) == 10 and rdt > lv:
                    out.append(self._new(c, subj,
                        f"{dom}.{dtcol}={rdt} is after last SV visit {lv}",
                        confidence="Medium"))
        return out

    def _chk_DAT009(self, c, dd):
        """DAT009: Partial date with year+day known but month missing."""
        import re
        _pat = re.compile(r"^\d{4}--\d{2}$")
        domains_cols = {
            "LB": ["LBDTC"], "EG": ["EGDTC"], "VS": ["VSDTC"],
            "CM": ["CMSTDTC","CMENDTC"], "MH": ["MHSTDTC"]
        }
        out = []
        for dom, cols in domains_cols.items():
            df = dd.get(dom, pd.DataFrame())
            if df.empty: continue
            for col in cols:
                if col not in df.columns: continue
                for _, r in df.iterrows():
                    v = str(r.get(col,"")).strip()
                    if _pat.match(v):
                        out.append(self._new(c, r.get("USUBJID","?"),
                            f"{dom}.{col}='{v}' — year+day known but month missing",
                            confidence="Medium"))
        return out

    def _chk_ONC006(self, c, dd):
        """ONC006: TR response inconsistent with RS overall response — RECIST 1.1."""
        tr = dd.get("TR", pd.DataFrame())
        rs = dd.get("RS", pd.DataFrame())
        if tr.empty or rs.empty: return []
        if "TRORRES" not in tr.columns or "RSORRES" not in rs.columns: return []
        # CR in TR but PD in RS is a contradiction
        cr_subjs_visits: set = set()
        for _, r in tr[tr["TRORRES"].str.upper().str.strip() == "CR"].iterrows():
            cr_subjs_visits.add((r.get("USUBJID","?"), str(r.get("VISITNUM",""))))
        out = []
        for _, r in rs[rs["RSORRES"].str.upper().str.strip() == "PD"].iterrows():
            key = (r.get("USUBJID","?"), str(r.get("VISITNUM","")))
            if key in cr_subjs_visits:
                out.append(self._new(c, key[0],
                    f"TR shows CR but RS shows PD at VISITNUM={key[1]} — RECIST contradiction",
                    confidence="High"))
        return out

    def _chk_ONC007(self, c, dd):
        """ONC007: TRSTRESN missing for LDIAM target lesion."""
        tr = dd.get("TR", pd.DataFrame())
        if tr.empty: return []
        if "TRTESTCD" not in tr.columns: return []
        ldiam = tr[tr["TRTESTCD"].str.upper().str.strip() == "LDIAM"]
        out = []
        for _, r in ldiam.iterrows():
            v = str(r.get("TRSTRESN","")).strip()
            if not v or v in ("nan",""):
                out.append(self._new(c, r.get("USUBJID","?"),
                    f"LDIAM record at VISITNUM={r.get('VISITNUM','?')} missing TRSTRESN",
                    confidence="High"))
        return out

    def _chk_QS001(self, c, dd):
        """QS001: QSSTAT=NOT DONE but QSSTRESC not null."""
        qs = dd.get("QS", pd.DataFrame())
        if qs.empty or "QSSTAT" not in qs.columns: return []
        out = []
        for _, r in qs[qs["QSSTAT"].str.upper().str.strip() == "NOT DONE"].iterrows():
            v = str(r.get("QSSTRESC","")).strip()
            if v and v != "nan":
                out.append(self._new(c, r.get("USUBJID","?"),
                    f"QSTESTCD={r.get('QSTESTCD','?')} QSSTAT=NOT DONE but QSSTRESC='{v}'",
                    confidence="High"))
        return out

    def _chk_QS002(self, c, dd):
        """QS002: QSDTC after DTHDTC — post-mortem PRO collection."""
        qs = dd.get("QS", pd.DataFrame())
        dm = dd.get("DM", pd.DataFrame())
        if qs.empty or dm.empty: return []
        if "QSDTC" not in qs.columns or "DTHDTC" not in dm.columns: return []
        dth_map = {r["USUBJID"]: str(r.get("DTHDTC",""))[:10]
                   for _, r in dm.iterrows() if str(r.get("DTHDTC","")).strip()}
        out = []
        for _, r in qs.iterrows():
            subj = r.get("USUBJID","?")
            qsdt = str(r.get("QSDTC",""))[:10]
            dthdtc = dth_map.get(subj,"")
            if dthdtc and len(qsdt) == 10 and qsdt > dthdtc:
                out.append(self._new(c, subj,
                    f"QSTESTCD={r.get('QSTESTCD','?')} QSDTC={qsdt} after DTHDTC={dthdtc}",
                    confidence="High"))
        return out

    def _chk_QS003(self, c, dd):
        """QS003: Duplicate QS records."""
        qs = dd.get("QS", pd.DataFrame())
        if qs.empty: return []
        key_cols = [col for col in ["USUBJID","QSTESTCD","QSDTC","VISITNUM"] if col in qs.columns]
        if len(key_cols) < 3: return []
        dups = qs[qs.duplicated(subset=key_cols, keep=False)]
        out = []
        seen: set = set()
        for _, r in dups.iterrows():
            subj = r.get("USUBJID","?")
            key  = (subj, r.get("QSTESTCD",""), str(r.get("QSDTC","")), str(r.get("VISITNUM","")))
            if key not in seen:
                seen.add(key)
                out.append(self._new(c, subj,
                    f"Duplicate: QSTESTCD={key[1]} QSDTC={key[2]} VISITNUM={key[3]}",
                    confidence="High"))
        return out

    def _chk_QS004(self, c, dd):
        """QS004: QSSTAT=NOT DONE but QSREASND missing."""
        qs = dd.get("QS", pd.DataFrame())
        if qs.empty or "QSSTAT" not in qs.columns: return []
        out = []
        for _, r in qs[qs["QSSTAT"].str.upper().str.strip() == "NOT DONE"].iterrows():
            reasnd = str(r.get("QSREASND","")).strip()
            if not reasnd or reasnd == "nan":
                out.append(self._new(c, r.get("USUBJID","?"),
                    f"QSTESTCD={r.get('QSTESTCD','?')} QSSTAT=NOT DONE but QSREASND absent",
                    confidence="Medium"))
        return out

    def _chk_ANL001(self, c, dd):
        """ANL001: Randomized subject missing stratification factor."""
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty or "ARMCD" not in dm.columns: return []
        rand = dm[~dm["ARMCD"].str.upper().str.strip().isin({"SCRNFAIL","SCREEN FAILURE",""})]
        # Proxy: check STRATCD or any SUPP strat variable
        suppdm = dd.get("SUPPDM", pd.DataFrame())
        strat_subjs: set = set()
        if not suppdm.empty and "QNAM" in suppdm.columns:
            strat_subjs = set(
                suppdm[suppdm["QNAM"].str.upper().str.strip().str.startswith("STRAT")]["USUBJID"].tolist())
        out = []
        for _, r in rand.iterrows():
            subj = r.get("USUBJID","?")
            if "STRATCD" in dm.columns:
                if str(r.get("STRATCD","")).strip() in ("","nan"):
                    out.append(self._new(c, subj,
                        f"ARMCD={r.get('ARMCD','?')} — STRATCD missing in DM",
                        confidence="Medium"))
            elif subj not in strat_subjs and not suppdm.empty:
                out.append(self._new(c, subj,
                    f"ARMCD={r.get('ARMCD','?')} — no stratification factor in DM/SUPPDM",
                    confidence="Low"))
        return out

    def _chk_ANL002(self, c, dd):
        """ANL002: TS missing MedDRA version (TSPARMCD=MEDDRA)."""
        ts = dd.get("TS", pd.DataFrame())
        if ts.empty: return []
        if "TSPARMCD" not in ts.columns: return []
        has_meddra = any(
            str(v).upper().strip() == "MEDDRA"
            for v in ts["TSPARMCD"].tolist())
        if not has_meddra:
            return [self._new(c, "ALL",
                "TSPARMCD=MEDDRA not found in TS — MedDRA version undeclared",
                confidence="High")]
        return []

    def _chk_ANL003(self, c, dd):
        """ANL003: TS missing WHODrug version (TSPARMCD=WHODRUG)."""
        ts = dd.get("TS", pd.DataFrame())
        if ts.empty: return []
        if "TSPARMCD" not in ts.columns: return []
        has_who = any(
            str(v).upper().strip() == "WHODRUG"
            for v in ts["TSPARMCD"].tolist())
        if not has_who:
            return [self._new(c, "ALL",
                "TSPARMCD=WHODRUG not found in TS — WHODrug version undeclared",
                confidence="High")]
        return []

    def _chk_META001(self, c, dd):
        """META001: SUPP QORIG inconsistency (demo-level check)."""
        # Full Define-XML cross-reference requires define.xml parser;
        # this flags SUPP records with suspicious QORIG values
        out = []
        valid_qorig = {"CRF","eDT","DERIVED","ASSIGNED","PROTOCOL","PREDECESSOR"}
        for dom_name, df in dd.items():
            if not dom_name.startswith("SUPP"): continue
            if df.empty or "QORIG" not in df.columns: continue
            for _, r in df.iterrows():
                qo = str(r.get("QORIG","")).strip().upper()
                if qo and qo not in valid_qorig:
                    out.append(self._new(c, r.get("USUBJID","ALL"),
                        f"{dom_name}.QORIG='{r.get('QORIG','')}' not in standard Origin set",
                        confidence="Medium"))
        return out

    def _chk_META002(self, c, dd):
        """META002: CT value not in declared package — demo-level spot check."""
        # Full check requires CT package; this flags known bad CT values
        ae = dd.get("AE", pd.DataFrame())
        if ae.empty: return []
        valid_aeout = {"RECOVERED/RESOLVED","NOT RECOVERED/NOT RESOLVED",
                       "RECOVERED/RESOLVED WITH SEQUELAE","FATAL","UNKNOWN"}
        out = []
        if "AEOUT" in ae.columns:
            for _, r in ae.iterrows():
                v = str(r.get("AEOUT","")).strip().upper()
                if v and v not in valid_aeout:
                    out.append(self._new(c, r.get("USUBJID","?"),
                        f"AEOUT='{r.get('AEOUT','')}' not in CDISC CT — possible off-list value",
                        confidence="Medium"))
        return out

    def _chk_META003(self, c, dd):
        """META003: Drug variable naming convention (FDA TCG)."""
        ex = dd.get("EX", pd.DataFrame())
        if ex.empty: return []
        # FDA TCG: treatment variable should be EXTRT, not custom names
        bad_cols = [col for col in ex.columns
                    if col.startswith("EX") and col not in
                    {"EXTRT","EXDOSE","EXDOSU","EXDOSFRM","EXDOSFRQ","EXROUTE",
                     "EXSTDTC","EXENDTC","EXSTDY","EXENDY","EXSEQ","EXGRPID","EXREFID",
                     "EXSPID","VISITNUM","VISIT","EPOCH","USUBJID","STUDYID","DOMAIN"}]
        if bad_cols:
            return [self._new(c, "ALL",
                f"Non-standard EX variable(s): {', '.join(bad_cols)} — review FDA TCG naming",
                confidence="Low")]
        return []
