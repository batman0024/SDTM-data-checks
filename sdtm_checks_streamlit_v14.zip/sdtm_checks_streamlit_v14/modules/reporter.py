"""modules/reporter.py v8.1 - readable HTML + domain/issue Excel tabs + IMP002 audit metadata."""
import io, datetime, math

RISK_LABEL = {
    "submission-blocker": "Submission Blocker",
    "medical-concern":    "Medical Concern",
    "structural":         "Structural Error",
    "advisory":           "Advisory",
}
RISK_COL = {
    "submission-blocker": "#ff6868",
    "medical-concern":    "#ff9898",
    "structural":         "#ffc070",
    "advisory":           "#7aaaff",
}
SEV_COL = {
    "REJECT":   "#ff6868",
    "CRITICAL": "#ff9898",
    "ERROR":    "#ffc070",
    "WARNING":  "#f0d840",
    "NOTICE":   "#7aaaff",
}
LAYER_COL = {
    "Structure":          "#7aaaff",
    "Trial Design":       "#90d8ff",
    "P21-Base":           "#ffc070",
    "Beyond-P21":         "#ff9898",
    "Hidden Integrity":   "#ff6868",
    "Temporal Integrity": "#ff6868",
}
XL_RISK_BG = {
    "submission-blocker": "FFE8E8",
    "medical-concern":    "FFF0F0",
    "structural":         "FFF8EC",
    "advisory":           "EEF4FF",
}
XL_RISK_FC = {
    "submission-blocker": "8B0000",
    "medical-concern":    "A03030",
    "structural":         "704010",
    "advisory":           "1A3880",
}
DOMAIN_GROUPS = [
    ("DM + DS",    ["DM","DS","SS"]),
    ("AE",         ["AE"]),
    ("LB + EG",    ["LB","EG"]),
    ("VS",         ["VS"]),
    ("EX",         ["EX","PC","PP"]),
    ("CM + MH",    ["CM","MH","PR"]),
    ("Oncology",   ["TR","TU","RS"]),
    ("Other Dom",  ["QS","IE","SV","SE","FA","EC","HO","DV",
                    "TS","TA","TE","TV","TI","ALL","RELREC","SUPP","DEFINE"]),
]

def _e(s):
    if not s: return ""
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")

def _dom(f):
    return f.get("domain","ALL").split("/")[0]

# ---------- SVG helpers ------------------------------------------------------
def _svg_bars(data_dict, cmap=None, max_bars=14, bh=20, gap=5, bar_area=220, lbl_w=150):
    if not data_dict:
        return "<p style='color:#3a4060;font-size:11px'>No data</p>"
    items  = sorted(data_dict.items(), key=lambda x: -x[1])[:max_bars]
    mx     = max(v for _,v in items) or 1
    val_w  = 34
    svg_w  = lbl_w + bar_area + val_w + 10
    svg_h  = len(items)*(bh+gap) + 8
    out    = [f'<svg width="{svg_w}" height="{svg_h}" xmlns="http://www.w3.org/2000/svg" style="display:block">']
    for i,(k,v) in enumerate(items):
        y   = i*(bh+gap)+4
        bw  = max(int(v/mx*bar_area), 2)
        col = (cmap or {}).get(k, "#4880ff")
        out += [
            f'<text x="{lbl_w-6}" y="{y+bh-5}" text-anchor="end" '
            f'font-family="Courier New" font-size="10" fill="#a0a8c0">{_e(str(k)[:24])}</text>',
            f'<rect x="{lbl_w}" y="{y}" width="{bar_area}" height="{bh}" fill="#0e0f1c" rx="2"/>',
            f'<rect x="{lbl_w}" y="{y}" width="{bw}" height="{bh}" fill="{col}" rx="2" opacity=".82"/>',
            f'<text x="{lbl_w+bw+4}" y="{y+bh-5}" font-family="Courier New" font-size="10" fill="#d0d8f0">{v}</text>',
        ]
    out.append("</svg>")
    return "".join(out)

def _svg_donut(data_dict, cmap=None, size=170, thickness=36):
    if not data_dict: return ""
    items = list(data_dict.items())
    total = sum(v for _,v in items) or 1
    cx=cy=size//2
    r = cx - thickness//2 - 4
    out = [f'<svg width="{size}" height="{size+len(items)*14+6}" xmlns="http://www.w3.org/2000/svg" style="display:inline-block;vertical-align:top">']
    out += [
        f'<text x="{cx}" y="{cy-8}" text-anchor="middle" font-family="Arial" font-size="22" font-weight="800" fill="#d0d8f0">{total}</text>',
        f'<text x="{cx}" y="{cy+9}" text-anchor="middle" font-family="Courier New" font-size="9" fill="#6878a0">TOTAL</text>',
    ]
    angle = -90.0
    for k,v in items:
        col   = (cmap or {}).get(k,"#4880ff")
        sweep = v/total*360
        if sweep >= 360: sweep = 359.9
        r1 = math.radians(angle)
        r2 = math.radians(angle+sweep)
        x1 = cx + r*math.cos(r1); y1 = cy + r*math.sin(r1)
        x2 = cx + r*math.cos(r2); y2 = cy + r*math.sin(r2)
        lg = 1 if sweep>180 else 0
        out.append(f'<path d="M {x1:.1f} {y1:.1f} A {r} {r} 0 {lg} 1 {x2:.1f} {y2:.1f}" fill="none" stroke="{col}" stroke-width="{thickness}"/>')
        angle += sweep
    ly = size+4
    for k,v in items:
        col   = (cmap or {}).get(k,"#4880ff")
        pct   = f"{v/total*100:.0f}%"
        out += [
            f'<rect x="4" y="{ly}" width="10" height="10" fill="{col}" rx="2"/>',
            f'<text x="17" y="{ly+9}" font-family="Courier New" font-size="9" fill="#9098b8">{_e(str(k)[:20])} ({pct})</text>',
        ]
        ly += 14
    out.append("</svg>")
    return "".join(out)

# ---------- HTML report ------------------------------------------------------
def make_html_report(findings, files_meta, enabled_ids, run_meta=None):
    now    = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    real   = [f for f in findings if not f.get("dep_warning")]
    active = [f for f in real if not f.get("waived")]
    waived = [f for f in real if f.get("waived")]

    # IMP002 – audit block
    run_meta = run_meta or {}
    _run_id     = run_meta.get("run_id", "")
    _yaml_hash  = run_meta.get("checks_yaml_hash", "")
    _cis_ver    = run_meta.get("cis_version", "8.0")
    _datasets   = run_meta.get("run_dataset_list", [])
    _n_enabled  = len(enabled_ids)
    audit_html  = ""
    if _run_id:
        ds_list = ", ".join(_datasets[:10]) + ("…" if len(_datasets)>10 else "")
        audit_html = (
            f'<div style="margin:10px 0 16px;padding:8px 14px;background:#090a14;'
            f'border:1px solid #1a1e30;border-left:3px solid #4060c0;border-radius:4px;'
            f'font-family:Courier New,monospace;font-size:9px;color:#505878;line-height:1.9">'
            f'<span style="color:#6878a8;font-weight:700;text-transform:uppercase;'
            f'letter-spacing:.06em">Audit Trail</span><br>'
            f'Run ID: <span style="color:#8898c8">{_run_id}</span> &nbsp;|&nbsp; '
            f'CIS Version: <span style="color:#8898c8">v{_cis_ver}</span> &nbsp;|&nbsp; '
            f'YAML Hash: <span style="color:#8898c8">{_yaml_hash}</span> &nbsp;|&nbsp; '
            f'Checks Enabled: <span style="color:#8898c8">{_n_enabled}</span><br>'
            f'Datasets ({len(_datasets)}): <span style="color:#7888a8">{_e(ds_list) or "none"}</span>'
            f'</div>'
        )

    by_risk={};by_sev={};by_dom={};by_layer={};by_cat={}
    for f in active:
        by_risk[f["risk"]]         = by_risk.get(f["risk"],0)+1
        by_sev[f["sev"]]           = by_sev.get(f["sev"],0)+1
        by_dom[_dom(f)]            = by_dom.get(_dom(f),0)+1
        by_layer[f.get("layer","")]= by_layer.get(f.get("layer",""),0)+1
        by_cat[f.get("cat","")]    = by_cat.get(f.get("cat",""),0)+1

    def sc(label,val,col,sub=""):
        s = f'<div style="background:#0c0d18;border:1px solid {col}55;border-radius:7px;padding:16px 10px;text-align:center;border-top:3px solid {col}">'
        s += f'<div style="font-family:Arial,sans-serif;font-size:30px;font-weight:800;color:{col}">{val}</div>'
        s += f'<div style="font-size:10px;color:#8898b8;text-transform:uppercase;letter-spacing:.08em;margin-top:5px">{label}</div>'
        if sub: s += f'<div style="font-size:9px;color:#506080;margin-top:2px">{sub}</div>'
        return s+"</div>"

    scores = (
        sc("Active Findings", len(active), "#c0c8e8") +
        sc("Submission Blockers", by_risk.get("submission-blocker",0), "#ff6868", "submission") +
        sc("Medical Concerns",    by_risk.get("medical-concern",0),    "#ff9898") +
        sc("Structural Errors",   by_risk.get("structural",0),         "#ffc070") +
        sc("Advisory",            by_risk.get("advisory",0),           "#7aaaff") +
        sc("Waived",              len(waived),                          "#60c890")
    )

    risk_lbl_map = {RISK_LABEL.get(k,k): v for k,v in by_risk.items()}
    risk_col_lbl = {RISK_LABEL.get(k,k): RISK_COL[k] for k in RISK_COL}
    dom_top15    = dict(sorted(by_dom.items(),key=lambda x:-x[1])[:15])
    cat_top10    = dict(sorted(by_cat.items(),key=lambda x:-x[1])[:10])
    dom_top8     = dict(sorted(by_dom.items(),key=lambda x:-x[1])[:8])
    dom_colours  = ["#7aaaff","#ff9898","#ffc070","#60d090","#d090ff","#ff9030","#90d8ff","#f0d840"]
    dom_cmap     = {d: dom_colours[i%8] for i,d in enumerate(dom_top8)}

    COL_HDRS = ["ID","SEV","RISK","SUBJECT","DOMAIN","CHECK DESCRIPTION","FINDING DETAIL","SOURCE"]
    th_html  = "".join(
        f'<th style="background:#111320;border:1px solid #1e2238;padding:8px 10px;'
        f'text-align:left;color:#7aaaff;font-size:10px;text-transform:uppercase;'
        f'letter-spacing:.06em;white-space:nowrap;position:sticky;top:0;z-index:3">{h}</th>'
        for h in COL_HDRS
    )

    def finding_rows(flist, limit=500):
        out=[]
        for f in flist[:limit]:
            risk = f.get("risk","structural")
            sev  = f.get("sev","")
            sc2  = SEV_COL.get(sev,"#aaa")
            rc   = RISK_COL.get(risk,"#aaa")
            rl   = RISK_LABEL.get(risk,risk)
            subj = "GLOBAL" if f.get("subj","")=="ALL" else (f.get("subj","") or "-")
            dom  = _dom(f)
            ab   = ('<span style="background:#1a4028;color:#60d090;border:1px solid #2a6040;border-radius:2px;padding:1px 5px;font-size:8px">ACTUAL</span>'
                    if f.get("actual") else
                    '<span style="background:#1a2450;color:#7aaaff;border:1px solid #2a3870;border-radius:2px;padding:1px 5px;font-size:8px">DEMO</span>')
            root = (f'<div style="margin-top:4px;font-size:9px;color:#7088a8">Root: {_e(f.get("root",""))}</div>'
                    if f.get("root") else "")
            wn   = (f'<div style="margin-top:4px;font-size:9px;color:#50c890">Waived: {_e(f.get("waiver_note",""))}</div>'
                    if f.get("waiver_note") else "")
            td   = "border:1px solid #1e2238;padding:7px 9px;vertical-align:top"
            out.append(
                f'<tr>'
                f'<td style="{td};font-size:9px;color:#8898b8;white-space:nowrap;font-family:monospace">{_e(f.get("fid",""))}</td>'
                f'<td style="{td};white-space:nowrap"><span style="border:1px solid {sc2};color:{sc2};font-size:9px;padding:2px 6px;border-radius:3px;font-weight:700">{_e(sev)}</span></td>'
                f'<td style="{td};white-space:nowrap;color:{rc};font-size:10px;font-weight:600">{_e(rl)}</td>'
                f'<td style="{td};color:#90c0ff;font-weight:700;font-size:11px;white-space:nowrap">{_e(subj)}</td>'
                f'<td style="{td};white-space:nowrap"><span style="display:inline-block;background:#232030;border:1px solid #4a4060;color:#e0c888;font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;letter-spacing:.05em">{_e(dom)}</span></td>'
                f'<td style="{td};color:#d8e0f8;font-size:11px;line-height:1.55">{_e(f.get("label",""))} {ab}{root}</td>'
                f'<td style="{td};color:#e8f0ff;font-size:11px;line-height:1.6">{_e(f.get("detail",""))}{wn}</td>'
                f'<td style="{td};color:#9098c0;font-size:10px;white-space:nowrap">{_e(f.get("source",""))}</td>'
                f'</tr>'
            )
        return "".join(out)

    def section(title, flist, limit=500):
        if not flist: return ""
        n = len(flist)
        return (
            f'<div style="margin-bottom:30px">'
            f'<h2 style="margin-bottom:6px">{_e(title)} <span style="font-weight:400;font-size:11px;color:#506080">({n} finding{"s" if n!=1 else ""})</span></h2>'
            f'<div style="overflow-x:auto;border-radius:6px;border:1px solid #1e2238">'
            f'<table style="width:100%;border-collapse:collapse"><thead><tr>{th_html}</tr></thead>'
            f'<tbody>{finding_rows(flist,limit)}</tbody></table></div></div>'
        )

    file_rows=""
    for fn,m in files_meta.items():
        vs  = ", ".join((m.get("variables") or [])[:5])
        err = m.get("parse_error","") or m.get("parse_note","")
        ok  = err[:50] if err else "OK"
        fc  = "#ff7070" if m.get("parse_error") else "#60c890"
        td  = "border:1px solid #1e2238;padding:7px 9px"
        file_rows += (
            f'<tr>'
            f'<td style="{td};color:#7aaaff;font-weight:600;white-space:nowrap">{_e(fn)}</td>'
            f'<td style="{td};color:#a0b0cc">{_e(m.get("type",""))}</td>'
            f'<td style="{td};text-align:right;color:#d0d8f0;font-weight:700">{m.get("rows",0)}</td>'
            f'<td style="{td};text-align:right;color:#d0d8f0">{m.get("cols",0)}</td>'
            f'<td style="{td};text-align:right;color:#9098b8">{m.get("size",0):,}</td>'
            f'<td style="{td};font-size:10px;color:#8090a8">{_e(vs)}</td>'
            f'<td style="{td};font-size:10px;color:{fc}">{_e(ok)}</td>'
            f'</tr>'
        )

    bloc  = [f for f in active if f["risk"] in ("submission-blocker","medical-concern")]
    strct = [f for f in active if f["risk"]=="structural"]
    adv   = [f for f in active if f["risk"]=="advisory"]

    fthr  = "background:#111320;border:1px solid #1e2238;padding:8px 10px;color:#7aaaff;font-size:10px;text-transform:uppercase;letter-spacing:.06em"
    ftd   = "border:1px solid #1e2238;padding:7px 9px"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Clinical Integrity Report - CIS v8.0</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#07070d;color:#c0c8e0;font-family:"Courier New",monospace;font-size:12px;line-height:1.65;padding:28px 24px}}
.page{{max-width:1300px;margin:0 auto}}
h1{{font-family:Arial,sans-serif;font-size:22px;font-weight:900;color:#d0dcf0;margin-bottom:4px}}
h2{{font-size:13px;font-weight:700;color:#c8d4f0;margin:24px 0 10px;padding-bottom:6px;border-bottom:1px solid #1e2238;letter-spacing:.02em}}
.meta{{font-size:10px;color:#3a4468;letter-spacing:.06em;margin-bottom:6px}}
.g6{{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin:14px 0 24px}}
.g2{{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px}}
.g3{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;margin-bottom:20px}}
.cb{{background:#0b0c18;border:1px solid #1a1e30;border-radius:6px;padding:14px 16px}}
.ct{{font-size:10px;color:#6878a0;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;font-weight:700}}
hr{{border:none;border-top:1px solid #1a1e30;margin:20px 0}}
tr:nth-child(even) td{{background:#0a0b14}}
tr:hover td{{background:#0e0f1e!important}}
footer{{margin-top:32px;padding-top:12px;border-top:1px solid #1a1e30;font-size:9px;color:#252840;text-align:center}}
</style>
</head>
<body><div class="page">
<div style="font-size:9px;color:#22263a;letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">
  SDTM Clinical Integrity Suite v8.0 -- Beyond-P21 Validation Engine
</div>
<h1>Clinical Integrity Report</h1>
<div class="meta">Generated: {now} &bull; {len(real)} findings &bull; {len(active)} active &bull; {len(waived)} waived &bull; {len(enabled_ids)} checks &bull; {len(files_meta)} files</div>
{audit_html}
<div class="g6">{scores}</div>

<h2>Findings Overview</h2>
<div class="g2">
  <div class="cb"><div class="ct">By Risk Category</div>{_svg_bars(risk_lbl_map,risk_col_lbl,bh=24,bar_area=230)}</div>
  <div class="cb"><div class="ct">By Severity Level</div>{_svg_bars(by_sev,SEV_COL,bh=24,bar_area=230)}</div>
</div>
<div class="g2">
  <div class="cb"><div class="ct">By SDTM Domain (top 15)</div>{_svg_bars(dom_top15,bh=18,bar_area=230)}</div>
  <div class="cb"><div class="ct">By Validation Layer</div>{_svg_bars(by_layer,LAYER_COL,bh=24,bar_area=230)}</div>
</div>
<div class="g2">
  <div class="cb"><div class="ct">Domain Distribution</div>{_svg_donut(dom_top8,dom_cmap,size=180,thickness=38)}</div>
  <div class="cb"><div class="ct">Top Finding Categories</div>{_svg_bars(cat_top10,bh=18,bar_area=230)}</div>
</div>

<hr>
{section("Submission Blockers and Medical Concerns",bloc)}
{section("Structural Errors",strct)}
{section("Advisory Notices",adv)}
{section("Waived Findings",waived)}

<h2>Loaded Files ({len(files_meta)})</h2>
<div style="overflow-x:auto;border-radius:6px;border:1px solid #1e2238">
<table style="width:100%;border-collapse:collapse">
<thead><tr>
<th style="{fthr}">Filename</th><th style="{fthr}">Type</th>
<th style="{fthr}">Rows</th><th style="{fthr}">Cols</th>
<th style="{fthr}">Size</th><th style="{fthr}">Variables</th><th style="{fthr}">Status</th>
</tr></thead>
<tbody>{file_rows or f'<tr><td colspan="7" style="{ftd};text-align:center;color:#3a4060">No files loaded</td></tr>'}</tbody>
</table></div>

<footer>SDTM Clinical Integrity Suite v8.0 &bull; Beyond-P21 &bull; FDA TCG 2024, SDTMIG v3.4, PharmaSUG, ICH E2A/E3/E6/E14, CDISC CT, RECIST 1.1, FDA DILI</footer>
</div></body></html>"""


# ---------- Excel report -----------------------------------------------------
def make_excel_report(findings, files_meta, enabled_ids, run_meta=None):
    try:
        import xlsxwriter
        return _xl_xlsxwriter(findings, files_meta, enabled_ids, run_meta=run_meta)
    except ImportError:
        return _xl_openpyxl(findings, files_meta, enabled_ids, run_meta=run_meta)


def _xl_xlsxwriter(findings, files_meta, enabled_ids, run_meta=None):
    import xlsxwriter as xl
    buf=io.BytesIO()
    wb =xl.Workbook(buf,{"in_memory":True})
    now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    run_meta = run_meta or {}

    HDR=wb.add_format({"bold":True,"font_color":"#FFFFFF","bg_color":"#1C2670","border":1,
                       "font_name":"Calibri","font_size":10,"text_wrap":True,"valign":"vcenter"})
    HDR_C=wb.add_format({"bold":True,"font_color":"#FFFFFF","bg_color":"#1C2670","border":1,
                         "font_name":"Calibri","font_size":10,"valign":"vcenter","align":"center"})

    def row_fmt(bg,fc,bold=False):
        return wb.add_format({"font_name":"Calibri","font_size":9,"border":1,"text_wrap":True,
                              "valign":"top","bg_color":bg,"font_color":fc,"bold":bold})

    RF={r: row_fmt({"submission-blocker":"#FFE8E8","medical-concern":"#FFF0F0",
                    "structural":"#FFF8EC","advisory":"#EEF4FF","waived":"#F0FFF4"}[r],
                   "#"+XL_RISK_FC.get(r,"202020") if r!="waived" else "#1A5030")
        for r in ["submission-blocker","medical-concern","structural","advisory","waived"]}
    SF={r: row_fmt({"submission-blocker":"#FFE0E0","medical-concern":"#FFE8E8",
                    "structural":"#FFF0DC","advisory":"#E8F0FF","waived":"#E8FFF0"}[r],
                   "#"+{"submission-blocker":"C00000","medical-concern":"C03030",
                        "structural":"905010","advisory":"1A3880","waived":"206030"}[r], True)
        for r in ["submission-blocker","medical-concern","structural","advisory","waived"]}
    DF={r: row_fmt({"submission-blocker":"#FFE0E0","medical-concern":"#FFE8E8",
                    "structural":"#FFF0DC","advisory":"#E8F0FF","waived":"#E8FFF0"}[r],
                   "#"+{"submission-blocker":"8B0000","medical-concern":"A02020",
                        "structural":"704010","advisory":"1A3070","waived":"205030"}[r], True)
        for r in ["submission-blocker","medical-concern","structural","advisory","waived"]}
    SEV_FMT={s: row_fmt({"REJECT":"#FFE0E0","CRITICAL":"#FFE8E8","ERROR":"#FFF4E0",
                          "WARNING":"#FFFFDD","NOTICE":"#EEF4FF"}[s],
                         "#"+{"REJECT":"800000","CRITICAL":"A02020","ERROR":"705010",
                              "WARNING":"606000","NOTICE":"1A3070"}[s], True)
             for s in ["REJECT","CRITICAL","ERROR","WARNING","NOTICE"]}
    ID_FMT=wb.add_format({"font_name":"Courier New","font_size":8,"border":1,"valign":"top",
                          "bg_color":"#F8F8FC","font_color":"#606080"})
    SRC_FMT=wb.add_format({"font_name":"Calibri","font_size":8,"border":1,"valign":"top",
                           "bg_color":"#F5F5FF","font_color":"#404080","italic":True})

    COLS=[("ID",7),("Severity",10),("Risk",22),("Subject",12),("Domain",10),
          ("Layer",16),("Category",20),("Check Description",54),("Finding Detail",62),
          ("Source",18),("Data",8),("Waiver Note",36)]

    def set_w(ws):
        for ci,(_,w) in enumerate(COLS): ws.set_column(ci,ci,w)

    def write_hdr(ws, row=0):
        for ci,(h,_) in enumerate(COLS):
            ws.write(row,ci,h,HDR_C if ci in (0,1,4,10) else HDR)

    def write_row(ws, row, f, is_waived=False):
        risk=f.get("risk","structural")
        sev =f.get("sev","")
        key ="waived" if is_waived else risk
        rfmt=RF.get(key,RF["advisory"])
        sfmt=SF.get(key,SF["advisory"])
        dfmt=DF.get(key,DF["advisory"])
        sevfmt=SEV_FMT.get(sev,rfmt)
        subj="GLOBAL" if f.get("subj","")=="ALL" else (f.get("subj","") or "-")
        vals=[f.get("fid",""),sev,RISK_LABEL.get(risk,risk),subj,_dom(f),
              f.get("layer",""),f.get("cat",""),f.get("label",""),f.get("detail",""),
              f.get("source",""),"ACTUAL" if f.get("actual") else "DEMO",f.get("waiver_note","")]
        for ci,v in enumerate(vals):
            if   ci==0: ws.write(row,ci,v,ID_FMT)
            elif ci==1: ws.write(row,ci,v,sevfmt)
            elif ci==3: ws.write(row,ci,v,sfmt)
            elif ci==4: ws.write(row,ci,v,dfmt)
            elif ci==9: ws.write(row,ci,v,SRC_FMT)
            else:       ws.write(row,ci,v,rfmt)

    def make_sheet(ws, flist, tab_col, is_waived=False):
        ws.set_tab_color(tab_col); ws.freeze_panes(1,0)
        ws.autofilter(0,0,max(len(flist),1),len(COLS)-1); ws.set_zoom(95)
        write_hdr(ws); set_w(ws)
        for ri,f in enumerate(flist,1):
            ws.set_row(ri,32); write_row(ws,ri,f,is_waived)

    active=[f for f in findings if not f.get("waived") and not f.get("dep_warning")]
    waived=[f for f in findings if f.get("waived")]

    # -- Summary
    ws0=wb.add_worksheet("Summary"); ws0.set_tab_color("#1C2670")
    ws0.hide_gridlines(2); ws0.set_zoom(100)
    tf=wb.add_format({"bold":True,"font_size":18,"font_color":"#1a2870","font_name":"Calibri"})
    sf2=wb.add_format({"font_size":9,"font_color":"#606888","font_name":"Calibri","italic":True})
    audit_fmt=wb.add_format({"font_size":8,"font_color":"#404878","font_name":"Courier New","italic":True})
    ws0.write("A1","SDTM Clinical Integrity Suite v8.0",tf)
    ws0.write("A2",f"Generated: {now}  |  Active: {len(active)}  |  Waived: {len(waived)}  |  Files: {len(files_meta)}",sf2)
    # IMP002 – audit metadata row
    _run_id    = run_meta.get("run_id","")
    _yaml_hash = run_meta.get("checks_yaml_hash","")
    _cis_ver   = run_meta.get("cis_version","8.0")
    _ds_list   = ", ".join(run_meta.get("run_dataset_list",[])[:15])
    if _run_id:
        ws0.write("A3", f"Run ID: {_run_id}  |  CIS: v{_cis_ver}  |  YAML: {_yaml_hash}  |  Datasets: {_ds_list}", audit_fmt)
    by_risk={};by_sev={};by_dom={}
    for f in active:
        by_risk[f["risk"]]=by_risk.get(f["risk"],0)+1
        by_sev[f["sev"]]=by_sev.get(f["sev"],0)+1
        by_dom[_dom(f)]=by_dom.get(_dom(f),0)+1
    scorecards=[("Active",len(active),"C8D0F0","F0F2FF"),
                ("Blockers",by_risk.get("submission-blocker",0),"CC0000","FFE0E0"),
                ("Medical",by_risk.get("medical-concern",0),"C03030","FFF0F0"),
                ("Structural",by_risk.get("structural",0),"B06010","FFF8EC"),
                ("Advisory",by_risk.get("advisory",0),"1A3880","EEF4FF"),
                ("Waived",len(waived),"1A6030","F0FFF4")]
    ws0.set_row(3,40); ws0.set_row(4,18)
    for ci,(lbl,val,fc,bg) in enumerate(scorecards):
        ws0.set_column(ci,ci,16)
        vf=wb.add_format({"bold":True,"font_size":24,"align":"center","valign":"vcenter","border":1,"font_color":"#"+fc,"bg_color":"#"+bg,"font_name":"Calibri"})
        lf=wb.add_format({"font_size":8,"align":"center","valign":"vcenter","border":1,"font_color":"#606888","bg_color":"#"+bg,"font_name":"Calibri","italic":True})
        ws0.write(3,ci,val,vf); ws0.write(4,ci,lbl,lf)
    ws0.write(6,0,"Risk Category",HDR); ws0.write(6,1,"Count",HDR_C)
    for ri,k in enumerate(["submission-blocker","medical-concern","structural","advisory"],7):
        bg=XL_RISK_BG.get(k,"FAFAFA"); fc=XL_RISK_FC.get(k,"202020")
        rf2=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#"+fc,"bg_color":"#"+bg,"bold":True})
        cf2=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#"+fc,"bg_color":"#"+bg,"align":"right"})
        ws0.write(ri,0,RISK_LABEL.get(k,k),rf2); ws0.write(ri,1,by_risk.get(k,0),cf2)
    ws0.write(6,3,"Severity",HDR); ws0.write(6,4,"Count",HDR_C)
    ss_spec={"REJECT":("FFE0E0","7A0000"),"CRITICAL":("FFE8E8","9A2020"),
             "ERROR":("FFF4E0","664010"),"WARNING":("FFFFDD","505000"),"NOTICE":("EEF4FF","1A3070")}
    for ri,k in enumerate([s for s in ["REJECT","CRITICAL","ERROR","WARNING","NOTICE"] if s in by_sev],7):
        bg2,fc2=ss_spec.get(k,("FAFAFA","202020"))
        sf3=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#"+fc2,"bg_color":"#"+bg2})
        cf3=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#"+fc2,"bg_color":"#"+bg2,"align":"right"})
        ws0.write(ri,3,k,sf3); ws0.write(ri,4,by_sev[k],cf3)
    ws0.write(6,6,"SDTM Domain",HDR); ws0.write(6,7,"Count",HDR_C)
    df3=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#1A2870","bg_color":"#EEF4FF","bold":True})
    cf4=wb.add_format({"font_name":"Calibri","font_size":10,"border":1,"font_color":"#1A2870","bg_color":"#EEF4FF","align":"right"})
    for ri,(k,v) in enumerate(sorted(by_dom.items(),key=lambda x:-x[1])[:20],7):
        ws0.write(ri,6,k,df3); ws0.write(ri,7,v,cf4)
    ws0.set_column(6,6,12); ws0.set_column(7,7,8)

    # -- Issue-type sheets
    make_sheet(wb.add_worksheet("Blockers"),        [f for f in active if f["risk"]=="submission-blocker"],"#AA2222")
    make_sheet(wb.add_worksheet("Medical Concerns"),[f for f in active if f["risk"]=="medical-concern"],  "#CC5555")
    make_sheet(wb.add_worksheet("Structural Errors"),[f for f in active if f["risk"]=="structural"],      "#AA7722")
    make_sheet(wb.add_worksheet("Advisory"),         [f for f in active if f["risk"]=="advisory"],        "#336699")
    make_sheet(wb.add_worksheet("All Findings"),     active,                                               "#223388")
    make_sheet(wb.add_worksheet("Waived"),           waived,                                               "#226633", True)

    # -- Domain-group sheets
    dom_map={}
    for f in active: dom_map.setdefault(_dom(f),[]).append(f)
    DOM_TAB_COL={"DM + DS":"#1A4060","AE":"#802020","LB + EG":"#1A5030","VS":"#1A3050",
                 "EX":"#404020","CM + MH":"#403020","Oncology":"#303060","Other Dom":"#303030"}
    for grp,doms in DOMAIN_GROUPS:
        grp_f=[f for d in doms for f in dom_map.get(d,[])]
        if not grp_f: continue
        make_sheet(wb.add_worksheet(grp[:31]),grp_f,DOM_TAB_COL.get(grp,"#303040"))

    # -- Files sheet
    ws_f=wb.add_worksheet("Files"); ws_f.set_tab_color("#404060"); ws_f.freeze_panes(1,0)
    fhdr=["Filename","Type","Rows","Cols","Size (B)","Variables (preview)","Status"]
    fwid=[32,14,7,6,12,52,36]
    for ci,(h,w) in enumerate(zip(fhdr,fwid)):
        ws_f.write(0,ci,h,HDR); ws_f.set_column(ci,ci,w)
    for ri,(fn,m) in enumerate(files_meta.items(),1):
        vs=", ".join((m.get("variables") or [])[:6])
        note=m.get("parse_error","") or m.get("parse_note","")
        st=("WARN: "+note[:32]) if note else "OK"
        fc_f="#880000" if m.get("parse_error") else "#1A5030" if m.get("rows",0)>0 else "#505020"
        bg_f="FFE8E8" if m.get("parse_error") else "F0FFF4" if m.get("rows",0)>0 else "FAFAF0"
        rf_f=wb.add_format({"font_name":"Calibri","font_size":9,"border":1,"font_color":fc_f,"bg_color":"#"+bg_f})
        for ci,v in enumerate([fn,m.get("type",""),m.get("rows",0),m.get("cols",0),m.get("size",0),vs,st]):
            ws_f.write(ri,ci,v,rf_f)

    wb.close(); buf.seek(0); return buf.read()


def _xl_openpyxl(findings, files_meta, enabled_ids):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb=openpyxl.Workbook(); now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    thin=Side(style="thin",color="C0C8D8"); bdr=Border(left=thin,right=thin,top=thin,bottom=thin)
    def hdr(ws,r,c,v):
        ce=ws.cell(row=r,column=c,value=v)
        ce.font=Font(name="Calibri",bold=True,color="FFFFFF",size=10)
        ce.fill=PatternFill("solid",fgColor="1C2670"); ce.border=bdr
        ce.alignment=Alignment(wrap_text=True,vertical="center")
    def dat(ws,r,c,v,risk="structural",bold=False):
        bg=XL_RISK_BG.get(risk,"F8F8FC"); fc=XL_RISK_FC.get(risk,"202020")
        ce=ws.cell(row=r,column=c,value=v)
        ce.font=Font(name="Calibri",size=9,color="#"+fc,bold=bold)
        ce.fill=PatternFill("solid",fgColor="#"+bg); ce.border=bdr
        ce.alignment=Alignment(wrap_text=True,vertical="top")
    COLS=["ID","Severity","Risk","Subject","Domain","Layer","Category",
          "Check Description","Finding Detail","Source","Data","Waiver Note"]
    active=[f for f in findings if not f.get("waived") and not f.get("dep_warning")]
    waived=[f for f in findings if f.get("waived")]
    def write_sheet(ws,flist,title):
        ws.title=title[:31]
        for ci,h in enumerate(COLS,1): hdr(ws,1,ci,h)
        ws.freeze_panes="A2"
        for ri,f in enumerate(flist,2):
            risk=f.get("risk","structural")
            vals=[f.get("fid",""),f.get("sev",""),RISK_LABEL.get(risk,risk),
                  "GLOBAL" if f.get("subj","")=="ALL" else (f.get("subj","") or "-"),
                  _dom(f),f.get("layer",""),f.get("cat",""),f.get("label",""),
                  f.get("detail",""),f.get("source",""),
                  "ACTUAL" if f.get("actual") else "DEMO",f.get("waiver_note","")]
            for ci,v in enumerate(vals,1):
                dat(ws,ri,ci,v,risk,ci in (4,5))
    ws0=wb.active; ws0.title="Summary"
    ws0["A1"]=f"SDTM CIS v8.0 | {now}"
    ws0["A1"].font=Font(name="Calibri",bold=True,size=13,color="1A2870")
    write_sheet(wb.create_sheet("Blockers"),        [f for f in active if f["risk"]=="submission-blocker"],"Blockers")
    write_sheet(wb.create_sheet("Medical Concerns"),[f for f in active if f["risk"]=="medical-concern"],  "Medical Concerns")
    write_sheet(wb.create_sheet("Structural"),      [f for f in active if f["risk"]=="structural"],       "Structural")
    write_sheet(wb.create_sheet("Advisory"),        [f for f in active if f["risk"]=="advisory"],         "Advisory")
    write_sheet(wb.create_sheet("All Findings"),    active,"All Findings")
    write_sheet(wb.create_sheet("Waived"),          waived,"Waived")
    dom_map={}
    for f in active: dom_map.setdefault(_dom(f),[]).append(f)
    for grp,doms in DOMAIN_GROUPS:
        grp_f=[f for d in doms for f in dom_map.get(d,[])]
        if grp_f: write_sheet(wb.create_sheet(grp[:31]),grp_f,grp[:31])
    buf=io.BytesIO(); wb.save(buf); buf.seek(0); return buf.read()
