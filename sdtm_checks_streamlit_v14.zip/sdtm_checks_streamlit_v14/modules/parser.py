"""
modules/parser.py  v8.0
Full XPT v5 row reader (no external deps).
pyreadstat used for SAS7BDAT if available, falls back to header scan.
"""
import re, csv, io, json, struct


class FileParser:
    TYPE_MAP = {
        ".sas7bdat": "SAS Dataset", ".xpt": "XPT Transport",
        ".csv": "CSV", ".xlsx": "Excel", ".xls": "Excel (legacy)",
        ".json": "JSON", ".xml": "XML/Define", ".txt": "Text", ".pdf": "PDF",
    }

    @staticmethod
    def analyze(raw_bytes: bytes, fname: str, ext: str) -> dict:
        meta = {
            "filename": fname, "size": len(raw_bytes),
            "type": FileParser.TYPE_MAP.get(ext, "Unknown"),
            "ext": ext, "rows": 0, "cols": 0, "variables": [], "data": [],
        }
        try:
            if ext == ".csv":
                FileParser._csv(raw_bytes, meta)
            elif ext in (".xlsx", ".xls"):
                FileParser._xlsx(raw_bytes, meta)
            elif ext == ".xpt":
                FileParser._xpt_full(raw_bytes, meta)
            elif ext == ".sas7bdat":
                FileParser._sas7bdat_full(raw_bytes, meta)
            elif ext == ".json":
                FileParser._json(raw_bytes, meta)
            elif ext == ".xml":
                FileParser._xml(raw_bytes, meta)
        except Exception as e:
            meta["parse_error"] = str(e)
        return meta

    # ------------------------------------------------------------------
    @staticmethod
    def _csv(data, meta):
        text = data.decode("utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        rows = []
        for i, row in enumerate(reader):
            rows.append({k: (v or "") for k, v in row.items()})
            if i >= 4999:
                break
        meta["variables"] = list(rows[0].keys()) if rows else []
        meta["cols"]      = len(meta["variables"])
        meta["rows"]      = len(rows)
        meta["data"]      = rows

    @staticmethod
    def _xlsx(data, meta):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.active
        all_rows = list(ws.iter_rows(values_only=True))
        if not all_rows:
            wb.close(); return
        header = [str(h) if h is not None else "" for h in all_rows[0]]
        rows = []
        for r in all_rows[1:5001]:
            rows.append(dict(zip(header, [str(v) if v is not None else "" for v in r])))
        meta["variables"] = header
        meta["cols"]      = len(header)
        meta["rows"]      = len(rows)
        meta["data"]      = rows
        wb.close()

    # ------------------------------------------------------------------
    # XPT v5 full row reader (pure stdlib)
    # SAS XPT v5 spec: 80-byte records, NAMESTR=140 bytes, obs records follow
    # ------------------------------------------------------------------
    @staticmethod
    def _xpt_full(data: bytes, meta: dict):
        """Read a SAS XPT v5 transport file into list-of-dicts (up to 5000 rows)."""
        if len(data) < 480:
            # Too small - fall back to header scan
            FileParser._xpt_header_only(data, meta)
            return
        try:
            parsed = FileParser._parse_xpt(data)
            if parsed["data"]:
                meta["variables"] = parsed["names"]
                meta["cols"]      = len(parsed["names"])
                meta["rows"]      = len(parsed["data"])
                meta["data"]      = parsed["data"]
            else:
                # Got column names but no rows
                meta["variables"] = parsed["names"]
                meta["cols"]      = len(parsed["names"])
                meta["data"]      = []
                meta["rows"]      = 0
        except Exception as e:
            # Fall back to header-only scan
            FileParser._xpt_header_only(data, meta)
            meta["parse_error"] = f"XPT row parse failed ({e}), headers only"

    @staticmethod
    def _parse_xpt(data: bytes) -> dict:
        """Full XPT v5 parser. Returns {names, types, lengths, data}."""
        buf = io.BytesIO(data)

        def read_record():
            return buf.read(80)

        def read_n_records(n):
            return buf.read(80 * n)

        # ---- File header: 3 records ----
        rec1 = read_record()
        if not rec1.startswith(b"HEADER RECORD"):
            raise ValueError("Not an XPT file")
        read_record()   # SAS version info
        read_record()   # creation datetime

        # ---- Scan forward to NAMESTR HEADER (handles variable member header counts) ----
        # Real SAS XPTs vary: some have MEMBER+DSCRPTR+name (3 recs), others differ.
        # We read up to 10 records until we find the NAMESTR HEADER RECORD.
        rec_ns_hdr = None
        for _ in range(10):
            rec = read_record()
            if not rec or len(rec) < 8:
                raise ValueError("Unexpected EOF before NAMESTR header")
            if b"NAMESTR" in rec and b"HEADER" in rec:
                rec_ns_hdr = rec
                break

        if rec_ns_hdr is None:
            raise ValueError("NAMESTR HEADER RECORD not found within expected range")

        # rec_ns_hdr is already set to the NAMESTR record from the scan above
        # The variable count sits at bytes 48-55 of the 80-byte header:
        # "HEADER RECORD*******NAMESTR HEADER RECORD!!!!!!!{nvar:8d}OBSERVATIONS..."
        # "OBSERVATIONS" is frequently truncated at the 80-byte boundary, so
        # extract by byte position rather than regex.
        nvar = 0
        try:
            nv_field = rec_ns_hdr[48:56].decode("ascii","replace").strip()
            if nv_field.isdigit():
                nvar = int(nv_field)
        except Exception:
            pass
        if nvar == 0:
            # Fallback: scan for first run of digits followed by OBS
            ns_text = rec_ns_hdr.decode("ascii","replace")
            m = re.search(r"(\d+)\s*OBS", ns_text)
            if m:
                try: nvar = int(m.group(1))
                except ValueError: pass
        if nvar == 0:
            raise ValueError("Could not determine variable count")

        # ---- Read NAMESTR blocks (140 bytes each) ----
        ns_total_bytes = nvar * 140
        # Round up to 80-byte record boundary
        ns_padded = ((ns_total_bytes + 79) // 80) * 80
        ns_data   = buf.read(ns_padded)

        names   = []
        types   = []   # 1=numeric, 2=char
        lengths = []
        formats = []

        for i in range(nvar):
            ns = ns_data[i*140:(i+1)*140]
            if len(ns) < 140:
                break
            ntype  = struct.unpack(">h", ns[0:2])[0]   # 1=num, 2=char
            length = struct.unpack(">h", ns[2:4])[0]    # field length in obs record
            # name is at offset 8, padded to 8 chars
            name   = ns[8:16].decode("ascii","replace").strip()
            fmt    = ns[24:32].decode("ascii","replace").strip()
            if not name:
                name = f"VAR{i+1}"
            names.append(name)
            types.append(ntype)
            lengths.append(max(length, 1))
            formats.append(fmt)

        if not names:
            raise ValueError("No variable names parsed")

        # ---- OBS header record ----
        obs_hdr = read_record()
        # Extract true row count from OBS header: "...NNNNNNNNOBSERVATIONS..."
        nobs = 0
        m = re.search(rb"(\d+)\s*OBSERVATIONS", obs_hdr)
        if m:
            try:
                nobs = int(m.group(1))
            except ValueError:
                nobs = 0

        # Read observations - stop at nobs (from header) or EOF
        obs_len = sum(lengths)
        if obs_len == 0:
            return {"names": names, "types": types, "lengths": lengths, "data": []}

        obs_data = buf.read()   # rest of file

        rows = []
        pos  = 0
        MAX_ROWS = min(nobs, 5000) if nobs > 0 else 5000
        while pos + obs_len <= len(obs_data) and len(rows) < MAX_ROWS:
            obs = obs_data[pos:pos + obs_len]
            row = {}
            field_pos = 0
            for j, name in enumerate(names):
                flen  = lengths[j]
                ftype = types[j]
                raw   = obs[field_pos:field_pos + flen]
                if ftype == 2:
                    # Character
                    val = raw.decode("ascii","replace").rstrip("\x00 ")
                else:
                    # IBM floating point -> Python float
                    try:
                        fval = FileParser._ibm_float(raw, flen)
                        import math
                        val = "" if (math.isnan(fval) or math.isinf(fval)) else str(fval)
                    except Exception:
                        val = ""
                row[name] = val
                field_pos += flen
            rows.append(row)
            pos += obs_len

        return {"names": names, "types": types, "lengths": lengths, "data": rows}

    @staticmethod
    def _ibm_float(raw: bytes, length: int) -> float:
        """Convert IBM 370 floating point (4 or 8 bytes) to Python float."""
        if len(raw) < length or all(b == 0 for b in raw):
            return float("nan")
        # Pad to 8 bytes for double
        b = bytearray(raw).ljust(8, b"\x00")
        sign     = (b[0] & 0x80) >> 7
        exponent = (b[0] & 0x7F) - 64
        mantissa = 0
        for i in range(1, 8):
            mantissa = (mantissa << 8) | b[i]
        value = mantissa * (16 ** (exponent - 14))
        return -value if sign else value

    @staticmethod
    def _xpt_header_only(data: bytes, meta: dict):
        """Fallback: extract only variable names from XPT header."""
        if len(data) < 240:
            return
        raw = data[240:]
        pos, names = 0, []
        while pos + 140 <= len(raw):
            chunk = raw[pos:pos+140]
            try:
                ntype = struct.unpack(">h", chunk[0:2])[0]
            except struct.error:
                break
            if ntype not in (1, 2):
                break
            name = chunk[8:16].decode("ascii","replace").strip()
            if name:
                names.append(name)
            pos += 140
        meta["variables"] = names
        meta["cols"]      = len(names)
        meta["data"]      = []

    # ------------------------------------------------------------------
    # SAS7BDAT: try pyreadstat, fall back to header scan
    # ------------------------------------------------------------------
    @staticmethod
    def _sas7bdat_full(data: bytes, meta: dict):
        """Attempt full SAS7BDAT read via pyreadstat; fall back to header scan."""
        try:
            import pyreadstat
            import tempfile, os
            with tempfile.NamedTemporaryFile(suffix=".sas7bdat", delete=False) as tmp:
                tmp.write(data)
                tmp_path = tmp.name
            try:
                df, sas_meta = pyreadstat.read_sas7bdat(
                    tmp_path, row_limit=5000, metadataonly=False
                )
                rows = df.fillna("").astype(str).to_dict("records")
                meta["variables"] = list(df.columns)
                meta["cols"]      = len(df.columns)
                meta["rows"]      = len(rows)
                meta["data"]      = rows
            finally:
                os.unlink(tmp_path)
            return
        except ImportError:
            pass
        except Exception as e:
            meta["parse_error"] = f"pyreadstat: {e}"

        # Fallback: header scan
        FileParser._sas7bdat_header(data, meta)

    @staticmethod
    def _sas7bdat_header(data: bytes, meta: dict):
        """Extract variable names from SAS7BDAT binary header (no row data)."""
        text = data[:131072].decode("ascii", errors="replace")
        skip = {"SAS","SASLIB","UNIX","WINDOWS","W32","AMD64","LINUX","X86","IA64"}
        candidates = re.findall(r"\b[A-Z][A-Z0-9_]{0,31}\b", text)
        seen, names = set(), []
        for c in candidates:
            if c not in seen and c not in skip and len(c) <= 32:
                seen.add(c)
                names.append(c)
            if len(names) >= 200:
                break
        # Heuristic: keep only SDTM-like names (short, uppercase, common patterns)
        sdtm_names = [n for n in names if len(n) <= 8 or any(
            n.startswith(p) for p in ["USUBJID","STUDYID","SITEID","SUBJID",
                                       "DOMAIN","--","AE","CM","DM","DS","EG",
                                       "EX","LB","MH","PR","QS","SV","VS"]
        )]
        final = sdtm_names[:50] if sdtm_names else names[:50]
        meta["variables"] = final
        meta["cols"]      = len(final)
        meta["data"]      = []
        meta["rows"]      = 0
        meta["parse_note"] = "Header scan only. Install pyreadstat for full row data."

    # ------------------------------------------------------------------
    @staticmethod
    def _json(data, meta):
        obj = json.loads(data.decode("utf-8", errors="replace"))
        if isinstance(obj, list) and obj:
            meta["variables"] = list(obj[0].keys()) if isinstance(obj[0], dict) else []
            meta["rows"]      = len(obj)
            meta["cols"]      = len(meta["variables"])
            meta["data"]      = obj[:5000]
        elif isinstance(obj, dict):
            meta["variables"] = list(obj.keys())
            meta["cols"]      = len(meta["variables"])
            meta["rows"]      = 1
            meta["data"]      = [obj]

    @staticmethod
    def _xml(data, meta):
        text  = data.decode("utf-8", errors="replace")
        items = re.findall(r'OID="([^"]+)"', text)
        meta["variables"] = items[:50]
        meta["cols"]      = len(items)
        meta["rows"]      = text.count("<ItemDef")
        meta["type"]      = "Define-XML"
        meta["data"]      = []
