# SDTM Clinical Integrity Suite — v14 Changelog

## v14 (2026-03) — SUPP Merge + SAS Code + AgGrid

### 1. SUPP Domain Back-Merge (engine.py)

**Architecture:** Two-pass `_map_domains()`.

- **Pass 1** — collects all parent domain rows as before
- **Pass 2** — detects every `SUPPXX` file by filename prefix or `RDOMAIN` column,
  pivots `QNAM/QVAL` to wide format using `pandas.pivot_table`, and
  left-joins onto the parent domain using `USUBJID + IDVAR/IDVARVAL` keys
- Join key logic: prefers `{DOM}SEQ` (e.g. `AESEQ` for `SUPPAE`); falls back to
  `USUBJID`-only join when no `--SEQ` column exists
- After merge, all SUPP variables (e.g. `SAENARR`, `AECONTRT`, `DTHCAUS`) appear
  as real columns in the parent domain DataFrame — checks run against the enriched data
- SUPP merge log exposed to UI via `Files → SUPP Back-Merge Log` panel
- No crash when SUPP loaded without corresponding parent domain

**New structural checks now implemented (previously registry-only stubs):**

| Check | Description |
|-------|-------------|
| S016  | QNAM uses a reserved standard SDTM variable name |
| S017  | SUPP-- RDOMAIN does not match parent domain code |
| S018  | SUPP-- IDVAR/IDVARVAL does not resolve to an existing parent record |
| AE014 | AESER=Y but SAE narrative (SUPPAE.SAENARR) blank/missing |

### 2. SAS Code Generation (engine.py)

- Every finding now carries a `sas_code` field
- Generator: `_sas_code(domain, check_id, usubjid, detail)` builds a `PROC SQL` snippet
- Smart extraction: pulls date column+value from detail text for tighter `WHERE` clause
- TESTCD extraction: adds `LBTESTCD`/`VSTESTCD` clause when present in detail
- GLOBAL findings (USUBJID=ALL): no subject filter emitted
- Shown as collapsible **"SAS Code"** expander under every finding card
- Also surfaced in AgGrid tab when a row is selected

**Example output:**
```sas
/* CIS Check: AE004 | Finding: AESTDTC='2024-06-15' after AEENDTC='2024-06-10' */
PROC SQL;
  SELECT *
  FROM SDTM.AE
  WHERE 1=1
    AND USUBJID = 'GS-001-007'
    AND AESTDTC = '2024-06-15';
QUIT;
```

### 3. AgGrid Interactive Review Tab (app.py)

- New **⚡ AgGrid Review** tab (7th tab)
- Risk-category cell colouring via `JsCode`
- Column pinning: ID + Subject pinned left
- Full column resize, sort, filter
- Row selection → SAS code display below grid
- Multi-select risk filter + domain text filter + hide-waived toggle
- **CSV export** of filtered view
- Graceful fallback to `st.dataframe` + SAS code selectbox if `streamlit-aggrid` not installed
- `streamlit-aggrid>=0.3.4` added to `requirements.txt`

### 4. Dashboard / UX Improvements (app.py)

- Finding cards show **SUPP-MERGED** badge when the finding used back-merged data
- Files tab: SUPP Back-Merge Log panel shows merge status per domain, flags S016/S017/S018
- SUPP merge log stored in session state (`supp_merge_log`)

### 5. Regression — All v13 fixes retained

22/22 tests pass covering:
fingerprint stability, AE008 named column, LB003 dedup, XPT NaN,
VS001 VISITNUM normalisation, LB011 temporal window, INT005 SV skip,
INT002 DTC column selection, registry thread safety, HTML/Excel audit metadata,
waiver persistence, demo suppression, SUPP back-merge (T05–T12).
