"""
CIS FastAPI Gateway  -  Email-only auth + activity tracking
============================================================
- No passwords. Enter work email -> session cookie -> access granted.
- Activity logged to activity.db (SQLite).
- Reverse-proxies HTTP + WebSocket to Streamlit on localhost:8501.
- Supports up to ~10 concurrent internal users.

Run:
    uvicorn gateway:app --host 0.0.0.0 --port 8000
"""

import sqlite3, time, secrets, re, os
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI, Request, Response, Form, HTTPException, WebSocket
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
import websockets

# ── Config ────────────────────────────────────────────────────────────────────
STREAMLIT_URL   = os.environ.get("STREAMLIT_URL", "http://127.0.0.1:8501")
STREAMLIT_WS    = STREAMLIT_URL.replace("http://", "ws://").replace("https://", "wss://")
DB_PATH         = Path(__file__).parent / "activity.db"
COOKIE_NAME     = "cis_session"
SESSION_HOURS   = int(os.environ.get("SESSION_HOURS", "8"))
ALLOWED_DOMAINS = os.environ.get("ALLOWED_DOMAINS", "")   # "gilead.com" or "" = any
# Fix: only non-empty emails are admins
_raw_admin      = os.environ.get("ADMIN_EMAILS", "")
ADMIN_EMAILS    = {e.strip().lower() for e in _raw_admin.split(",") if e.strip()}

# ── DB ────────────────────────────────────────────────────────────────────────
def _db():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def _init_db():
    con = _db()
    con.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY, email TEXT NOT NULL,
            created_at REAL NOT NULL, expires_at REAL NOT NULL,
            ip TEXT, user_agent TEXT
        );
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL NOT NULL, ts_str TEXT NOT NULL,
            email TEXT NOT NULL, ip TEXT,
            action TEXT NOT NULL, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_act_email ON activity(email);
        CREATE INDEX IF NOT EXISTS idx_act_ts    ON activity(ts);
    """)
    con.commit(); con.close()

_init_db()

# ── Helpers ───────────────────────────────────────────────────────────────────
def _log(email: str, ip: str, action: str, detail: str = ""):
    try:
        con = _db()
        now = time.time()
        con.execute(
            "INSERT INTO activity(ts,ts_str,email,ip,action,detail) VALUES(?,?,?,?,?,?)",
            (now, datetime.utcfromtimestamp(now).strftime("%Y-%m-%d %H:%M:%S UTC"),
             email, ip, action, detail[:500])
        )
        con.commit(); con.close()
    except Exception:
        pass

def _make_session(email: str, ip: str, ua: str) -> str:
    token = secrets.token_urlsafe(32)
    now   = time.time()
    con   = _db()
    con.execute(
        "INSERT INTO sessions(token,email,created_at,expires_at,ip,user_agent) VALUES(?,?,?,?,?,?)",
        (token, email.lower().strip(), now, now + SESSION_HOURS*3600, ip, ua[:300])
    )
    con.commit(); con.close()
    _log(email, ip, "LOGIN")
    return token

def _validate_session(token: str) -> Optional[str]:
    if not token:
        return None
    try:
        con = _db()
        row = con.execute(
            "SELECT email,expires_at FROM sessions WHERE token=?", (token,)
        ).fetchone()
        con.close()
        if row and time.time() <= row["expires_at"]:
            return row["email"]
    except Exception:
        pass
    return None

def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for", "")
    return xff.split(",")[0].strip() if xff else (request.client.host if request.client else "unknown")

def _validate_email(email: str) -> bool:
    email = email.strip().lower()
    if not re.match(r"^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$", email):
        return False
    if ALLOWED_DOMAINS:
        domain = email.split("@")[-1]
        allowed = [d.strip() for d in ALLOWED_DOMAINS.split(",") if d.strip()]
        if allowed and domain not in allowed:
            return False
    return True

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="CIS Gateway", docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Login page ────────────────────────────────────────────────────────────────
LOGIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CIS - Sign In</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Orbitron:wght@700;900&display=swap');
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#070810;min-height:100vh;display:flex;align-items:center;
     justify-content:center;font-family:'JetBrains Mono',monospace;color:#c0cce8}}
.card{{background:linear-gradient(145deg,#0e1028,#090c1c);border:1px solid #1e2448;
       border-radius:12px;padding:2.8rem 2.4rem;width:100%;max-width:420px;
       box-shadow:0 8px 40px rgba(0,0,0,.6)}}
.logo{{font-family:'Orbitron',monospace;font-size:1.7rem;font-weight:900;
       background:linear-gradient(120deg,#60a8ff,#a0d0ff,#c0e8ff);
       -webkit-background-clip:text;-webkit-text-fill-color:transparent;
       background-clip:text;letter-spacing:.06em;text-align:center}}
.sub{{font-size:.62rem;text-transform:uppercase;letter-spacing:.14em;
      color:#5870a8;text-align:center;margin:.4rem 0 2rem}}
.divider{{height:1px;background:linear-gradient(90deg,transparent,#2848d0,transparent);
           margin:1.4rem 0 1.6rem;opacity:.6}}
label{{font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;
       color:#6878a8;display:block;margin-bottom:.45rem}}
input[type=email]{{width:100%;background:#0b0d1c;border:1px solid #1e2448;
  border-radius:6px;padding:.75rem 1rem;font-family:'JetBrains Mono',monospace;
  font-size:.88rem;color:#d0dcf8;outline:none;transition:border-color .2s,box-shadow .2s}}
input[type=email]:focus{{border-color:#3060c0;box-shadow:0 0 0 3px rgba(48,96,192,.18)}}
button{{width:100%;margin-top:1.2rem;padding:.8rem 1rem;
  background:linear-gradient(135deg,#0d2070,#1840cc);border:1px solid #3d70e8;
  border-radius:6px;font-family:'JetBrains Mono',monospace;font-size:.82rem;
  font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#b0d0ff;
  cursor:pointer;box-shadow:0 0 18px rgba(40,100,220,.22);transition:all .2s}}
button:hover{{color:#d0e8ff;box-shadow:0 0 28px rgba(60,140,255,.45);border-color:#5a90ff}}
.msg{{font-size:.74rem;margin-top:.9rem;text-align:center;padding:.5rem .8rem;
      border-radius:5px;border:1px solid transparent}}
.msg.err{{color:#e06060;background:rgba(220,80,80,.08);border-color:rgba(220,80,80,.22)}}
.note{{font-size:.64rem;color:#4858a8;text-align:center;margin-top:1.4rem;line-height:1.7}}
.powered{{font-size:.58rem;color:#282e50;text-align:center;margin-top:1.8rem}}
</style>
</head>
<body>
<div class="card">
  <div class="logo">CIS v15</div>
  <div class="sub">SDTM Clinical Integrity Suite</div>
  <div class="divider"></div>
  <form method="post" action="/login">
    <label for="email">Work Email Address</label>
    <input type="email" id="email" name="email" placeholder="you@company.com"
           required autofocus autocomplete="email" value="{email_prefill}">
    <button type="submit">Enter &rarr;</button>
    {msg_html}
  </form>
  <div class="note">
    No password required. Enter any valid work email to access.<br>
    All access is logged for compliance and audit purposes.
  </div>
  <div class="powered">CIS Gateway - Internal Use Only</div>
</div>
</body>
</html>"""

@app.get("/login", response_class=HTMLResponse)
async def login_page(error: str = ""):
    msg = f'<div class="msg err">{error}</div>' if error else ""
    return LOGIN_HTML.format(msg_html=msg, email_prefill="")

@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request, email: str = Form(...)):
    ip = _client_ip(request)
    ua = request.headers.get("user-agent", "")
    email = email.strip().lower()

    if not _validate_email(email):
        hint = f" (allowed domains: {ALLOWED_DOMAINS})" if ALLOWED_DOMAINS else ""
        msg = f'<div class="msg err">Invalid or unauthorised email{hint}.</div>'
        return HTMLResponse(LOGIN_HTML.format(msg_html=msg, email_prefill=email))

    token = _make_session(email, ip, ua)
    resp = RedirectResponse(url="/app", status_code=303)
    resp.set_cookie(COOKIE_NAME, token, max_age=SESSION_HOURS*3600, httponly=True, samesite="lax")
    return resp

@app.get("/logout")
async def logout(request: Request):
    token = request.cookies.get(COOKIE_NAME, "")
    if token:
        email = _validate_session(token) or "unknown"
        _log(email, _client_ip(request), "LOGOUT")
        try:
            con = _db()
            con.execute("DELETE FROM sessions WHERE token=?", (token,))
            con.commit(); con.close()
        except Exception:
            pass
    resp = RedirectResponse(url="/login", status_code=302)
    resp.delete_cookie(COOKIE_NAME)
    return resp

# ── Admin view ────────────────────────────────────────────────────────────────
ADMIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="30">
<title>CIS - Activity Log</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');
body{{background:#070810;color:#b0bcd8;font-family:'JetBrains Mono',monospace;font-size:.78rem;padding:2rem}}
h2{{color:#60a8ff;margin-bottom:1rem;font-size:1rem;letter-spacing:.08em}}
.meta{{font-size:.65rem;color:#3848a0;margin-bottom:1.5rem}}
table{{border-collapse:collapse;width:100%;margin-top:1rem}}
th{{background:#0e1028;color:#6878a8;text-transform:uppercase;letter-spacing:.08em;
    padding:.5rem .7rem;text-align:left;border-bottom:1px solid #1e2448;font-size:.68rem}}
td{{padding:.45rem .7rem;border-bottom:1px solid #111628;vertical-align:top;max-width:400px;word-break:break-all}}
tr:hover td{{background:#0d0f20}}
.t-login{{color:#50e0a0}}.t-logout{{color:#8090b8}}
.t-run{{color:#e06060}}.t-download{{color:#e0a040}}.t-page{{color:#5080e0}}
.sessions{{margin-bottom:2.5rem}}
a{{color:#5080e0;text-decoration:none}}
.logout-btn{{float:right;color:#e06060;border:1px solid #e06060;padding:.2rem .6rem;border-radius:4px}}
.logout-btn:hover{{background:rgba(224,96,96,.1)}}
.note{{font-size:.62rem;color:#283060;margin-top:.5rem}}
</style>
</head>
<body>
<h2>CIS Activity Log &nbsp;<a class="logout-btn" href="/logout">Logout</a></h2>
<div class="meta">Auto-refreshes every 30s &bull; {n_sess} active session(s)</div>
<div class="sessions">
<b style="color:#6878a8">Active Sessions</b>
<table>
<tr><th>Email</th><th>IP</th><th>Login Time</th><th>Expires</th></tr>
{sess_rows}
</table>
</div>
<b style="color:#6878a8">Recent Activity (last 200 events)</b>
<table>
<tr><th>Time (UTC)</th><th>Email</th><th>IP</th><th>Action</th><th>Detail</th></tr>
{act_rows}
</table>
<div class="note">Logged events: LOGIN, LOGOUT, PAGE, RUN, DOWNLOAD</div>
</body></html>"""

@app.get("/admin", response_class=HTMLResponse)
async def admin_view(request: Request):
    token = request.cookies.get(COOKIE_NAME, "")
    email = _validate_session(token)
    if not email:
        return RedirectResponse("/login")
    # If ADMIN_EMAILS is configured, check membership; otherwise allow any logged-in user
    if ADMIN_EMAILS and email not in ADMIN_EMAILS:
        return HTMLResponse(
            "<h3 style='font-family:monospace;color:#e06060;padding:2rem'>"
            "Admin access not configured. Set ADMIN_EMAILS in start_cis.bat<br><br>"
            "<a href='/app' style='color:#5080e0'>Back to app</a></h3>",
            status_code=403
        )

    con = _db()
    sessions = con.execute(
        "SELECT email,ip,created_at,expires_at FROM sessions WHERE expires_at>? ORDER BY created_at DESC",
        (time.time(),)
    ).fetchall()
    acts = con.execute(
        "SELECT ts_str,email,ip,action,detail FROM activity ORDER BY ts DESC LIMIT 200"
    ).fetchall()
    con.close()

    def _ts(t): return datetime.utcfromtimestamp(t).strftime("%m-%d %H:%M")
    cmap = {"LOGIN":"t-login","LOGOUT":"t-logout","RUN":"t-run","DOWNLOAD":"t-download","PAGE":"t-page"}

    sess_rows = "".join(
        f"<tr><td>{r['email']}</td><td>{r['ip']}</td>"
        f"<td>{_ts(r['created_at'])}</td><td>{_ts(r['expires_at'])}</td></tr>"
        for r in sessions
    ) or "<tr><td colspan='4' style='color:#283060'>No active sessions</td></tr>"

    act_rows = "".join(
        f"<tr><td>{r['ts_str']}</td><td>{r['email']}</td><td>{r['ip']}</td>"
        f"<td class='{cmap.get(r["action"],"t-page")}'>{r["action"]}</td>"
        f"<td>{r['detail'] or ''}</td></tr>"
        for r in acts
    ) or "<tr><td colspan='5' style='color:#283060'>No activity yet</td></tr>"

    return ADMIN_HTML.format(n_sess=len(sessions), sess_rows=sess_rows, act_rows=act_rows)

# ── WebSocket proxy (critical for Streamlit) ──────────────────────────────────
@app.websocket("/app/{path:path}")
async def ws_proxy(websocket: WebSocket, path: str):
    """Proxy WebSocket connections to Streamlit (_stcore/stream etc)."""
    token = websocket.cookies.get(COOKIE_NAME, "")
    email = _validate_session(token)
    if not email:
        await websocket.close(code=1008)
        return

    ws_target = f"{STREAMLIT_WS}/{path}"
    if websocket.query_string:
        ws_target += f"?{websocket.query_string.decode()}"

    await websocket.accept()

    try:
        async with websockets.connect(
            ws_target,
            additional_headers={"X-CIS-User": email},
            max_size=50 * 1024 * 1024,
        ) as ws_backend:
            import asyncio

            async def client_to_backend():
                try:
                    while True:
                        data = await websocket.receive_bytes()
                        await ws_backend.send(data)
                except Exception:
                    pass

            async def backend_to_client():
                try:
                    async for msg in ws_backend:
                        if isinstance(msg, bytes):
                            await websocket.send_bytes(msg)
                        else:
                            await websocket.send_text(msg)
                except Exception:
                    pass

            await asyncio.gather(client_to_backend(), backend_to_client())
    except Exception:
        try:
            await websocket.close()
        except Exception:
            pass

# ── HTTP proxy ────────────────────────────────────────────────────────────────
SKIP_LOG = {"_stcore", "static", "favicon", ".js", ".css", ".woff", ".png", ".ico", ".map"}

@app.get("/app")
@app.get("/app/{path:path}")
@app.post("/app/{path:path}")
async def http_proxy(request: Request, path: str = ""):
    token = request.cookies.get(COOKIE_NAME, "")
    email = _validate_session(token)
    if not email:
        return RedirectResponse(f"/login")

    ip = _client_ip(request)

    # Log meaningful actions only
    if not any(s in path for s in SKIP_LOG):
        action = "RUN" if "run" in path else "DOWNLOAD" if "download" in path or "report" in path else "PAGE"
        _log(email, ip, action, f"/{path}"[:200])

    target = f"{STREAMLIT_URL}/{path}"
    if request.url.query:
        target += f"?{request.url.query}"

    headers = {k: v for k, v in request.headers.items()
               if k.lower() not in ("host", "connection", "transfer-encoding")}
    headers["X-CIS-User"] = email

    async with httpx.AsyncClient(timeout=120, follow_redirects=False) as client:
        try:
            resp = await client.request(
                method=request.method,
                url=target,
                headers=headers,
                content=await request.body(),
            )
        except httpx.ConnectError:
            return HTMLResponse(
                "<div style='font-family:monospace;color:#e06060;padding:3rem;background:#07070d'>"
                "<h3>Streamlit is starting up...</h3>"
                "<p style='margin-top:1rem;color:#6878a8'>Please wait 10 seconds and refresh.</p>"
                "<script>setTimeout(()=>location.reload(),8000)</script></div>",
                status_code=503
            )

    resp_headers = {k: v for k, v in resp.headers.items()
                    if k.lower() not in ("content-encoding", "content-length",
                                         "transfer-encoding", "connection")}

    content = resp.content
    if "text/html" in resp.headers.get("content-type", ""):
        try:
            html = content.decode("utf-8")
            banner = (
                f'<div style="position:fixed;top:0;right:0;z-index:99999;'
                f'background:rgba(7,8,16,.95);border-bottom:1px solid #1e2448;'
                f'border-left:1px solid #1e2448;padding:.35rem .9rem;'
                f'font-family:JetBrains Mono,monospace;font-size:.68rem;'
                f'color:#6878a8;border-radius:0 0 0 6px;display:flex;align-items:center;gap:.5rem">'
                f'<span style="color:#50e0a0">&#9679;</span>'
                f'<span>{email}</span>'
                f'&nbsp;|&nbsp;'
                f'<a href="/logout" style="color:#e06060;text-decoration:none;font-weight:700">Logout</a>'
                f'</div>'
            )
            html = html.replace("</body>", banner + "</body>", 1)
            content = html.encode("utf-8")
        except Exception:
            pass

    return Response(content=content, status_code=resp.status_code, headers=resp_headers)

# ── Root & health ─────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return RedirectResponse("/app")

@app.get("/_health")
async def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}

# ── Startup ───────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def _startup():
    try:
        con = _db()
        deleted = con.execute("DELETE FROM sessions WHERE expires_at<?", (time.time(),)).rowcount
        con.commit(); con.close()
        if deleted:
            print(f"[CIS] Cleaned {deleted} expired session(s)")
    except Exception:
        pass
    print(f"[CIS] Gateway ready -> http://0.0.0.0:8000  |  Streamlit @ {STREAMLIT_URL}")
    print(f"[CIS] Activity DB: {DB_PATH}")
    print(f"[CIS] Admin emails: {ADMIN_EMAILS or '(any logged-in user can view /admin)'}")
    print(f"[CIS] Domain restriction: {ALLOWED_DOMAINS or 'none (any email accepted)'}")
