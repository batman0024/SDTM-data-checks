"""
CIS Theme Loader
Reads dark.css / light.css from the ui/ folder and injects them via
st.markdown().  Keeps all CSS out of app.py.
"""
import os
import streamlit as st

_UI_DIR = os.path.dirname(__file__)


def _read_css(filename: str) -> str:
    path = os.path.join(_UI_DIR, filename)
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def inject_theme(theme: str = "dark") -> None:
    """
    Inject base dark CSS always, then light overrides on top when
    theme == 'light'.  Call once near the top of app.py, after
    st.set_page_config().
    """
    dark_css = _read_css("dark.css")
    st.markdown(f"<style>\n{dark_css}\n</style>", unsafe_allow_html=True)

    if theme == "light":
        light_css = _read_css("light.css")
        st.markdown(f"<style>\n{light_css}\n</style>", unsafe_allow_html=True)


def inject_scroll_fab() -> None:
    """
    Inject the floating scroll-to-top button + JS.
    Call once near the top of app.py (after inject_theme).
    The FAB is defined in dark.css; this just adds the HTML+JS.
    """
    st.markdown(
        """
<div id="cis-scroll-top" title="Back to top">&#9650;</div>
<script>
(function(){
  function init(){
    var btn=document.getElementById('cis-scroll-top');
    if(!btn)return;
    var d=window.parent?window.parent.document:document;
    /* Try the main scroll container Streamlit uses */
    /* Try multiple selectors across Streamlit versions */
    var s = d.querySelector('[data-testid="stMain"]')
          || d.querySelector('[data-testid="stAppViewContainer"] > section')
          || d.querySelector('.main')
          || d.body;
    if (!s || s === d.documentElement) {
      /* Last resort: find the scrolling element */
      var all = d.querySelectorAll('*');
      for (var i = 0; i < all.length; i++) {
        if (all[i].scrollHeight > all[i].clientHeight + 100) {
          s = all[i]; break;
        }
      }
    }
    function chk(){btn.classList.toggle('visible', s.scrollTop > 260);}
    s.addEventListener('scroll', chk, {passive: true});
    btn.onclick = function(){ s.scrollTo({top:0, behavior:'smooth'}); };
    chk();
  }
  /* Run on load and again after Streamlit's DOM swap */
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  setTimeout(init, 1200);
})();
</script>
""",
        unsafe_allow_html=True,
    )
