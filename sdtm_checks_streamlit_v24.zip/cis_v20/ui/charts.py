"""
CIS Dashboard Charts
All Altair visualisations for the Summary Dashboard tab.
Imported by app.py:  from ui import render_dashboard_charts
"""
import pandas as pd
import streamlit as st

try:
    import altair as alt
    _HAS_ALTAIR = True
except ImportError:
    _HAS_ALTAIR = False

from .tokens import (
    RISK_LABELS,
    RISK_CHART_PALETTE,
    SEV_CHART_PALETTE,
    OUTCOME_CHART_PALETTE,
    LAYER_CHART_COLORS,
    DOMAIN_CHART_RANGE,
    CHART_DARK_BG,
    CHART_AXIS_CLR,
    CHART_GRID_CLR,
)

# ── helpers ───────────────────────────────────────────────────────────────────

def _cfg(ch, height: int):
    """Apply shared chart config (background, padding, no stroke)."""
    return (
        ch.properties(
            height=height,
            background=CHART_DARK_BG,
            padding={"left": 4, "right": 6, "top": 6, "bottom": 4},
        )
        .configure_view(strokeWidth=0)
    )


def _ax(label_limit: int = 120, angle: int = 0, label_color: str = CHART_AXIS_CLR):
    return alt.Axis(
        labelColor=label_color,
        tickColor=CHART_AXIS_CLR,
        domainColor=CHART_GRID_CLR,
        gridColor=CHART_GRID_CLR,
        labelAngle=angle,
        labelFont="JetBrains Mono",
        labelFontSize=10,
        labelLimit=label_limit,
    )


def _ax_noGrid(label_limit: int = 120, angle: int = 0, label_color: str = CHART_AXIS_CLR):
    return alt.Axis(
        labelColor=label_color,
        tickColor=CHART_AXIS_CLR,
        domainColor=CHART_GRID_CLR,
        labelAngle=angle,
        labelFont="JetBrains Mono",
        labelFontSize=10,
        labelLimit=label_limit,
    )


def _card(title: str):
    st.markdown(
        f'<div class="chart-card"><div class="chart-title">{title}</div>',
        unsafe_allow_html=True,
    )


def _end_card():
    st.markdown("</div>", unsafe_allow_html=True)


# ── individual charts ─────────────────────────────────────────────────────────

def _chart_risk(by_risk: dict):
    _card("Findings by Risk Category")
    df = pd.DataFrame([
        {"Risk": RISK_LABELS.get(k, k), "Count": v}
        for k, v in sorted(by_risk.items(), key=lambda x: -x[1])
    ])
    if not df.empty and _HAS_ALTAIR:
        domain = list(RISK_CHART_PALETTE.keys())
        rng    = list(RISK_CHART_PALETTE.values())
        ch = _cfg(
            alt.Chart(df)
            .mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4)
            .encode(
                x=alt.X("Risk:N", sort="-y", title=None, axis=_ax_noGrid(angle=0)),
                y=alt.Y("Count:Q", title=None, axis=_ax()),
                color=alt.Color("Risk:N",
                    scale=alt.Scale(domain=domain, range=rng), legend=None),
                tooltip=["Risk:N", "Count:Q"],
            ),
            200,
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


def _chart_severity(by_sev: dict):
    _card("Findings by Severity")
    df = pd.DataFrame([
        {"Severity": k, "Count": v}
        for k, v in sorted(by_sev.items(), key=lambda x: -x[1])
        if k != "NOTICE"
    ])
    if not df.empty and _HAS_ALTAIR:
        domain = list(SEV_CHART_PALETTE.keys())
        rng    = list(SEV_CHART_PALETTE.values())
        ch = _cfg(
            alt.Chart(df)
            .mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4)
            .encode(
                x=alt.X("Severity:N", sort="-y", title=None, axis=_ax_noGrid(angle=0)),
                y=alt.Y("Count:Q", title=None, axis=_ax()),
                color=alt.Color("Severity:N",
                    scale=alt.Scale(domain=domain, range=rng), legend=None),
                tooltip=["Severity:N", "Count:Q"],
            ),
            200,
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


def _chart_domain(active: list, domain_of_fn):
    _card("Findings by SDTM Domain (top 20)")
    dom_counts: dict = {}
    for f in active:
        d = domain_of_fn(f)
        dom_counts[d] = dom_counts.get(d, 0) + 1
    df = pd.DataFrame([
        {"Domain": k, "Count": v}
        for k, v in sorted(dom_counts.items(), key=lambda x: -x[1])[:20]
    ])
    if not df.empty and _HAS_ALTAIR:
        mx = max(1, df["Count"].max())
        ch = _cfg(
            alt.Chart(df)
            .mark_bar(cornerRadiusTopRight=4, cornerRadiusBottomRight=4)
            .encode(
                x=alt.X("Count:Q", title=None, axis=_ax()),
                y=alt.Y("Domain:N", sort="-x", title=None,
                    axis=_ax_noGrid(label_limit=70, label_color="#a0b4d8")),
                color=alt.Color("Count:Q",
                    scale=alt.Scale(range=DOMAIN_CHART_RANGE, domain=[0, mx]),
                    legend=None),
                tooltip=["Domain:N", "Count:Q"],
            ),
            max(160, len(df) * 22),
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


def _chart_layer(by_layer: dict):
    _card("By Layer")
    df = pd.DataFrame([
        {"Layer": k, "Count": v}
        for k, v in sorted(by_layer.items(), key=lambda x: -x[1])
    ])
    if not df.empty and _HAS_ALTAIR:
        n_layers = len(df)
        dh = max(320, 120 + n_layers * 22)
        ch = (alt.Chart(df)
            .mark_arc(innerRadius=40, outerRadius=85, cornerRadius=3)
            .encode(
                theta=alt.Theta("Count:Q"),
                color=alt.Color("Layer:N",
                    scale=alt.Scale(range=LAYER_CHART_COLORS),
                    legend=alt.Legend(
                        labelColor="#a0b4d8", titleColor=CHART_AXIS_CLR,
                        labelFont="JetBrains Mono", labelFontSize=10,
                        orient="right", symbolSize=80, padding=6,
                    )),
                tooltip=[alt.Tooltip("Layer:N", title="Layer"),
                         alt.Tooltip("Count:Q", title="Findings")],
            )
            .properties(height=dh, background=CHART_DARK_BG,
                        padding={"left": 8, "right": 8, "top": 10, "bottom": 10})
            .configure_view(strokeWidth=0)
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


def _chart_categories(by_cat: dict):
    _card("Top Finding Categories")
    df = pd.DataFrame([
        {"Category": k, "Count": v}
        for k, v in sorted(by_cat.items(), key=lambda x: -x[1])[:12]
    ])
    if not df.empty and _HAS_ALTAIR:
        ch = _cfg(
            alt.Chart(df)
            .mark_bar(cornerRadiusTopRight=4, cornerRadiusBottomRight=4)
            .encode(
                x=alt.X("Count:Q", title=None, axis=_ax()),
                y=alt.Y("Category:N", sort="-x", title=None,
                    axis=_ax_noGrid(label_limit=150, label_color="#a0b4d8")),
                color=alt.value("#7050d8"),
                tooltip=["Category:N", "Count:Q"],
            ),
            240,
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


def _chart_outcome(active: list):
    _card("Outcome Class")
    oc_counts: dict = {}
    for f in active:
        oc = f.get("outcome_class", "Other") or "Other"
        oc_counts[oc] = oc_counts.get(oc, 0) + 1
    df = pd.DataFrame([
        {"Class": k, "Count": v}
        for k, v in sorted(oc_counts.items(), key=lambda x: -x[1])
    ])
    if not df.empty and _HAS_ALTAIR:
        domain = list(OUTCOME_CHART_PALETTE.keys())
        rng    = list(OUTCOME_CHART_PALETTE.values())
        ch = (alt.Chart(df)
            .mark_arc(innerRadius=35, outerRadius=80, cornerRadius=3)
            .encode(
                theta=alt.Theta("Count:Q"),
                color=alt.Color("Class:N",
                    scale=alt.Scale(domain=domain, range=rng),
                    legend=alt.Legend(
                        labelColor="#a0b4d8", titleColor=CHART_AXIS_CLR,
                        labelFont="JetBrains Mono", labelFontSize=10,
                        orient="right", symbolSize=80, padding=6,
                    )),
                tooltip=[alt.Tooltip("Class:N", title="Outcome"),
                         alt.Tooltip("Count:Q", title="Findings")],
            )
            .properties(height=300, background=CHART_DARK_BG,
                        padding={"left": 8, "right": 8, "top": 10, "bottom": 10})
            .configure_view(strokeWidth=0)
        )
        st.altair_chart(ch, use_container_width=True)
    _end_card()


# ── public entry point ────────────────────────────────────────────────────────

def render_dashboard_charts(
    active: list,
    by_risk: dict,
    by_sev: dict,
    by_cat: dict,
    by_layer: dict,
    domain_of_fn,
) -> None:
    """
    Render all six dashboard charts in the standard 2+2+2 layout.
    Pass the active findings list and pre-computed count dicts from app.py.
    domain_of_fn  –  callable that returns the domain string for a finding.
    """
    if not _HAS_ALTAIR:
        st.warning(
            "altair is not installed. Run: pip install altair>=5  "
            "then restart the app."
        )
        return

    # Row 1: Risk + Severity
    col_l, col_r = st.columns(2)
    with col_l:
        _chart_risk(by_risk)
    with col_r:
        _chart_severity(by_sev)

    # Row 2: Domain (wide) + Layer (donut)
    col_l2, col_r2 = st.columns([3, 1])
    with col_l2:
        _chart_domain(active, domain_of_fn)
    with col_r2:
        _chart_layer(by_layer)

    # Row 3: Categories + Outcome class
    col_c1, col_c2 = st.columns([2, 1])
    with col_c1:
        _chart_categories(by_cat)
    with col_c2:
        _chart_outcome(active)
