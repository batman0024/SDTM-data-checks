@echo off
:: ============================================================
:: CIS Launcher  –  Streamlit + FastAPI Gateway
:: Clinical Integrity Suite v15  |  Internal Use Only
:: ============================================================
:: USAGE:
::   Double-click  start_cis.bat          -> normal start
::   start_cis.bat --admin admin@co.com   -> set admin email
::   start_cis.bat --domains gilead.com   -> restrict to domain
:: ============================================================

title CIS Clinical Integrity Suite

:: ── User-editable config ──────────────────────────────────────────────
set STREAMLIT_PORT=8501
set GATEWAY_PORT=8000
set APP_DIR=%~dp0sdtm_v18
set GATEWAY_FILE=%~dp0gateway.py
set SESSION_HOURS=8

:: Admin email (can view activity log at /admin) - set here or pass --admin flag
set ADMIN_EMAILS=

:: Restrict login to specific domains (comma-separated, blank = allow all)
set ALLOWED_DOMAINS=

:: Python / conda env — adjust if needed
set PYTHON_CMD=python
:: If using conda: set PYTHON_CMD=C:\ProgramData\Miniconda3\envs\cis\python.exe
:: If using venv:  set PYTHON_CMD=%~dp0.venv\Scripts\python.exe

:: ── Parse optional CLI args ───────────────────────────────────────────
:parse_args
if "%1"=="--admin"   (set ADMIN_EMAILS=%2 & shift & shift & goto parse_args)
if "%1"=="--domains" (set ALLOWED_DOMAINS=%2 & shift & shift & goto parse_args)
if "%1"=="--hours"   (set SESSION_HOURS=%2 & shift & shift & goto parse_args)
if "%1"=="--port"    (set GATEWAY_PORT=%2 & shift & shift & goto parse_args)

:: ── Banner ────────────────────────────────────────────────────────────
echo.
echo  ╔═══════════════════════════════════════════════════════╗
echo  ║   CIS Clinical Integrity Suite v15  –  Launcher      ║
echo  ║   SDTM Beyond-P21  ^|  Internal Use Only              ║
echo  ╚═══════════════════════════════════════════════════════╝
echo.
echo  [CONFIG]
echo    App dir      : %APP_DIR%
echo    Streamlit    : http://127.0.0.1:%STREAMLIT_PORT%  (internal)
echo    Gateway      : http://0.0.0.0:%GATEWAY_PORT%      (user-facing)
echo    Session hrs  : %SESSION_HOURS%
if not "%ADMIN_EMAILS%"=="" echo    Admin emails : %ADMIN_EMAILS%
if not "%ALLOWED_DOMAINS%"=="" echo    Domains      : %ALLOWED_DOMAINS%
echo.

:: ── Check Python ─────────────────────────────────────────────────────
%PYTHON_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Check PYTHON_CMD in this script.
    echo  Press any key to exit...
    pause >nul
    exit /b 1
)

:: ── Check dependencies ────────────────────────────────────────────────
echo  [CHECK] Verifying packages...
%PYTHON_CMD% -c "import streamlit, fastapi, uvicorn, httpx, altair" 2>nul
if errorlevel 1 (
    echo.
    echo  [INSTALL] Installing missing packages...
    %PYTHON_CMD% -m pip install streamlit fastapi uvicorn[standard] httpx altair pandas --quiet
    echo  [INSTALL] Done.
    echo.
)

:: ── Set environment variables for gateway ─────────────────────────────
set STREAMLIT_URL=http://127.0.0.1:%STREAMLIT_PORT%

:: ── Start Streamlit (background window) ──────────────────────────────
echo  [START] Launching Streamlit on port %STREAMLIT_PORT%...
start "CIS Streamlit" /min cmd /c (
    cd /d "%APP_DIR%" && %PYTHON_CMD% -m streamlit run app.py ^
        --server.port %STREAMLIT_PORT% ^
        --server.headless true ^
        --server.address 127.0.0.1 ^
        --browser.gatherUsageStats false ^
        2>&1
)

:: Brief pause to let Streamlit initialise
echo  [WAIT]  Waiting for Streamlit to start...
timeout /t 4 /nobreak >nul

:: ── Start FastAPI gateway (this window) ──────────────────────────────
echo  [START] Launching CIS Gateway on port %GATEWAY_PORT%...
echo.
echo  ┌─────────────────────────────────────────────────────┐
echo  │  Open your browser:  http://localhost:%GATEWAY_PORT%           │
echo  │  Activity log:       http://localhost:%GATEWAY_PORT%/admin     │
echo  │  Press Ctrl+C to stop both services                 │
echo  └─────────────────────────────────────────────────────┘
echo.

%PYTHON_CMD% -m uvicorn gateway:app ^
    --host 0.0.0.0 ^
    --port %GATEWAY_PORT% ^
    --log-level info

:: If gateway exits, also kill Streamlit window
echo.
echo  [STOP] Gateway stopped. Closing Streamlit...
taskkill /fi "WINDOWTITLE eq CIS Streamlit" /f >nul 2>&1
echo  [DONE] All services stopped.
pause
