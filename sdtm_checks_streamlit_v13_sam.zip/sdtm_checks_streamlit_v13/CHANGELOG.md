# SDTM Clinical Integrity Suite — Changelog

## v13 (2025-03) — Principal Engineer Audit Release

### Bugs Fixed
| ID | File | Issue | Fix |
|----|------|-------|-----|
| B1 | `engine.py` | `_chk_AE008` accessed groupby count via positional `r[0]` — fragile across pandas versions | Renamed to `_n` via `reset_index(name="_n")` |
| B2 | `engine.py` | `_chk_LB003` emitted one finding **per row** — 5 000-row LB with no ref range produced 5 000 cards (root cause of duplicate-scroll in Image 2) | Deduplicated per `(USUBJID, LBTESTCD)` — one finding per subject/test pair |
| B3 | `parser.py` | XPT IBM float all-zero values produced `str(nan)` = `"nan"` — comparisons to `""` silently failed across all numeric checks | `math.isnan/isinf` guard → empty string `""` |
| B4 | `engine.py` | `_chk_VS001` pivot key mixed `VISITNUM` `"2.0"` and `"2"` as distinct rows — impossible readings missed | Normalised via `int(float(v))` coercion before building pivot key |
| B5 | `engine.py` | `_chk_LB011` Hys Law used set intersection on `USUBJID` only — ALT peak at Month 1 and Bili peak at Month 6 (unrelated) incorrectly triggered | Added 30-day temporal co-occurrence window |

### Clinical Domain Corrections
| ID | Issue | Fix |
|----|-------|-----|
| C1 | `INT005` included `SV` (Screening Visits) — always precede consent by design → systematic false positives | Added `"SV"` and `"SE"` to `skip_domains` |
| C2 | `INT002` only checked `dtc_cols[0]` — domains with multiple DTC columns (e.g. LB has `LBDTC` + `LBENDTC`) only validated on first | Now selects domain-appropriate DTC col (prefers `{DOM}DTC` prefix match) |

### Architecture & Performance
| ID | Issue | Fix |
|----|-------|-----|
| A1 | `registry.py` global `_cache_mtime/_cache_checks` not thread-safe in multi-user Streamlit Cloud | Added `threading.Lock`; `_get_checks()` returns a list copy to prevent external mutation |
| A2 | IMP002 run metadata (`run_id`, YAML hash, dataset list) only shown in Streamlit header — absent from HTML and Excel reports | `make_html_report` and `make_excel_report` now accept `run_meta=` dict; HTML embeds an Audit Trail block; Excel Summary row A3 carries full audit string |

### IMP002 — Run Metadata / Audit Layer (completed)
- `run_id` (UUID), `checks_yaml_hash` (MD5), `cis_version`, `run_dataset_list` captured at validation time
- Displayed in Streamlit header after each run
- Embedded in HTML report (Audit Trail block below meta line)
- Embedded in Excel Summary sheet row A3
- Summary Dashboard now shows Actual / Demo / Waived breakdown alongside run ID

### IMP005 — Issue Fingerprinting (MD5, from v12)
- Sequential `F0001` IDs replaced with stable `MD5(domain|check_id|usubjid|detail)[:7]`
- Same issue always gets the same fingerprint across runs → waivers persist
- `seen_fids` deduplication in `run()` eliminates duplicate findings at assembly time

### Test Suite
- 22 automated tests added covering all fixes above
- All 22 pass on v13

---

## v12 (2025-03) — IMP002 + IMP005 initial implementation
- MD5 fingerprint IDs (IMP005)
- Run metadata session state + Streamlit header (IMP002 partial)
- Demo suppression when real files loaded

## v11 and earlier
- See README.txt
