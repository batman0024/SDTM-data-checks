"""
SDTM Clinical Integrity Suite v8.0
Streamlit Edition - Redesigned Dashboard
"""
import hashlib
import uuid
import streamlit as st
import pandas as pd
import os, datetime

from modules.registry import CHECKS, get_check, get_checks, LAYERS, CATEGORIES
from modules.engine   import ValidationEngine, DEMO_POOL
from modules.parser   import FileParser
from modules.reporter import make_html_report, make_excel_report

# __ PAGE CONFIG ______________________________________________________________
st.set_page_config(
    page_title="SDTM Clinical Integrity Suite v8.0",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={"About": "SDTM CIS v8.0 | Beyond-P21 | 135 Checks"},
)

# __ CSS ______________________________________________________________________
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Orbitron:wght@400;700;900&display=swap');

html,body,[class*="css"]{font-family:'JetBrains Mono','Courier New',monospace!important}
.stApp{background:#05060a!important}
.block-container{padding-top:.8rem!important;padding-bottom:2rem!important;max-width:100%!important}

[data-testid="stSidebar"]{background:#07080d!important;border-right:1px solid #181b2c!important}
[data-testid="stSidebar"] p,[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,[data-testid="stSidebar"] div{color:#a8b0cc!important}
[data-testid="stSidebar"] [data-testid="stCaptionContainer"]{color:#606888!important}

.suite-title{font-family:'Orbitron',monospace!important;font-size:1.5rem!important;
  font-weight:900!important;background:linear-gradient(135deg,#5898ff,#78b8ff,#98d8ff);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  letter-spacing:.04em;line-height:1.2}
.suite-sub{font-size:.68rem;color:#7880a8!important;text-transform:uppercase;
  letter-spacing:.1em;margin-top:.2rem}

/* Scorecard row */
.score-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:.6rem;margin:1rem 0}
.score-card{background:#0c0d16;border:1px solid #1a1d2e;border-radius:6px;
  padding:.8rem .6rem;text-align:center;transition:transform .15s}
.score-card:hover{transform:translateY(-2px)}
.score-val{font-family:'Orbitron',monospace;font-size:1.8rem;font-weight:700}
.score-lbl{font-size:.58rem;text-transform:uppercase;letter-spacing:.09em;
  color:#7880a8;margin-top:3px}

/* Metric override */
[data-testid="stMetricValue"]{font-family:'Orbitron',monospace!important;
  font-size:1.9rem!important;font-weight:700!important;color:#dce0f8!important}
[data-testid="stMetricLabel"]{font-size:.62rem!important;text-transform:uppercase!important;
  letter-spacing:.08em!important;color:#7880a8!important}
[data-testid="stMetricDelta"]{display:none!important}
[data-testid="metric-container"]{background:#0c0d16!important;
  border:1px solid #1a1d2e!important;border-radius:6px!important;
  padding:.8rem!important;transition:transform .2s!important}
[data-testid="metric-container"]:hover{transform:translateY(-2px)!important}

/* Tabs */
[data-testid="stTabs"] button{font-family:'JetBrains Mono',monospace!important;
  font-size:.72rem!important;text-transform:uppercase!important;letter-spacing:.07em!important;
  color:#7880a8!important;padding:.5rem .9rem!important}
[data-testid="stTabs"] button[aria-selected="true"]{color:#70a8ff!important;
  border-bottom:2px solid #4880ff!important}
[data-testid="stTabs"] button:hover{color:#a0c8ff!important}

/* Buttons */
.stButton>button{font-family:'JetBrains Mono',monospace!important;
  font-size:.73rem!important;font-weight:700!important;
  letter-spacing:.05em!important;text-transform:uppercase!important;
  border-radius:4px!important;transition:all .2s!important}
.stButton>button[kind="primary"]{background:linear-gradient(135deg,#0a2060,#183ebf)!important;
  border:1px solid #4880ff!important;color:#a0c8ff!important;
  box-shadow:0 0 14px rgba(40,100,220,.28)!important}
.stButton>button[kind="primary"]:hover{color:#c0dcff!important;
  box-shadow:0 0 24px rgba(64,128,255,.55)!important}
.stButton>button[kind="secondary"]{background:#0c0d16!important;
  border:1px solid #252840!important;color:#9098b8!important}
.stButton>button[kind="secondary"]:hover{border-color:#4080ff!important;color:#90b8ff!important}

/* Inputs */
.stTextInput>div>div>input,.stTextArea textarea{background:#0c0d16!important;
  border:1px solid #1a1d2e!important;color:#d0d8f0!important;
  font-family:'JetBrains Mono',monospace!important;font-size:.76rem!important;border-radius:3px!important}
[data-testid="stSelectbox"] span,[data-testid="stSelectbox"] div{color:#c0c8e0!important}
[data-testid="stCheckbox"] label{color:#a8b0c8!important;font-size:.76rem!important}

/* Expanders */
[data-testid="stExpander"]{background:#0b0c15!important;
  border:1px solid #1a1d2e!important;border-radius:5px!important}
[data-testid="stExpander"] summary{font-size:.74rem!important;
  text-transform:uppercase!important;letter-spacing:.07em!important;
  color:#8ab0e8!important;font-weight:700!important}

/* Progress */
[data-testid="stProgress"]>div>div{background:linear-gradient(90deg,#2060e0,#4890ff,#70b8ff)!important}

/* File uploader */
[data-testid="stFileUploader"]{background:#0c0d16!important;
  border:2px dashed #252840!important;border-radius:6px!important}
[data-testid="stFileUploaderDropzone"] label,
[data-testid="stFileUploaderDropzone"] div,
[data-testid="stFileUploaderDropzone"] span{color:#6870a0!important}

/* Finding cards */
.finding-card{background:#0b0c15;border:1px solid #1a1d2e;border-radius:5px;
  padding:.75rem 1rem;margin-bottom:.4rem;border-left:3px solid #252840;
  transition:background .15s}
.finding-card:hover{background:#0d0e18}
.finding-card.medical{border-left-color:#ff8080}
.finding-card.blocker{border-left-color:#ff6060}
.finding-card.structural{border-left-color:#ffb060}
.finding-card.advisory{border-left-color:#6898ff}
.finding-subject{color:#78a8ff;font-weight:700;font-size:.82rem}
.finding-domain{color:#7888b0;font-size:.7rem}
.finding-label{color:#a8b4cc;font-size:.77rem;font-weight:500;margin-top:3px;line-height:1.5}
.finding-detail{color:#c8d2e8;font-size:.74rem;margin-top:5px;line-height:1.6}
.finding-meta{color:#5a6484;font-size:.64rem;margin-top:5px}
.finding-root{color:#607090;font-size:.67rem;margin-top:4px}

/* Badges */
.badge{display:inline-block;font-size:.63rem;padding:2px 7px;border-radius:3px;
  border:1px solid currentColor;font-weight:700;white-space:nowrap;letter-spacing:.04em}
.badge-reject{color:#ff6060;background:rgba(255,96,96,.12)}
.badge-critical{color:#ff8080;background:rgba(255,128,128,.12)}
.badge-error{color:#ffb060;background:rgba(255,176,96,.12)}
.badge-warning{color:#f0d840;background:rgba(240,216,64,.1)}
.badge-blocker{color:#ff6060;background:rgba(255,96,96,.1)}
.badge-medical{color:#ff8080;background:rgba(255,128,128,.1)}
.badge-struct{color:#ffb060;background:rgba(255,176,96,.1)}
.badge-advisory{color:#6898ff;background:rgba(104,152,255,.1)}
.badge-actual{font-size:.6rem;color:#58c890;border:1px solid rgba(88,200,144,.4);
  padding:1px 5px;border-radius:2px;background:rgba(88,200,144,.08)}
.badge-demo{font-size:.6rem;color:#6898ff;border:1px solid rgba(104,152,255,.35);
  padding:1px 5px;border-radius:2px;background:rgba(104,152,255,.08)}
.waived-badge{display:inline-block;font-size:.6rem;font-weight:700;padding:2px 6px;
  border-radius:2px;color:#58c890;background:rgba(88,200,144,.1);
  border:1px solid rgba(88,200,144,.35)}
.dep-notice{background:rgba(104,152,255,.05);border:1px solid rgba(104,152,255,.2);
  border-radius:4px;padding:.45rem .75rem;margin-bottom:.3rem;font-size:.7rem;
  color:#7888b0;border-left:2px solid #6898ff}

/* Info/section boxes */
.info-box{background:rgba(72,128,255,.06);border:1px solid rgba(72,128,255,.2);
  border-radius:4px;padding:.6rem .85rem;font-size:.74rem;color:#9aa2c0;margin-bottom:.7rem}
.section-lbl{font-size:.68rem;text-transform:uppercase;letter-spacing:.1em;
  color:#5a6888;display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem}
.section-lbl::after{content:'';flex:1;height:1px;background:#1a1d2e}

/* Header glow */
.header-glow{background:linear-gradient(135deg,#0a1840 0%,#040508 65%);
  border-bottom:1px solid #1a1d2e;padding:.8rem 0 .7rem;margin-bottom:.7rem;position:relative}
.header-glow::after{content:'';position:absolute;bottom:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,#4880ff,#78b8ff,#4880ff,transparent);opacity:.55}

/* Sidebar branding */
.sidebar-title{font-family:'Orbitron',monospace;font-size:1.05rem;font-weight:900;
  background:linear-gradient(135deg,#5898ff,#90c8ff);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.sidebar-sub{font-size:.58rem;color:#586080!important;text-transform:uppercase;
  letter-spacing:.12em;margin-top:3px}

/* Domain issue group headers */
.domain-group-hdr{background:#0d0e18;border:1px solid #1a1d2e;border-radius:5px;
  padding:.5rem .8rem;font-size:.72rem;font-weight:700;color:#90b8ff;
  text-transform:uppercase;letter-spacing:.07em;margin-bottom:.4rem;
  display:flex;justify-content:space-between;align-items:center}
.domain-count-pill{background:#1a1d2e;border-radius:10px;padding:1px 8px;
  font-size:.65rem;color:#7880a8}

/* Scrollbar */
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:#05060a}
::-webkit-scrollbar-thumb{background:#252840;border-radius:2px}
::-webkit-scrollbar-thumb:hover{background:#4880ff}

/* Chart axis text */
.vega-embed text{fill:#7880a8!important;font-size:11px!important}

hr{border:none;border-top:1px solid #1a1d2e!important;margin:.6rem 0!important}

/* Pyreadstat install notice */
.install-notice{background:rgba(255,176,96,.05);border:1px solid rgba(255,176,96,.2);
  border-radius:4px;padding:.45rem .75rem;font-size:.68rem;color:#c09060;margin-top:.2rem}
</style>
""", unsafe_allow_html=True)

# __ SESSION STATE _____________________________________________________________
def _init():
    defs = {
        "uploaded_files_meta": {}, "findings": [],
        "enabled_ids": set(c["id"] for c in get_checks()),
        "is_running": False, "run_count": 0, "last_run_ts": "",
        "waived_notes": {}, "clear_trigger": 0,
        # IMP002 – Run Metadata / Audit Layer
        "run_id": "",
        "checks_yaml_hash": "",
        "run_dataset_list": [],
        "cis_version": "8.0",
    }
    for k, v in defs.items():
        if k not in st.session_state:
            st.session_state[k] = v
_init()

# __ CONSTANTS _________________________________________________________________
RISK_COLORS = {"submission-blocker":"#ff6060","medical-concern":"#ff8080",
               "structural":"#ffb060","advisory":"#6898ff"}
RISK_LABELS = {"submission-blocker":"Submission Blocker","medical-concern":"Medical Concern",
               "structural":"Structural Error","advisory":"Advisory"}
SEV_COLORS  = {"REJECT":"#ff6060","CRITICAL":"#ff8080","ERROR":"#ffb060",
               "WARNING":"#f0d840","NOTICE":"#6898ff"}
SEV_BADGE   = {"REJECT":"badge-reject","CRITICAL":"badge-critical","ERROR":"badge-error",
               "WARNING":"badge-warning"}
RISK_BADGE  = {"submission-blocker":"badge-blocker","medical-concern":"badge-medical",
               "structural":"badge-struct","advisory":"badge-advisory"}

CARD_LIMIT = 50   # render interactive cards only for groups <= this size; larger groups use dataframe view

# SDTM domains grouped for display
DOMAIN_GROUPS = {
    "Demographics & Disposition": ["DM","DS","SS"],
    "Safety & Adverse Events":    ["AE","MH","CM","PR","DV"],
    "Exposure & PK":              ["EX","PC","PP"],
    "Lab & Vitals":               ["LB","VS","EG"],
    "Oncology & Tumor":           ["TR","TU","RS"],
    "Questionnaires & Other":     ["QS","IE","SV","SE","FA","EC","HO"],
    "Trial Design":               ["TS","TA","TE","TV","TI"],
    "Structural":                 ["ALL","DEFINE","SUPP","RELREC"],
}

# __ HELPERS ___________________________________________________________________
def _active():
    return [f for f in st.session_state.findings
            if not f.get("waived") and not f.get("dep_warning")]

def _dep_warns():
    return [f for f in st.session_state.findings if f.get("dep_warning")]

def _count_by(lst, key):
    out = {}
    for f in lst:
        v = f.get(key,"?")
        out[v] = out.get(v,0) + 1
    return out

def _worst_risk(risks):
    for r in ["submission-blocker","medical-concern","structural","advisory"]:
        if r in risks: return r
    return "advisory"

def _badge(text, kind):
    cls = SEV_BADGE.get(text) or RISK_BADGE.get(kind) or "badge-struct"
    return f'<span class="badge {cls}">{text}</span>'

def _sev_icon(sev):
    return {"REJECT":"[!]","CRITICAL":"[X]","ERROR":"[^]","WARNING":"[~]","NOTICE":"[i]"}.get(sev,"[-]")

def _domain_of(f):
    return f.get("domain","ALL").split("/")[0]

def _findings_df(findings, risk_filter="All"):
    rows = []
    for f in findings:
        if risk_filter != "All" and f.get("risk") != risk_filter:
            continue
        rows.append({
            "ID": f["fid"], "Sev": f["sev"],
            "Risk": RISK_LABELS.get(f["risk"], f["risk"]),
            "Subject": "GLOBAL" if f["subj"]=="ALL" else f["subj"],
            "Domain":  _domain_of(f),
            "Check":   f["label"][:55] + ("..." if len(f["label"])>55 else ""),
            "Detail":  f["detail"][:75] + ("..." if len(f["detail"])>75 else ""),
            "Source":  f["source"], "Layer": f["layer"],
            "Waived":  "YES" if f.get("waived") else "",
        })
    if not rows:
        return pd.DataFrame(columns=["ID","Sev","Risk","Subject","Domain","Check","Detail","Source","Layer","Waived"])
    return pd.DataFrame(rows)

# __ FINDING CARD ______________________________________________________________
# tab_ctx makes widget keys unique across tabs (avoids DuplicateWidgetID)
def _render_card(f, compact=False, tab_ctx="t"):
    risk      = f.get("risk","structural")
    sev       = f.get("sev","")
    is_waived = f.get("waived",False)
    fid       = f["fid"]
    subj      = "GLOBAL" if f["subj"]=="ALL" else f["subj"]
    css_cls   = {"submission-blocker":"blocker","medical-concern":"medical",
                 "structural":"structural","advisory":"advisory"}.get(risk,"structural")
    wb = '<span class="waived-badge">WAIVED</span>' if is_waived else ""
    ab = ('<span class="badge-actual">ACTUAL</span>' if f.get("actual")
          else '<span class="badge-demo">DEMO</span>')
    root_html = (f'<div class="finding-root">Root: {f["root"]}</div>'
                 if f.get("root") else "")

    st.markdown(f"""
    <div class="finding-card {css_cls}" style="opacity:{'0.4' if is_waived else '1'}">
      <div style="display:flex;align-items:center;gap:7px;margin-bottom:4px;flex-wrap:wrap">
        <code style="font-size:.67rem;color:#505878;background:none;border:none;padding:0">{_sev_icon(sev)}</code>
        {_badge(sev,sev)}&nbsp;{_badge(RISK_LABELS.get(risk,risk),risk)}
        <span class="finding-subject">{subj}</span>
        <span class="finding-domain">[{_domain_of(f)}]</span>
        {ab} {wb}
      </div>
      <div class="finding-label">{f.get("label","")}</div>
      <div class="finding-detail">{f.get("detail","")}</div>
      {root_html}
      <div class="finding-meta">{fid} &bull; {f.get("cat","")} &bull; {f.get("source","")}</div>
    </div>""", unsafe_allow_html=True)

    if not compact:
        c1, c2 = st.columns([5, 1])
        with c1:
            note = st.text_input("Note", value=f.get("waiver_note",""),
                                 placeholder="cSDRG Section 4 justification...",
                                 key=f"note_{fid}_{tab_ctx}", label_visibility="collapsed")
        with c2:
            if st.button("Unwaive" if is_waived else "Waive", key=f"waive_{fid}_{tab_ctx}",
                         use_container_width=True):
                f["waived"] = not is_waived
                f["waiver_note"] = note
                if f["waived"]:
                    st.session_state.waived_notes[fid] = note
                else:
                    st.session_state.waived_notes.pop(fid, None)
                st.rerun()

# __ VALIDATION RUNNER _________________________________________________________
def _compute_yaml_hash() -> str:
    """Compute MD5 of checks.yaml for audit traceability (IMP002)."""
    try:
        yaml_path = os.path.join(os.path.dirname(__file__), "checks.yaml")
        with open(yaml_path, "rb") as fh:
            return hashlib.md5(fh.read()).hexdigest()[:12].upper()
    except Exception:
        return "N/A"

def run_validation():
    st.session_state.is_running   = True
    st.session_state.findings     = []
    files_meta  = dict(st.session_state.uploaded_files_meta)
    enabled_ids = set(st.session_state.enabled_ids)
    engine      = ValidationEngine(files_meta, enabled_ids)
    prog_ph     = st.empty()
    bar         = prog_ph.progress(0, text="Initializing...")

    def cb(pct, label=""):
        bar.progress(min(pct,100)/100, text=label[:75] if label else "Running...")

    findings = engine.run(cb)

    # Restore waivers using stable fingerprint fids (IMP005 fix)
    for f in findings:
        fid = f.get("fid","")
        if fid and fid in st.session_state.waived_notes:
            f["waived"] = True
            f["waiver_note"] = st.session_state.waived_notes[fid]

    st.session_state.findings     = findings
    st.session_state.is_running   = False
    st.session_state.run_count   += 1
    st.session_state.last_run_ts  = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # IMP002 – capture run metadata
    st.session_state.run_id           = str(uuid.uuid4())
    st.session_state.checks_yaml_hash = _compute_yaml_hash()
    st.session_state.run_dataset_list = sorted(files_meta.keys())

    prog_ph.empty()

# __ SIDEBAR ___________________________________________________________________
with st.sidebar:
    st.markdown("""
    <div style="text-align:center;padding:.4rem 0 .8rem;border-bottom:1px solid #1a1d2e;margin-bottom:.6rem">
      <div class="sidebar-title">CIS v8.0</div>
      <div class="sidebar-sub">SDTM Beyond-P21</div>
    </div>""", unsafe_allow_html=True)

    # -- File Upload --
    st.markdown('<div style="font-size:.7rem;font-weight:700;color:#8ab0e8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Upload Datasets</div>',
                unsafe_allow_html=True)

    # key includes clear_trigger so the widget fully resets when Clear is pressed
    uploaded = st.file_uploader(
        "files", type=["sas7bdat","xpt","csv","xlsx","xls","json","xml","txt","pdf"],
        accept_multiple_files=True, label_visibility="collapsed",
        key=f"uploader_{st.session_state.clear_trigger}",
        help="SAS7BDAT (full rows via pyreadstat), XPT (full rows built-in), CSV, XLSX, JSON, XML")

    if uploaded:
        for uf in uploaded:
            fname = uf.name
            if fname not in st.session_state.uploaded_files_meta:
                ext  = os.path.splitext(fname)[1].lower()
                raw  = uf.read()
                meta = FileParser.analyze(raw, fname, ext)
                st.session_state.uploaded_files_meta[fname] = meta

    n_files = len(st.session_state.uploaded_files_meta)
    if n_files > 0:
        # Show pyreadstat notice if SAS7BDAT with 0 rows
        has_sas_no_rows = any(
            m.get("ext","")==".sas7bdat" and m.get("rows",0)==0
            for m in st.session_state.uploaded_files_meta.values()
        )
        if has_sas_no_rows:
            st.markdown(
                '<div class="install-notice">SAS7BDAT shows 0 rows. '
                'Run: <b>pip install pyreadstat</b> for full data.</div>',
                unsafe_allow_html=True)

        st.markdown(f'<div style="font-size:.7rem;color:#6898ff;font-weight:600;margin:.3rem 0">'
                    f'{n_files} file(s) loaded</div>', unsafe_allow_html=True)
        for fname, m in st.session_state.uploaded_files_meta.items():
            err   = m.get("parse_error","")
            ok    = '<span style="color:#58c890">OK</span>' if not err else '<span style="color:#ff7070">ERR</span>'
            short = fname[:24] + "..." if len(fname) > 24 else fname
            r, c  = m.get("rows",0), m.get("cols",0)
            st.markdown(f'<div style="font-size:.66rem;color:#7888b0;padding:2px 0">'
                        f'{ok} <span style="color:#a8b4cc">{short}</span> '
                        f'<span style="color:#505878">({r}r,{c}c)</span></div>',
                        unsafe_allow_html=True)

        st.markdown("<div style='height:3px'></div>", unsafe_allow_html=True)
        # FIX: Use a unique key based on trigger counter to force rerun
        if st.button("Clear All Files", key="clear_btn",
                     use_container_width=True):
            # Increment clear_trigger FIRST   this changes the file_uploader key,
            # which forces Streamlit to create a fresh empty uploader widget.
            st.session_state.clear_trigger += 1
            st.session_state.uploaded_files_meta = {}
            st.session_state.findings      = []
            st.session_state.waived_notes  = {}
            st.rerun()
    else:
        st.markdown('<div class="info-box">No files loaded. Runs with 59 demo findings.</div>',
                    unsafe_allow_html=True)

    st.divider()

    # -- Check Config --
    _live = get_checks()
    n_en  = len(st.session_state.enabled_ids)
    st.markdown('<div style="font-size:.7rem;font-weight:700;color:#8ab0e8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Check Configuration</div>',
                unsafe_allow_html=True)
    st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">'
                f'<span style="color:#8ab0e8;font-weight:700">{n_en}</span> / {len(_live)} active'
                f' <span style="font-size:.6rem;color:#404868">(checks.yaml auto-reloads)</span></div>',
                unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Enable All", key="ena", use_container_width=True):
            st.session_state.enabled_ids = set(c["id"] for c in _live); st.rerun()
    with c2:
        if st.button("Disable All", key="dis", use_container_width=True):
            st.session_state.enabled_ids = set(); st.rerun()

    sel_layer = st.selectbox("Layer", ["All"] + sorted(LAYERS), key="lay")
    sel_cat   = st.selectbox("Category", ["All"] + sorted(CATEGORIES), key="cat")
    srch_chk  = st.text_input("Search", placeholder="Check ID or keyword...", key="csr")

    filtered = [c for c in _live
                if (sel_layer=="All" or c["layer"]==sel_layer)
                and (sel_cat=="All" or c["cat"]==sel_cat)
                and (not srch_chk or srch_chk.lower() in c["label"].lower()
                     or srch_chk.lower() in c["id"].lower())]

    with st.expander(f"Toggle Checks  ({len(filtered)} shown)", expanded=False):
        for c in filtered:
            is_on   = c["id"] in st.session_state.enabled_ids
            new_val = st.checkbox(
                f"**{c['id']}**  {c['label'][:44]}{'...' if len(c['label'])>44 else ''}",
                value=is_on, key=f"chk_{c['id']}",
                help=f"Layer:{c['layer']} | Sev:{c['sev']} | Domain:{c['domain']}")
            if new_val != is_on:
                if new_val: st.session_state.enabled_ids.add(c["id"])
                else:       st.session_state.enabled_ids.discard(c["id"])

    st.divider()

    # -- Run + Download --
    if st.session_state.last_run_ts:
        st.markdown(f'<div style="font-size:.66rem;color:#505878;margin-bottom:.3rem">'
                    f'Last run: <span style="color:#7880a8">{st.session_state.last_run_ts}</span>'
                    f' (#{st.session_state.run_count})</div>', unsafe_allow_html=True)

    if st.button("Run Validation", type="primary", use_container_width=True,
                 disabled=st.session_state.is_running, key="run_btn"):
        run_validation(); st.rerun()

    if st.session_state.findings:
        st.divider()
        _run_meta = {
            "run_id":           st.session_state.run_id,
            "checks_yaml_hash": st.session_state.checks_yaml_hash,
            "cis_version":      st.session_state.cis_version,
            "run_dataset_list": st.session_state.run_dataset_list,
        }
        rh = make_html_report(findings=st.session_state.findings,
                              files_meta=st.session_state.uploaded_files_meta,
                              enabled_ids=st.session_state.enabled_ids,
                              run_meta=_run_meta)
        st.download_button("Download HTML Report", data=rh.encode("utf-8"),
            file_name=f"cis_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
            mime="text/html", use_container_width=True, key="dl_html")
        try:
            xl = make_excel_report(findings=st.session_state.findings,
                                   files_meta=st.session_state.uploaded_files_meta,
                                   enabled_ids=st.session_state.enabled_ids,
                                   run_meta=_run_meta)
            st.download_button("Download Excel Report", data=xl,
                file_name=f"cis_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True, key="dl_xl")
        except Exception as _xe:
            st.caption(f"Excel unavailable: {_xe}")

# __ MAIN HEADER _______________________________________________________________
_run_meta_html = ""
if st.session_state.run_id:
    _ds_count = len(st.session_state.run_dataset_list)
    _run_meta_html = (
        f'<div style="font-size:.62rem;color:#4a5475;margin-top:.35rem;font-family:JetBrains Mono,monospace;'
        f'border-top:1px solid #131624;padding-top:.3rem;display:flex;gap:1.2rem;flex-wrap:wrap">'
        f'<span>RUN&nbsp;<span style="color:#6878a8">{st.session_state.run_id[:8].upper()}</span></span>'
        f'<span>CIS&nbsp;<span style="color:#6878a8">v{st.session_state.cis_version}</span></span>'
        f'<span>YAML&nbsp;<span style="color:#6878a8">{st.session_state.checks_yaml_hash}</span></span>'
        f'<span>DATASETS&nbsp;<span style="color:#6878a8">{_ds_count}</span></span>'
        f'<span>TS&nbsp;<span style="color:#6878a8">{st.session_state.last_run_ts}</span></span>'
        f'</div>'
    )

st.markdown(
    f'<div class="header-glow">'
    f'<div class="suite-title">Clinical Integrity Suite</div>'
    f'<div class="suite-sub">SDTM Beyond-P21 &nbsp;|&nbsp; v8.0 &nbsp;|&nbsp; '
    f'{len(_live)} Checks &nbsp;|&nbsp; 35+ Domains &nbsp;|&nbsp; FDA JumpStart</div>'
    f'{_run_meta_html}'
    f'</div>', unsafe_allow_html=True)

# __ SCORECARD ROW _____________________________________________________________
findings_all = st.session_state.findings
active       = _active()
by_risk      = _count_by(active,"risk")
waived_n     = len([f for f in findings_all if f.get("waived")])
dep_n        = len(_dep_warns())

m1,m2,m3,m4,m5,m6 = st.columns(6)
m1.metric("Active",    len(active))
m2.metric("Blockers",  by_risk.get("submission-blocker",0))
m3.metric("Medical",   by_risk.get("medical-concern",0))
m4.metric("Structural",by_risk.get("structural",0))
m5.metric("Waived",    waived_n)
m6.metric("Advisory",  by_risk.get("advisory",0))

st.divider()

# __ MAIN TABS _________________________________________________________________
t_summ, t_domain, t_issue, t_subj, t_reg, t_files = st.tabs([
    "Summary Dashboard",
    "By Domain",
    "By Issue Type",
    "By Subject",
    "Check Registry",
    "Files",
])

# ____________________________________________________________________
# TAB 1: SUMMARY DASHBOARD
# ____________________________________________________________________
with t_summ:
    if not active:
        st.markdown("""
        <div style="text-align:center;padding:4rem 2rem">
          <div style="font-size:2.5rem;opacity:.1;font-family:Orbitron,monospace">CIS</div>
          <div style="font-family:Orbitron,monospace;font-size:1rem;color:#404868;margin:.5rem 0">
            SDTM Clinical Integrity Suite v8.0</div>
          <div style="color:#363858;font-size:.76rem;line-height:1.8">
            Upload SDTM datasets in the sidebar and click <b style="color:#506090">Run Validation</b>.<br>
            Accepts SAS7BDAT (XPT native row reader), CSV, XLSX, JSON.<br>
            Or click Run Validation now to see demo findings.
          </div>
        </div>""", unsafe_allow_html=True)
    else:
        by_sev   = _count_by(active,"sev")
        by_dom   = _count_by(active, "domain")
        by_cat   = _count_by(active,"cat")
        by_layer = _count_by(active,"layer")

        # ---- Run Info Panel (IMP002) ----
        if st.session_state.run_id:
            _actual_n = sum(1 for f in active if f.get("actual"))
            _demo_n   = sum(1 for f in active if not f.get("actual"))
            _ds_n     = len(st.session_state.run_dataset_list)
            _waived_n = len([f for f in findings_all if f.get("waived")])
            st.markdown(
                f'<div style="background:#090a14;border:1px solid #1a1e30;border-left:3px solid #3050a0;'
                f'border-radius:4px;padding:.5rem .9rem;font-size:.68rem;color:#4a5070;'
                f'display:flex;flex-wrap:wrap;gap:1.4rem;margin-bottom:.6rem">'
                f'<span>RUN&nbsp;<b style="color:#6878a8">{st.session_state.run_id[:8].upper()}</b></span>'
                f'<span>YAML&nbsp;<b style="color:#6878a8">{st.session_state.checks_yaml_hash}</b></span>'
                f'<span>DATASETS&nbsp;<b style="color:#6878a8">{_ds_n}</b></span>'
                f'<span>ACTUAL&nbsp;<b style="color:#58c890">{_actual_n}</b></span>'
                f'<span>DEMO&nbsp;<b style="color:#6898ff">{_demo_n}</b></span>'
                f'<span>WAIVED&nbsp;<b style="color:#c0c890">{_waived_n}</b></span>'
                f'<span>TS&nbsp;<b style="color:#6878a8">{st.session_state.last_run_ts}</b></span>'
                f'</div>', unsafe_allow_html=True)

        # ---- Row 1: Risk + Severity ----
        col_l, col_r = st.columns(2)
        with col_l:
            st.markdown("**Findings by Risk Category**")
            df_risk = pd.DataFrame([
                {"Risk": RISK_LABELS.get(k,k), "Count": v}
                for k,v in sorted(by_risk.items(), key=lambda x:-x[1])
            ])
            if not df_risk.empty:
                st.bar_chart(df_risk.set_index("Risk")["Count"], color="#5898ff", height=200)

        with col_r:
            st.markdown("**Findings by Severity**")
            df_sev = pd.DataFrame([
                {"Severity": k, "Count": v}
                for k,v in sorted(by_sev.items(), key=lambda x:-x[1])
                if k != "NOTICE"  # exclude dep-warning noise
            ])
            if not df_sev.empty:
                st.bar_chart(df_sev.set_index("Severity")["Count"], color="#ff9060", height=200)

        # ---- Row 2: Domain + Layer ----
        col_l2, col_r2 = st.columns([3, 1])
        with col_l2:
            st.markdown("**Findings by SDTM Domain** (top 20)")
            # Normalise domain (use first part of slash-separated)
            dom_counts = {}
            for f in active:
                d = _domain_of(f)
                dom_counts[d] = dom_counts.get(d,0)+1
            df_dom = pd.DataFrame([
                {"Domain": k, "Count": v}
                for k,v in sorted(dom_counts.items(), key=lambda x:-x[1])[:20]
            ])
            if not df_dom.empty:
                st.bar_chart(df_dom.set_index("Domain")["Count"], color="#58b8ff", height=220)

        with col_r2:
            st.markdown("**By Layer**")
            df_lay = pd.DataFrame([
                {"Layer": k.replace(" ","\n"), "Count": v}
                for k,v in sorted(by_layer.items(), key=lambda x:-x[1])
            ])
            if not df_lay.empty:
                st.bar_chart(df_lay.set_index("Layer")["Count"], color="#70d098", height=220)

        # ---- Row 3: Top categories ----
        st.markdown("**Top Finding Categories**")
        df_cat = pd.DataFrame([
            {"Category": k, "Count": v}
            for k,v in sorted(by_cat.items(), key=lambda x:-x[1])[:12]
        ])
        if not df_cat.empty:
            st.bar_chart(df_cat.set_index("Category")["Count"], color="#c878ff", height=200)

        # ---- Dep warnings summary (compact) ----
        if dep_n > 0:
            st.divider()
            st.markdown(
                f'<div class="info-box">'
                f'<b style="color:#6898ff">{dep_n} dependency notices</b> _ checks skipped '
                f'because required domains are not loaded. '
                f'Upload the missing domain files to enable them.</div>',
                unsafe_allow_html=True)
            with st.expander(f"Show {dep_n} dependency notices", expanded=False):
                for w in _dep_warns():
                    st.markdown(
                        f'<div class="dep-notice"><b style="color:#78a8ff">{w["checkId"]}</b> '
                        f'{w["detail"]}</div>', unsafe_allow_html=True)

# ____________________________________________________________________
# TAB 2: BY DOMAIN
# ____________________________________________________________________
with t_domain:
    if not active:
        st.info("Run validation to see domain findings.")
    else:
        # Risk filter
        rf = st.selectbox("Filter by Risk", ["All","submission-blocker","medical-concern","structural","advisory"],
                          format_func=lambda x: "All Findings" if x=="All" else RISK_LABELS.get(x,x),
                          key="dom_risk")
        hide_w = st.checkbox("Hide waived", key="dom_hw")

        filtered_active = [f for f in findings_all
                           if not f.get("dep_warning")
                           and not (hide_w and f.get("waived"))
                           and (rf=="All" or f.get("risk")==rf)]

        # Group by domain group
        for group_name, dom_list in DOMAIN_GROUPS.items():
            group_findings = [f for f in filtered_active if _domain_of(f) in dom_list]
            if not group_findings:
                continue
            n = len(group_findings)
            worst = _worst_risk([f["risk"] for f in group_findings])
            wc    = RISK_COLORS.get(worst,"#6898ff")
            with st.expander(f"{group_name}  [{n} finding{'s' if n!=1 else ''}]", expanded=False):
                # Sub-group by individual domain
                sub_doms = {}
                for f in group_findings:
                    sub_doms.setdefault(_domain_of(f),[]).append(f)
                for dom, dfinds in sorted(sub_doms.items()):
                    st.markdown(
                        f'<div class="domain-group-hdr">'
                        f'{dom} <span class="domain-count-pill">{len(dfinds)}</span></div>',
                        unsafe_allow_html=True)
                    for f in dfinds:
                        _render_card(f)

        # Any domain not in DOMAIN_GROUPS
        all_grouped_doms = {d for dl in DOMAIN_GROUPS.values() for d in dl}
        ungrouped = [f for f in filtered_active if _domain_of(f) not in all_grouped_doms]
        if ungrouped:
            with st.expander(f"Other Domains  [{len(ungrouped)} findings]", expanded=False):
                for f in ungrouped:
                    _render_card(f)

# ____________________________________________________________________
# TAB 3: BY ISSUE TYPE
# ____________________________________________________________________
with t_issue:
    if not active:
        st.info("Run validation to see findings by issue type.")
    else:
        hide_w2 = st.checkbox("Hide waived", key="iss_hw")
        filtered2 = [f for f in findings_all
                     if not f.get("dep_warning")
                     and not (hide_w2 and f.get("waived"))]

        # Show Medical + Blockers first (highest priority)
        critical_f = [f for f in filtered2 if f.get("risk") in ("submission-blocker","medical-concern")]
        if critical_f:
            # Root-cause clusters
            root_groups = {}
            standalone  = []
            for f in critical_f:
                if f.get("root"):
                    root_groups.setdefault(f["root"],[]).append(f)
                else:
                    standalone.append(f)

            st.markdown('<div class="section-lbl">Submission Blockers and Medical Concerns</div>',
                        unsafe_allow_html=True)

            if root_groups:
                st.markdown('<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">Root-Cause Clusters</div>',
                            unsafe_allow_html=True)
                for root, rf_list in root_groups.items():
                    worst = _worst_risk([f["risk"] for f in rf_list])
                    with st.expander(f"Root: {root}  [{len(rf_list)} findings]  {RISK_LABELS.get(worst,worst)}", expanded=False):
                        if len(rf_list) <= CARD_LIMIT:
                            for fi in rf_list: _render_card(fi, tab_ctx=f"iss_root")
                        else:
                            st.dataframe(_findings_df(rf_list), use_container_width=True, hide_index=True, height=400)

            if standalone:
                st.markdown('<div style="font-size:.7rem;color:#7880a8;margin:.4rem 0">Individual Findings</div>',
                            unsafe_allow_html=True)
                if len(standalone) <= CARD_LIMIT:
                    for fi in standalone: _render_card(fi, tab_ctx='iss_crit')
                else:
                    st.info(f"{len(standalone)} findings   table view (> {CARD_LIMIT} cards would freeze the browser)")
                    st.dataframe(_findings_df(standalone), use_container_width=True, hide_index=True, height=400)

        struct_f = [f for f in filtered2 if f.get("risk")=="structural"]
        if struct_f:
            st.divider()
            st.markdown('<div class="section-lbl">Structural Errors</div>', unsafe_allow_html=True)
            # Group by category
            cats = {}
            for f in struct_f:
                cats.setdefault(f.get("cat","Other"),[]).append(f)
            for cat, cf in sorted(cats.items(), key=lambda x:-len(x[1])):
                with st.expander(f"{cat}  [{len(cf)}]", expanded=False):
                    if len(cf) <= CARD_LIMIT:
                        for fi in cf: _render_card(fi, tab_ctx=f"iss_struct")
                    else:
                        st.dataframe(_findings_df(cf), use_container_width=True, hide_index=True, height=400)

        adv_f = [f for f in filtered2 if f.get("risk")=="advisory"]
        if adv_f:
            st.divider()
            st.markdown('<div class="section-lbl">Advisory Notices</div>', unsafe_allow_html=True)
            if len(adv_f) <= CARD_LIMIT:
                for fi in adv_f: _render_card(fi, compact=True, tab_ctx="iss_adv")
            else:
                st.dataframe(_findings_df(adv_f), use_container_width=True, hide_index=True, height=300)

        if not filtered2:
            st.info("No findings match the current filter.")

        # Full table at bottom
        st.divider()
        st.markdown('<div class="section-lbl">Complete Findings Table</div>', unsafe_allow_html=True)
        df_all = _findings_df(filtered2)
        st.dataframe(df_all, use_container_width=True, hide_index=True, height=360)

# ____________________________________________________________________
# TAB 4: BY SUBJECT
# ____________________________________________________________________
with t_subj:
    if not active:
        st.info("Run validation to see subject data.")
    else:
        srch_s = st.text_input("Filter by Subject ID", placeholder="e.g. 001-007",
                               key="subj_s")
        sm = {}
        for f in [x for x in findings_all if not x.get("dep_warning") and not x.get("waived")]:
            k = "GLOBAL" if f["subj"]=="ALL" else f["subj"]
            sm.setdefault(k,[]).append(f)

        # Summary table
        rows = []
        for subj, sf in sorted(sm.items(),
                key=lambda x:(0 if _worst_risk([f["risk"] for f in x[1]])=="medical-concern" else 1, x[0])):
            if srch_s and srch_s.lower() not in subj.lower():
                continue
            doms = list(dict.fromkeys(_domain_of(f) for f in sf))
            rows.append({"Subject":subj,"Findings":len(sf),
                         "Worst Risk":RISK_LABELS.get(_worst_risk([f["risk"] for f in sf]),""),
                         "Domains":", ".join(doms[:6]),
                         "Categories":", ".join(list(dict.fromkeys(f["cat"] for f in sf))[:4])})

        if rows:
            st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">'
                        f'<span style="color:#8ab0e8;font-weight:700">{len(rows)}</span>'
                        f' subjects with active findings</div>', unsafe_allow_html=True)
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True, height=400)

        # Expandable detail for searched subject
        if srch_s:
            matches = [f for f in active if srch_s.lower() in (f["subj"] or "").lower()]
            if matches:
                st.divider()
                st.markdown(f'<div class="section-lbl">Detail: "{srch_s}"</div>', unsafe_allow_html=True)
                for fi in matches: _render_card(fi, tab_ctx="subj_detail")

# ____________________________________________________________________
# TAB 5: CHECK REGISTRY
# ____________________________________________________________________
with t_reg:
    st.markdown('<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;color:#a0b8e0;margin-bottom:.5rem">Full Check Registry</div>', unsafe_allow_html=True)
    rc1, rc2, rc3 = st.columns([2,1,1])
    with rc1: srch_r = st.text_input("Search", placeholder="ID or keyword...", key="reg_s")
    with rc2: lr = st.selectbox("Layer", ["All"]+sorted(LAYERS), key="reg_l")
    with rc3: cr = st.selectbox("Category", ["All"]+sorted(CATEGORIES), key="reg_c")

    reg_ch = [c for c in _live
              if (not srch_r or srch_r.lower() in c["label"].lower() or srch_r.lower() in c["id"].lower())
              and (lr=="All" or c["layer"]==lr)
              and (cr=="All" or c["cat"]==cr)]

    df_reg = pd.DataFrame([{
        "ID":c["id"],"Layer":c["layer"],"Category":c["cat"],"Domain":c["domain"],
        "Severity":c["sev"],"Risk":RISK_LABELS.get(c["risk"],c["risk"]),
        "Description":c["label"],"Source":c["source"],
        "Enabled":"ON" if c["id"] in st.session_state.enabled_ids else "OFF",
    } for c in reg_ch])

    st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.3rem">'
                f'<span style="color:#8ab0e8;font-weight:700">{len(df_reg)}</span>'
                f' of {len(_live)} checks shown</div>', unsafe_allow_html=True)
    st.dataframe(df_reg, use_container_width=True, hide_index=True, height=500)

# ____________________________________________________________________
# TAB 6: FILES
# ____________________________________________________________________
with t_files:
    st.markdown('<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;color:#a0b8e0;margin-bottom:.5rem">Loaded Files</div>', unsafe_allow_html=True)

    fm = st.session_state.uploaded_files_meta
    if not fm:
        st.markdown('<div class="info-box">No files loaded. Upload via the sidebar.</div>', unsafe_allow_html=True)
    else:
        file_rows = []
        for fname, m in fm.items():
            note = m.get("parse_note","")
            err  = m.get("parse_error","")
            status = ("WARN: " + note[:40]) if note else ("ERR: " + err[:40]) if err else "OK"
            file_rows.append({
                "Filename":fname,"Type":m.get("type",""),"Rows":m.get("rows",0),
                "Cols":m.get("cols",0),"Size":f"{m.get('size',0):,} B",
                "Variables":", ".join((m.get("variables") or [])[:5]),
                "Status":status,
            })
        st.dataframe(pd.DataFrame(file_rows), use_container_width=True, hide_index=True)

        # If any SAS7BDAT with 0 rows, show install hint prominently
        sas_no_rows = [(fn, m) for fn, m in fm.items()
                       if m.get("ext","")==".sas7bdat" and m.get("rows",0)==0]
        if sas_no_rows:
            st.markdown("""
            <div class="install-notice" style="margin-top:.6rem;font-size:.75rem;padding:.7rem 1rem">
              <b>SAS7BDAT files loaded as header-only (0 rows)</b><br>
              To read full row data, install pyreadstat in your conda environment:<br>
              <code style="background:rgba(255,176,96,.1);border:1px solid rgba(255,176,96,.3);
              padding:2px 8px;border-radius:2px;color:#e0b070">
              pip install pyreadstat</code><br>
              Then re-upload the files. XPT files are read with full rows using the built-in parser.
            </div>""", unsafe_allow_html=True)

        # Variable preview
        st.divider()
        st.markdown('<div class="section-lbl">Variable Preview</div>', unsafe_allow_html=True)
        sel_f = st.selectbox("Select file", list(fm.keys()), key="fp_sel")
        if sel_f:
            m  = fm[sel_f]
            dt = m.get("data",[])
            if dt:
                st.dataframe(pd.DataFrame(dt[:50]), use_container_width=True,
                             hide_index=True, height=280)
            else:
                st.markdown('<div class="info-box">No row data. SAS7BDAT: install pyreadstat. XPT: already has native row reader.</div>', unsafe_allow_html=True)
