"""
SDTM Clinical Integrity Suite - Streamlit Edition v5.0
Beyond-P21 Validation Dashboard

HOW TO RUN:
    pip install streamlit pandas openpyxl plotly
    streamlit run app.py

Then open: http://localhost:8501
"""

import streamlit as st
import pandas as pd
import json
import os
import time
import datetime
import io
import threading

from modules.registry import CHECKS, get_check, LAYERS, CATEGORIES
from modules.engine import ValidationEngine, DEMO_POOL
from modules.parser import FileParser
from modules.reporter import make_html_report

# ---------------------------------------------------------------------------
# PAGE CONFIG  (must be FIRST Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SDTM Clinical Integrity Suite v5.0",
    page_icon="https://raw.githubusercontent.com/streamlit/streamlit/develop/lib/streamlit/static/favicon.png",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": None,
        "Report a bug": None,
        "About": "SDTM Clinical Integrity Suite v5.0 | Beyond-P21 Validation",
    },
)

# ---------------------------------------------------------------------------
# CUSTOM CSS  - futuristic dark-mode theme
# ---------------------------------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Orbitron:wght@400;600;700;900&display=swap');

/* ---- ROOT ---- */
html, body, [class*="css"] {
    font-family: 'JetBrains Mono', 'Courier New', monospace !important;
}

/* ---- MAIN BACKGROUND ---- */
.stApp {
    background: #05060a !important;
}
.block-container {
    padding-top: 1rem !important;
    padding-bottom: 2rem !important;
    max-width: 100% !important;
}

/* ---- SIDEBAR ---- */
[data-testid="stSidebar"] {
    background: #08090e !important;
    border-right: 1px solid #14162a !important;
    box-shadow: 2px 0 20px rgba(0,0,0,0.5) !important;
}
[data-testid="stSidebar"] .block-container {
    padding: 1rem 0.75rem !important;
}

/* ---- HEADER TITLE ---- */
.suite-title {
    font-family: 'Orbitron', monospace !important;
    font-size: 1.6rem !important;
    font-weight: 900 !important;
    background: linear-gradient(135deg, #4080ff, #60a0ff, #80c0ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 0.04em;
    line-height: 1.2;
    margin-bottom: 0.1rem;
}
.suite-subtitle {
    font-size: 0.65rem;
    color: #454870;
    text-transform: uppercase;
    letter-spacing: 0.12em;
}

/* ---- METRIC CARDS ---- */
[data-testid="metric-container"] {
    background: #0c0d14 !important;
    border: 1px solid #14162a !important;
    border-radius: 6px !important;
    padding: 0.8rem 1rem !important;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.03) !important;
    transition: transform 0.2s !important;
}
[data-testid="metric-container"]:hover {
    transform: translateY(-2px) !important;
    border-color: #1c1f38 !important;
}
[data-testid="stMetricValue"] {
    font-family: 'Orbitron', monospace !important;
    font-size: 1.8rem !important;
    font-weight: 700 !important;
}
[data-testid="stMetricLabel"] {
    font-size: 0.65rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.08em !important;
    color: #454870 !important;
}

/* ---- BUTTONS ---- */
.stButton > button {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.75rem !important;
    font-weight: 700 !important;
    letter-spacing: 0.06em !important;
    text-transform: uppercase !important;
    border-radius: 4px !important;
    transition: all 0.2s !important;
}
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #0a2060, #1840c0) !important;
    border: 1px solid #4080ff !important;
    color: #60a0ff !important;
    box-shadow: 0 0 15px rgba(32, 96, 224, 0.25) !important;
}
.stButton > button[kind="primary"]:hover {
    box-shadow: 0 0 25px rgba(64, 128, 255, 0.5) !important;
    transform: translateY(-1px) !important;
}
.stButton > button[kind="secondary"] {
    background: transparent !important;
    border: 1px solid #1c1f38 !important;
    color: #8890b0 !important;
}
.stButton > button[kind="secondary"]:hover {
    border-color: #4080ff !important;
    color: #60a0ff !important;
}

/* ---- TABS ---- */
[data-testid="stTabs"] button {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.7rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.08em !important;
    color: #454870 !important;
    border-radius: 0 !important;
}
[data-testid="stTabs"] button[aria-selected="true"] {
    color: #4080ff !important;
    border-bottom: 2px solid #4080ff !important;
    background: transparent !important;
}

/* ---- DATAFRAMES / TABLES ---- */
[data-testid="stDataFrame"] {
    border: 1px solid #14162a !important;
    border-radius: 5px !important;
    overflow: hidden !important;
}
.dataframe thead th {
    background: #10111a !important;
    color: #4080ff !important;
    font-size: 0.65rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.06em !important;
    border-bottom: 1px solid #14162a !important;
}
.dataframe tbody tr:hover td {
    background: rgba(64, 128, 255, 0.04) !important;
}

/* ---- EXPANDERS ---- */
[data-testid="stExpander"] {
    background: #0c0d14 !important;
    border: 1px solid #14162a !important;
    border-radius: 5px !important;
    overflow: hidden !important;
}
[data-testid="stExpander"] summary {
    font-size: 0.7rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.08em !important;
    color: #60a0ff !important;
    font-weight: 700 !important;
}

/* ---- PROGRESS BAR ---- */
[data-testid="stProgress"] > div > div {
    background: linear-gradient(90deg, #2060e0, #4080ff, #60a0ff) !important;
    box-shadow: 0 0 8px rgba(64, 128, 255, 0.5) !important;
}

/* ---- INPUTS / SELECTS ---- */
.stTextInput > div > div > input,
.stSelectbox > div > div > div,
.stTextArea textarea {
    background: #0c0d14 !important;
    border: 1px solid #14162a !important;
    color: #d0d8f0 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.75rem !important;
    border-radius: 3px !important;
}
.stTextInput > div > div > input:focus {
    border-color: #4080ff !important;
    box-shadow: 0 0 0 1px #4080ff !important;
}

/* ---- FILE UPLOADER ---- */
[data-testid="stFileUploader"] {
    background: #0c0d14 !important;
    border: 2px dashed #1c1f38 !important;
    border-radius: 6px !important;
    transition: border-color 0.2s !important;
}
[data-testid="stFileUploader"]:hover {
    border-color: #4080ff !important;
    background: rgba(64, 128, 255, 0.02) !important;
}
[data-testid="stFileUploaderDropzone"] {
    color: #454870 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.75rem !important;
}

/* ---- SEVERITY / RISK BADGES ---- */
.badge {
    display: inline-block;
    font-size: 0.6rem;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 3px;
    border: 1px solid currentColor;
    letter-spacing: 0.05em;
    white-space: nowrap;
}
.badge-reject    { color: #ff3a3a; background: rgba(255,58,58,0.1); }
.badge-critical  { color: #e05c5c; background: rgba(224,92,92,0.1); }
.badge-error     { color: #e08a2e; background: rgba(224,138,46,0.1); }
.badge-warning   { color: #c4b400; background: rgba(196,180,0,0.08); }
.badge-blocker   { color: #ff3a3a; background: rgba(255,58,58,0.08); }
.badge-medical   { color: #e05c5c; background: rgba(224,92,92,0.08); }
.badge-struct    { color: #e08a2e; background: rgba(224,138,46,0.08); }
.badge-advisory  { color: #4080ff; background: rgba(64,128,255,0.08); }

/* ---- FINDING CARDS ---- */
.finding-card {
    background: #0c0d14;
    border: 1px solid #14162a;
    border-radius: 5px;
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    transition: border-color 0.15s;
    border-left: 3px solid #14162a;
}
.finding-card:hover { border-color: #1c1f38; }
.finding-card.medical { border-left-color: #e05c5c; }
.finding-card.blocker { border-left-color: #ff3a3a; }
.finding-card.structural { border-left-color: #e08a2e; }
.finding-card.advisory { border-left-color: #4080ff; }
.finding-subject { color: #4080ff; font-weight: 700; font-size: 0.8rem; }
.finding-domain  { color: #454870; font-size: 0.7rem; }
.finding-label   { color: #8890b0; font-size: 0.75rem; font-weight: 500; }
.finding-detail  { color: #d0d8f0; font-size: 0.7rem; margin-top: 4px; line-height: 1.5; }
.finding-meta    { color: #252840; font-size: 0.65rem; margin-top: 4px; }

/* ---- STAT BOXES ---- */
.stat-box {
    background: #0c0d14;
    border: 1px solid #14162a;
    border-radius: 5px;
    padding: 0.75rem;
    text-align: center;
    transition: transform 0.2s;
}
.stat-box:hover { transform: translateY(-2px); }
.stat-val { font-family: 'Orbitron', monospace; font-size: 1.8rem; font-weight: 700; }
.stat-lbl { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.1em; color: #454870; }

/* ---- GLOW EFFECT ON HEADER ---- */
.header-glow {
    background: linear-gradient(135deg, #0a1840 0%, #050608 60%);
    border-bottom: 1px solid #14162a;
    padding: 1rem 0 0.75rem;
    margin-bottom: 1rem;
    position: relative;
}
.header-glow::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent, #4080ff, #60a0ff, #4080ff, transparent);
    opacity: 0.4;
}

/* ---- SCROLLBAR ---- */
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: #05060a; }
::-webkit-scrollbar-thumb { background: #1c1f38; border-radius: 2px; }
::-webkit-scrollbar-thumb:hover { background: #4080ff; }

/* ---- DOMAIN CARD ---- */
.domain-card {
    background: #0c0d14;
    border: 1px solid #14162a;
    border-radius: 4px;
    padding: 0.6rem 0.75rem;
    margin-bottom: 0.4rem;
    font-size: 0.7rem;
    transition: border-color 0.15s;
}
.domain-card.has-findings {
    border-left: 2px solid #e05c5c;
    background: rgba(224,92,92,0.03);
}

/* ---- INFO BOX ---- */
.info-box {
    background: rgba(64, 128, 255, 0.06);
    border: 1px solid rgba(64, 128, 255, 0.2);
    border-radius: 4px;
    padding: 0.6rem 0.8rem;
    font-size: 0.72rem;
    color: #8890b0;
    margin-bottom: 0.75rem;
}

/* ---- WAIVED STYLE ---- */
.waived-badge {
    display: inline-block;
    font-size: 0.6rem;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 2px;
    color: #30a060;
    background: rgba(48,160,96,0.1);
    border: 1px solid rgba(48,160,96,0.3);
    letter-spacing: 0.05em;
}
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# SESSION STATE INITIALISATION
# ---------------------------------------------------------------------------
def _init_state():
    defaults = {
        "uploaded_files_meta": {},
        "findings": [],
        "enabled_ids": set(c["id"] for c in CHECKS),
        "is_running": False,
        "run_progress": 0,
        "run_label": "",
        "run_count": 0,
        "last_run_ts": "",
        "waived_notes": {},       # fid -> note text
        "risk_filter": "All",
        "check_search": "",
        "check_layer_filter": "All",
        "check_cat_filter": "All",
        "subject_search": "",
        "active_tab": 0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
RISK_COLORS = {
    "submission-blocker": "#ff3a3a",
    "medical-concern":    "#e05c5c",
    "structural":         "#e08a2e",
    "advisory":           "#4080ff",
}
RISK_LABELS = {
    "submission-blocker": "Submission Blocker",
    "medical-concern":    "Medical Concern",
    "structural":         "Structural Error",
    "advisory":           "Advisory",
}
SEV_COLORS = {
    "REJECT":   "#ff3a3a",
    "CRITICAL": "#e05c5c",
    "ERROR":    "#e08a2e",
    "WARNING":  "#c4b400",
    "NOTICE":   "#4080ff",
}

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def _active_findings():
    return [f for f in st.session_state.findings
            if not f.get("waived")]

def _count_by(findings, key):
    out = {}
    for f in findings:
        v = f.get(key, "?")
        out[v] = out.get(v, 0) + 1
    return out

def _count_dom(findings):
    out = {}
    for f in findings:
        d = f.get("domain", "?").split("/")[0]
        out[d] = out.get(d, 0) + 1
    return out

def _worst_risk(risk_list):
    order = ["submission-blocker", "medical-concern", "structural", "advisory"]
    for r in order:
        if r in risk_list:
            return r
    return "advisory"

def _badge_html(text, kind):
    cls_map = {
        "REJECT": "badge-reject", "CRITICAL": "badge-critical",
        "ERROR": "badge-error", "WARNING": "badge-warning",
        "submission-blocker": "badge-blocker", "medical-concern": "badge-medical",
        "structural": "badge-struct", "advisory": "badge-advisory",
    }
    cls = cls_map.get(text, cls_map.get(kind, "badge-struct"))
    return f'<span class="badge {cls}">{text}</span>'

def _sev_icon(sev):
    return {"REJECT": "[!]", "CRITICAL": "[X]", "ERROR": "^",
            "WARNING": "[~]", "NOTICE": "[i]"}.get(sev, "-")

def _findings_to_df(findings, risk_filter="All"):
    rows = []
    for f in findings:
        if risk_filter != "All" and f.get("risk") != risk_filter:
            continue
        rows.append({
            "ID":      f["fid"],
            "Sev":     f["sev"],
            "Risk":    RISK_LABELS.get(f["risk"], f["risk"]),
            "Subject": "GLOBAL" if f["subj"] == "ALL" else f["subj"],
            "Domain":  f["domain"].split("/")[0],
            "Check":   f["label"][:55] + ("..." if len(f["label"]) > 55 else ""),
            "Detail":  f["detail"][:75] + ("..." if len(f["detail"]) > 75 else ""),
            "Source":  f["source"],
            "Layer":   f["layer"],
            "Waived":  "YES" if f.get("waived") else "",
        })
    if not rows:
        return pd.DataFrame(columns=["ID","Sev","Risk","Subject","Domain","Check","Detail","Source","Layer","Waived"])
    return pd.DataFrame(rows)

def _files_to_df(meta_dict):
    rows = []
    for fname, m in meta_dict.items():
        rows.append({
            "Filename": fname,
            "Type":     m.get("type", ""),
            "Rows":     m.get("rows", 0),
            "Cols":     m.get("cols", 0),
            "Size":     f"{m.get('size', 0):,} B",
            "Variables": ", ".join((m.get("variables") or [])[:5]),
            "Status":   "ERROR: " + m["parse_error"] if m.get("parse_error") else "OK",
        })
    if not rows:
        return pd.DataFrame(columns=["Filename","Type","Rows","Cols","Size","Variables","Status"])
    return pd.DataFrame(rows)

def _subject_summary(findings):
    sm = {}
    for f in [x for x in findings if not x.get("waived")]:
        k = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
        sm.setdefault(k, []).append(f)
    rows = []
    for subj, sf in sorted(sm.items(),
            key=lambda x: (0 if _worst_risk([f["risk"] for f in x[1]]) == "medical-concern" else 1, x[0])):
        doms = list(dict.fromkeys(f["domain"].split("/")[0] for f in sf))
        rows.append({
            "Subject":     subj,
            "Findings":    len(sf),
            "Worst Risk":  RISK_LABELS.get(_worst_risk([f["risk"] for f in sf]), ""),
            "Domains":     ", ".join(doms[:6]),
            "Categories":  ", ".join(list(dict.fromkeys(f["cat"] for f in sf))[:4]),
        })
    if not rows:
        return pd.DataFrame(columns=["Subject","Findings","Worst Risk","Domains","Categories"])
    return pd.DataFrame(rows)

def _domain_map_df(findings):
    active = [f for f in findings if not f.get("waived")]
    dom_counts = _count_dom(active)
    all_doms = sorted(set(
        d for c in CHECKS for d in c["domain"].split("/")
        if d not in ("ALL", "DEFINE", "SUPP", "RELREC")
    ))
    rows = []
    for dom in all_doms:
        dc = [c for c in CHECKS if dom in c["domain"].split("/")]
        en = len([c for c in dc if c["id"] in st.session_state.enabled_ids])
        has_crit = any(c["sev"] in ("CRITICAL", "REJECT") for c in dc)
        rows.append({
            "Domain":           dom,
            "Total Checks":     len(dc),
            "Enabled":          en,
            "Critical Rules":   "YES" if has_crit else "",
            "Active Findings":  dom_counts.get(dom, 0),
        })
    if not rows:
        return pd.DataFrame(columns=["Domain","Total Checks","Enabled","Critical Rules","Active Findings"])
    return pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# VALIDATION RUNNER
# ---------------------------------------------------------------------------
def run_validation():
    """Run validation and store results in session state."""
    st.session_state.is_running = True
    st.session_state.findings = []
    st.session_state.run_progress = 0

    files_meta = dict(st.session_state.uploaded_files_meta)
    enabled_ids = set(st.session_state.enabled_ids)

    engine = ValidationEngine(files_meta, enabled_ids)

    progress_placeholder = st.empty()
    label_placeholder = st.empty()
    bar = progress_placeholder.progress(0, text="Initializing...")

    def progress_cb(pct, label=""):
        st.session_state.run_progress = pct
        st.session_state.run_label = label
        bar.progress(min(pct, 100) / 100, text=label[:70] if label else "Running...")

    findings = engine.run(progress_cb)

    st.session_state.findings = findings
    # Apply any existing waiver notes
    for f in st.session_state.findings:
        if f["fid"] in st.session_state.waived_notes:
            f["waived"] = True
            f["waiver_note"] = st.session_state.waived_notes[f["fid"]]

    st.session_state.is_running = False
    st.session_state.run_progress = 100
    st.session_state.run_count += 1
    st.session_state.last_run_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    progress_placeholder.empty()
    label_placeholder.empty()

# ---------------------------------------------------------------------------
# SIDEBAR
# ---------------------------------------------------------------------------
with st.sidebar:
    # Logo + title in sidebar
    st.markdown("""
    <div style="text-align:center;padding:0.5rem 0 1rem">
      <div style="font-family:'Orbitron',monospace;font-size:1.1rem;font-weight:900;
                  background:linear-gradient(135deg,#4080ff,#80c0ff);
                  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
                  background-clip:text;letter-spacing:0.04em">
        CIS v5.0
      </div>
      <div style="font-size:0.6rem;color:#252840;text-transform:uppercase;letter-spacing:0.1em;margin-top:2px">
        SDTM Beyond-P21
      </div>
    </div>
    """, unsafe_allow_html=True)

    # -- FILE UPLOAD ------------------------------------------------------
    st.markdown("#### [DIR] Upload Datasets")

    uploaded = st.file_uploader(
        "Drop SDTM files here",
        type=["sas7bdat", "xpt", "csv", "xlsx", "xls", "json", "xml", "txt", "pdf"],
        accept_multiple_files=True,
        help="Supports SAS7BDAT, XPT, CSV, XLSX, JSON, Define-XML, PDF",
        label_visibility="collapsed",
    )

    if uploaded:
        for uf in uploaded:
            fname = uf.name
            if fname not in st.session_state.uploaded_files_meta:
                ext = os.path.splitext(fname)[1].lower()
                raw = uf.read()
                meta = FileParser.analyze(raw, fname, ext)
                st.session_state.uploaded_files_meta[fname] = meta

    n_files = len(st.session_state.uploaded_files_meta)
    if n_files > 0:
        st.caption(f"**{n_files} file(s) loaded**")
        for fname, m in st.session_state.uploaded_files_meta.items():
            err = m.get("parse_error", "")
            icon = "[ERR]" if err else "[OK]"
            st.caption(f"{icon} {fname} ({m.get('rows',0)} rows, {m.get('cols',0)} cols)")

        if st.button("[DEL] Clear All Files", key="clear_files", use_container_width=True):
            st.session_state.uploaded_files_meta = {}
            st.session_state.findings = []
            st.session_state.waived_notes = {}
            st.rerun()
    else:
        st.markdown(
            '<div class="info-box">No files loaded. App will run with 40 demo findings.</div>',
            unsafe_allow_html=True,
        )

    st.divider()

    # -- CHECK CONFIGURATION ----------------------------------------------
    st.markdown("#### [cfg] Check Configuration")

    n_enabled = len(st.session_state.enabled_ids)
    n_total = len(CHECKS)
    st.caption(f"**{n_enabled} / {n_total} checks active**")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Enable All", key="enable_all", use_container_width=True):
            st.session_state.enabled_ids = set(c["id"] for c in CHECKS)
            st.rerun()
    with col2:
        if st.button("Disable All", key="disable_all", use_container_width=True):
            st.session_state.enabled_ids = set()
            st.rerun()

    layer_opts = ["All"] + sorted(LAYERS)
    sel_layer = st.selectbox("Filter by Layer", layer_opts,
                              key="layer_filter_sel",
                              label_visibility="visible")
    cat_opts = ["All"] + sorted(CATEGORIES)
    sel_cat = st.selectbox("Filter by Category", cat_opts,
                            key="cat_filter_sel",
                            label_visibility="visible")
    srch = st.text_input("Search checks", placeholder="Type check ID or keyword...",
                          key="check_search_input",
                          label_visibility="visible")

    # Filtered check list with toggles
    filtered_checks = [
        c for c in CHECKS
        if (sel_layer == "All" or c["layer"] == sel_layer)
        and (sel_cat == "All" or c["cat"] == sel_cat)
        and (not srch or srch.lower() in c["label"].lower() or srch.lower() in c["id"].lower())
    ]

    with st.expander(f"Toggle Checks ({len(filtered_checks)} shown)", expanded=False):
        for c in filtered_checks:
            is_on = c["id"] in st.session_state.enabled_ids
            new_val = st.checkbox(
                f"**{c['id']}** -- {c['label'][:50]}{'...' if len(c['label'])>50 else ''}",
                value=is_on,
                key=f"chk_{c['id']}",
                help=f"Layer: {c['layer']} | Domain: {c['domain']} | Sev: {c['sev']} | Source: {c['source']}",
            )
            if new_val != is_on:
                if new_val:
                    st.session_state.enabled_ids.add(c["id"])
                else:
                    st.session_state.enabled_ids.discard(c["id"])

    st.divider()

    # -- RUN BUTTON -------------------------------------------------------
    if st.session_state.last_run_ts:
        st.caption(f"Last run: {st.session_state.last_run_ts} (#{st.session_state.run_count})")

    run_clicked = st.button(
        ">  Run Validation",
        type="primary",
        use_container_width=True,
        disabled=st.session_state.is_running,
        key="run_btn",
    )

    if run_clicked:
        run_validation()
        st.rerun()

    # -- REPORT DOWNLOAD --------------------------------------------------
    if st.session_state.findings:
        st.divider()
        report_html = make_html_report(
            findings=st.session_state.findings,
            files_meta=st.session_state.uploaded_files_meta,
            enabled_ids=st.session_state.enabled_ids,
        )
        st.download_button(
            label="[DOWN] Download HTML Report",
            data=report_html.encode("utf-8"),
            file_name=f"clinical_integrity_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
            mime="text/html",
            use_container_width=True,
            key="dl_report",
        )

# ---------------------------------------------------------------------------
# MAIN HEADER
# ---------------------------------------------------------------------------
col_t, col_s = st.columns([2, 3])
with col_t:
    st.markdown("""
    <div class="header-glow">
      <div class="suite-title">Clinical Integrity Suite</div>
      <div class="suite-subtitle">
        SDTM Beyond-P21 &nbsp;|&nbsp; v5.0 &nbsp;|&nbsp;
        {} Checks &nbsp;|&nbsp; 35+ Domains &nbsp;|&nbsp; FDA JumpStart
      </div>
    </div>
    """.format(len(CHECKS)), unsafe_allow_html=True)

# Scorecards
findings_all = st.session_state.findings
active = _active_findings()
by_risk = _count_by(active, "risk")

m1, m2, m3, m4, m5, m6 = st.columns(6)
m1.metric("Active Findings",    len(active),                       delta=None)
m2.metric("Submission Blockers", by_risk.get("submission-blocker", 0), delta=None)
m3.metric("Medical Concerns",   by_risk.get("medical-concern", 0),    delta=None)
m4.metric("Structural Errors",  by_risk.get("structural", 0),          delta=None)
m5.metric("Advisory",           by_risk.get("advisory", 0),            delta=None)
m6.metric("Waived",             len([f for f in findings_all if f.get("waived")]), delta=None)

st.divider()

# ---------------------------------------------------------------------------
# MAIN TABS
# ---------------------------------------------------------------------------
tab_dash, tab_report, tab_subject, tab_domain, tab_registry, tab_files = st.tabs([
    "[CHART] Dashboard",
    "[LIST] Integrity Report",
    "[SUBJ] Subject View",
    "[MAP] Domain Map",
    "[REG] Check Registry",
    "[FILES] Files",
])

# -- TAB 1: DASHBOARD --------------------------------------------------------
with tab_dash:
    if not active:
        st.markdown("""
        <div style="text-align:center;padding:4rem 2rem">
          <div style="font-size:3rem;margin-bottom:1rem;opacity:0.15">[+]</div>
          <div style="font-family:'Orbitron',monospace;font-size:1.1rem;color:#252840;margin-bottom:0.5rem">
            SDTM Clinical Integrity Suite
          </div>
          <div style="color:#252840;font-size:0.75rem">
            Upload SDTM datasets in the sidebar and click Run Validation.<br>
            Or click Run Validation now to see 40 pre-loaded demo findings.
          </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        by_sev = _count_by(active, "sev")
        by_dom = _count_dom(active)
        by_cat = _count_by(active, "cat")
        by_layer = _count_by(active, "layer")

        # Charts
        col_l, col_r = st.columns(2)
        with col_l:
            st.markdown("**Findings by Risk Category**")
            df_risk = pd.DataFrame([
                {"Category": RISK_LABELS.get(k, k), "Count": v,
                 "Color": RISK_COLORS.get(k, "#4080ff")}
                for k, v in sorted(by_risk.items(), key=lambda x: -x[1])
            ])
            if not df_risk.empty:
                st.bar_chart(df_risk.set_index("Category")["Count"])

        with col_r:
            st.markdown("**Findings by Severity**")
            df_sev = pd.DataFrame([
                {"Severity": k, "Count": v}
                for k, v in sorted(by_sev.items(), key=lambda x: -x[1])
            ])
            if not df_sev.empty:
                st.bar_chart(df_sev.set_index("Severity")["Count"])

        col_l2, col_r2 = st.columns([2, 1])
        with col_l2:
            st.markdown("**Findings by SDTM Domain**")
            df_dom = pd.DataFrame([
                {"Domain": k, "Count": v}
                for k, v in sorted(by_dom.items(), key=lambda x: -x[1])[:18]
            ])
            if not df_dom.empty:
                st.bar_chart(df_dom.set_index("Domain")["Count"])

        with col_r2:
            st.markdown("**Findings by Layer**")
            df_layer = pd.DataFrame([
                {"Layer": k, "Count": v}
                for k, v in sorted(by_layer.items(), key=lambda x: -x[1])
            ])
            if not df_layer.empty:
                st.bar_chart(df_layer.set_index("Layer")["Count"])

        # Top categories
        st.markdown("**Top Finding Categories**")
        df_cat = pd.DataFrame([
            {"Category": k, "Count": v}
            for k, v in sorted(by_cat.items(), key=lambda x: -x[1])[:10]
        ])
        if not df_cat.empty:
            st.bar_chart(df_cat.set_index("Category")["Count"])

# -- TAB 2: INTEGRITY REPORT --------------------------------------------------
with tab_report:
    if not findings_all:
        st.info("Run validation to see findings.", icon="[i]")
    else:
        # Filter controls
        f_col1, f_col2, f_col3 = st.columns([1, 1, 2])
        with f_col1:
            risk_opts = ["All", "submission-blocker", "medical-concern", "structural", "advisory"]
            risk_filter = st.selectbox(
                "Filter by Risk",
                risk_opts,
                format_func=lambda x: "All Findings" if x == "All" else RISK_LABELS.get(x, x),
                key="risk_filter_sel",
            )
        with f_col2:
            hide_waived = st.checkbox("Hide waived findings", value=False, key="hide_waived")
        with f_col3:
            df_findings = _findings_to_df(
                [f for f in findings_all if not (hide_waived and f.get("waived"))],
                risk_filter
            )
            st.caption(f"**{len(df_findings)} findings shown** | Total: {len(findings_all)} | Waived: {len([f for f in findings_all if f.get('waived')])}")

        # Root-cause groups
        root_groups = {}
        standalone = []
        for f in findings_all:
            if (risk_filter == "All" or f.get("risk") == risk_filter) and \
               not (hide_waived and f.get("waived")):
                if f.get("root"):
                    root_groups.setdefault(f["root"], []).append(f)
                else:
                    standalone.append(f)

        if root_groups:
            st.markdown("---")
            st.markdown("##### [->] Root-Cause Clusters")
            for root, rf in root_groups.items():
                worst = _worst_risk([f["risk"] for f in rf])
                wc = RISK_COLORS.get(worst, "#4080ff")
                subjs = ", ".join(set("GLOBAL" if f["subj"] == "ALL" else f["subj"] for f in rf))
                with st.expander(
                    f"**Root: {root}** -- {len(rf)} findings -- {RISK_LABELS.get(worst, worst)}",
                    expanded=False,
                ):
                    for f in rf:
                        _render_finding_card(f)

        if standalone:
            # Group by subject
            sm = {}
            for f in standalone:
                k = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
                sm.setdefault(k, []).append(f)

            st.markdown("---")
            st.markdown("##### [SUBJ] Subject Groups")
            sorted_subjects = sorted(sm.items(),
                key=lambda x: (0 if _worst_risk([f["risk"] for f in x[1]]) == "medical-concern" else 1, x[0]))

            for subj, sf in sorted_subjects:
                worst = _worst_risk([f["risk"] for f in sf])
                wc = RISK_COLORS.get(worst, "#4080ff")
                doms = ", ".join(list(dict.fromkeys(f["domain"].split("/")[0] for f in sf))[:5])
                with st.expander(
                    f"**{subj}** -- {len(sf)} finding{'s' if len(sf) > 1 else ''} -- {doms}",
                    expanded=False,
                ):
                    for f in sf:
                        _render_finding_card(f)

        st.markdown("---")
        st.markdown("##### [LIST] Full Findings Table")
        st.dataframe(
            df_findings,
            use_container_width=True,
            hide_index=True,
            height=380,
        )

# -- TAB 3: SUBJECT VIEW ------------------------------------------------------
with tab_subject:
    if not active:
        st.info("Run validation to see subject data.", icon="[i]")
    else:
        srch_subj = st.text_input(
            "Filter by Subject ID",
            placeholder="e.g. 001-007",
            key="subj_search_main",
            label_visibility="visible",
        )
        df_subj = _subject_summary(findings_all)
        if srch_subj:
            df_subj = df_subj[df_subj["Subject"].str.contains(srch_subj, case=False, na=False)]
        st.caption(f"**{len(df_subj)} subjects with findings**")
        st.dataframe(df_subj, use_container_width=True, hide_index=True, height=460)

        st.markdown("---")
        # Expandable detail per subject
        if srch_subj:
            matches = [f for f in active
                       if srch_subj.lower() in (f["subj"] or "").lower()]
            if matches:
                st.markdown(f"##### Detail for subject matching '{srch_subj}'")
                for f in matches:
                    _render_finding_card(f)

# -- TAB 4: DOMAIN MAP --------------------------------------------------------
with tab_domain:
    st.markdown("##### [MAP] Domain Coverage Matrix")
    st.caption(f"{len(CHECKS)} checks registered across 35+ SDTM domains")
    df_dom_map = _domain_map_df(findings_all)

    # Style the table - highlight domains with findings
    def _style_domain(row):
        if row["Active Findings"] > 0:
            return ["color: #e05c5c"] * len(row)
        return [""] * len(row)

    styled = df_dom_map.style.apply(_style_domain, axis=1)
    st.dataframe(styled, use_container_width=True, hide_index=True, height=520)

# -- TAB 5: CHECK REGISTRY ----------------------------------------------------
with tab_registry:
    st.markdown("##### [REG] Full Check Registry")
    srch_reg = st.text_input("Search registry", placeholder="Check ID or keyword...",
                              key="reg_search", label_visibility="visible")
    layer_reg = st.selectbox("Layer", ["All"] + sorted(LAYERS), key="reg_layer")
    cat_reg   = st.selectbox("Category", ["All"] + sorted(CATEGORIES), key="reg_cat")

    reg_checks = [
        c for c in CHECKS
        if (not srch_reg or srch_reg.lower() in c["label"].lower() or srch_reg.lower() in c["id"].lower())
        and (layer_reg == "All" or c["layer"] == layer_reg)
        and (cat_reg == "All" or c["cat"] == cat_reg)
    ]

    df_reg = pd.DataFrame([{
        "ID":          c["id"],
        "Layer":       c["layer"],
        "Category":    c["cat"],
        "Domain":      c["domain"],
        "Severity":    c["sev"],
        "Risk":        RISK_LABELS.get(c["risk"], c["risk"]),
        "Description": c["label"],
        "Source":      c["source"],
        "Enabled":     "ON" if c["id"] in st.session_state.enabled_ids else "OFF",
    } for c in reg_checks])

    st.caption(f"**{len(df_reg)} checks shown** of {len(CHECKS)} total")
    st.dataframe(df_reg, use_container_width=True, hide_index=True, height=500)

# -- TAB 6: FILES -------------------------------------------------------------
with tab_files:
    st.markdown("##### [FILES] Loaded Files")
    df_files = _files_to_df(st.session_state.uploaded_files_meta)
    if df_files.empty:
        st.info("No files loaded. Upload datasets via the sidebar.", icon="[i]")
    else:
        st.dataframe(df_files, use_container_width=True, hide_index=True)

        st.markdown("---")
        st.markdown("##### Variable Preview")
        selected_file = st.selectbox(
            "Select file to preview",
            list(st.session_state.uploaded_files_meta.keys()),
            key="file_preview_sel",
        )
        if selected_file:
            m = st.session_state.uploaded_files_meta[selected_file]
            data = m.get("data", [])
            if data:
                df_preview = pd.DataFrame(data[:50])
                st.dataframe(df_preview, use_container_width=True, hide_index=True, height=300)
            else:
                st.caption("No row data available (header-only parse for SAS7BDAT/XPT).")

# ---------------------------------------------------------------------------
# FINDING CARD RENDERER  (defined here so it can use session state)
# ---------------------------------------------------------------------------
def _render_finding_card(f):
    risk = f.get("risk", "structural")
    sev = f.get("sev", "")
    css_cls = {
        "submission-blocker": "blocker",
        "medical-concern": "medical",
        "structural": "structural",
        "advisory": "advisory",
    }.get(risk, "structural")

    is_waived = f.get("waived", False)
    fid = f["fid"]
    subj = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
    waived_badge = '<span class="waived-badge">WAIVED</span>' if is_waived else ""
    actual_badge = (
        '<span style="font-size:0.6rem;color:#30a060;border:1px solid rgba(48,160,96,0.4);'
        'padding:1px 5px;border-radius:2px;background:rgba(48,160,96,0.08)">ACTUAL</span>'
        if f.get("actual") else
        '<span style="font-size:0.6rem;color:#4080ff;border:1px solid rgba(64,128,255,0.3);'
        'padding:1px 5px;border-radius:2px;background:rgba(64,128,255,0.08)">DEMO</span>'
    )
    root_line = f'<div style="font-size:0.65rem;color:#252840;margin-top:3px">Root: {f["root"]}</div>' if f.get("root") else ""

    st.markdown(f"""
    <div class="finding-card {css_cls}" style="opacity:{'0.35' if is_waived else '1'}">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
        <span>{_sev_icon(sev)}</span>
        {_badge_html(sev, sev)}
        {_badge_html(RISK_LABELS.get(risk, risk), risk)}
        <span class="finding-subject">{subj}</span>
        <span class="finding-domain">{f.get('domain','').split('/')[0]}</span>
        {actual_badge}
        {waived_badge}
      </div>
      <div class="finding-label">{f.get('label','')}</div>
      <div class="finding-detail">{f.get('detail','')}</div>
      {root_line}
      <div class="finding-meta">{fid} &bull; {f.get('cat','')} &bull; Source: {f.get('source','')}</div>
    </div>
    """, unsafe_allow_html=True)

    # Waiver controls inline
    with st.container():
        wc1, wc2, wc3 = st.columns([3, 1, 1])
        with wc1:
            note = st.text_input(
                "cSDRG waiver note",
                value=f.get("waiver_note", ""),
                placeholder="Document justification for cSDRG Section 4...",
                key=f"note_{fid}",
                label_visibility="collapsed",
            )
        with wc2:
            action = "Unwaive" if is_waived else "Waive"
            if st.button(action, key=f"waive_{fid}", use_container_width=True):
                f["waived"] = not is_waived
                f["waiver_note"] = note
                if f["waived"]:
                    st.session_state.waived_notes[fid] = note
                else:
                    st.session_state.waived_notes.pop(fid, None)
                st.rerun()
        with wc3:
            st.caption(f"{'v Waived' if is_waived else ''}")
