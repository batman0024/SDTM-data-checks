"""modules/parser.py"""
import re, csv, io, json, os, struct


class FileParser:
    TYPE_MAP = {
        ".sas7bdat": "SAS Dataset", ".xpt": "XPT Transport",
        ".csv": "CSV", ".xlsx": "Excel", ".xls": "Excel (legacy)",
        ".json": "JSON", ".xml": "XML/Define", ".txt": "Text", ".pdf": "PDF",
    }

    @staticmethod
    def analyze(raw_bytes: bytes, fname: str, ext: str) -> dict:
        meta = {
            "filename": fname, "size": len(raw_bytes),
            "type": FileParser.TYPE_MAP.get(ext, "Unknown"),
            "ext": ext, "rows": 0, "cols": 0, "variables": [], "data": [],
        }
        try:
            if ext == ".csv":
                FileParser._csv(raw_bytes, meta)
            elif ext in (".xlsx", ".xls"):
                FileParser._xlsx(raw_bytes, meta)
            elif ext == ".xpt":
                FileParser._xpt(raw_bytes, meta)
            elif ext == ".sas7bdat":
                FileParser._sas7bdat(raw_bytes, meta)
            elif ext == ".json":
                FileParser._json(raw_bytes, meta)
            elif ext == ".xml":
                FileParser._xml(raw_bytes, meta)
        except Exception as e:
            meta["parse_error"] = str(e)
        return meta

    @staticmethod
    def _csv(data, meta):
        text = data.decode("utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        rows = []
        for i, row in enumerate(reader):
            rows.append(dict(row))
            if i >= 4999:
                break
        meta["variables"] = list(rows[0].keys()) if rows else []
        meta["cols"] = len(meta["variables"])
        meta["rows"] = len(rows)
        meta["data"] = rows

    @staticmethod
    def _xlsx(data, meta):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.active
        all_rows = list(ws.iter_rows(values_only=True))
        if not all_rows:
            wb.close()
            return
        header = [str(h) if h is not None else "" for h in all_rows[0]]
        rows = []
        for r in all_rows[1:5001]:
            rows.append(dict(zip(header, [str(v) if v is not None else "" for v in r])))
        meta["variables"] = header
        meta["cols"] = len(header)
        meta["rows"] = len(rows)
        meta["data"] = rows
        wb.close()

    @staticmethod
    def _xpt(data, meta):
        try:
            if len(data) < 240:
                return
            raw = data[240:]
            namestr_len = 140
            pos = 0
            names = []
            while pos + namestr_len <= len(raw):
                chunk = raw[pos:pos + namestr_len]
                ntype = struct.unpack(">h", chunk[0:2])[0]
                if ntype not in (1, 2):
                    break
                name = chunk[8:16].decode("ascii", errors="replace").strip()
                if name:
                    names.append(name)
                pos += namestr_len
            meta["variables"] = names
            meta["cols"] = len(names)
            meta["data"] = []
        except Exception as e:
            meta["parse_error"] = "XPT: " + str(e)

    @staticmethod
    def _sas7bdat(data, meta):
        text = data[:65536].decode("ascii", errors="replace")
        skip = {"SAS", "SASLIB", "UNIX", "WINDOWS", "W32", "AMD64", "LINUX"}
        candidates = re.findall(r"\b[A-Z][A-Z0-9_]{0,31}\b", text)
        seen, names = set(), []
        for c in candidates:
            if c not in seen and c not in skip:
                seen.add(c)
                names.append(c)
            if len(names) >= 80:
                break
        meta["variables"] = names[:50]
        meta["cols"] = len(meta["variables"])
        meta["data"] = []

    @staticmethod
    def _json(data, meta):
        obj = json.loads(data.decode("utf-8", errors="replace"))
        if isinstance(obj, list) and obj:
            meta["variables"] = list(obj[0].keys()) if isinstance(obj[0], dict) else []
            meta["rows"] = len(obj)
            meta["cols"] = len(meta["variables"])
            meta["data"] = obj[:5000]
        elif isinstance(obj, dict):
            meta["variables"] = list(obj.keys())
            meta["cols"] = len(meta["variables"])
            meta["rows"] = 1
            meta["data"] = [obj]

    @staticmethod
    def _xml(data, meta):
        text = data.decode("utf-8", errors="replace")
        items = re.findall(r'OID="([^"]+)"', text)
        meta["variables"] = items[:50]
        meta["cols"] = len(items)
        meta["rows"] = text.count("<ItemDef")
        meta["type"] = "Define-XML"
        meta["data"] = []
