@echo off
chcp 65001 >nul 2>&1
:: ============================================================
::  CIS Launcher  --  Streamlit + FastAPI Gateway
::  Clinical Integrity Suite v15  |  Internal Use Only
:: ============================================================
::
::  FIXES UNC NETWORK PATH ISSUE:
::  If run from a network share (\\server\...) cmd.exe cannot
::  use %~dp0 as a working directory.  This script uses pushd
::  which auto-maps the UNC path to a temporary drive letter
::  so all relative paths work correctly.
::
::  FOLDER STRUCTURE (unzip preserves this):
::    sdtm_checks_streamlit_v20\
::      start_cis.bat              <- this file
::      gateway.py
::      requirements_gateway.txt
::      cis_v20\                   <- Streamlit app
::        app.py  ui\  modules\
::
::  USAGE:
::    Double-click  start_cis.bat
::    start_cis.bat --admin you@company.com
::    start_cis.bat --domains company.com
::    start_cis.bat --hours 12
::    start_cis.bat --port 9000
:: ============================================================

title CIS Clinical Integrity Suite v15

:: ---- Map UNC share to a drive letter (key fix for network paths) ----
pushd "%~dp0"
if errorlevel 1 (
    echo  [ERROR] Cannot access: %~dp0
    echo  Copy the folder to a local drive and try again.
    pause
    exit /b 1
)
:: %CD% is now the correct path, even on UNC shares
set SCRIPT_DIR=%CD%\

:: ---- Config (edit if needed) ----------------------------------------
set STREAMLIT_PORT=8501
set GATEWAY_PORT=8000
set SESSION_HOURS=8
set APP_DIR=%SCRIPT_DIR%cis_v20
set GATEWAY_FILE=%SCRIPT_DIR%gateway.py
set ADMIN_EMAILS=
set ALLOWED_DOMAINS=
set PYTHON_CMD=python
:: conda: set PYTHON_CMD=C:\ProgramData\Miniconda3\envs\cis\python.exe
:: venv:  set PYTHON_CMD=%SCRIPT_DIR%.venv\Scripts\python.exe
:: ---------------------------------------------------------------------

:parse_args
if "%1"=="--admin"   (set ADMIN_EMAILS=%2   & shift & shift & goto parse_args)
if "%1"=="--domains" (set ALLOWED_DOMAINS=%2& shift & shift & goto parse_args)
if "%1"=="--hours"   (set SESSION_HOURS=%2  & shift & shift & goto parse_args)
if "%1"=="--port"    (set GATEWAY_PORT=%2   & shift & shift & goto parse_args)
if "%1"=="--appdir"  (set APP_DIR=%2        & shift & shift & goto parse_args)

echo.
echo  =====================================================
echo   CIS Clinical Integrity Suite v15  --  Launcher
echo   SDTM Beyond-P21  ^|  Internal Use Only
echo  =====================================================
echo.
echo  [CONFIG]
echo    Root dir  : %SCRIPT_DIR%
echo    App dir   : %APP_DIR%
echo    Streamlit : http://127.0.0.1:%STREAMLIT_PORT%  (internal)
echo    Gateway   : http://0.0.0.0:%GATEWAY_PORT%      (browser)
echo    Session   : %SESSION_HOURS% hours
if not "%ADMIN_EMAILS%"==""    echo    Admin     : %ADMIN_EMAILS%
if not "%ALLOWED_DOMAINS%"=="" echo    Domains   : %ALLOWED_DOMAINS%
echo.

:: Verify paths
if not exist "%APP_DIR%\app.py" (
    echo  [ERROR] app.py not found in: %APP_DIR%
    echo  Expected: start_cis.bat + gateway.py + cis_v20\app.py
    echo.
    popd & pause & exit /b 1
)
if not exist "%GATEWAY_FILE%" (
    echo  [ERROR] gateway.py not found in: %SCRIPT_DIR%
    echo.
    popd & pause & exit /b 1
)

:: Check Python
%PYTHON_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Edit PYTHON_CMD in this script.
    popd & pause & exit /b 1
)
for /f "tokens=*" %%v in ('%PYTHON_CMD% --version 2^>^&1') do echo  [INFO]  Using %%v

:: Install packages if missing
echo  [CHECK] Verifying packages...
%PYTHON_CMD% -c "import streamlit,fastapi,uvicorn,httpx,altair,pandas" 2>nul
if errorlevel 1 (
    echo  [INSTALL] Installing missing packages...
    %PYTHON_CMD% -m pip install streamlit fastapi "uvicorn[standard]" httpx altair pandas openpyxl --quiet
    if errorlevel 1 (
        echo  [ERROR] pip install failed. Run manually:
        echo    %PYTHON_CMD% -m pip install streamlit fastapi uvicorn httpx altair pandas openpyxl
        popd & pause & exit /b 1
    )
    echo  [OK]    Packages installed.
) else (
    echo  [OK]    All packages present.
)
echo.

:: Set gateway env var
set STREAMLIT_URL=http://127.0.0.1:%STREAMLIT_PORT%

:: Launch Streamlit (minimised background window, uses pushd for UNC)
echo  [START] Launching Streamlit on port %STREAMLIT_PORT%...
start "CIS Streamlit" /min cmd /c "pushd ""%APP_DIR%"" && %PYTHON_CMD% -m streamlit run app.py --server.port %STREAMLIT_PORT% --server.headless true --server.address 127.0.0.1 --browser.gatherUsageStats false 2>&1"

echo  [WAIT]  Allowing 6s for Streamlit to initialise...
timeout /t 6 /nobreak >nul

:: Launch gateway (foreground)
echo  [START] Launching Gateway on port %GATEWAY_PORT%...
echo.
echo  ---------------------------------------------------------
echo   Browser : http://localhost:%GATEWAY_PORT%
echo   Admin   : http://localhost:%GATEWAY_PORT%/admin
echo   Ctrl+C  : stops all services
echo  ---------------------------------------------------------
echo.

%PYTHON_CMD% -m uvicorn gateway:app --host 0.0.0.0 --port %GATEWAY_PORT% --log-level info

:: Cleanup
echo.
echo  [STOP] Closing Streamlit...
taskkill /fi "WINDOWTITLE eq CIS Streamlit" /f >nul 2>&1
echo  [DONE]
popd
pause
