# =============================================================================
# pages/01_data_overview.py  -  Domain inspection, CDISC checks, consistency
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df
from src.utils.theme import apply_theme, get_colors
from src.utils.helpers import (
    get_domain_label, detect_variable_type, create_frequency_table,
    run_consistency_checks,
)
from src.analysis.descriptive import continuous_stats
from src.analysis.plots import bar_chart

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("SDTM Data Overview")

if not st.session_state.get("data_loaded"):
    st.warning("Load data from the Home page first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
domains = sorted(sdtm.keys())

domain = st.selectbox(
    "Select Domain",
    domains,
    format_func=lambda x: f"{x.upper()} - {get_domain_label(x)}",
)
df = sdtm[domain]

# KPIs
k1, k2, k3, k4 = st.columns(4)
n_subj = int(df["USUBJID"].nunique()) if "USUBJID" in df.columns else "-"
total_cells = len(df) * len(df.columns) or 1
miss_pct = df.isna().sum().sum() / total_cells * 100
k1.metric("Records", f"{len(df):,}")
k2.metric("Subjects", f"{n_subj:,}" if isinstance(n_subj, int) else n_subj)
k3.metric("Variables", len(df.columns))
k4.metric("Missing %", f"{miss_pct:.1f}%")

st.markdown("---")
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Preview", "Distribution", "Completeness", "CDISC Conformance", "Consistency Checks"
])

# ---- Tab 1: Preview ----
with tab1:
    n_rows = st.number_input("Rows to display", 10, 5000, 100, step=50)
    st.dataframe(df.head(n_rows), use_container_width=True, height=420)
    st.download_button(
        "Download CSV",
        df.to_csv(index=False).encode("utf-8"),
        f"{domain}.csv", "text/csv",
    )

# ---- Tab 2: Distribution ----
with tab2:
    col = st.selectbox("Variable", df.columns.tolist(), key="dist_col")
    vtype = detect_variable_type(df[col])
    st.caption(f"Detected type: **{vtype}**")

    col_a, col_b = st.columns([2, 1])
    with col_b:
        if vtype == "continuous":
            stats = continuous_stats(df[col])
            st.dataframe(stats.T.rename(columns={0: "Value"}), use_container_width=True)
        else:
            ft = create_frequency_table(df[col])
            st.dataframe(ft, use_container_width=True, hide_index=True)

    with col_a:
        if vtype == "continuous":
            import plotly.graph_objects as go
            fig_h = go.Figure(go.Histogram(
                x=pd.to_numeric(df[col], errors="coerce"),
                nbinsx=30, marker_color=c["accent"],
            ))
            fig_h.update_layout(
                title=f"{col} Distribution",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                margin=dict(l=40, r=20, t=40, b=40),
            )
            st.plotly_chart(fig_h, use_container_width=True)
        else:
            vc = df[col].value_counts().head(20).reset_index()
            vc.columns = ["Category", "Count"]
            fig_b = bar_chart(vc, "Category", "Count",
                              title=f"{col} Frequency", dark=dark)
            if fig_b:
                st.plotly_chart(fig_b, use_container_width=True)

# ---- Tab 3: Completeness Dashboard (Q3) ----
with tab3:
    st.markdown("### Domain Completeness Dashboard")

    # Expected domains per CDISC SDTM IG
    expected = ["dm", "ae", "ex", "lb", "vs", "cm", "mh", "ds",
                "sv", "tr", "rs", "tu", "dv", "fa", "eg"]
    comp_rows = []
    for d in expected:
        if d in sdtm:
            df_d = sdtm[d]
            tc   = len(df_d) * max(len(df_d.columns), 1)
            miss = df_d.isna().sum().sum() / tc * 100 if tc > 0 else 0.0
            comp_rows.append({
                "Domain":         d.upper(),
                "Status":         "Available",
                "Records":        str(len(df_d)),
                "Subjects":       str(int(df_d["USUBJID"].nunique())) if "USUBJID" in df_d.columns else "-",
                "Variables":      str(len(df_d.columns)),
                "Completeness %": round(100.0 - miss, 1),
            })
        else:
            comp_rows.append({
                "Domain":         d.upper(),
                "Status":         "Missing",
                "Records":        "0",
                "Subjects":       "0",
                "Variables":      "0",
                "Completeness %": 0.0,
            })

    comp_df = pd.DataFrame(comp_rows)

    def _color_status(v):
        if v == "Available":
            return f"color: {c['success']}"
        return f"color: {c['danger']}"
    def _color_comp(v):
        if isinstance(v, (int, float)):
            if v >= 95: return f"color: {c['success']}"
            if v >= 80: return f"color: {c['warning']}"
            return f"color: {c['danger']}"
        return ""

    try:
        styled = comp_df.style\
            .map(_color_status, subset=["Status"])\
            .map(_color_comp, subset=["Completeness %"])
    except AttributeError:
        styled = comp_df.style\
            .applymap(_color_status, subset=["Status"])\
            .applymap(_color_comp, subset=["Completeness %"])
    st.dataframe(styled, use_container_width=True, hide_index=True)

    # Missing data per variable in selected domain
    st.markdown(f"### {domain.upper()} Variable-Level Missing Data")
    miss_var = df.isna().sum().reset_index()
    miss_var.columns = ["Variable", "Missing_N"]
    miss_var["Missing_Pct"] = (miss_var["Missing_N"] / len(df) * 100).round(1)
    miss_var = miss_var[miss_var["Missing_N"] > 0].sort_values("Missing_Pct", ascending=False)

    if miss_var.empty:
        st.success(f"No missing values in {domain.upper()}.")
    else:
        st.dataframe(miss_var, use_container_width=True, hide_index=True)
        import plotly.graph_objects as go
        top = miss_var.head(20)
        fig_mv = go.Figure(go.Bar(
            x=top["Missing_Pct"], y=top["Variable"],
            orientation="h", marker_color=c["danger"],
        ))
        fig_mv.update_layout(
            title=f"{domain.upper()} - % Missing by Variable",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            height=max(300, len(top) * 26),
            margin=dict(l=150, r=20, t=40, b=40),
        )
        st.plotly_chart(fig_mv, use_container_width=True)

    # Unique values per variable
    with st.expander("Unique values per variable"):
        uniq = pd.DataFrame({
            "Variable": df.columns,
            "Unique_Values": [df[col2].nunique() for col2 in df.columns],
            "Sample": [str(df[col2].dropna().iloc[0]) if df[col2].notna().any() else "" for col2 in df.columns],
        })
        st.dataframe(uniq, use_container_width=True, hide_index=True)

# ---- Tab 4: CDISC Conformance Checks (Q1 - full) ----
with tab4:
    dom_upper = domain.upper()
    checks = []

    # 1. STUDYID present and consistent
    if "STUDYID" in df.columns:
        uniq_sid = df["STUDYID"].dropna().nunique()
        status = "PASS" if uniq_sid == 1 else "WARN"
        checks.append({"Rule": "STUDYID present and unique", "Status": status,
                        "Detail": f"{uniq_sid} unique STUDYID value(s)"})
    else:
        checks.append({"Rule": "STUDYID present", "Status": "FAIL", "Detail": "STUDYID column missing"})

    # 2. DOMAIN column
    if "DOMAIN" in df.columns:
        dom_vals = df["DOMAIN"].dropna().unique().tolist()
        if len(dom_vals) == 1 and dom_vals[0].upper() == dom_upper:
            checks.append({"Rule": "DOMAIN value matches filename", "Status": "PASS",
                            "Detail": f"DOMAIN = {dom_vals[0]}"})
        else:
            checks.append({"Rule": "DOMAIN value matches filename", "Status": "WARN",
                            "Detail": f"Values: {dom_vals}"})
    else:
        checks.append({"Rule": "DOMAIN column present", "Status": "WARN", "Detail": "DOMAIN not found"})

    # 3. USUBJID
    if "USUBJID" in df.columns:
        checks.append({"Rule": "USUBJID present", "Status": "PASS",
                        "Detail": f"{df['USUBJID'].nunique()} unique subjects"})
    else:
        checks.append({"Rule": "USUBJID present", "Status": "FAIL", "Detail": "USUBJID missing"})

    # 4. Sequence variable uniqueness
    seq_col = f"{dom_upper}SEQ"
    if seq_col in df.columns:
        key_cols = ["USUBJID", seq_col] if "USUBJID" in df.columns else [seq_col]
        dups = int(df.duplicated(subset=key_cols).sum())
        checks.append({"Rule": f"{seq_col} unique within subject",
                        "Status": "PASS" if dups == 0 else "FAIL",
                        "Detail": f"{dups} duplicate SEQ values"})
    else:
        checks.append({"Rule": f"{seq_col} present", "Status": "INFO",
                        "Detail": f"{seq_col} not found (optional in some domains)"})

    # 5. Date ISO 8601 format
    dtc_cols = [col2 for col2 in df.columns if col2.upper().endswith("DTC")]
    for dtc in dtc_cols[:5]:
        sample = df[dtc].dropna().astype(str).head(50)
        bad = sample[~sample.str.match(r"^\d{4}(-\d{2}(-\d{2})?)?$", na=False)]
        n_bad = len(bad)
        checks.append({"Rule": f"{dtc} ISO 8601 format",
                        "Status": "PASS" if n_bad == 0 else "WARN",
                        "Detail": f"{n_bad} non-conformant out of {len(sample)} sampled"
                        + (f" (e.g. {bad.iloc[0]})" if n_bad > 0 else "")})

    # 6. Controlled terminology - comprehensive
    CT_CHECKS = {
        "SEX":    {"Y", "F", "M", "MALE", "FEMALE", "UNKNOWN", "U", "UNDIFFERENTIATED"},
        "RACE":   {"WHITE", "BLACK OR AFRICAN AMERICAN", "ASIAN", "AMERICAN INDIAN OR ALASKA NATIVE",
                   "NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER", "MULTIPLE", "OTHER", "UNKNOWN", "NOT REPORTED"},
        "AESER":  {"Y", "N"},
        "AEOUT":  {"RECOVERED/RESOLVED", "RECOVERING/RESOLVING", "NOT RECOVERED/NOT RESOLVED",
                   "RECOVERED/RESOLVED WITH SEQUELAE", "FATAL", "UNKNOWN",
                   "RECOVERED", "RECOVERING", "NOT RECOVERED", "FATAL/DEATH"},
        "LBNRIND":{"LOW", "NORMAL", "HIGH", "LOW LOW", "HIGH HIGH", "L", "H", "LL", "HH",
                   "ABNORMAL", "NORMAL", "BORDERLINE"},
        "VSSTAT": {"NOT DONE"},
        "DSSCAT": {"STUDY COMPLETION", "STUDY DISCONTINUATION", "DISPOSITION EVENT"},
    }
    for col2, allowed in CT_CHECKS.items():
        if col2 in df.columns:
            vals = set(df[col2].dropna().astype(str).str.upper().unique())
            outside = vals - allowed
            if outside:
                checks.append({"Rule": f"{col2} controlled terminology",
                                "Status": "WARN",
                                "Detail": f"Non-standard values: {list(outside)[:5]}"})
            else:
                checks.append({"Rule": f"{col2} controlled terminology",
                                "Status": "PASS",
                                "Detail": f"{len(vals)} unique values, all conformant"})

    # 7. Numeric variables stored as numeric
    NUM_VARS = [f"{dom_upper}STRESN", f"{dom_upper}STRESC", "EXDOSE", "AGE",
                "AETOXGR", "LBSTRESN", "VSSTRESN"]
    for v in NUM_VARS:
        if v in df.columns:
            numeric_ok = pd.to_numeric(df[v], errors="coerce").notna().sum()
            total_notnull = df[v].notna().sum()
            pct = numeric_ok / total_notnull * 100 if total_notnull > 0 else 100
            checks.append({"Rule": f"{v} is numeric",
                            "Status": "PASS" if pct >= 95 else "WARN",
                            "Detail": f"{pct:.1f}% values parseable as numeric"})

    # 8. VISITNUM numeric and increasing
    if "VISITNUM" in df.columns:
        vn = pd.to_numeric(df["VISITNUM"], errors="coerce")
        non_num = vn.isna().sum()
        checks.append({"Rule": "VISITNUM numeric",
                        "Status": "PASS" if non_num == 0 else "WARN",
                        "Detail": f"{non_num} non-numeric VISITNUM values"})

    checks_df = pd.DataFrame(checks)

    def _color_check(v):
        colors_map = {"PASS": c["success"], "FAIL": c["danger"], "WARN": c["warning"], "INFO": c["subtext"]}
        return f"color: {colors_map.get(v, c['text'])}"

    try:
        styled_checks = checks_df.style.map(_color_check, subset=["Status"])
    except AttributeError:
        styled_checks = checks_df.style.applymap(_color_check, subset=["Status"])
    st.dataframe(styled_checks, use_container_width=True, hide_index=True)

    # Score summary
    pass_n = (checks_df["Status"] == "PASS").sum()
    warn_n = (checks_df["Status"] == "WARN").sum()
    fail_n = (checks_df["Status"] == "FAIL").sum()
    info_n = (checks_df["Status"] == "INFO").sum()
    st.markdown(
        f"**Conformance Score: "
        f"<span style='color:{c['success']}'>{pass_n} PASS</span> | "
        f"<span style='color:{c['warning']}'>{warn_n} WARN</span> | "
        f"<span style='color:{c['danger']}'>{fail_n} FAIL</span> | "
        f"<span style='color:{c['subtext']}'>{info_n} INFO</span>**",
        unsafe_allow_html=True,
    )
    st.download_button(
        "Download Conformance Report",
        checks_df.to_csv(index=False).encode("utf-8"),
        f"cdisc_conformance_{domain}.csv",
    )

# ---- Tab 5: Cross-domain consistency checks (Q2) ----
with tab5:
    st.markdown("### Cross-Domain Subject Consistency Checks")
    st.caption(
        "Validates data integrity across domains: orphan records, impossible dates, "
        "duplicates, and values outside plausible ranges."
    )
    if st.button("Run Consistency Checks", type="primary"):
        with st.spinner("Running checks ..."):
            results = run_consistency_checks(sdtm, adsl if not adsl.empty else None)
        if results.empty:
            st.info("No checks run. Load DM + at least one other domain.")
        else:
            def _color_cons(v):
                colors_map = {"PASS": c["success"], "FAIL": c["danger"], "WARN": c["warning"]}
                return f"color: {colors_map.get(v, c['text'])}"
            try:
                styled_cons = results.style.map(_color_cons, subset=["Status"])
            except AttributeError:
                styled_cons = results.style.applymap(_color_cons, subset=["Status"])
            st.dataframe(styled_cons, use_container_width=True, hide_index=True)

            pass_n = (results["Status"] == "PASS").sum()
            fail_n = (results["Status"] == "FAIL").sum()
            warn_n = (results["Status"] == "WARN").sum()
            st.markdown(
                f"**Result: "
                f"<span style='color:{c['success']}'>{pass_n} PASS</span> | "
                f"<span style='color:{c['warning']}'>{warn_n} WARN</span> | "
                f"<span style='color:{c['danger']}'>{fail_n} FAIL</span>**",
                unsafe_allow_html=True,
            )
            st.download_button(
                "Download Consistency Report",
                results.to_csv(index=False).encode("utf-8"),
                "consistency_checks.csv",
            )
    else:
        st.info("Click 'Run Consistency Checks' to validate cross-domain data integrity.")
