# =============================================================================
# pages/13_advanced_tools.py  -  PP3 CM timeline, PP4 PDF, PP5 comparison,
#                                 Q5 snapshot diff
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.utils.helpers import export_figure_png, export_figure_svg

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    HAS_PX = True
except ImportError:
    HAS_PX = False

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Advanced Tools")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm  = st.session_state["sdtm_data"]
adsl  = get_population_df()
trt_col = get_trt_col(adsl)

tab1, tab2, tab3, tab4 = st.tabs([
    "Subject Comparison",
    "Timeline + Concomitant Meds",
    "Figure Export (PDF/PNG/SVG)",
    "Dataset Snapshot Comparison",
])

# =============================================================
# Tab 1: Subject Comparison side-by-side  (PP5)
# =============================================================
with tab1:
    st.markdown("### Side-by-Side Subject Comparison (PP5)")
    st.caption(
        "Select 2-4 subjects to compare their AE profiles, lab trends, "
        "and treatment durations on a synchronized study-day axis."
    )
    if adsl.empty:
        st.info("ADSL required.")
        st.stop()

    subjs = sorted(adsl["USUBJID"].dropna().unique())
    sel_subjs = st.multiselect(
        "Select 2-4 subjects", subjs,
        default=subjs[:2] if len(subjs) >= 2 else subjs,
        max_selections=4,
    )

    if len(sel_subjs) < 2:
        st.info("Select at least 2 subjects.")
    else:
        compare_view = st.radio(
            "Compare by", ["AE Profile", "Lab Trend", "Treatment Duration"],
            horizontal=True,
        )

        ae_dom = sdtm.get("ae")
        lb_dom = sdtm.get("lb")

        if compare_view == "AE Profile" and ae_dom is not None:
            cols = st.columns(len(sel_subjs))
            for col_idx, sid in enumerate(sel_subjs):
                with cols[col_idx]:
                    st.markdown(f"**{sid}**")
                    arm_row = adsl[adsl["USUBJID"] == sid]
                    arm = str(arm_row[trt_col].iloc[0]) if not arm_row.empty and trt_col else "N/A"
                    st.caption(f"Arm: {arm}")
                    sub_ae = ae_dom[ae_dom["USUBJID"] == sid]
                    if sub_ae.empty:
                        st.info("No AEs")
                    else:
                        pt_col = "AEDECOD" if "AEDECOD" in sub_ae.columns else "AETERM"
                        disp = [c2 for c2 in [pt_col, "AETOXGR", "AESEV", "AESER", "AEREL", "AESTDTC"]
                                if c2 in sub_ae.columns]
                        st.dataframe(sub_ae[disp], use_container_width=True,
                                     hide_index=True, height=300)
                        sae_n = int((sub_ae["AESER"] == "Y").sum()) if "AESER" in sub_ae.columns else 0
                        st.metric("AEs", len(sub_ae), f"{sae_n} SAE")

        elif compare_view == "Lab Trend" and lb_dom is not None:
            tests = sorted(lb_dom["LBTESTCD"].dropna().unique()) if "LBTESTCD" in lb_dom.columns else []
            test = st.selectbox("Lab test", tests)
            fig_cmp = go.Figure()
            colors_cmp = [c["accent"], c["accent2"], c["success"], c["warning"]]
            for i, sid in enumerate(sel_subjs):
                sub = lb_dom[(lb_dom["USUBJID"] == sid) & (lb_dom["LBTESTCD"] == test)]
                if sub.empty:
                    continue
                x_col = "VISIT" if "VISIT" in sub.columns else "LBDTC"
                sub = sub.sort_values(x_col)
                y_vals = pd.to_numeric(sub["LBSTRESN"], errors="coerce") if "LBSTRESN" in sub.columns else None
                if y_vals is None:
                    continue
                fig_cmp.add_trace(go.Scatter(
                    x=sub[x_col], y=y_vals,
                    mode="lines+markers",
                    name=sid,
                    line=dict(color=colors_cmp[i % len(colors_cmp)], width=2),
                    marker=dict(size=7),
                ))
            unit = ""
            if "LBSTRESU" in lb_dom.columns:
                u = lb_dom[lb_dom["LBTESTCD"] == test]["LBSTRESU"].dropna().unique()
                unit = str(u[0]) if len(u) > 0 else ""
            fig_cmp.update_layout(
                title=f"{test} ({unit}) - Subject Comparison",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                xaxis_title="Visit", yaxis_title=f"{test} ({unit})",
                legend=dict(bgcolor=c["card"], font=dict(color=c["text"])),
            )
            st.plotly_chart(fig_cmp, use_container_width=True)

        elif compare_view == "Treatment Duration":
            rows_dur = []
            for sid in sel_subjs:
                row = adsl[adsl["USUBJID"] == sid]
                if row.empty:
                    continue
                rows_dur.append({
                    "Subject": sid,
                    "Arm": str(row[trt_col].iloc[0]) if trt_col else "N/A",
                    "Duration (days)": row["TRTDURD"].iloc[0] if "TRTDURD" in row.columns else np.nan,
                    "Start": str(row["TRTSDT"].iloc[0]) if "TRTSDT" in row.columns else "N/A",
                    "End": str(row["TRTEDT"].iloc[0]) if "TRTEDT" in row.columns else "N/A",
                    "Safety": str(row["SAFFL"].iloc[0]) if "SAFFL" in row.columns else "N/A",
                })
            if rows_dur:
                st.dataframe(pd.DataFrame(rows_dur), use_container_width=True, hide_index=True)

# =============================================================
# Tab 2: Timeline with Concomitant Meds overlay (PP3)
# =============================================================
with tab2:
    st.markdown("### Patient Timeline with Concomitant Medications (PP3)")
    st.caption(
        "Shows treatment exposure, adverse events, and concomitant medications "
        "as overlaid horizontal bars on a shared date axis."
    )
    cm_dom = sdtm.get("cm")
    ae_dom = sdtm.get("ae")
    ex_dom = sdtm.get("ex")

    if cm_dom is None:
        st.info("CM (Concomitant Medications) domain not loaded.")
    else:
        subjs_cm = sorted(adsl["USUBJID"].dropna().unique()) if not adsl.empty else []
        sel_cm = st.selectbox("Select Subject", subjs_cm, key="cm_timeline_subj")

        def _dt(series):
            return pd.to_datetime(series, errors="coerce")

        fig_cm = make_subplots(
            rows=3, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.05,
            subplot_titles=["Drug Exposure (EX)", "Adverse Events (AE)", "Concomitant Medications (CM)"],
            row_heights=[0.2, 0.4, 0.4],
        )
        bg   = "#0f172a" if dark else "#ffffff"
        paper_bg = "#1e293b" if dark else "#f8fafc"
        text_col = "#e2e8f0" if dark else "#1e293b"

        # Panel 1: EX
        if ex_dom is not None and "USUBJID" in ex_dom.columns:
            ex_s = ex_dom[ex_dom["USUBJID"] == sel_cm].copy()
            if "EXSTDTC" in ex_s.columns:
                ex_s["_dt"] = _dt(ex_s["EXSTDTC"])
                for _, r in ex_s.dropna(subset=["_dt"]).iterrows():
                    fig_cm.add_trace(go.Scatter(
                        x=[r["_dt"]], y=["Dose"],
                        mode="markers",
                        marker=dict(symbol="diamond", size=14, color=c["accent"]),
                        showlegend=False,
                        hovertemplate=f"Dose: {r.get('EXDOSE','?')} {r.get('EXDOSU','')}<br>%{{x}}<extra></extra>",
                    ), row=1, col=1)

        # Panel 2: AE
        GRADE_COLORS = {1: "#fbbf24", 2: "#f97316", 3: "#ef4444", 4: "#9f1239"}
        if ae_dom is not None and "USUBJID" in ae_dom.columns:
            ae_s = ae_dom[ae_dom["USUBJID"] == sel_cm].copy()
            if "AESTDTC" in ae_s.columns:
                ae_s["_st"] = _dt(ae_s["AESTDTC"])
                ae_s["_en"] = _dt(ae_s.get("AEENDTC", pd.Series(dtype="object")))
                ae_s["_en"] = ae_s["_en"].fillna(ae_s["_st"] + pd.Timedelta(days=1))
                pt_col_ae = "AEDECOD" if "AEDECOD" in ae_s.columns else "AETERM"
                for _, r in ae_s.dropna(subset=["_st"]).iterrows():
                    label = str(r.get(pt_col_ae, "AE"))
                    grade = None
                    for gc in ["AETOXGR", "AESEV"]:
                        if gc in r:
                            try: grade = int(float(str(r[gc]))); break
                            except: pass
                    col_ae = GRADE_COLORS.get(grade, c["accent2"])
                    dur = max(1, (r["_en"] - r["_st"]).days + 1)
                    fig_cm.add_trace(go.Bar(
                        x=[dur], y=[label], base=r["_st"],
                        orientation="h",
                        marker_color=col_ae, marker_line_width=0,
                        showlegend=False, width=0.6,
                        hovertemplate=f"{label}<br>Grade: {grade or 'N/A'}<br>%{{base}} - {r['_en'].date()}<extra></extra>",
                    ), row=2, col=1)

        # Panel 3: CM (concomitant meds on timeline)
        cm_s = cm_dom[cm_dom["USUBJID"] == sel_cm].copy()
        drug_col_cm = "CMDECOD" if "CMDECOD" in cm_s.columns else ("CMTRT" if "CMTRT" in cm_s.columns else None)
        if drug_col_cm and "CMSTDTC" in cm_s.columns:
            cm_s["_st"] = _dt(cm_s["CMSTDTC"])
            cm_s["_en"] = _dt(cm_s.get("CMENDTC", pd.Series(dtype="object")))
            CM_COLORS = [c["success"], c["warning"], c["accent"], c["accent2"],
                         "#f59e0b", "#8b5cf6", "#10b981", "#f43f5e"]
            drugs = cm_s[drug_col_cm].dropna().unique()
            drug_color_map = {d: CM_COLORS[i % len(CM_COLORS)] for i, d in enumerate(drugs)}

            for _, r in cm_s.dropna(subset=["_st"]).iterrows():
                drug  = str(r.get(drug_col_cm, "Med"))
                start = r["_st"]
                end   = r["_en"] if pd.notna(r["_en"]) else start + pd.Timedelta(days=14)
                dur   = max(1, (end - start).days + 1)
                fig_cm.add_trace(go.Bar(
                    x=[dur], y=[drug], base=start,
                    orientation="h",
                    marker_color=drug_color_map.get(drug, c["accent"]),
                    marker_line_width=0,
                    showlegend=False, width=0.6,
                    hovertemplate=f"<b>{drug}</b><br>Start: {start.date()}<br>End: {end.date()}<extra></extra>",
                ), row=3, col=1)
        else:
            st.caption("CMSTDTC or drug name column not found in CM domain.")

        fig_cm.update_layout(
            height=700, paper_bgcolor=paper_bg, plot_bgcolor=bg,
            font=dict(color=text_col, size=11),
            barmode="overlay",
            margin=dict(l=160, r=40, t=40, b=40),
            title=dict(text=f"Concomitant Meds Timeline: {sel_cm}", font=dict(color=text_col)),
        )
        for i in range(1, 4):
            fig_cm.update_xaxes(row=i, col=1, showgrid=True, gridcolor="#334155" if dark else "#e2e8f0",
                                 tickfont=dict(size=9, color=text_col))
            fig_cm.update_yaxes(row=i, col=1, tickfont=dict(size=9, color=text_col))

        st.plotly_chart(fig_cm, use_container_width=True)

# =============================================================
# Tab 3: Figure Export (PP4 / X3)
# =============================================================
with tab3:
    st.markdown("### Figure Export at Publication Quality (PP4 / X3)")
    st.caption(
        "Export any chart from the tool to PNG (300 DPI) or SVG (vector).  \n"
        "Requires `pip install kaleido`"
    )
    export_format = st.radio("Format", ["PNG (300 DPI)", "SVG (vector)"], horizontal=True)

    st.markdown("#### Quick demo export")
    st.markdown("Generates a sample bar chart and exports it in the selected format.")
    if st.button("Generate and Export Sample Figure"):
        demo_fig = go.Figure(go.Bar(
            x=["Arm A", "Arm B", "Placebo"],
            y=[72, 68, 75],
            marker_color=[c["accent"], c["success"], c["subtext"]],
        ))
        demo_fig.update_layout(
            title="Sample: AE Rate by Arm",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            xaxis_title="Treatment Arm", yaxis_title="% Subjects with AE",
        )
        st.plotly_chart(demo_fig, use_container_width=True)

        if "PNG" in export_format:
            img_bytes = export_figure_png(demo_fig)
            if img_bytes:
                st.download_button(
                    "Download PNG",
                    img_bytes,
                    "figure_export.png",
                    "image/png",
                )
            else:
                st.error("kaleido not installed. Run: pip install kaleido")
        else:
            img_bytes = export_figure_svg(demo_fig)
            if img_bytes:
                st.download_button(
                    "Download SVG",
                    img_bytes,
                    "figure_export.svg",
                    "image/svg+xml",
                )
            else:
                st.error("kaleido not installed. Run: pip install kaleido")

    st.markdown("---")
    st.markdown(
        "**Patient profile printable summary (PP4)**  \n"
        "Select a subject and download their profile as a self-contained HTML file."
    )
    subjs_pdf = sorted(adsl["USUBJID"].dropna().unique()) if not adsl.empty else []
    if subjs_pdf:
        sel_pdf = st.selectbox("Subject for report", subjs_pdf, key="pp4_subj")
        if st.button("Generate Patient Profile HTML Report"):
            adsl_row = adsl[adsl["USUBJID"] == sel_pdf]
            arm = str(adsl_row[trt_col].iloc[0]) if not adsl_row.empty and trt_col else "N/A"
            age = str(adsl_row["AGE"].iloc[0]) if not adsl_row.empty and "AGE" in adsl_row.columns else "N/A"
            sex = str(adsl_row["SEX"].iloc[0]) if not adsl_row.empty and "SEX" in adsl_row.columns else "N/A"

            ae_s = sdtm.get("ae")
            ae_html = ""
            if ae_s is not None and "USUBJID" in ae_s.columns:
                sub_ae = ae_s[ae_s["USUBJID"] == sel_pdf]
                if not sub_ae.empty:
                    ae_html = sub_ae.to_html(index=False, border=1,
                                              classes="table", justify="left")

            html_report = f"""<!DOCTYPE html>
<html><head><meta charset='UTF-8'>
<title>Patient Profile - {sel_pdf}</title>
<style>
body{{font-family:Arial,sans-serif;margin:30px;color:#1e293b;}}
h1{{color:#2563eb;}} h2{{color:#334155;border-bottom:1px solid #e2e8f0;padding-bottom:4px;}}
.meta{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:16px 0;}}
.meta div{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px;}}
.meta .label{{font-size:0.75rem;color:#64748b;font-weight:600;text-transform:uppercase;}}
.meta .value{{font-size:1.1rem;font-weight:700;color:#1e293b;margin-top:4px;}}
table{{border-collapse:collapse;width:100%;font-size:0.85rem;}}
th{{background:#1e293b;color:white;padding:8px 12px;text-align:left;}}
td{{padding:6px 12px;border-bottom:1px solid #e2e8f0;}}
tr:hover td{{background:#f8fafc;}}
</style></head><body>
<h1>Patient Profile: {sel_pdf}</h1>
<div class='meta'>
  <div><div class='label'>Subject ID</div><div class='value'>{sel_pdf}</div></div>
  <div><div class='label'>Treatment Arm</div><div class='value'>{arm}</div></div>
  <div><div class='label'>Age / Sex</div><div class='value'>{age} / {sex}</div></div>
  <div><div class='label'>Safety Pop</div><div class='value'>{adsl_row['SAFFL'].iloc[0] if not adsl_row.empty and 'SAFFL' in adsl_row.columns else 'N/A'}</div></div>
</div>
<h2>Adverse Events</h2>
{ae_html if ae_html else '<p>No AE records.</p>'}
<p style='color:#94a3b8;font-size:0.75rem;margin-top:30px;'>
Generated by SDTM Clinical Data Explorer
</p>
</body></html>"""
            st.download_button(
                "Download Patient Profile HTML",
                html_report.encode("utf-8"),
                f"patient_profile_{sel_pdf}.html",
                "text/html",
            )
            st.success(f"Patient profile for {sel_pdf} ready for download.")

# =============================================================
# Tab 4: Dataset Snapshot Comparison (Q5)
# =============================================================
with tab4:
    st.markdown("### Dataset Snapshot Comparison (Q5)")
    st.caption(
        "Compare two versions of the same SDTM domain to identify changes "
        "between data cuts, amendments, or database lock updates."
    )
    st.markdown("**Upload snapshot 2 (the newer cut) to compare against currently loaded data:**")

    domain_for_diff = st.selectbox(
        "Domain to compare",
        sorted(sdtm.keys()), format_func=str.upper, key="snapshot_dom"
    )
    snapshot_file = st.file_uploader(
        "Upload new snapshot (.xpt, .sas7bdat, or .csv)",
        type=["xpt", "sas7bdat", "csv"],
        key="snapshot_upload",
    )

    if snapshot_file is not None:
        try:
            if snapshot_file.name.endswith(".csv"):
                df_new = pd.read_csv(snapshot_file)
            elif snapshot_file.name.endswith(".xpt"):
                df_new = pd.read_sas(snapshot_file, format="xport", encoding="latin1")
            else:
                try:
                    import pyreadstat, tempfile, pathlib
                    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".sas7bdat")
                    tmp.write(snapshot_file.getvalue())
                    tmp.flush()
                    df_new, _ = pyreadstat.read_sas7bdat(tmp.name)
                except Exception:
                    df_new = pd.read_sas(snapshot_file, format="sas7bdat", encoding="latin1")

            df_new.columns = [col.strip().upper() for col in df_new.columns]
            df_old = sdtm[domain_for_diff].copy()

            k1c, k2c, k3c, k4c = st.columns(4)
            k1c.metric("Old records", len(df_old))
            k2c.metric("New records", len(df_new))
            k3c.metric("Difference", len(df_new) - len(df_old), delta_color="normal")

            old_subjs = set(df_old["USUBJID"].dropna()) if "USUBJID" in df_old.columns else set()
            new_subjs = set(df_new["USUBJID"].dropna()) if "USUBJID" in df_new.columns else set()
            k4c.metric("New subjects", len(new_subjs - old_subjs))

            tab_a, tab_b, tab_c = st.tabs(["New subjects", "Removed subjects", "Column changes"])
            with tab_a:
                added = new_subjs - old_subjs
                if added:
                    st.success(f"{len(added)} new subjects in snapshot 2")
                    st.write(sorted(added))
                else:
                    st.info("No new subjects.")
            with tab_b:
                removed = old_subjs - new_subjs
                if removed:
                    st.warning(f"{len(removed)} subjects in old but not in new snapshot")
                    st.write(sorted(removed))
                else:
                    st.info("No removed subjects.")
            with tab_c:
                old_cols = set(df_old.columns)
                new_cols = set(df_new.columns)
                added_cols   = new_cols - old_cols
                removed_cols = old_cols - new_cols
                common_cols  = old_cols & new_cols
                st.markdown(f"**Added columns ({len(added_cols)}):** {sorted(added_cols)}")
                st.markdown(f"**Removed columns ({len(removed_cols)}):** {sorted(removed_cols)}")
                st.markdown(f"**Common columns:** {len(common_cols)}")

                if "USUBJID" in df_old.columns and "USUBJID" in df_new.columns:
                    common_subjs = old_subjs & new_subjs
                    if common_subjs and common_cols:
                        # For common subjects, check record count changes
                        old_counts = df_old[df_old["USUBJID"].isin(common_subjs)].groupby("USUBJID").size().rename("Old_N")
                        new_counts = df_new[df_new["USUBJID"].isin(common_subjs)].groupby("USUBJID").size().rename("New_N")
                        diff_counts = pd.concat([old_counts, new_counts], axis=1).fillna(0)
                        diff_counts["Delta"] = diff_counts["New_N"] - diff_counts["Old_N"]
                        changed = diff_counts[diff_counts["Delta"] != 0]
                        if not changed.empty:
                            st.markdown(f"**Subjects with changed record counts: {len(changed)}**")
                            st.dataframe(changed.head(20), use_container_width=True)
                        else:
                            st.success("No record count changes for common subjects.")
        except Exception as exc:
            st.error(f"Could not load snapshot file: {exc}")
            import traceback
            st.code(traceback.format_exc())
    else:
        st.info(
            "Upload a second version of the selected domain to compare.  \n"
            "This is useful for tracking changes between:\n"
            "- Data cuts (DBL, 50% cut, final)\n"
            "- Database amendments\n"
            "- Pre- vs post-lock datasets"
        )
