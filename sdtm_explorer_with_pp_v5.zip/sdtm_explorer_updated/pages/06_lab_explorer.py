# =============================================================================
# pages/06_lab_explorer.py  -  Lab analysis: shift tables, CHG, MAAVs
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.safety import build_shift_table, derive_chg
from src.analysis.descriptive import mean_ci_by_visit
from src.analysis.plots import (
    line_trend, box_plot, spaghetti_plot, bar_chart,
)
from src.utils.helpers import normalize_visit_order

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Laboratory Explorer")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
lb = sdtm.get("lb")
if lb is None or lb.empty:
    st.error("LB domain not available.")
    st.stop()

adsl = get_population_df()
trt_col = get_trt_col(adsl)

# Filter LB to population
pop_subjs = adsl["USUBJID"].dropna().tolist() if not adsl.empty else []
if pop_subjs:
    lb = lb[lb["USUBJID"].isin(pop_subjs)]

if "LBTESTCD" not in lb.columns:
    st.error("LBTESTCD not found in LB domain.")
    st.stop()

# ---- Parameter selection ----
PANELS = {
    "(All)": None,
    "Hepatic": ["ALT", "AST", "ALP", "BILI", "TBIL", "DBIL", "GGT", "LDH"],
    "Renal": ["CREAT", "BUN", "SODIUM", "POTASSIUM", "PHOS", "URIC"],
    "Hematology": ["HGB", "WBC", "PLT", "RBC", "NEUT", "LYM", "MONO", "EOS"],
    "Metabolic": ["GLUC", "CHOL", "TRIG", "HDL", "LDL", "ALB", "PROT"],
    "Coagulation": ["PT", "PTT", "INR", "APTT"],
}

col_a, col_b = st.columns([1, 3])
with col_a:
    panel = st.selectbox("Lab Panel", list(PANELS.keys()))
    panel_tests = PANELS[panel]
    available = sorted(lb["LBTESTCD"].dropna().unique())
    if panel_tests:
        tests = [t for t in panel_tests if t in available] or available
    else:
        tests = available
    param = st.selectbox("Parameter (LBTESTCD)", tests)

with col_b:
    x_var = st.radio("X-axis", ["VISIT", "Study Day (LBDY)"], horizontal=True)
    if x_var == "VISIT" and "VISIT" in lb.columns:
        x_col = "VISIT"
    elif "LBDY" in lb.columns:
        x_col = "LBDY"
    else:
        x_col = "VISIT" if "VISIT" in lb.columns else lb.columns[0]

param_df = lb[lb["LBTESTCD"] == param].copy()
if param_df.empty:
    st.warning(f"No data for {param}.")
    st.stop()

# Merge treatment arm
if trt_col and not adsl.empty:
    param_df = param_df.merge(
        adsl[["USUBJID", trt_col, "TRTSDT"]].drop_duplicates(),
        on="USUBJID", how="left",
    )

# Sort visits
if x_col == "VISIT" and "VISIT" in param_df.columns:
    param_df["_visit_order"] = normalize_visit_order(param_df["VISIT"])
    param_df = param_df.sort_values("_visit_order")

# Derive CHG/PCHG
value_col = "LBSTRESN" if "LBSTRESN" in param_df.columns else None
if value_col:
    trtsdt_map = {}
    if "TRTSDT" in param_df.columns and "USUBJID" in param_df.columns:
        trtsdt_map = param_df.groupby("USUBJID")["TRTSDT"].first().to_dict()
    param_df = derive_chg(
        param_df, value_col, "LBTESTCD", "LBDTC",
        bl_flag_col="LBBLFL" if "LBBLFL" in param_df.columns else None,
        trtsdt_map=trtsdt_map if trtsdt_map else None,
    )

# Unit label
unit = ""
if "LBSTRESU" in param_df.columns:
    units = param_df["LBSTRESU"].dropna().unique()
    unit = str(units[0]) if len(units) > 0 else ""

st.markdown("---")
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "Trend (Mean +- CI)",
    "Spaghetti",
    "Shift Table",
    "MAAVs",
    "Subject View",
])

# ---- Tab 1: Mean trend with CI ----
with tab1:
    y_choice = st.radio("Y-axis", ["Value", "CHG", "PCHG"], horizontal=True, key="lab_y")
    y_map = {"Value": value_col, "CHG": "CHG", "PCHG": "PCHG"}
    y_col = y_map.get(y_choice, value_col)
    if y_col and y_col in param_df.columns:
        summary_df = mean_ci_by_visit(
            param_df, y_col, x_col,
            group_col=trt_col if trt_col else None,
        )
        if not summary_df.empty:
            fig = line_trend(
                summary_df, x_col, "Mean",
                group_col=trt_col if trt_col else None,
                lower_col="Lower_CI", upper_col="Upper_CI",
                title=f"{param} - Mean {y_choice} by {x_col}",
                y_label=f"{y_choice} ({unit})",
                n_col="N",
                dark=dark,
            )
            if fig:
                st.plotly_chart(fig, use_container_width=True)
            st.dataframe(summary_df, use_container_width=True, hide_index=True)
        else:
            st.info("Insufficient data for trend analysis.")
    else:
        st.info(f"{y_col} column not available.")

# ---- Tab 2: Spaghetti ----
with tab2:
    if value_col and value_col in param_df.columns:
        fig_sp = spaghetti_plot(
            param_df, x_col, value_col,
            group_col=trt_col if trt_col else None,
            title=f"{param} Individual Trajectories",
            dark=dark,
        )
        if fig_sp:
            st.plotly_chart(fig_sp, use_container_width=True)
    else:
        st.info("LBSTRESN required for spaghetti plot.")

# ---- Tab 3: Shift Table (correct worst post-baseline) ----
with tab3:
    st.markdown(
        "Baseline reference range category (rows) vs. "
        "**worst post-baseline** reference range category (columns). "
        "Uses LBNRIND. Off-diagonal cells indicate clinically relevant shifts."
    )
    if adsl.empty:
        st.info("ADSL required for shift table.")
    else:
        shift = build_shift_table(lb, adsl, trt_col, param)
        if not shift.empty:
            st.dataframe(shift.style.highlight_max(axis=None, color="#ef444430"),
                         use_container_width=True)
        else:
            st.info("LBNRIND not available or insufficient data for shift table.")

# ---- Tab 4: Markedly Abnormal Values ----
with tab4:
    st.markdown(
        "Subjects with values outside normal limits by a predefined multiple "
        "(Markedly Abnormal / Clinically Notable Values)."
    )
    if value_col and "LBSTNRHI" in param_df.columns:
        param_df["LBSTNRHI"] = pd.to_numeric(param_df["LBSTNRHI"], errors="coerce")
        param_df["LBSTNRLO"] = pd.to_numeric(param_df.get("LBSTNRLO", pd.Series()), errors="coerce")
        param_df[value_col] = pd.to_numeric(param_df[value_col], errors="coerce")

        mult_hi = st.slider("Upper limit multiplier (x ULN)", 1.0, 10.0, 3.0, 0.5, key="maav_hi")
        mult_lo = st.slider("Lower limit fraction (x LLN)", 0.1, 1.0, 0.5, 0.1, key="maav_lo")

        hi_mask = param_df[value_col] > param_df["LBSTNRHI"] * mult_hi
        lo_mask = (
            param_df[value_col] < param_df["LBSTNRLO"] * mult_lo
            if "LBSTNRLO" in param_df.columns and param_df["LBSTNRLO"].notna().any()
            else pd.Series(False, index=param_df.index)
        )

        maav = param_df[hi_mask | lo_mask].copy()
        n_maav = maav["USUBJID"].nunique()
        st.metric(f"Subjects with MAV (>{mult_hi}x ULN or <{mult_lo}x LLN)", n_maav)

        if not maav.empty:
            disp_cols = [c2 for c2 in ["USUBJID", trt_col, "VISIT", value_col, "LBSTNRHI", "LBNRIND", "LBDTC"]
                         if c2 and c2 in maav.columns]
            st.dataframe(maav[disp_cols].head(100), use_container_width=True, hide_index=True)

        # Hy's Law check (ALT/AST + Bili)
        if param in ["ALT", "AST"]:
            st.markdown("---")
            st.markdown("#### Hy's Law Screen (ALT/AST >3x ULN + BILI >2x ULN)")
            bili_params = ["BILI", "TBIL", "DBIL"]
            bili_data = lb[lb["LBTESTCD"].isin(bili_params)].copy()
            if not bili_data.empty and "LBSTNRHI" in bili_data.columns:
                bili_data["LBSTRESN"] = pd.to_numeric(bili_data.get("LBSTRESN", pd.Series()), errors="coerce")
                bili_data["LBSTNRHI"] = pd.to_numeric(bili_data["LBSTNRHI"], errors="coerce")
                bili_flag = bili_data[bili_data["LBSTRESN"] > bili_data["LBSTNRHI"] * 2]["USUBJID"].unique()
                alt_flag = maav["USUBJID"].unique()
                hys_subjs = set(bili_flag) & set(alt_flag)
                if hys_subjs:
                    st.warning(f"Potential Hy's Law subjects: {sorted(hys_subjs)}")
                else:
                    st.success("No Hy's Law signals detected.")
    else:
        st.info("LBSTNRHI (upper normal limit) not available in LB domain.")

# ---- Tab 5: Subject-level view ----
with tab5:
    subj_list = sorted(param_df["USUBJID"].dropna().unique())
    if not subj_list:
        st.info("No subjects.")
    else:
        sel_s = st.selectbox("Subject", subj_list)
        sub = param_df[param_df["USUBJID"] == sel_s].sort_values(x_col)
        if not sub.empty:
            disp = [c2 for c2 in [x_col, "LBDTC", value_col, "CHG", "PCHG", "LBSTRESU", "LBNRIND", "LBSTNRLO", "LBSTNRHI"]
                    if c2 and c2 in sub.columns]
            st.dataframe(sub[disp], use_container_width=True, hide_index=True)

            if value_col and value_col in sub.columns:
                import plotly.graph_objects as go
                fig_s = go.Figure()
                fig_s.add_trace(go.Scatter(
                    x=sub[x_col], y=pd.to_numeric(sub[value_col], errors="coerce"),
                    mode="lines+markers", marker_color=c["accent"],
                    name=param,
                ))
                # Normal range bands
                if "LBSTNRHI" in sub.columns and "LBSTNRLO" in sub.columns:
                    lo = pd.to_numeric(sub["LBSTNRLO"], errors="coerce").iloc[0]
                    hi = pd.to_numeric(sub["LBSTNRHI"], errors="coerce").iloc[0]
                    if pd.notna(hi):
                        fig_s.add_hline(y=hi, line_dash="dash", line_color=c["danger"],
                                        annotation_text="ULN")
                    if pd.notna(lo):
                        fig_s.add_hline(y=lo, line_dash="dash", line_color=c["warning"],
                                        annotation_text="LLN")
                fig_s.update_layout(
                    title=f"{param} - Subject {sel_s}",
                    paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                    font=dict(color=c["text"]),
                    xaxis_title=x_col, yaxis_title=f"{param} ({unit})",
                )
                st.plotly_chart(fig_s, use_container_width=True)
