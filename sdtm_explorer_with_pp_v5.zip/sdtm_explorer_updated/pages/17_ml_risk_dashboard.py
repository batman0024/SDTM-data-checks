# =============================================================================
# pages/17_ml_risk_dashboard.py  -  Subject risk scoring + heatmap
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

try:
    import plotly.graph_objects as go
    import plotly.express as px
    HAS_PX = True
except ImportError:
    HAS_PX = False

st.title("Subject Risk Dashboard")
st.caption(
    "Composite risk scores per subject combining AE severity, lab abnormalities, "
    "vital sign flags, and exposure data. "
    "EXPLORATORY ONLY - not validated for clinical decision-making."
)

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm    = st.session_state["sdtm_data"]
adsl    = get_population_df()
trt_col = get_trt_col(adsl)

try:
    from src.ml.feature_engineering import build_subject_feature_matrix, prepare_for_ml
    from src.ml.risk_scorer import (
        compute_risk_scores, get_top_risk_drivers,
        build_risk_summary_table, DEFAULT_WEIGHTS,
    )
except Exception as e:
    st.error(f"ML module import failed: {e}")
    st.stop()

# ---- Settings ----
with st.expander("Scoring Settings", expanded=False):
    method = st.radio(
        "Scoring method",
        ["weighted_sum", "isolation_forest", "both"],
        horizontal=True,
        help=(
            "Weighted Sum: transparent, fully explainable. "
            "IsolationForest: ML-based anomaly score. "
            "Both: average of the two."
        ),
    )
    contamination = st.slider(
        "IF contamination (only for IF method)",
        0.05, 0.30, 0.10, 0.01,
    )

    st.markdown("**Domain feature inclusion:**")
    col1, col2 = st.columns(2)
    with col1:
        include_lb = st.toggle("Lab (LB)",    value=True, key="rs_lb")
        include_ae = st.toggle("AE",          value=True, key="rs_ae")
    with col2:
        include_vs = st.toggle("VS",          value=True, key="rs_vs")
        include_ex = st.toggle("Exposure",    value=True, key="rs_ex")

    st.markdown("**Custom weight overrides (optional):**")
    st.caption(
        "Adjust clinical weights. Positive = higher value increases risk. "
        "Negative = higher value decreases risk."
    )
    custom_weights = {}
    weight_cols = st.columns(3)
    default_w_items = list(DEFAULT_WEIGHTS.items())[:9]
    for i, (feat, w) in enumerate(default_w_items):
        col_idx = i % 3
        with weight_cols[col_idx]:
            new_w = st.number_input(
                feat[-25:], value=float(w), step=0.5, key=f"w_{feat}",
            )
            if new_w != w:
                custom_weights[feat] = new_w

if st.button("Compute Risk Scores", type="primary"):
    with st.spinner("Building features and scoring subjects ..."):
        try:
            feat_df, feat_names, feat_meta = build_subject_feature_matrix(
                sdtm, adsl,
                include_lb=include_lb,
                include_ae=include_ae,
                include_vs=include_vs,
                include_ex=include_ex,
            )
            if feat_df.empty:
                st.error("Feature matrix empty.")
                st.stop()

            X_prep, imp, sc = prepare_for_ml(feat_df, scale=True)
            if X_prep.empty:
                st.error("Could not prepare feature matrix.")
                st.stop()

            score_result = compute_risk_scores(
                X_prep, feat_meta,
                method=method,
                custom_weights=custom_weights if custom_weights else None,
                contamination=contamination,
            )

            st.session_state["ml_risk_result"]    = score_result
            st.session_state["ml_risk_feat_df"]   = feat_df
            st.session_state["ml_risk_X_prep"]    = X_prep
            st.session_state["ml_risk_feat_meta"] = feat_meta

        except Exception as exc:
            st.error(f"Risk scoring failed: {exc}")
            import traceback
            st.code(traceback.format_exc())
            st.stop()

# ---- Display ----
score_result = st.session_state.get("ml_risk_result")
feat_df      = st.session_state.get("ml_risk_feat_df")
X_prep       = st.session_state.get("ml_risk_X_prep")
feat_meta    = st.session_state.get("ml_risk_feat_meta", {})

if score_result is None:
    st.info("Configure settings and click 'Compute Risk Scores'.")
    st.stop()

for w in score_result["warnings"]:
    st.warning(w)

scores         = score_result["scores"]
traffic_lights = score_result["traffic_light"]
feat_contrib   = score_result["feature_contrib"]
shap_df        = score_result["shap_values"]

if scores.empty:
    st.error("No scores computed.")
    st.stop()

# Traffic light KPIs
n_red   = int((traffic_lights == "red").sum())
n_amber = int((traffic_lights == "amber").sum())
n_green = int((traffic_lights == "green").sum())

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Subjects",     len(scores))
k2.metric("High Risk (Red)",    n_red,   help="Score >= 66/100")
k3.metric("Medium Risk (Amber)",n_amber, help="Score 33-66/100")
k4.metric("Low Risk (Green)",   n_green, help="Score < 33/100")

st.markdown(f"**Scoring method:** {score_result['method_used']}")
if shap_df is not None:
    st.info("SHAP values computed for feature attribution.")

tab1, tab2, tab3, tab4 = st.tabs([
    "Risk Overview",
    "Risk Heatmap",
    "Subject Detail",
    "Feature Importance",
])

# ---- Tab 1: Overview ----
with tab1:
    summary_df = build_risk_summary_table(scores, traffic_lights, adsl, trt_col)
    if not HAS_PX:
        st.dataframe(summary_df, use_container_width=True)
    else:
        # Color-code the Risk_Level column
        def _color_risk(val):
            colors_map = {
                "red":   f"background-color: {c['danger']}33; color: {c['danger']}; font-weight:bold",
                "amber": f"background-color: {c['warning']}33; color: {c['warning']}; font-weight:bold",
                "green": f"background-color: {c['success']}33; color: {c['success']}; font-weight:bold",
            }
            return colors_map.get(str(val).lower(), "")
        try:
            styled = summary_df.style.map(_color_risk, subset=["Risk_Level"])
        except AttributeError:
            styled = summary_df.style.applymap(_color_risk, subset=["Risk_Level"])
        st.dataframe(styled, use_container_width=True, hide_index=True, height=420)

    st.download_button(
        "Download Risk Summary",
        summary_df.to_csv(index=False).encode("utf-8"),
        "risk_summary.csv",
    )

    # Distribution plot
    fig_dist = go.Figure()
    colors_tl = {"red": c["danger"], "amber": c["warning"], "green": c["success"]}
    for level in ["red", "amber", "green"]:
        mask = traffic_lights == level
        if mask.sum() > 0:
            fig_dist.add_trace(go.Box(
                y=scores[mask].values,
                name=level.capitalize(),
                marker_color=colors_tl[level],
                boxmean=True,
            ))
    fig_dist.update_layout(
        title="Risk Score Distribution by Level",
        paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
        font=dict(color=c["text"]),
        yaxis_title="Risk Score (0-100)",
    )
    st.plotly_chart(fig_dist, use_container_width=True)

    # By treatment arm
    if trt_col and not adsl.empty:
        arm_scores = scores.reset_index().rename(columns={"index": "USUBJID"})
        arm_scores = arm_scores.merge(
            adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
        )
        fig_arm = px.box(
            arm_scores, x=trt_col, y="Risk_Score" if "Risk_Score" in arm_scores.columns else scores.name or 0,
            color=trt_col,
            color_discrete_sequence=[c["accent"], c["success"], c["warning"]],
            title="Risk Score by Treatment Arm",
            template="plotly_dark" if dark else "plotly_white",
        )
        fig_arm.update_layout(
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"], font=dict(color=c["text"])
        )
        st.plotly_chart(fig_arm, use_container_width=True)

# ---- Tab 2: Risk Heatmap ----
with tab2:
    if feat_df is None or feat_df.empty:
        st.info("Feature matrix not available.")
    else:
        st.markdown(
            "Rows = subjects (sorted by risk score), Columns = features. "
            "Color = z-score magnitude. Red border = high risk subjects."
        )
        top_n_subj = st.slider("Subjects to show", 10, min(100, len(scores)), 40, key="rh_subj")
        top_n_feat = st.slider("Features to show",  5, min(30, len(feat_df.columns)), 15, key="rh_feat")

        sorted_subjs = scores.sort_values(ascending=False).index[:top_n_subj]
        feat_var     = feat_df.var().sort_values(ascending=False)
        top_feats    = feat_var.index[:top_n_feat].tolist()

        hm = feat_df.loc[feat_df.index.isin(sorted_subjs), top_feats]
        hm_z = ((hm - hm.mean()) / (hm.std().replace(0, 1))).clip(-3, 3)

        # Colour row labels by risk level
        row_labels = []
        for sid in hm_z.index:
            level = traffic_lights.get(sid, "green")
            prefix = {"red": "R!", "amber": "~", "green": "OK"}.get(level, "")
            row_labels.append(f"{prefix} {str(sid)[:12]}")

        col_labels = [f[:18] for f in hm_z.columns]

        fig_hm = go.Figure(go.Heatmap(
            z=hm_z.values,
            x=col_labels,
            y=row_labels,
            colorscale="RdBu_r",
            zmid=0, zmin=-3, zmax=3,
            colorbar=dict(title="Z-score", tickfont=dict(color=c["text"])),
            hovertemplate="Subject: %{y}<br>Feature: %{x}<br>Z: %{z:.2f}<extra></extra>",
        ))
        fig_hm.update_layout(
            title="Risk Heatmap: Subjects x Features (sorted by risk score)",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"], size=9),
            height=max(450, len(sorted_subjs) * 18),
            margin=dict(l=100, r=30, t=60, b=130),
        )
        fig_hm.update_xaxes(tickangle=45)
        st.plotly_chart(fig_hm, use_container_width=True)

# ---- Tab 3: Subject detail ----
with tab3:
    sorted_by_risk = scores.sort_values(ascending=False).index.tolist()
    sel_s = st.selectbox("Subject (sorted by risk)", sorted_by_risk, key="risk_subj")
    subj_score = float(scores.get(sel_s, 0))
    subj_level = traffic_lights.get(sel_s, "green")
    level_color = {"red": c["danger"], "amber": c["warning"], "green": c["success"]}.get(subj_level, c["text"])

    st.markdown(
        f"<h4>Risk Score: <span style='color:{level_color}'>"
        f"{subj_score:.1f} / 100 ({subj_level.upper()})</span></h4>",
        unsafe_allow_html=True,
    )

    drivers = get_top_risk_drivers(sel_s, feat_contrib, shap_df, feat_meta, top_n=8)
    if drivers:
        st.markdown("**Top risk drivers:**")
        driver_df = pd.DataFrame(drivers)[[
            "description", "value", "direction", "source"
        ]].rename(columns={
            "description": "Feature",
            "value":       "Importance",
            "direction":   "Direction",
            "source":      "Method",
        })

        def _color_dir(v):
            return f"color: {c['danger']}" if "increases" in str(v) else f"color: {c['success']}"
        try:
            styled_d = driver_df.style.map(_color_dir, subset=["Direction"])
        except AttributeError:
            styled_d = driver_df.style.applymap(_color_dir, subset=["Direction"])
        st.dataframe(styled_d, use_container_width=True, hide_index=True)

        # Horizontal bar chart of feature contributions
        if HAS_PX and len(drivers) > 0:
            contrib_vals  = [d["value"] * (1 if "increases" in d["direction"] else -1) for d in drivers]
            contrib_labels = [d["description"].split("|")[-1].strip()[:30] for d in drivers]
            bar_colors    = [c["danger"] if v > 0 else c["success"] for v in contrib_vals]
            fig_contrib = go.Figure(go.Bar(
                x=contrib_vals,
                y=contrib_labels,
                orientation="h",
                marker_color=bar_colors,
            ))
            fig_contrib.update_layout(
                title=f"Risk Contributions: {sel_s}",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                xaxis_title="Risk Contribution",
                height=max(250, len(drivers) * 40),
            )
            st.plotly_chart(fig_contrib, use_container_width=True)

# ---- Tab 4: Global feature importance ----
with tab4:
    st.markdown("### Global Feature Importance (across all subjects)")
    if shap_df is not None:
        mean_shap = shap_df.abs().mean().sort_values(ascending=False).head(20)
        fig_shap = go.Figure(go.Bar(
            x=mean_shap.values,
            y=[f[:25] for f in mean_shap.index],
            orientation="h",
            marker_color=c["accent"],
        ))
        fig_shap.update_layout(
            title="Mean |SHAP| Feature Importance (top 20)",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            xaxis_title="Mean |SHAP value|",
            height=max(350, len(mean_shap) * 28),
            margin=dict(l=200, r=30, t=50, b=40),
        )
        st.plotly_chart(fig_shap, use_container_width=True)
        st.caption("SHAP values: contribution of each feature to predicting high risk status.")
    elif not feat_contrib.empty:
        # Fallback: mean absolute contribution from weighted sum
        mean_contrib = feat_contrib.abs().mean().sort_values(ascending=False).head(20)
        feat_labels = [feat_meta.get(f, f)[-30:] for f in mean_contrib.index]
        fig_imp = go.Figure(go.Bar(
            x=mean_contrib.values,
            y=feat_labels,
            orientation="h",
            marker_color=c["accent"],
        ))
        fig_imp.update_layout(
            title="Mean Feature Contribution (Weighted Sum - top 20)",
            paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
            font=dict(color=c["text"]),
            xaxis_title="Mean Absolute Contribution",
            height=max(350, len(mean_contrib) * 28),
            margin=dict(l=200, r=30, t=50, b=40),
        )
        st.plotly_chart(fig_imp, use_container_width=True)
        st.caption(
            "SHAP not available (install with: pip install shap). "
            "Showing weighted-sum feature contributions instead."
        )
    else:
        st.info("Feature importance data not available.")
