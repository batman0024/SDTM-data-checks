# =============================================================================
# pages/09_patient_profile.py  –  5-panel patient timeline + PP Plot tab
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
from datetime import timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors

try:
    from src.utils.defensive import safe_vline, safe_update_layout
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    HAS_PX = True
except ImportError:
    HAS_PX = False

# New PP engine
try:
    from src.patient_profile import PPEngine, BIOMARKER_DEFAULTS
    HAS_PP_ENGINE = True
except ImportError:
    HAS_PP_ENGINE = False

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c    = get_colors()

st.title("Patient Profile")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

if not HAS_PX:
    st.error("plotly required.")
    st.stop()

sdtm    = st.session_state["sdtm_data"]
adsl    = get_population_df()
trt_col = get_trt_col(adsl)

# ── USUBJID guard: if ADSL is missing the column something went wrong at load ─
if not adsl.empty and "USUBJID" not in adsl.columns:
    # Try to recover from index
    if adsl.index.name and str(adsl.index.name).upper() == "USUBJID":
        adsl = adsl.reset_index()
    else:
        st.error(
            "USUBJID column not found in the analysis dataset. "
            "This usually means the DM domain loaded from your files has no USUBJID variable, "
            "or the column name contains unexpected characters (e.g. byte strings from SAS). "
            "Please reload the data — the loader will now attempt to fix this automatically."
        )
        st.stop()

# ── Subject selection ─────────────────────────────────────────────────────────
subjs = sorted(adsl["USUBJID"].dropna().unique()) if not adsl.empty else []
if not subjs:
    st.error("No subjects in current population.")
    st.stop()

col_a, col_b = st.columns([3, 1])
with col_a:
    search = st.text_input("Search subject ID", placeholder="Enter partial ID...")
    if search:
        subjs = [s for s in subjs if search.lower() in str(s).lower()]
    if not subjs:
        st.warning("No matching subjects.")
        st.stop()
    sel = st.selectbox("Subject", subjs)
with col_b:
    if st.button("Random Subject"):
        import random
        sel = random.choice(subjs)

# ── KPI strip ─────────────────────────────────────────────────────────────────
adsl_row = adsl[adsl["USUBJID"] == sel]
arm    = str(adsl_row[trt_col].iloc[0])  if not adsl_row.empty and trt_col else "N/A"
age    = str(adsl_row["AGE"].iloc[0])    if not adsl_row.empty and "AGE"    in adsl_row.columns else "N/A"
sex    = str(adsl_row["SEX"].iloc[0])    if not adsl_row.empty and "SEX"    in adsl_row.columns else "N/A"
trtsdt = adsl_row["TRTSDT"].iloc[0]      if not adsl_row.empty and "TRTSDT" in adsl_row.columns else None
trtedt = adsl_row["TRTEDT"].iloc[0]      if not adsl_row.empty and "TRTEDT" in adsl_row.columns else None
trtsdt = pd.to_datetime(trtsdt, errors="coerce")
trtedt = pd.to_datetime(trtedt, errors="coerce")

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Subject", sel)
k2.metric("Arm", arm)
k3.metric("Age / Sex", f"{age} / {sex}")
trtdur = (str(adsl_row["TRTDURD"].iloc[0]) + " d"
          if not adsl_row.empty and "TRTDURD" in adsl_row.columns else "N/A")
k4.metric("Tx Duration", trtdur)
ae_sub = sdtm.get("ae")
ae_sub = ae_sub[ae_sub["USUBJID"] == sel] if ae_sub is not None else pd.DataFrame()
k5.metric("AEs", len(ae_sub))

st.markdown("---")

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_tl, tab_pp, tab_labs, tab_raw = st.tabs([
    "Timeline",
    "📊 PP Plot (Study-style)",
    "Lab Values",
    "Raw Data",
])


# ─────────────────────────────────────────────────────────────────────────────
# Shared date helper
# ─────────────────────────────────────────────────────────────────────────────
def _safe_dt(val):
    try:
        return pd.to_datetime(val, errors="coerce")
    except Exception:
        return pd.NaT


def _parse_date_series(series):
    return series.map(lambda v: _safe_dt(v))


# =============================================================================
# Tab 1 – Timeline  (original 5-panel layout, unchanged)
# =============================================================================
with tab_tl:
    def _subj(dom_key):
        df = sdtm.get(dom_key)
        if df is None or "USUBJID" not in df.columns:
            return pd.DataFrame()
        return df[df["USUBJID"] == sel].copy()

    ex_s = _subj("ex")
    ae_s = _subj("ae")
    tr_s = _subj("tr")
    vs_s = _subj("vs")
    lb_s = _subj("lb")

    all_dates = []
    if not ex_s.empty and "EXSTDTC" in ex_s.columns:
        all_dates += _parse_date_series(ex_s["EXSTDTC"]).dropna().tolist()
    if not ae_s.empty and "AESTDTC" in ae_s.columns:
        all_dates += _parse_date_series(ae_s["AESTDTC"]).dropna().tolist()
    if trtsdt and pd.notna(trtsdt):
        all_dates.append(trtsdt)
    if trtedt and pd.notna(trtedt):
        all_dates.append(trtedt)

    if all_dates:
        t_start = min(all_dates) - timedelta(days=5)
        t_end   = max(all_dates) + timedelta(days=10)
    else:
        st.info("No date data available for timeline.")
        t_start = t_end = None

    n_panels = 3
    if not lb_s.empty:
        n_panels = 4
    if not tr_s.empty:
        n_panels = 5

    row_heights = [0.12, 0.18, 0.30]
    if n_panels >= 4:
        row_heights = [0.10, 0.15, 0.30, 0.25]
    if n_panels >= 5:
        row_heights = [0.10, 0.13, 0.28, 0.22, 0.27]

    subtitles = ["Study Timeline", "Drug Exposure (EX)", "Adverse Events"]
    if n_panels >= 4:
        subtitles.append("Lab Values")
    if n_panels >= 5:
        subtitles.append("Tumor Measurements")

    fig = make_subplots(
        rows=n_panels, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.04,
        subplot_titles=subtitles,
        row_heights=row_heights,
    )

    bg       = "#0f172a" if dark else "#ffffff"
    paper_bg = "#1e293b" if dark else "#f8fafc"
    text_col = "#e2e8f0" if dark else "#1e293b"
    grid_col = "#334155" if dark else "#e2e8f0"

    # Panel 1: Study phases
    if t_start and t_end:
        fig.add_trace(go.Scatter(
            x=[t_start, t_end], y=["Phase", "Phase"], mode="lines",
            line=dict(color="#334155", width=16),
            hoverinfo="skip", showlegend=False,
        ), row=1, col=1)
        if pd.notna(trtsdt):
            fig.add_trace(go.Scatter(
                x=[t_start, trtsdt], y=["Phase", "Phase"], mode="lines",
                line=dict(color="#22c55e", width=20),
                hovertemplate="Screening<extra></extra>",
                showlegend=False, name="Screening",
            ), row=1, col=1)
        if pd.notna(trtsdt) and pd.notna(trtedt):
            fig.add_trace(go.Scatter(
                x=[trtsdt, trtedt], y=["Phase", "Phase"], mode="lines",
                line=dict(color="#38bdf8", width=20),
                hovertemplate="Treatment<extra></extra>",
                showlegend=False, name="Treatment",
            ), row=1, col=1)
        if pd.notna(trtedt) and trtedt < t_end:
            fig.add_trace(go.Scatter(
                x=[trtedt, t_end], y=["Phase", "Phase"], mode="lines",
                line=dict(color="#fbbf24", width=20),
                hovertemplate="Follow-up<extra></extra>",
                showlegend=False, name="Follow-up",
            ), row=1, col=1)
        if pd.notna(trtsdt):
            safe_vline(fig, trtsdt, line_dash="dot",
                       line_color=text_col)

    # Panel 2: Dose events
    if not ex_s.empty and "EXSTDTC" in ex_s.columns:
        ex_s["_dt"] = _parse_date_series(ex_s["EXSTDTC"])
        ex_s = ex_s.dropna(subset=["_dt"])
        drug_col = "EXTRT" if "EXTRT" in ex_s.columns else None
        for _, row_ex in ex_s.iterrows():
            label = str(row_ex.get(drug_col, "Dose")) if drug_col else "Dose"
            dose  = str(row_ex.get("EXDOSE", "")) if "EXDOSE" in row_ex else ""
            fig.add_trace(go.Scatter(
                x=[row_ex["_dt"]], y=["Dose"], mode="markers",
                marker=dict(symbol="diamond", size=14, color="#38bdf8",
                            line=dict(color=paper_bg, width=1)),
                hovertemplate=f"{label} {dose}<br>%{{x}}<extra></extra>",
                showlegend=False,
            ), row=2, col=1)

    # Panel 3: AE events
    GRADE_COLORS = {1: "#fbbf24", 2: "#f97316", 3: "#ef4444", 4: "#9f1239"}
    if not ae_s.empty and "AESTDTC" in ae_s.columns:
        ae_s["_st"] = _parse_date_series(ae_s["AESTDTC"])
        ae_s["_en"] = _parse_date_series(ae_s.get("AEENDTC", pd.Series(dtype="object")))
        ae_s = ae_s.dropna(subset=["_st"])
        ae_s["_en"] = ae_s["_en"].fillna(ae_s["_st"] + timedelta(days=1))
        pt_col    = "AEDECOD" if "AEDECOD" in ae_s.columns else "AETERM"
        grade_col = "AETOXGR" if "AETOXGR" in ae_s.columns else (
                    "AESEV"   if "AESEV"   in ae_s.columns else None)
        for _, row_ae in ae_s.iterrows():
            label = str(row_ae.get(pt_col, "AE"))
            grade = None
            if grade_col:
                try:
                    grade = int(float(str(row_ae.get(grade_col, ""))))
                except (ValueError, TypeError):
                    grade = None
            color = GRADE_COLORS.get(grade, "#38bdf8")
            x0, x1 = row_ae["_st"], row_ae["_en"]
            dur = (x1 - x0).days + 1
            hover = (f"<b>{label}</b><br>Grade: {grade or 'N/A'}<br>"
                     f"{x0.date()} - {x1.date()}<br>Duration: {dur} days")
            fig.add_trace(go.Bar(
                x=[dur], y=[label], base=x0, orientation="h",
                marker_color=color, marker_line_width=0,
                hovertext=hover, hoverinfo="text",
                showlegend=False, width=0.6,
            ), row=3, col=1)
            fig.add_annotation(
                x=x0, y=label, row=3, col=1,
                text=f"<b>{label[:25]}</b>", showarrow=False,
                xanchor="right", bgcolor="rgba(255,255,255,0.1)",
                font=dict(color=text_col, size=9),
            )

    # Panel 4: Labs (optional)
    if n_panels >= 4 and not lb_s.empty:
        with st.sidebar:
            lb_tests = sorted(lb_s["LBTESTCD"].dropna().unique()) if "LBTESTCD" in lb_s.columns else []
            sel_labs = st.multiselect("Lab parameters to show in profile",
                                      lb_tests, default=lb_tests[:3])
        COLORS_LAB = ["#22c55e", "#f59e0b", "#a855f7", "#ec4899", "#fb923c"]
        for i, test in enumerate(sel_labs[:5]):
            lb_t = lb_s[lb_s["LBTESTCD"] == test].copy()
            if "LBDTC" not in lb_t.columns or "LBSTRESN" not in lb_t.columns:
                continue
            lb_t["_dt"] = _parse_date_series(lb_t["LBDTC"])
            lb_t["LBSTRESN"] = pd.to_numeric(lb_t["LBSTRESN"], errors="coerce")
            lb_t = lb_t.dropna(subset=["_dt", "LBSTRESN"]).sort_values("_dt")
            unit = (str(lb_t["LBSTRESU"].iloc[0])
                    if "LBSTRESU" in lb_t.columns and lb_t["LBSTRESU"].notna().any() else "")
            fig.add_trace(go.Scatter(
                x=lb_t["_dt"], y=lb_t["LBSTRESN"],
                mode="lines+markers",
                name=f"{test} ({unit})",
                line=dict(color=COLORS_LAB[i % len(COLORS_LAB)], width=2),
                marker=dict(size=7),
                hovertemplate=f"{test}: %{{y:.2f}} {unit}<br>%{{x}}<extra></extra>",
            ), row=4, col=1)

    # Panel 5: Tumor (optional)
    if n_panels >= 5 and not tr_s.empty and "TRDTC" in tr_s.columns:
        tr_s["_dt"]     = _parse_date_series(tr_s["TRDTC"])
        tr_s["TRORRES"] = pd.to_numeric(tr_s["TRORRES"], errors="coerce")
        tr_s = tr_s.dropna(subset=["_dt", "TRORRES"])
        sum_by_date = tr_s.groupby("_dt")["TRORRES"].sum().reset_index()
        if not sum_by_date.empty:
            base = sum_by_date.iloc[0]["TRORRES"]
            sum_by_date["PCHG"] = (
                (sum_by_date["TRORRES"] - base) / base * 100 if base != 0 else 0
            )
            fig.add_trace(go.Scatter(
                x=sum_by_date["_dt"], y=sum_by_date["PCHG"],
                mode="lines+markers",
                line=dict(color="#f87171", width=3),
                marker=dict(size=9),
                name="SoD % Change",
                hovertemplate="Date: %{x}<br>% Change: %{y:.1f}%<extra></extra>",
            ), row=5, col=1)
            fig.add_hline(y=-30, line_dash="dash", line_color="#22c55e", row=5, col=1)
            fig.add_hline(y=20,  line_dash="dash", line_color="#ef4444", row=5, col=1)

    total_height = 160 + n_panels * 200
    fig.update_layout(
        height=total_height,
        paper_bgcolor=paper_bg, plot_bgcolor=bg,
        font=dict(color=text_col, size=11),
        legend=dict(bgcolor=paper_bg, bordercolor=grid_col, borderwidth=1,
                    font=dict(color=text_col)),
        margin=dict(l=160, r=40, t=40, b=40),
        barmode="overlay",
        title=dict(text=f"Patient Profile: {sel} | {arm}", font=dict(color=text_col)),
    )
    for i in range(1, n_panels + 1):
        fig.update_xaxes(row=i, col=1,
                         showgrid=True, gridcolor=grid_col,
                         tickfont=dict(size=9, color=text_col),
                         range=[t_start, t_end] if t_start else None)
        fig.update_yaxes(row=i, col=1,
                         showgrid=False,
                         tickfont=dict(size=9, color=text_col))

    st.plotly_chart(fig, use_container_width=True)


# =============================================================================
# Tab 2 – PP Plot  (Study-style)   ← NEW
# =============================================================================
with tab_pp:
    if not HAS_PP_ENGINE:
        st.error(
            "PP engine not found. Ensure `src/patient_profile/pp_engine.py` "
            "exists in your project directory."
        )
    else:
        # ── Settings expander ─────────────────────────────────────────────────
        with st.expander("⚙️  PP Plot Settings", expanded=False):
            s_col1, s_col2, s_col3 = st.columns(3)

            with s_col1:
                drug_label = st.text_input(
                    "Drug / Product Label",
                    value="Study Drug",
                    key="pp_drug_label",
                )
                dose_var = st.text_input(
                    "Dose variable (EX domain)",
                    value="EXDOSE",
                    key="pp_dose_var",
                )

            with s_col2:
                cutoff_input = st.text_input(
                    "Data cut-off date (YYYY-MM-DD)",
                    value="",
                    placeholder="e.g. 2024-07-22",
                    key="pp_cutoff",
                )
                data_cutoff = cutoff_input.strip() or None

            with s_col3:
                # Detect which biomarker LBTESTCDs are present for this subject
                lb_all = sdtm.get("lb", pd.DataFrame())
                available_tests = []
                if lb_all is not None and not lb_all.empty and "LBTESTCD" in lb_all.columns:
                    subj_lb = lb_all[lb_all["USUBJID"] == sel]
                    available_tests = sorted(subj_lb["LBTESTCD"].dropna().unique().tolist())

                default_testcds = [b[0] for b in BIOMARKER_DEFAULTS]
                all_opts        = sorted(set(default_testcds + available_tests))

                sel_biomarkers = st.multiselect(
                    "Biomarkers to plot (LBTESTCD)",
                    options=all_opts,
                    default=[t for t in default_testcds if t in available_tests],
                    key="pp_biomarkers",
                )

            chk1, chk2, chk3 = st.columns(3)
            show_dose = chk1.checkbox("Show Dose panel",  value=True, key="pp_show_dose")
            show_ae   = chk2.checkbox("Show AE panel",    value=True, key="pp_show_ae")
            show_cm   = chk3.checkbox("Show CM panel",    value=True, key="pp_show_cm")

            pp_height = st.slider(
                "Plot height (px)",
                min_value=600, max_value=2000,
                value=1100, step=50, key="pp_height",
            )

        # ── Build figure ──────────────────────────────────────────────────────
        engine = PPEngine(
            sdtm        = sdtm,
            dark        = dark,
            drug_label  = drug_label,
            dose_var    = dose_var,
            data_cutoff = data_cutoff,
            biomarkers  = sel_biomarkers or [b[0] for b in BIOMARKER_DEFAULTS],
        )

        with st.spinner("Building PP plot…"):
            pp_fig = engine.build(
                usubjid         = sel,
                height          = pp_height,
                show_dose_panel = show_dose,
                show_ae_panel   = show_ae,
                show_cm_panel   = show_cm,
            )

        st.plotly_chart(pp_fig, use_container_width=True)

        # ── Medical History table ─────────────────────────────────────────────
        mh_df = engine._mh_table(sel)
        if not mh_df.empty:
            st.markdown("#### Medical History")
            st.dataframe(mh_df, use_container_width=True, hide_index=True)
        else:
            st.caption("No medical history (MH) records for this subject.")

        # ── Download buttons ──────────────────────────────────────────────────
        st.markdown("---")
        dl1, dl2, dl3 = st.columns(3)

        with dl1:
            html_bytes = pp_fig.to_html(
                include_plotlyjs="cdn", full_html=True,
                config={"responsive": True, "scrollZoom": True},
            ).encode("utf-8")
            st.download_button(
                label="⬇️  Download HTML",
                data=html_bytes,
                file_name=f"pp_{sel}.html",
                mime="text/html",
                key="pp_dl_html",
            )

        with dl2:
            try:
                png_bytes = pp_fig.to_image(format="png", scale=2)
                st.download_button(
                    label="⬇️  Download PNG",
                    data=png_bytes,
                    file_name=f"pp_{sel}.png",
                    mime="image/png",
                    key="pp_dl_png",
                )
            except Exception:
                st.caption("PNG export requires kaleido (`pip install kaleido`)")

        with dl3:
            try:
                svg_bytes = pp_fig.to_image(format="svg")
                st.download_button(
                    label="⬇️  Download SVG",
                    data=svg_bytes,
                    file_name=f"pp_{sel}.svg",
                    mime="image/svg+xml",
                    key="pp_dl_svg",
                )
            except Exception:
                st.caption("SVG export requires kaleido (`pip install kaleido`)")


# =============================================================================
# Tab 3 – Lab Values standalone  (unchanged)
# =============================================================================
with tab_labs:
    lb_s2 = sdtm.get("lb", pd.DataFrame())
    if lb_s2 is not None and not lb_s2.empty and "USUBJID" in lb_s2.columns:
        lb_s2 = lb_s2[lb_s2["USUBJID"] == sel].copy()
    else:
        lb_s2 = pd.DataFrame()

    if lb_s2.empty:
        st.info("No lab data for this subject.")
    else:
        lb_tests = (sorted(lb_s2["LBTESTCD"].dropna().unique())
                    if "LBTESTCD" in lb_s2.columns else [])
        sel_test = st.selectbox("Lab Test", lb_tests, key="pf_lab")
        lb_t = lb_s2[lb_s2["LBTESTCD"] == sel_test].copy()
        if "LBDTC" in lb_t.columns and "LBSTRESN" in lb_t.columns:
            lb_t["_dt"] = _parse_date_series(lb_t["LBDTC"])
            lb_t["LBSTRESN"] = pd.to_numeric(lb_t["LBSTRESN"], errors="coerce")
            lb_t = lb_t.dropna(subset=["_dt", "LBSTRESN"]).sort_values("_dt")
            unit_l = str(lb_t["LBSTRESU"].iloc[0]) if "LBSTRESU" in lb_t.columns else ""
            fig_l  = go.Figure()
            fig_l.add_trace(go.Scatter(
                x=lb_t["_dt"], y=lb_t["LBSTRESN"],
                mode="lines+markers", marker_color=c["accent"],
            ))
            for nrhi_col in ["LBSTNRHI"]:
                if nrhi_col in lb_t.columns:
                    hi = pd.to_numeric(lb_t[nrhi_col], errors="coerce").iloc[0]
                    if pd.notna(hi):
                        fig_l.add_hline(y=hi, line_dash="dash", line_color=c["danger"])
            for nrlo_col in ["LBSTNRLO"]:
                if nrlo_col in lb_t.columns:
                    lo = pd.to_numeric(lb_t[nrlo_col], errors="coerce").iloc[0]
                    if pd.notna(lo):
                        fig_l.add_hline(y=lo, line_dash="dash", line_color=c["warning"])
            fig_l.update_layout(
                title=f"{sel_test} ({unit_l}) - {sel}",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                xaxis_title="Date", yaxis_title=f"{sel_test} ({unit_l})",
            )
            st.plotly_chart(fig_l, use_container_width=True)
        disp_l = [col for col in ["LBDTC", "VISIT", "LBSTRESN", "LBSTRESU",
                                   "LBNRIND", "LBSTNRLO", "LBSTNRHI"]
                  if col in lb_t.columns]
        st.dataframe(lb_t[disp_l], use_container_width=True, hide_index=True)


# =============================================================================
# Tab 4 – Raw Data  (unchanged)
# =============================================================================
with tab_raw:
    domains_shown = {
        "DM": sdtm.get("dm"), "EX": sdtm.get("ex"), "AE": sdtm.get("ae"),
        "LB": sdtm.get("lb"), "VS": sdtm.get("vs"), "CM": sdtm.get("cm"),
        "MH": sdtm.get("mh"), "TR": sdtm.get("tr"), "RS": sdtm.get("rs"),
    }
    for dom_name, dom_df in domains_shown.items():
        if (dom_df is not None and not dom_df.empty
                and "USUBJID" in dom_df.columns):
            sub_df = dom_df[dom_df["USUBJID"] == sel]
            if not sub_df.empty:
                with st.expander(f"{dom_name}  ({len(sub_df)} records)"):
                    st.dataframe(sub_df, use_container_width=True, hide_index=True)
