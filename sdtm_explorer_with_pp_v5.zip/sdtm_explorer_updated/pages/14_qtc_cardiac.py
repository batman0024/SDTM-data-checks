# =============================================================================
# pages/14_qtc_cardiac.py  -  QTc cardiac safety analysis (ICH E14)
# =============================================================================
# ICH E14 requires analysis of QTc prolongation for most new drugs.
# Domains: EG (ECG) or VS (if QT stored there), EX for dose timing.
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.utils.config_loader import get_qtc_thresholds
from src.analysis.safety import derive_chg
from src.analysis.plots import line_trend, box_plot
from src.utils.helpers import normalize_visit_order

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

QTC_CFG = get_qtc_thresholds()

st.title("QTc Cardiac Safety (ICH E14)")
st.caption(
    "Fridericia (QTcF) and Bazett (QTcB) correction, categorical outliers, "
    "delta-QTc analysis per ICH E14 guidance."
)

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm   = st.session_state["sdtm_data"]
adsl   = get_population_df()
trt_col = get_trt_col(adsl)

# Look for QT data in EG domain first, then VS
eg = sdtm.get("eg")
vs = sdtm.get("vs")

qt_df = None
qt_source = None

if eg is not None and "EGTESTCD" in eg.columns:
    qt_candidates = eg[eg["EGTESTCD"].str.upper().isin(
        ["QT", "QTF", "QTC", "QTCF", "QTCB", "QTCL", "QTLCF", "QTLCB"]
    )]
    if not qt_candidates.empty:
        qt_df = eg.copy()
        qt_source = "EG"

if qt_df is None and vs is not None and "VSTESTCD" in vs.columns:
    qt_candidates = vs[vs["VSTESTCD"].str.upper().isin(
        ["QT", "QTF", "QTC", "QTCF", "QTCB", "HR", "RR"]
    )]
    if not qt_candidates.empty:
        qt_df = vs.copy()
        qt_source = "VS"

if qt_df is None:
    st.info(
        "No QT data found in EG or VS domain.  \n\n"
        "Expected variables: **QTCF** or **QTCB** in EG domain (EGTESTCD), "
        "or QT + HR in VS domain.  \n\n"
        "If your study has an EG domain with ECG measurements, load it and return here."
    )

    # Show demo threshold reference even without data
    st.markdown("### ICH E14 QTc Thresholds (Reference)")
    thresholds = pd.DataFrame([
        {"Threshold": "QTcF concern (male)",     "Value": f"> {QTC_CFG.get('concern_threshold_male', 450)} ms"},
        {"Threshold": "QTcF concern (female)",   "Value": f"> {QTC_CFG.get('concern_threshold_female', 470)} ms"},
        {"Threshold": "QTcF high risk (all)",    "Value": f"> {QTC_CFG.get('high_risk_threshold', 500)} ms"},
        {"Threshold": "Delta-QTcF concern",      "Value": f"> {QTC_CFG.get('delta_concern', 30)} ms from baseline"},
        {"Threshold": "Delta-QTcF high risk",    "Value": f"> {QTC_CFG.get('delta_high_risk', 60)} ms from baseline"},
    ])
    st.dataframe(thresholds, use_container_width=True, hide_index=True)
    st.stop()

# ---- Identify columns ----
testcd_col = "EGTESTCD" if qt_source == "EG" else "VSTESTCD"
result_col = "EGSTRESN" if qt_source == "EG" else "VSSTRESN"
dtc_col    = "EGDTC"    if qt_source == "EG" else "VSDTC"
visit_col  = "VISIT"

st.success(f"QT data found in {qt_source} domain: {len(qt_df):,} records")

if not adsl.empty:
    qt_df = qt_df[qt_df["USUBJID"].isin(adsl["USUBJID"].tolist())]
    for col in ["USUBJID", trt_col]:
        if col and col not in qt_df.columns:
            qt_df = qt_df.merge(
                adsl[["USUBJID", trt_col]].drop_duplicates(),
                on="USUBJID", how="left",
            )
            break

available_tests = sorted(qt_df[testcd_col].dropna().unique())
st.markdown(f"**Available tests:** {available_tests}")

# ---- Select QTc parameter ----
qtc_prefs = ["QTCF", "QTCB", "QTC", "QTF", "QT"]
qt_test = next((t for t in qtc_prefs if t in available_tests), available_tests[0] if available_tests else None)
qt_sel  = st.selectbox("QTc parameter", available_tests, index=available_tests.index(qt_test) if qt_test in available_tests else 0)
hr_tests = [t for t in available_tests if "HR" in t or t == "RRNORM"]
hr_sel   = st.selectbox("HR parameter (for manual QTcF/B if needed)", ["None"] + hr_tests)

qt_param = qt_df[qt_df[testcd_col] == qt_sel].copy()
if result_col in qt_param.columns:
    qt_param[result_col] = pd.to_numeric(qt_param[result_col], errors="coerce")
qt_param = qt_param.dropna(subset=[result_col])

if qt_param.empty:
    st.error(f"No numeric values found for {qt_sel}.")
    st.stop()

# ---- Derive QTcF / QTcB manually if raw QT and HR available ----
if "QT" in available_tests and hr_sel != "None":
    st.info(
        "Manual QTc correction available. "
        "QTcF = QT / RR^(1/3)   QTcB = QT / RR^(0.5)   where RR = 60/HR (seconds)"
    )

# ---- Baseline and delta-QTc ----
bl_flag = "EGBLFL" if qt_source == "EG" else "VSBLFL"
trtsdt_map = {}
if "TRTSDT" in adsl.columns:
    trtsdt_map = adsl.groupby("USUBJID")["TRTSDT"].first().to_dict()

qt_chg = derive_chg(
    qt_param.copy(), result_col, testcd_col, dtc_col,
    bl_flag_col=bl_flag if bl_flag in qt_param.columns else None,
    trtsdt_map=trtsdt_map if trtsdt_map else None,
)

# ---- Thresholds from config ----
male_thr   = QTC_CFG.get("concern_threshold_male",   450)
female_thr = QTC_CFG.get("concern_threshold_female", 470)
high_thr   = QTC_CFG.get("high_risk_threshold",      500)
delta_warn = QTC_CFG.get("delta_concern",             30)
delta_high = QTC_CFG.get("delta_high_risk",           60)

st.markdown("---")
tab1, tab2, tab3, tab4 = st.tabs([
    "Categorical Outliers",
    "Delta-QTc Analysis",
    "Mean Trend",
    "ICH E14 Summary",
])

# ---- Tab 1: Categorical outliers ----
with tab1:
    st.markdown("### Categorical Outlier Counts (ICH E14 Table)")
    st.caption(f"Concern: >{male_thr} ms (M) / >{female_thr} ms (F)   High-risk: >{high_thr} ms")

    # Merge sex for gender-specific thresholds
    has_sex = "SEX" in adsl.columns
    if has_sex and not adsl.empty:
        qt_cat = qt_chg.merge(adsl[["USUBJID", "SEX", trt_col]].drop_duplicates(),
                               on="USUBJID", how="left")
    else:
        qt_cat = qt_chg.copy()
        qt_cat["SEX"] = "ALL"

    def _apply_threshold(row):
        val = row.get(result_col, np.nan)
        if pd.isna(val):
            return "Unknown"
        sex = str(row.get("SEX", "ALL")).upper()
        thr = female_thr if sex in ("F", "FEMALE") else male_thr
        if val > high_thr:
            return f">{high_thr} ms (High Risk)"
        if val > thr:
            return f">{thr} ms (Concern)"
        return f"<={thr} ms (Normal)"

    qt_cat["QTC_CAT"] = qt_cat.apply(_apply_threshold, axis=1)

    # Summary per visit per arm
    if visit_col in qt_cat.columns and trt_col in qt_cat.columns:
        qt_cat["_visit_order"] = normalize_visit_order(qt_cat[visit_col])
        cat_summ = (
            qt_cat.groupby([visit_col, "_visit_order", trt_col, "QTC_CAT"])["USUBJID"]
            .nunique()
            .reset_index()
            .rename(columns={"USUBJID": "N_Subjects"})
            .sort_values(["_visit_order", trt_col])
        )
        st.dataframe(cat_summ.drop(columns=["_visit_order"]),
                     use_container_width=True, hide_index=True)
    else:
        vc = qt_cat["QTC_CAT"].value_counts().reset_index()
        vc.columns = ["Category", "N_Subjects"]
        st.dataframe(vc, use_container_width=True, hide_index=True)

    # KPIs
    n_high = int((qt_cat[result_col] > high_thr).sum())
    n_warn = int(((qt_cat[result_col] > male_thr) & (qt_cat[result_col] <= high_thr)).sum())
    n_subj_high = qt_cat.loc[qt_cat[result_col] > high_thr, "USUBJID"].nunique()
    k1, k2, k3 = st.columns(3)
    k1.metric(f"Readings > {high_thr} ms", n_high)
    k2.metric(f"Readings > {male_thr} ms (M concern)", n_warn)
    k3.metric(f"Subjects with > {high_thr} ms", n_subj_high)

    st.download_button(
        "Download Outlier Table",
        qt_cat[[c2 for c2 in ["USUBJID", trt_col, "SEX", visit_col, result_col, "QTC_CAT"]
                if c2 in qt_cat.columns]].to_csv(index=False).encode("utf-8"),
        "qtc_categorical_outliers.csv",
    )

# ---- Tab 2: Delta-QTc ----
with tab2:
    st.markdown("### Delta-QTc from Baseline")
    st.caption(f"Concern: >+{delta_warn} ms   High Risk: >+{delta_high} ms from baseline")

    if "CHG" not in qt_chg.columns:
        st.info("CHG not computed. Ensure baseline records are present (BLFL=Y or pre-dose).")
    else:
        qt_d = qt_chg.dropna(subset=["CHG"])
        n_dlt_warn = int((qt_d["CHG"] > delta_warn).sum())
        n_dlt_high = int((qt_d["CHG"] > delta_high).sum())
        n_subj_dlt_high = qt_d.loc[qt_d["CHG"] > delta_high, "USUBJID"].nunique()
        k1, k2, k3 = st.columns(3)
        k1.metric(f"Delta > +{delta_warn} ms", n_dlt_warn)
        k2.metric(f"Delta > +{delta_high} ms", n_dlt_high)
        k3.metric(f"Subjects delta > +{delta_high}", n_subj_dlt_high)

        if visit_col in qt_d.columns and trt_col in qt_d.columns:
            from src.analysis.descriptive import mean_ci_by_visit
            summ_d = mean_ci_by_visit(qt_d, "CHG", visit_col, group_col=trt_col)
            fig_d = line_trend(
                summ_d, visit_col, "Mean",
                group_col=trt_col,
                lower_col="Lower_CI", upper_col="Upper_CI",
                title=f"Mean Delta-{qt_sel} by Visit",
                y_label="Delta-QTc (ms)",
                dark=dark,
            )
            if fig_d:
                st.plotly_chart(fig_d, use_container_width=True)

        st.download_button(
            "Download Delta-QTc Data",
            qt_d.to_csv(index=False).encode("utf-8"),
            "qtc_delta_data.csv",
        )

# ---- Tab 3: Mean trend ----
with tab3:
    if visit_col in qt_param.columns and trt_col in qt_param.columns:
        from src.analysis.descriptive import mean_ci_by_visit
        summ_t = mean_ci_by_visit(qt_param, result_col, visit_col, group_col=trt_col)
        fig_t = line_trend(
            summ_t, visit_col, "Mean",
            group_col=trt_col,
            lower_col="Lower_CI", upper_col="Upper_CI",
            title=f"Mean {qt_sel} over Time by Treatment",
            y_label=f"{qt_sel} (ms)",
            dark=dark,
        )
        if fig_t:
            st.plotly_chart(fig_t, use_container_width=True)

        fig_bx = box_plot(qt_param, y_col=result_col, x_col=visit_col, group_col=trt_col,
                          title=f"{qt_sel} Distribution by Visit", dark=dark)
        if fig_bx:
            st.plotly_chart(fig_bx, use_container_width=True)
    else:
        st.info("VISIT and treatment columns required for trend analysis.")

# ---- Tab 4: ICH E14 Summary Table ----
with tab4:
    st.markdown("### ICH E14 Integrated Cardiac Safety Summary")
    rows_e14 = [
        {"Analysis": f"Subjects with {qt_sel} > {high_thr} ms",
         "N": int((qt_chg[result_col] > high_thr).sum()),
         "Subjects": qt_chg.loc[qt_chg[result_col] > high_thr, "USUBJID"].nunique()},
        {"Analysis": f"Subjects with {qt_sel} > {male_thr} ms (M threshold)",
         "N": int((qt_chg[result_col] > male_thr).sum()),
         "Subjects": qt_chg.loc[qt_chg[result_col] > male_thr, "USUBJID"].nunique()},
    ]
    if "CHG" in qt_chg.columns:
        rows_e14 += [
            {"Analysis": f"Subjects with delta-{qt_sel} > +{delta_warn} ms",
             "N": int((qt_chg["CHG"] > delta_warn).sum()),
             "Subjects": qt_chg.loc[qt_chg["CHG"] > delta_warn, "USUBJID"].nunique()},
            {"Analysis": f"Subjects with delta-{qt_sel} > +{delta_high} ms",
             "N": int((qt_chg["CHG"] > delta_high).sum()),
             "Subjects": qt_chg.loc[qt_chg["CHG"] > delta_high, "USUBJID"].nunique()},
        ]
    e14_df = pd.DataFrame(rows_e14)
    st.dataframe(e14_df, use_container_width=True, hide_index=True)

    st.markdown("#### Threshold Reference (ICH E14 / E14 Q&A)")
    ref = pd.DataFrame([
        {"Threshold": "QTcF/QTcB > 500 ms",         "Significance": "High-risk, requires immediate evaluation"},
        {"Threshold": "QTcF/QTcB > 450 ms (male)",   "Significance": "Potential concern"},
        {"Threshold": "QTcF/QTcB > 470 ms (female)", "Significance": "Potential concern"},
        {"Threshold": "Delta-QTc > 60 ms",            "Significance": "Marked prolongation, high-risk"},
        {"Threshold": "Delta-QTc > 30 ms",            "Significance": "Regulatory concern threshold"},
    ])
    st.dataframe(ref, use_container_width=True, hide_index=True)
    st.download_button(
        "Download ICH E14 Summary",
        e14_df.to_csv(index=False).encode("utf-8"),
        "qtc_ich_e14_summary.csv",
    )
