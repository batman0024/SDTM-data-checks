# =============================================================================
# pages/02_subject_explorer.py  -  Subject-level drill-down
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.utils.helpers import format_n_pct

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Subject Explorer")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
adsl = get_population_df()
trt_col = get_trt_col(adsl)

if adsl.empty:
    st.error("No subjects in selected population.")
    st.stop()

# Guard: USUBJID must be a column (not index) before any page logic runs
if "USUBJID" not in adsl.columns:
    if adsl.index.name and str(adsl.index.name).upper() == "USUBJID":
        adsl = adsl.reset_index()
    else:
        st.error(
            "USUBJID column not found in the analysis dataset. "
            "Please reload the data — the loader will now attempt to fix this automatically."
        )
        st.stop()

# ---- Search + Selection ----
col_a, col_b = st.columns([4, 1])
with col_a:
    search = st.text_input("Search subject ID", placeholder="Type partial ID ...")
with col_b:
    if st.button("Random"):
        import random
        st.session_state["selected_subject"] = random.choice(adsl["USUBJID"].tolist())

subjs = adsl["USUBJID"].tolist()
if search:
    subjs = [s for s in subjs if search.lower() in str(s).lower()]

if not subjs:
    st.warning("No subjects match.")
    st.stop()

def_idx = 0
sel_subj = st.session_state.get("selected_subject")
if sel_subj and sel_subj in subjs:
    def_idx = subjs.index(sel_subj)

subject = st.selectbox("Subject", subjs, index=def_idx)
st.session_state["selected_subject"] = subject

row = adsl[adsl["USUBJID"] == subject]
if row.empty:
    st.error("Subject not found.")
    st.stop()
row = row.iloc[0]

# ---- Demographic KPIs ----
k1, k2, k3, k4, k5, k6 = st.columns(6)
k1.metric("Subject", subject)
k2.metric("Arm", str(row.get(trt_col, "N/A")) if trt_col else "N/A")
k3.metric("Age / Sex", f"{row.get('AGE','N/A')} / {row.get('SEX','N/A')}")
k4.metric("Race", str(row.get("RACE", "N/A")))
k5.metric("Safety Pop", str(row.get("SAFFL", "N/A")))

ae_d = sdtm.get("ae")
n_ae = len(ae_d[ae_d["USUBJID"] == subject]) if ae_d is not None and "USUBJID" in ae_d.columns else 0
k6.metric("AEs", n_ae)

st.markdown("---")

# ---- Domain tabs ----
domains_to_show = {
    "Exposure": "ex",
    "Adverse Events": "ae",
    "Lab Results": "lb",
    "Vital Signs": "vs",
    "Concomitant Meds": "cm",
    "Medical History": "mh",
    "Disposition": "ds",
    "Tumor Results": "tr",
    "Response": "rs",
}

available_tabs = [
    name for name, key in domains_to_show.items()
    if sdtm.get(key) is not None
]

if not available_tabs:
    st.info("No domain data available for this subject.")
    st.stop()

tabs = st.tabs(available_tabs)

for tab, tab_name in zip(tabs, available_tabs):
    dom_key = domains_to_show[tab_name]
    dom_df = sdtm.get(dom_key)
    with tab:
        if dom_df is None or "USUBJID" not in dom_df.columns:
            st.info(f"{dom_key.upper()} domain not available.")
            continue
        sub_df = dom_df[dom_df["USUBJID"] == subject].copy()
        if sub_df.empty:
            st.info(f"No {dom_key.upper()} records for this subject.")
            continue

        # Smart column ordering
        priority = {
            "ex": ["EXTRT", "EXDOSE", "EXDOSU", "EXSTDTC", "EXENDTC", "EXDOSFRQ"],
            "ae": ["AEDECOD", "AETERM", "AESTDTC", "AEENDTC", "AESEV", "AETOXGR", "AESER", "AEREL", "AEOUT"],
            "lb": ["LBTESTCD", "LBTEST", "VISIT", "LBDTC", "LBSTRESN", "LBSTRESU", "LBNRIND"],
            "vs": ["VSTESTCD", "VSTEST", "VISIT", "VSDTC", "VSSTRESN", "VSSTRESU"],
            "cm": ["CMDECOD", "CMTRT", "CMSTDTC", "CMENDTC", "CMDOSE", "CMINDC"],
            "mh": ["MHDECOD", "MHTERM", "MHBODSYS", "MHSTDTC"],
            "ds": ["DSDECOD", "DSTERM", "DSSTDTC", "DSSCAT"],
            "tr": ["TRTESTCD", "TRORRES", "TRSTRESC", "TRDTC", "VISIT", "TRLNKID"],
            "rs": ["RSSTRESC", "RSRESP", "RSDTC", "VISIT"],
        }
        prio_cols = priority.get(dom_key, [])
        ordered = [c for c in prio_cols if c in sub_df.columns]
        rest = [c for c in sub_df.columns if c not in ordered and c not in ["STUDYID", "DOMAIN", "USUBJID"]]
        display_cols = ordered + rest

        st.dataframe(sub_df[display_cols], use_container_width=True, hide_index=True)

        # Quick mini-chart for LB and VS
        if dom_key == "lb" and "LBSTRESN" in sub_df.columns and "LBTESTCD" in sub_df.columns:
            st.markdown("**Quick trend:**")
            tests = sorted(sub_df["LBTESTCD"].dropna().unique())
            sel_t = st.selectbox("Test", tests, key=f"lb_quick_{subject}")
            t_df = sub_df[sub_df["LBTESTCD"] == sel_t]
            x_c = "VISIT" if "VISIT" in t_df.columns else "LBDTC"
            if x_c in t_df.columns:
                import plotly.graph_objects as go
                fig_q = go.Figure(go.Scatter(
                    x=t_df[x_c],
                    y=pd.to_numeric(t_df["LBSTRESN"], errors="coerce"),
                    mode="lines+markers",
                    marker_color=c["accent"],
                ))
                fig_q.update_layout(
                    height=200, margin=dict(l=20, r=20, t=30, b=30),
                    paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                    font=dict(color=c["text"], size=10),
                    title=f"{sel_t}",
                )
                st.plotly_chart(fig_q, use_container_width=True)
