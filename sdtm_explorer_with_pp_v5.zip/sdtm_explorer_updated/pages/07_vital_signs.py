# =============================================================================
# pages/07_vital_signs.py  -  Vital signs analysis with CHG and flagging
# =============================================================================

import streamlit as st
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.data.session import init_session, get_population_df, get_trt_col
from src.utils.theme import apply_theme, get_colors
from src.analysis.safety import derive_chg
from src.analysis.descriptive import mean_ci_by_visit, continuous_stats
from src.analysis.plots import line_trend, box_plot, spaghetti_plot
from src.utils.helpers import normalize_visit_order

init_session()
apply_theme(st.session_state.get("dark_mode", True))
dark = st.session_state.get("dark_mode", True)
c = get_colors()

st.title("Vital Signs Analysis")

if not st.session_state.get("data_loaded"):
    st.warning("Load data first.")
    st.stop()

sdtm = st.session_state["sdtm_data"]
vs = sdtm.get("vs")
if vs is None or vs.empty:
    st.error("VS domain not available.")
    st.stop()

adsl = get_population_df()
trt_col = get_trt_col(adsl)

if not adsl.empty:
    vs = vs[vs["USUBJID"].isin(adsl["USUBJID"].tolist())]
    vs = vs.merge(
        adsl[["USUBJID", trt_col, "TRTSDT"]].drop_duplicates(),
        on="USUBJID", how="left",
    )

if "VSTESTCD" not in vs.columns:
    st.error("VSTESTCD not found in VS domain.")
    st.stop()

tests = sorted(vs["VSTESTCD"].dropna().unique())
test = st.selectbox("Vital Sign Parameter", tests)

vs_p = vs[vs["VSTESTCD"] == test].copy()
value_col = "VSSTRESN" if "VSSTRESN" in vs_p.columns else None

x_col = "VISIT" if "VISIT" in vs_p.columns else ("VSDY" if "VSDY" in vs_p.columns else None)
if x_col == "VISIT":
    vs_p["_visit_order"] = normalize_visit_order(vs_p["VISIT"])
    vs_p = vs_p.sort_values("_visit_order")

unit = ""
if "VSSTRESU" in vs_p.columns:
    u = vs_p["VSSTRESU"].dropna().unique()
    unit = str(u[0]) if len(u) > 0 else ""

# Derive CHG
if value_col:
    trtsdt_map = {}
    if "TRTSDT" in vs_p.columns:
        trtsdt_map = vs_p.groupby("USUBJID")["TRTSDT"].first().to_dict()
    vs_p = derive_chg(
        vs_p, value_col, "VSTESTCD",
        date_col="VSDTC" if "VSDTC" in vs_p.columns else None,
        trtsdt_map=trtsdt_map,
    )

st.markdown("---")
tab1, tab2, tab3, tab4 = st.tabs(["Mean Trend", "Distribution", "Clinical Flags", "Subject View"])

# ---- Tab 1: Mean trend ----
with tab1:
    if x_col is None or value_col is None:
        st.info("Insufficient columns for trend plot.")
    else:
        y_choice = st.radio("Y-axis", ["Value", "CHG", "PCHG"], horizontal=True)
        y_map = {"Value": value_col, "CHG": "CHG", "PCHG": "PCHG"}
        y_col = y_map[y_choice]
        if y_col in vs_p.columns:
            summary = mean_ci_by_visit(
                vs_p, y_col, x_col,
                group_col=trt_col if trt_col else None,
            )
            if not summary.empty:
                fig = line_trend(
                    summary, x_col, "Mean",
                    group_col=trt_col if trt_col else None,
                    lower_col="Lower_CI", upper_col="Upper_CI",
                    title=f"{test} - Mean {y_choice} by {x_col}",
                    y_label=f"{y_choice} ({unit})",
                    dark=dark,
                )
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Not enough data.")
        else:
            st.info(f"{y_col} not available.")

# ---- Tab 2: Distribution ----
with tab2:
    if value_col:
        fig_box = box_plot(
            vs_p, y_col=value_col,
            x_col=x_col,
            group_col=trt_col if trt_col else None,
            title=f"{test} Distribution by {x_col}",
            dark=dark,
        )
        if fig_box:
            st.plotly_chart(fig_box, use_container_width=True)

        st.markdown("#### Summary Statistics")
        stats_df = continuous_stats(
            pd.to_numeric(vs_p[value_col], errors="coerce"),
            group=vs_p[trt_col] if trt_col else None,
        )
        st.dataframe(stats_df, use_container_width=True, hide_index=True)

        st.markdown("#### Spaghetti Plot")
        fig_sp = spaghetti_plot(
            vs_p, x_col, value_col,
            group_col=trt_col if trt_col else None,
            title=f"{test} Individual Trajectories",
            dark=dark,
        )
        if fig_sp:
            st.plotly_chart(fig_sp, use_container_width=True)

# ---- Tab 3: Clinical Flags ----
with tab3:
    if value_col is None:
        st.info("VSSTRESN required for clinical flagging.")
        st.stop()

    vs_p[value_col] = pd.to_numeric(vs_p[value_col], errors="coerce")

    THRESHOLDS = {
        "SYSBP":  {"high": 160, "low": 90,  "label": "Systolic BP (mmHg)", "criteria": ">160 or <90"},
        "DIABP":  {"high": 100, "low": 60,  "label": "Diastolic BP (mmHg)", "criteria": ">100 or <60"},
        "PULSE":  {"high": 100, "low": 50,  "label": "Pulse (bpm)", "criteria": ">100 or <50"},
        "HR":     {"high": 100, "low": 50,  "label": "Heart Rate (bpm)", "criteria": ">100 or <50"},
        "TEMP":   {"high": 38.5, "low": 36, "label": "Temperature (C)", "criteria": ">38.5 or <36"},
        "RESP":   {"high": 20,  "low": 12,  "label": "Respiration Rate", "criteria": ">20 or <12"},
        "WEIGHT": {"high": None, "low": None, "label": "Weight (kg)", "criteria": ""},
    }

    thresh = THRESHOLDS.get(test.upper())
    if thresh and (thresh["high"] or thresh["low"]):
        hi = thresh["high"]
        lo = thresh["low"]
        flags = vs_p.copy()
        flag_mask = pd.Series(False, index=flags.index)
        if hi:
            flag_mask |= flags[value_col] > hi
        if lo:
            flag_mask |= flags[value_col] < lo
        flagged = flags[flag_mask]
        n_flagged = flagged["USUBJID"].nunique()
        total_n = vs_p["USUBJID"].nunique()

        st.metric(
            f"Subjects with {test} {thresh['criteria']}",
            f"{n_flagged} / {total_n}"
        )
        if not flagged.empty:
            disp = [col for col in ["USUBJID", trt_col, "VISIT", value_col, "VSDTC"]
                    if col and col in flagged.columns]
            st.dataframe(flagged[disp].head(200), use_container_width=True, hide_index=True)
        else:
            st.success("No flagged values at current thresholds.")

        # BP JNC classification
        if test.upper() == "SYSBP":
            st.markdown("#### JNC 8 Blood Pressure Classification")
            vs_sys = vs_p.dropna(subset=[value_col])
            def _bp_class(v):
                if v < 120: return "Normal"
                if v < 130: return "Elevated"
                if v < 140: return "Stage 1 HTN"
                return "Stage 2 HTN"
            vs_sys = vs_sys.copy()
            vs_sys["BP_Class"] = vs_sys[value_col].map(_bp_class)
            vc = vs_sys["BP_Class"].value_counts().reset_index()
            vc.columns = ["Class", "N"]
            st.dataframe(vc, use_container_width=True, hide_index=True)
    else:
        st.info(f"No predefined clinical thresholds for {test}.")
        st.markdown("**Descriptive statistics:**")
        stats_df = continuous_stats(pd.to_numeric(vs_p[value_col], errors="coerce"))
        st.dataframe(stats_df, use_container_width=True, hide_index=True)

# ---- Tab 4: Subject View ----
with tab4:
    subjs = sorted(vs_p["USUBJID"].dropna().unique())
    if not subjs:
        st.info("No subjects.")
    else:
        sel = st.selectbox("Subject", subjs, key="vs_subj")
        sub = vs_p[vs_p["USUBJID"] == sel]
        if value_col and not sub.empty:
            import plotly.graph_objects as go
            fig_s = go.Figure()
            fig_s.add_trace(go.Scatter(
                x=sub[x_col] if x_col else list(range(len(sub))),
                y=pd.to_numeric(sub[value_col], errors="coerce"),
                mode="lines+markers",
                marker_color=c["accent"],
                name=test,
            ))
            if thresh and thresh.get("high"):
                fig_s.add_hline(y=thresh["high"], line_dash="dash",
                                line_color=c["danger"], annotation_text="Upper threshold")
            if thresh and thresh.get("low"):
                fig_s.add_hline(y=thresh["low"], line_dash="dash",
                                line_color=c["warning"], annotation_text="Lower threshold")
            fig_s.update_layout(
                title=f"{test} - {sel}",
                paper_bgcolor=c["card"], plot_bgcolor=c["bg"],
                font=dict(color=c["text"]),
                xaxis_title=x_col or "Observation",
                yaxis_title=f"{test} ({unit})",
            )
            st.plotly_chart(fig_s, use_container_width=True)
        disp_cols = [col for col in [x_col, "VSDTC", value_col, "CHG", "PCHG", "VSSTRESU"]
                     if col and col in sub.columns]
        st.dataframe(sub[disp_cols], use_container_width=True, hide_index=True)
