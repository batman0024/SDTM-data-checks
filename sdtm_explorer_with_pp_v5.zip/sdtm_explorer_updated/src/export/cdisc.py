# =============================================================================
# src/export/cdisc.py  -  Export helpers: Excel, CSV, RTF-ready tables
# =============================================================================

import pandas as pd
import io
import os
import datetime
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Excel export (Streamlit download_button compatible)
# ---------------------------------------------------------------------------
def export_tables_to_excel(
    tables: Dict[str, pd.DataFrame],
    study_name: str = "Study",
    data_cut: Optional[str] = None,
) -> bytes:
    """
    Write multiple DataFrames to an Excel workbook, one sheet per table.
    Returns bytes suitable for st.download_button.
    """
    buf = io.BytesIO()
    cut = data_cut or datetime.date.today().isoformat()

    try:
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            # Cover sheet
            meta = pd.DataFrame([
                ["Study", study_name],
                ["Data Cut", cut],
                ["Generated", datetime.datetime.now().isoformat(timespec="seconds")],
                ["Tool", "SDTM Clinical Data Explorer"],
            ], columns=["Item", "Value"])
            meta.to_excel(writer, sheet_name="Info", index=False)

            for sheet_name, df in tables.items():
                safe_name = sheet_name[:31].replace("/", "_").replace("\\", "_")
                if df is not None and not df.empty:
                    df.to_excel(writer, sheet_name=safe_name, index=False)

        buf.seek(0)
        return buf.getvalue()
    except Exception as exc:
        logger.error("Excel export failed: %s", exc)
        raise


def export_single_table_excel(
    df: pd.DataFrame,
    suggested_name: str = "table.xlsx",
) -> Optional[bytes]:
    """Export a single DataFrame to Excel bytes."""
    if df is None or df.empty:
        return None
    try:
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Data", index=False)
        buf.seek(0)
        return buf.getvalue()
    except Exception as exc:
        logger.error("Single table export failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# CSV export helpers
# ---------------------------------------------------------------------------
def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    """Convert DataFrame to UTF-8 CSV bytes."""
    return df.to_csv(index=False).encode("utf-8")


# ---------------------------------------------------------------------------
# Simple text report (audit / session log)
# ---------------------------------------------------------------------------
def build_text_report(
    sections: Dict[str, Any],
    study_name: str = "Study",
) -> str:
    """
    Build a plain-text summary report.
    sections: {section_title: content (str | DataFrame | list)}
    """
    lines = []
    sep = "=" * 80
    lines.append(sep)
    lines.append(f"SDTM CLINICAL DATA EXPLORER - ANALYSIS REPORT")
    lines.append(f"Study: {study_name}")
    lines.append(f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}")
    lines.append(sep)
    lines.append("")

    for title, content in sections.items():
        lines.append("-" * 60)
        lines.append(f"  {title.upper()}")
        lines.append("-" * 60)
        if isinstance(content, pd.DataFrame):
            lines.append(content.to_string(index=False))
        elif isinstance(content, list):
            for item in content:
                lines.append(f"  - {item}")
        else:
            lines.append(str(content))
        lines.append("")

    lines.append(sep)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Domain summary helper used in export page
# ---------------------------------------------------------------------------
def build_domain_summary(sdtm_data: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for dom, df in sdtm_data.items():
        total_cells = len(df) * max(len(df.columns), 1)
        miss_pct = df.isna().sum().sum() / total_cells * 100
        rows.append({
            "Domain": dom.upper(),
            "Records": len(df),
            "Subjects": int(df["USUBJID"].nunique()) if "USUBJID" in df.columns else "N/A",
            "Variables": len(df.columns),
            "Missing_Pct": round(miss_pct, 2),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Streamlit download helpers (call from pages directly)
# ---------------------------------------------------------------------------
def render_excel_download_button(
    df: pd.DataFrame,
    label: str = "Download Excel",
    filename: str = "table.xlsx",
    key: Optional[str] = None,
):
    """Render a Streamlit download button for an Excel file."""
    try:
        import streamlit as st
        data = export_single_table_excel(df)
        if data:
            st.download_button(
                label=label,
                data=data,
                file_name=filename,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key=key,
            )
    except ImportError:
        pass


def render_csv_download_button(
    df: pd.DataFrame,
    label: str = "Download CSV",
    filename: str = "table.csv",
    key: Optional[str] = None,
):
    """Render a Streamlit download button for a CSV file."""
    try:
        import streamlit as st
        st.download_button(
            label=label,
            data=df_to_csv_bytes(df),
            file_name=filename,
            mime="text/csv",
            key=key,
        )
    except ImportError:
        pass
