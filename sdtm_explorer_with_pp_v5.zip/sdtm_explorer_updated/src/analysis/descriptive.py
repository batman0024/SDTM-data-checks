# =============================================================================
# src/analysis/descriptive.py  -  Descriptive stats + efficacy analyses
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Continuous statistics
# ---------------------------------------------------------------------------
def continuous_stats(
    data: pd.Series,
    group: Optional[pd.Series] = None,
    stats: Optional[List[str]] = None,
    decimals: int = 2,
) -> pd.DataFrame:
    """
    Summary statistics for a continuous variable.
    If group is provided, compute per group.
    """
    default_stats = ["N", "Mean", "SD", "Median", "Q1", "Q3", "Min", "Max"]
    use_stats = stats or default_stats

    def _one(s: pd.Series) -> Dict:
        s2 = pd.to_numeric(s, errors="coerce").dropna()
        n = len(s2)
        out = {}
        for st in use_stats:
            if st == "N":
                out["N"] = int(n)
            elif st == "Mean":
                out["Mean"] = round(float(s2.mean()), decimals) if n > 0 else np.nan
            elif st == "SD":
                out["SD"] = round(float(s2.std(ddof=1)), decimals) if n > 1 else np.nan
            elif st == "SE":
                out["SE"] = round(float(s2.sem()), decimals) if n > 1 else np.nan
            elif st == "Median":
                out["Median"] = round(float(s2.median()), decimals) if n > 0 else np.nan
            elif st == "Q1":
                out["Q1"] = round(float(s2.quantile(0.25)), decimals) if n > 0 else np.nan
            elif st == "Q3":
                out["Q3"] = round(float(s2.quantile(0.75)), decimals) if n > 0 else np.nan
            elif st == "Min":
                out["Min"] = round(float(s2.min()), decimals) if n > 0 else np.nan
            elif st == "Max":
                out["Max"] = round(float(s2.max()), decimals) if n > 0 else np.nan
        return out

    if group is None:
        result = _one(data)
        return pd.DataFrame([result])

    rows = []
    for grp_val, subset in data.groupby(group):
        r = _one(subset)
        r["Group"] = grp_val
        rows.append(r)
    df = pd.DataFrame(rows)
    cols = ["Group"] + [c for c in df.columns if c != "Group"]
    return df[cols]


# ---------------------------------------------------------------------------
# Categorical statistics
# ---------------------------------------------------------------------------
def categorical_stats(
    data: pd.Series,
    group: Optional[pd.Series] = None,
    denominator: Optional[int] = None,
) -> pd.DataFrame:
    """Frequency table with n (%) per category, optionally by group."""
    def _one(s: pd.Series, N: int) -> pd.DataFrame:
        counts = s.value_counts(dropna=True).reset_index()
        counts.columns = ["Category", "n"]
        counts["Pct"] = (counts["n"] / N * 100).round(1)
        counts["n (%)"] = counts.apply(
            lambda r: f"{int(r['n'])} ({r['Pct']:.1f}%)", axis=1
        )
        return counts

    if group is None:
        N = denominator or int(data.dropna().shape[0])
        return _one(data, N)

    frames = []
    for grp_val, subset in data.groupby(group):
        N = denominator or int(subset.dropna().shape[0])
        df = _one(subset, N)
        df.insert(0, "Group", grp_val)
        frames.append(df)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


# ---------------------------------------------------------------------------
# Mean + CI by visit (for trend plots with error bars)
# ---------------------------------------------------------------------------
def mean_ci_by_visit(
    df: pd.DataFrame,
    value_col: str,
    visit_col: str,
    group_col: Optional[str] = None,
    ci_level: float = 0.95,
) -> pd.DataFrame:
    """
    Returns per-visit mean, SD, SE, lower/upper CI.
    """
    import scipy.stats as sst

    group_cols = [visit_col]
    if group_col and group_col in df.columns:
        group_cols = [group_col, visit_col]

    df2 = df.copy()
    df2[value_col] = pd.to_numeric(df2[value_col], errors="coerce")

    rows = []
    for keys, grp in df2.groupby(group_cols):
        vals = grp[value_col].dropna()
        n = len(vals)
        mean = vals.mean() if n > 0 else np.nan
        sd = vals.std(ddof=1) if n > 1 else np.nan
        se = sd / np.sqrt(n) if n > 1 else np.nan
        if n > 1:
            t = sst.t.ppf((1 + ci_level) / 2, df=n - 1)
            lower = mean - t * se
            upper = mean + t * se
        else:
            lower = upper = mean
        row = {visit_col: keys[-1] if isinstance(keys, tuple) else keys,
               "N": n, "Mean": round(mean, 3), "SD": round(sd, 3) if pd.notna(sd) else np.nan,
               "SE": round(se, 3) if pd.notna(se) else np.nan,
               "Lower_CI": round(lower, 3) if pd.notna(lower) else np.nan,
               "Upper_CI": round(upper, 3) if pd.notna(upper) else np.nan}
        if group_col and isinstance(keys, tuple):
            row[group_col] = keys[0]
        rows.append(row)
    return pd.DataFrame(rows) if rows else pd.DataFrame()


# ---------------------------------------------------------------------------
# Kaplan-Meier (requires lifelines)
# ---------------------------------------------------------------------------
def kaplan_meier(
    time: pd.Series,
    event: pd.Series,
    group: Optional[pd.Series] = None,
    label: str = "PFS",
) -> Optional[Dict]:
    """
    Run KM analysis. Returns dict with timeline DataFrames per group
    and median + 95% CI.
    """
    try:
        from lifelines import KaplanMeierFitter
        from lifelines.statistics import logrank_test
    except ImportError:
        logger.warning("lifelines not installed; KM analysis unavailable")
        return None

    t = pd.to_numeric(time, errors="coerce")
    e = pd.to_numeric(event, errors="coerce").fillna(0).astype(int)
    mask = t.notna() & (t >= 0)
    t, e = t[mask], e[mask]

    results = {}

    if group is None or group.nunique() <= 1:
        kmf = KaplanMeierFitter()
        kmf.fit(t, e, label=label)
        results["Overall"] = {
            "timeline": kmf.survival_function_.reset_index(),
            "median": float(kmf.median_survival_time_),
            "ci": kmf.confidence_interval_survival_function_.reset_index(),
        }
    else:
        g = group[mask]
        groups = sorted(g.dropna().unique())
        for grp in groups:
            mask_g = g == grp
            kmf = KaplanMeierFitter()
            kmf.fit(t[mask_g], e[mask_g], label=str(grp))
            results[str(grp)] = {
                "timeline": kmf.survival_function_.reset_index(),
                "median": float(kmf.median_survival_time_),
                "ci": kmf.confidence_interval_survival_function_.reset_index(),
            }
        # Log-rank test
        if len(groups) == 2:
            g0, g1 = groups[0], groups[1]
            lr = logrank_test(
                t[g == g0], t[g == g1],
                event_observed_A=e[g == g0],
                event_observed_B=e[g == g1],
            )
            results["_logrank_p"] = float(lr.p_value)

    return results


# ---------------------------------------------------------------------------
# Subgroup / forest plot statistics
# ---------------------------------------------------------------------------
def subgroup_stats(
    adsl: pd.DataFrame,
    endpoint_series: pd.Series,
    trt_col: str,
    subgroup_defs: Optional[Dict] = None,
    endpoint_type: str = "binary",
) -> pd.DataFrame:
    """
    Compute per-subgroup effect estimates.
    endpoint_type: 'binary' (risk diff, RR, OR) or 'continuous' (mean diff)
    Returns DataFrame for forest plot.
    """
    if adsl is None or adsl.empty:
        return pd.DataFrame()

    df = adsl.copy()
    df["__endpoint"] = endpoint_series.reindex(df.index).values
    arms = sorted(df[trt_col].dropna().unique())
    if len(arms) < 2:
        return pd.DataFrame()

    ref_arm = arms[0]
    comp_arm = arms[1]

    subs = {"Overall": None}
    if "AGEGR2" in df.columns:
        subs["Age <65"] = ("AGEGR2", "<65")
        subs["Age >=65"] = ("AGEGR2", ">=65")
    if "SEX" in df.columns:
        for sex in df["SEX"].dropna().unique():
            subs[f"Sex: {sex}"] = ("SEX", sex)
    if subgroup_defs:
        subs.update(subgroup_defs)

    rows = []
    for label, cond in subs.items():
        sub = df.copy()
        if cond:
            col, val = cond
            if col in sub.columns:
                sub = sub[sub[col] == val]
        if sub.empty:
            continue

        g_ref  = sub[sub[trt_col] == ref_arm]["__endpoint"]
        g_comp = sub[sub[trt_col] == comp_arm]["__endpoint"]
        n_ref  = int(g_ref.notna().sum())
        n_comp = int(g_comp.notna().sum())

        if n_ref < 2 or n_comp < 2:
            continue

        if endpoint_type == "binary":
            p_ref  = float(pd.to_numeric(g_ref,  errors="coerce").mean())
            p_comp = float(pd.to_numeric(g_comp, errors="coerce").mean())
            rd = p_comp - p_ref
            se = np.sqrt(
                p_ref  * (1 - p_ref)  / n_ref +
                p_comp * (1 - p_comp) / n_comp
            )
            lower = rd - 1.96 * se
            upper = rd + 1.96 * se
            effect_label = "Risk Difference"
        else:
            m_ref  = float(pd.to_numeric(g_ref,  errors="coerce").mean())
            m_comp = float(pd.to_numeric(g_comp, errors="coerce").mean())
            sd_ref  = float(pd.to_numeric(g_ref,  errors="coerce").std(ddof=1))
            sd_comp = float(pd.to_numeric(g_comp, errors="coerce").std(ddof=1))
            rd = m_comp - m_ref
            se = np.sqrt(sd_ref**2 / n_ref + sd_comp**2 / n_comp)
            lower = rd - 1.96 * se
            upper = rd + 1.96 * se
            effect_label = "Mean Difference"

        rows.append({
            "Subgroup": label,
            "N": len(sub),
            f"N ({ref_arm})": n_ref,
            f"N ({comp_arm})": n_comp,
            "Effect": round(rd, 4),
            "Lower": round(lower, 4),
            "Upper": round(upper, 4),
            "Effect_Type": effect_label,
        })

    return pd.DataFrame(rows) if rows else pd.DataFrame()
