# =============================================================================
# src/analysis/safety.py  -  ICH-compliant AE safety analysis
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Optional, Dict, List, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CTCAE grade normalization
# ---------------------------------------------------------------------------
GRADE_MAP = {
    "1": 1, "GRADE 1": 1, "G1": 1, "MILD": 1,
    "2": 2, "GRADE 2": 2, "G2": 2, "MODERATE": 2,
    "3": 3, "GRADE 3": 3, "G3": 3, "SEVERE": 3,
    "4": 4, "GRADE 4": 4, "G4": 4, "LIFE-THREATENING": 4,
    "LIFE THREATENING": 4,
    "5": 5, "GRADE 5": 5, "G5": 5, "FATAL": 5, "DEATH": 5,
}

CAUSALITY_RELATED = {
    "Y", "YES", "1", "TRUE", "T",
    "RELATED", "PROBABLE", "POSSIBLE", "DEFINITE",
    "POSSIBLY RELATED", "PROBABLY RELATED", "DEFINITELY RELATED",
}

SAE_YES = {"Y", "YES", "1", "TRUE", "T"}


def normalize_grade(series: pd.Series) -> pd.Series:
    """Convert any CTCAE grade representation to numeric 1-5 (NaN if unknown)."""
    num = pd.to_numeric(series, errors="coerce")
    txt_mapped = (
        series.astype(str).str.strip().str.upper().map(GRADE_MAP)
    )
    return num.fillna(txt_mapped)


def is_causally_related(series: pd.Series) -> pd.Series:
    """Return bool Series: True if AE is (probably/possibly) drug-related."""
    return (
        series.astype(str).str.strip().str.upper().isin(CAUSALITY_RELATED)
    )


def is_serious(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.upper().isin(SAE_YES)


# ---------------------------------------------------------------------------
# Core: AE incidence table (subject-level n/N)
# ---------------------------------------------------------------------------
def ae_incidence_table(
    ae: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    teae_only: bool = True,
    min_pct: float = 0.0,
    grade_min: int = 0,
) -> pd.DataFrame:
    """
    Build ICH-compliant AE incidence table.

    Rows: SOC > PT (nested)
    Cols: treatment arms + Total
    Values: n (%) = subjects with AE / N in that arm * 100

    Returns wide DataFrame ready for display.
    """
    if ae is None or ae.empty or adsl is None or adsl.empty:
        return pd.DataFrame()

    # ----- denominators per arm -----
    pop_arms = adsl.groupby(trt_col)["USUBJID"].nunique().to_dict()
    n_total = adsl["USUBJID"].nunique()
    arms = sorted(pop_arms.keys())

    # ----- filter ae to population -----
    pop_subjs = set(adsl["USUBJID"].dropna())
    ae2 = ae[ae["USUBJID"].isin(pop_subjs)].copy()

    if teae_only and "TEAE" in ae2.columns:
        ae2 = ae2[ae2["TEAE"].astype(bool)]

    # grade filter
    if grade_min > 0:
        grade_col = "AETOXGR" if "AETOXGR" in ae2.columns else (
            "AESEV" if "AESEV" in ae2.columns else None
        )
        if grade_col:
            grades = normalize_grade(ae2[grade_col])
            ae2 = ae2[grades.ge(grade_min)]

    # Merge arm onto AE
    ae2 = ae2.merge(
        adsl[["USUBJID", trt_col]].drop_duplicates(),
        on="USUBJID",
        how="left",
    )

    pt_col = "AEDECOD" if "AEDECOD" in ae2.columns else "AETERM"
    soc_col = "AEBODSYS" if "AEBODSYS" in ae2.columns else None

    rows = []

    # Group by SOC then PT
    if soc_col:
        soc_pts = ae2.groupby([soc_col, pt_col, trt_col])["USUBJID"].nunique()
        soc_total_subjs = ae2.groupby([soc_col, pt_col])["USUBJID"].nunique()
    else:
        soc_pts = None
        soc_total_subjs = None

    pt_arm = ae2.groupby([pt_col, trt_col])["USUBJID"].nunique()
    pt_total = ae2.groupby(pt_col)["USUBJID"].nunique()

    # Build rows: iterate SOC -> PT
    if soc_col:
        all_socs = sorted(ae2[soc_col].dropna().unique())
    else:
        all_socs = [""]

    for soc in all_socs:
        if soc_col:
            soc_data = ae2[ae2[soc_col] == soc]
        else:
            soc_data = ae2

        # SOC-level row (subjects with any AE in this SOC)
        soc_row = {"Row_Type": "SOC", "SOC": soc, "PT": ""}
        if soc_col:
            soc_by_arm = soc_data.groupby(trt_col)["USUBJID"].nunique()
            soc_all = soc_data["USUBJID"].nunique()
        for arm in arms:
            n = int(soc_by_arm.get(arm, 0)) if soc_col else 0
            N = pop_arms.get(arm, 1)
            soc_row[arm] = _fmt_n_pct(n, N)
            soc_row[f"_n_{arm}"] = n
        soc_row["Total"] = _fmt_n_pct(int(soc_all) if soc_col else 0, n_total)
        soc_row["_n_Total"] = int(soc_all) if soc_col else 0
        rows.append(soc_row)

        # PT rows within this SOC
        pts = sorted(soc_data[pt_col].dropna().unique())
        for pt in pts:
            pt_data = soc_data[soc_data[pt_col] == pt]
            n_all_pt = int(pt_data["USUBJID"].nunique())
            pct_all = n_all_pt / n_total * 100 if n_total else 0
            if pct_all < min_pct:
                continue
            pt_row = {"Row_Type": "PT", "SOC": soc, "PT": pt}
            for arm in arms:
                arm_data = pt_data[pt_data[trt_col] == arm]
                n = int(arm_data["USUBJID"].nunique())
                N = pop_arms.get(arm, 1)
                pt_row[arm] = _fmt_n_pct(n, N)
                pt_row[f"_n_{arm}"] = n
            pt_row["Total"] = _fmt_n_pct(n_all_pt, n_total)
            pt_row["_n_Total"] = n_all_pt
            rows.append(pt_row)

    return pd.DataFrame(rows)


def _fmt_n_pct(n: int, N: int) -> str:
    pct = n / N * 100 if N > 0 else 0.0
    return f"{n} ({pct:.1f}%)"


# ---------------------------------------------------------------------------
# AE Summary table (any AE, SAE, Grade 3+, Related)
# ---------------------------------------------------------------------------
def ae_summary_table(
    ae: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
) -> pd.DataFrame:
    """
    High-level AE summary:
    - Subjects with >= 1 TEAE
    - Subjects with >= 1 SAE
    - Subjects with >= 1 Grade 3+ AE
    - Subjects with >= 1 Related AE
    - Subjects who discontinued due to AE
    - Deaths
    """
    if ae is None or ae.empty or adsl is None or adsl.empty:
        return pd.DataFrame()

    pop_subjs = set(adsl["USUBJID"].dropna())
    ae2 = ae[ae["USUBJID"].isin(pop_subjs)].copy()
    ae2 = ae2.merge(
        adsl[["USUBJID", trt_col]].drop_duplicates(), on="USUBJID", how="left"
    )

    arms = sorted(adsl[trt_col].dropna().unique())
    N_arms = adsl.groupby(trt_col)["USUBJID"].nunique().to_dict()
    N_total = adsl["USUBJID"].nunique()

    # TEAE filter
    if "TEAE" in ae2.columns:
        teae = ae2[ae2["TEAE"].astype(bool)]
    else:
        teae = ae2

    grade_col = next(
        (c for c in ["AETOXGR", "AESEV"] if c in ae2.columns), None
    )
    sae_col = next((c for c in ["AESER"] if c in ae2.columns), None)
    rel_col = next((c for c in ["AEREL", "AERELNS"] if c in ae2.columns), None)
    out_col = next((c for c in ["AEOUT"] if c in ae2.columns), None)

    def _subj_row(label, mask_df):
        row = {"Category": label}
        n_all = mask_df["USUBJID"].nunique()
        for arm in arms:
            n_arm = mask_df[mask_df[trt_col] == arm]["USUBJID"].nunique()
            row[arm] = _fmt_n_pct(int(n_arm), N_arms.get(arm, 1))
        row["Total"] = _fmt_n_pct(int(n_all), N_total)
        return row

    rows = []
    rows.append(_subj_row("Subjects with >= 1 TEAE", teae))

    if sae_col:
        rows.append(
            _subj_row("Subjects with >= 1 SAE", teae[is_serious(teae[sae_col])])
        )

    if grade_col:
        g3plus = teae[normalize_grade(teae[grade_col]).ge(3)]
        rows.append(_subj_row("Subjects with >= 1 Grade 3+ AE", g3plus))
        g4plus = teae[normalize_grade(teae[grade_col]).ge(4)]
        rows.append(_subj_row("Subjects with >= 1 Grade 4+ AE", g4plus))

    if rel_col:
        related = teae[is_causally_related(teae[rel_col])]
        rows.append(_subj_row("Subjects with >= 1 Related AE", related))
        if grade_col:
            rel_g3 = related[normalize_grade(related[grade_col]).ge(3)]
            rows.append(_subj_row("Related Grade 3+ AE", rel_g3))

    if out_col:
        fatal = teae[teae[out_col].astype(str).str.upper().isin({"FATAL", "DEATH"})]
        rows.append(_subj_row("Deaths", fatal))

    if "AEACN" in ae2.columns:
        dc = ae2[ae2["AEACN"].astype(str).str.upper().str.contains("WITHDRAW")]
        rows.append(_subj_row("Discontinued due to AE", dc))

    return pd.DataFrame(rows) if rows else pd.DataFrame()


# ---------------------------------------------------------------------------
# Shift table (correct: worst post-baseline, not mode)
# ---------------------------------------------------------------------------
SHIFT_PRIORITY = {"LOW LOW": 1, "LL": 1, "LOW": 2, "L": 2,
                  "NORMAL": 3, "N": 3, "HIGH": 4, "H": 4,
                  "HIGH HIGH": 5, "HH": 5}


def _worst_nrind(series: pd.Series) -> str:
    clean = series.dropna().astype(str).str.strip().str.upper()
    ranked = clean.map(lambda x: (SHIFT_PRIORITY.get(x, 99), x))
    if ranked.empty:
        return "NORMAL"
    # Worst = furthest from NORMAL = highest or lowest priority
    # Take max distance from 3 (NORMAL)
    extremes = clean.map(
        lambda x: abs(SHIFT_PRIORITY.get(x, 3) - 3)
    )
    idx = extremes.idxmax()
    return clean.loc[idx] if idx in clean.index else "NORMAL"


def build_shift_table(
    lb: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    testcd: str,
) -> pd.DataFrame:
    """
    Correct shift table: Baseline LBNRIND x Worst post-baseline LBNRIND.
    """
    if lb is None or lb.empty or "LBNRIND" not in lb.columns:
        return pd.DataFrame()
    if "LBTESTCD" not in lb.columns:
        return pd.DataFrame()

    param = lb[lb["LBTESTCD"] == testcd].copy()
    if param.empty:
        return pd.DataFrame()

    param = param.merge(
        adsl[["USUBJID", trt_col, "TRTSDT"]].drop_duplicates(),
        on="USUBJID",
        how="left",
    )

    date_col = "LBDTC" if "LBDTC" in param.columns else None

    if date_col:
        param[date_col] = pd.to_datetime(param[date_col], errors="coerce")
        param["TRTSDT"] = pd.to_datetime(param["TRTSDT"], errors="coerce")

    rows = []
    for sid, grp in param.groupby("USUBJID"):
        # Baseline: LBBLFL = Y, or first on/before TRTSDT
        if "LBBLFL" in grp.columns and (grp["LBBLFL"] == "Y").any():
            base_rows = grp[grp["LBBLFL"] == "Y"]
        elif date_col and "TRTSDT" in grp.columns:
            trtsdt = grp["TRTSDT"].iloc[0]
            base_rows = grp[grp[date_col] <= trtsdt] if pd.notna(trtsdt) else grp.head(1)
            if base_rows.empty:
                base_rows = grp.head(1)
        else:
            base_rows = grp.head(1)

        baseline_nrind = base_rows["LBNRIND"].dropna().astype(str).iloc[0].strip().upper() if not base_rows.empty else "NORMAL"

        # Post-baseline
        if date_col and "TRTSDT" in grp.columns and pd.notna(grp["TRTSDT"].iloc[0]):
            post = grp[grp[date_col] > grp["TRTSDT"].iloc[0]]
        else:
            post = grp.iloc[1:] if len(grp) > 1 else grp

        worst = _worst_nrind(post["LBNRIND"]) if not post.empty else baseline_nrind

        rows.append({
            "USUBJID": sid,
            "BASELINE": baseline_nrind,
            "WORST_POSTBL": worst,
            trt_col: grp[trt_col].iloc[0] if trt_col in grp.columns else "",
        })

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    pivot = (
        df.groupby(["BASELINE", "WORST_POSTBL"])["USUBJID"]
        .nunique()
        .reset_index()
        .rename(columns={"USUBJID": "N"})
        .pivot(index="BASELINE", columns="WORST_POSTBL", values="N")
        .fillna(0)
        .astype(int)
    )
    return pivot


# ---------------------------------------------------------------------------
# CHG / PCHG derivation
# ---------------------------------------------------------------------------
def derive_chg(
    df: pd.DataFrame,
    value_col: str,
    testcd_col: Optional[str],
    date_col: Optional[str],
    bl_flag_col: Optional[str] = None,
    trtsdt_map: Optional[Dict[str, pd.Timestamp]] = None,
) -> pd.DataFrame:
    """
    Derive CHG (change from baseline) and PCHG (% change) per subject × parameter.
    Baseline: bl_flag_col = Y, or first record <= TRTSDT, or first record.
    """
    if df is None or df.empty or value_col not in df.columns:
        return df

    out = df.copy()
    out[value_col] = pd.to_numeric(out[value_col], errors="coerce")

    group_cols = ["USUBJID"]
    if testcd_col and testcd_col in out.columns:
        group_cols.append(testcd_col)

    chg_list = []
    for keys, grp in out.groupby(group_cols):
        grp = grp.copy()
        if date_col and date_col in grp.columns:
            grp = grp.sort_values(date_col)

        # Find baseline
        if bl_flag_col and bl_flag_col in grp.columns and (grp[bl_flag_col] == "Y").any():
            bl_val = grp.loc[grp[bl_flag_col] == "Y", value_col].mean()
        elif date_col and trtsdt_map:
            sid = keys[0] if isinstance(keys, (list, tuple)) else keys
            trtsdt = trtsdt_map.get(str(sid))
            if trtsdt is not None:
                grp[date_col] = pd.to_datetime(grp[date_col], errors="coerce")
                pre = grp[grp[date_col] <= trtsdt]
                bl_val = pre[value_col].iloc[-1] if not pre.empty else grp[value_col].iloc[0]
            else:
                bl_val = grp[value_col].iloc[0]
        else:
            bl_val = grp[value_col].iloc[0]

        grp["CHG"] = grp[value_col] - bl_val
        if bl_val is not None and bl_val != 0:
            grp["PCHG"] = (grp["CHG"] / bl_val * 100).round(2)
        else:
            grp["PCHG"] = np.nan
        grp["BASELINE"] = bl_val
        chg_list.append(grp)

    if chg_list:
        return pd.concat(chg_list, ignore_index=True)
    return out


# =============================================================================
# Exposure-adjusted AE incidence rates  (S4)
# =============================================================================
def exposure_adjusted_ae_rate(
    ae: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    teae_only: bool = True,
    per_n: int = 100,
) -> pd.DataFrame:
    """
    Compute exposure-adjusted AE incidence rate per <per_n> patient-years.
    Rate = (N subjects with AE / total patient-years) * per_n
    Requires TRTDURD (days) in adsl.
    """
    if ae is None or ae.empty or adsl is None or adsl.empty:
        return pd.DataFrame()
    if "TRTDURD" not in adsl.columns:
        return pd.DataFrame()

    ae2 = ae[ae["USUBJID"].isin(adsl["USUBJID"].tolist())].copy()
    if teae_only and "TEAE" in ae2.columns:
        ae2 = ae2[ae2["TEAE"].astype(bool)]

    ae2 = ae2.merge(
        adsl[["USUBJID", trt_col, "TRTDURD"]].drop_duplicates(),
        on="USUBJID", how="left",
    )

    pt_col = "AEDECOD" if "AEDECOD" in ae2.columns else "AETERM"
    rows = []
    arms = sorted(adsl[trt_col].dropna().unique())

    for arm in arms:
        arm_adsl = adsl[adsl[trt_col] == arm]
        arm_ae   = ae2[ae2[trt_col] == arm]
        total_pt_years = arm_adsl["TRTDURD"].fillna(0).sum() / 365.25
        if total_pt_years <= 0:
            continue
        for pt, grp in arm_ae.groupby(pt_col):
            n_subj = grp["USUBJID"].nunique()
            rate   = n_subj / total_pt_years * per_n
            rows.append({
                "Arm": arm,
                "Preferred Term": pt,
                "N_Subjects": n_subj,
                "Patient_Years": round(total_pt_years, 2),
                f"Rate per {per_n} PY": round(rate, 2),
            })

    return pd.DataFrame(rows).sort_values(f"Rate per {per_n} PY", ascending=False) if rows else pd.DataFrame()


# =============================================================================
# Compliance / Relative Dose Intensity  (P5)
# =============================================================================
def exposure_compliance_summary(
    ex: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    planned_dose_per_cycle: float = None,
    cycle_days: int = 21,
) -> pd.DataFrame:
    """
    Per-arm exposure / compliance summary:
    - Mean treatment duration (days)
    - Total actual dose (sum EXDOSE)
    - N administrations
    - Dose interruptions (gaps > 7 days between cycles)
    - Relative Dose Intensity = actual / planned * 100 (if planned given)
    """
    if ex is None or ex.empty or adsl is None or adsl.empty:
        return pd.DataFrame()

    ex2 = ex[ex["USUBJID"].isin(adsl["USUBJID"].tolist())].copy()
    ex2 = ex2.merge(adsl[["USUBJID", trt_col, "TRTDURD"]].drop_duplicates(),
                    on="USUBJID", how="left")

    if "EXDOSE" in ex2.columns:
        ex2["EXDOSE"] = pd.to_numeric(ex2["EXDOSE"], errors="coerce")
    if "EXSTDTC" in ex2.columns:
        ex2["EXSTDTC"] = pd.to_datetime(ex2["EXSTDTC"], errors="coerce")

    rows = []
    for arm, grp in ex2.groupby(trt_col):
        n_subj    = grp["USUBJID"].nunique()
        mean_dur  = adsl[adsl[trt_col] == arm]["TRTDURD"].mean() if "TRTDURD" in adsl.columns else np.nan
        total_dose = grp["EXDOSE"].sum() if "EXDOSE" in grp.columns else np.nan
        n_admin   = len(grp)

        # Interruptions: gaps > 7d between consecutive administrations per subject
        interruptions = 0
        if "EXSTDTC" in grp.columns:
            for _, sub in grp.groupby("USUBJID"):
                s = sub["EXSTDTC"].dropna().sort_values()
                if len(s) > 1:
                    gaps = s.diff().dt.days.dropna()
                    interruptions += int((gaps > 7).sum())

        rdi = np.nan
        if planned_dose_per_cycle and mean_dur and mean_dur > 0:
            n_planned_cycles = mean_dur / cycle_days
            planned_total = n_planned_cycles * planned_dose_per_cycle * n_subj
            if planned_total > 0 and not np.isnan(total_dose):
                rdi = round(total_dose / planned_total * 100, 1)

        rows.append({
            "Arm": arm,
            "N Subjects": n_subj,
            "Mean Duration (days)": round(float(mean_dur), 1) if not np.isnan(mean_dur) else np.nan,
            "Total Administrations": n_admin,
            "Mean Administrations/Subject": round(n_admin / n_subj, 1) if n_subj else 0,
            "Total Dose": round(float(total_dose), 1) if not np.isnan(total_dose) else np.nan,
            "Dose Interruptions": interruptions,
            "RDI (%)": rdi,
        })

    return pd.DataFrame(rows) if rows else pd.DataFrame()
