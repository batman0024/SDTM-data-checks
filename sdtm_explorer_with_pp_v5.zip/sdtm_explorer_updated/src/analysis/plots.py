# =============================================================================
# src/analysis/plots.py  -  All clinical visualization functions
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Optional, List, Dict, Any

try:
    from src.utils.defensive import safe_vline, safe_update_layout
    from src.utils.theme import hex_to_rgba
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    HAS_PX = True
except ImportError:
    HAS_PX = False
    def hex_to_rgba(h, a=1.0): return h

logger = logging.getLogger(__name__)

COLORS_DARK  = ["#38bdf8", "#f87171", "#34d399", "#fbbf24",
                "#a78bfa", "#f472b6", "#fb923c", "#4ade80"]
COLORS_LIGHT = ["#2563eb", "#dc2626", "#16a34a", "#d97706",
                "#7c3aed", "#db2777", "#ea580c", "#15803d"]


def _colors(dark: bool = True) -> List[str]:
    return COLORS_DARK if dark else COLORS_LIGHT


def _layout(dark: bool = True) -> Dict:
    bg = "#0f172a" if dark else "#ffffff"
    paper = "#1e293b" if dark else "#f8fafc"
    text = "#e2e8f0" if dark else "#1e293b"
    grid = "#334155" if dark else "#e2e8f0"
    return {
        "paper_bgcolor": paper,
        "plot_bgcolor": bg,
        "font": {"color": text, "family": "Segoe UI, Arial, sans-serif", "size": 12},
        "xaxis": {"gridcolor": grid, "linecolor": grid, "zerolinecolor": grid},
        "yaxis": {"gridcolor": grid, "linecolor": grid, "zerolinecolor": grid},
        "legend": {
            "bgcolor": paper,
            "bordercolor": "#334155" if dark else "#e2e8f0",
            "borderwidth": 1,
            "font": {"color": text},
        },
        "margin": {"l": 60, "r": 30, "t": 60, "b": 60},
    }


# ---------------------------------------------------------------------------
# Bar chart
# ---------------------------------------------------------------------------
def bar_chart(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    group_col: Optional[str] = None,
    title: str = "",
    dark: bool = True,
    orientation: str = "v",
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    colors = _colors(dark)
    if group_col:
        fig = px.bar(df, x=x_col, y=y_col, color=group_col,
                     barmode="group", orientation=orientation,
                     color_discrete_sequence=colors,
                     title=title)
    else:
        if orientation == "h":
            fig = go.Figure(go.Bar(
                x=df[y_col], y=df[x_col],
                orientation="h",
                marker_color=colors[0],
            ))
        else:
            fig = go.Figure(go.Bar(
                x=df[x_col], y=df[y_col],
                marker_color=colors[0],
            ))
        fig.update_layout(title=title)
    fig.update_layout(**_layout(dark))
    return fig


# ---------------------------------------------------------------------------
# Horizontal bar (incidence)
# ---------------------------------------------------------------------------
def incidence_bar(
    df: pd.DataFrame,
    term_col: str,
    pct_col: str,
    group_col: Optional[str] = None,
    title: str = "Incidence (%)",
    dark: bool = True,
    top_n: int = 20,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    sub = df.nlargest(top_n, pct_col)
    sub = sub.sort_values(pct_col, ascending=True)
    colors = _colors(dark)
    if group_col:
        fig = px.bar(sub, x=pct_col, y=term_col, color=group_col,
                     barmode="group", orientation="h",
                     color_discrete_sequence=colors, title=title)
    else:
        fig = go.Figure(go.Bar(
            x=sub[pct_col], y=sub[term_col],
            orientation="h", marker_color=colors[0],
        ))
        fig.update_layout(title=title)
    fig.update_layout(**_layout(dark),
                      height=max(300, len(sub) * 28))
    return fig


# ---------------------------------------------------------------------------
# Line plot with optional error bars
# ---------------------------------------------------------------------------
def line_trend(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    group_col: Optional[str] = None,
    lower_col: Optional[str] = None,
    upper_col: Optional[str] = None,
    title: str = "",
    y_label: str = "",
    n_col: Optional[str] = None,
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    colors = _colors(dark)
    layout = _layout(dark)
    fig = go.Figure()

    groups = df[group_col].dropna().unique() if group_col else [None]
    for i, grp in enumerate(groups):
        sub = df[df[group_col] == grp] if grp is not None else df
        sub = sub.sort_values(x_col)
        color = colors[i % len(colors)]

        # Error bars
        err = None
        if lower_col and upper_col and lower_col in sub.columns and upper_col in sub.columns:
            err = dict(
                type="data",
                symmetric=False,
                array=(sub[upper_col] - sub[y_col]).tolist(),
                arrayminus=(sub[y_col] - sub[lower_col]).tolist(),
                color=color,
                thickness=1.5,
                width=4,
            )

        name = str(grp) if grp is not None else y_col
        fig.add_trace(go.Scatter(
            x=sub[x_col],
            y=sub[y_col],
            mode="lines+markers",
            name=name,
            line=dict(color=color, width=2),
            marker=dict(size=7, color=color),
            error_y=err,
            hovertemplate=(
                f"Visit: %{{x}}<br>{y_label or y_col}: %{{y:.2f}}<br>"
                + (f"N: {sub[n_col].iloc[0]}" if n_col else "")
                + "<extra></extra>"
            ),
        ))

    fig.update_layout(**layout, title=title,
                      yaxis_title=y_label or y_col,
                      xaxis_title=x_col)
    return fig


# ---------------------------------------------------------------------------
# Box plot
# ---------------------------------------------------------------------------
def box_plot(
    df: pd.DataFrame,
    y_col: str,
    x_col: Optional[str] = None,
    group_col: Optional[str] = None,
    title: str = "",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    colors = _colors(dark)
    fig = px.box(df, x=x_col, y=y_col,
                 color=group_col or x_col,
                 color_discrete_sequence=colors,
                 title=title,
                 points="outliers")
    fig.update_layout(**_layout(dark))
    return fig


# ---------------------------------------------------------------------------
# Waterfall plot (% change from baseline)
# ---------------------------------------------------------------------------
def waterfall_plot(
    df: pd.DataFrame,
    subj_col: str,
    pchg_col: str,
    group_col: Optional[str] = None,
    response_col: Optional[str] = None,
    title: str = "Best % Change from Baseline",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    sub = df.copy()
    sub[pchg_col] = pd.to_numeric(sub[pchg_col], errors="coerce")
    sub = sub.dropna(subset=[pchg_col]).sort_values(pchg_col)

    def _color(v):
        if v <= -30:
            return "#22c55e"  # PR green
        if v >= 20:
            return "#ef4444"  # PD red
        return "#94a3b8"       # SD gray

    colors = sub[pchg_col].map(_color).tolist()

    hovers = []
    for _, row in sub.iterrows():
        h = f"Subject: {row.get(subj_col, '')}<br>Change: {row[pchg_col]:.1f}%"
        if group_col and group_col in row:
            h += f"<br>Arm: {row[group_col]}"
        if response_col and response_col in row:
            h += f"<br>Best Response: {row[response_col]}"
        hovers.append(h)

    fig = go.Figure(go.Bar(
        x=list(range(len(sub))),
        y=sub[pchg_col].tolist(),
        marker_color=colors,
        hovertext=hovers,
        hoverinfo="text",
    ))
    fig.add_hline(y=-30, line_dash="dash", line_color="#22c55e",
                  annotation_text="PR (-30%)", annotation_font_color="#22c55e")
    fig.add_hline(y=20, line_dash="dash", line_color="#ef4444",
                  annotation_text="PD (+20%)", annotation_font_color="#ef4444")
    fig.add_hline(y=0, line_color="#64748b", line_width=1)

    layout = _layout(dark)
    # Remove xaxis from layout dict to avoid duplicate keyword argument
    xaxis_base = layout.pop("xaxis", {})
    fig.update_layout(
        **layout,
        title=title,
        xaxis_title="Subjects (sorted by best response)",
        yaxis_title="% Change from Baseline",
        xaxis=dict(showticklabels=False, **xaxis_base),
        showlegend=False,
    )
    return fig


# ---------------------------------------------------------------------------
# Spider plot (individual trajectories)
# ---------------------------------------------------------------------------
def spider_plot(
    df: pd.DataFrame,
    subj_col: str,
    time_col: str,
    pchg_col: str,
    group_col: Optional[str] = None,
    title: str = "Spider Plot - Tumor Burden % Change",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    df2 = df.copy()
    df2[pchg_col] = pd.to_numeric(df2[pchg_col], errors="coerce")
    df2 = df2.dropna(subset=[pchg_col, time_col])

    colors = _colors(dark)
    subjs = df2[subj_col].dropna().unique()
    fig = go.Figure()

    for i, sid in enumerate(subjs):
        sub = df2[df2[subj_col] == sid].sort_values(time_col)
        arm = str(sub[group_col].iloc[0]) if group_col and group_col in sub.columns else ""
        color = colors[i % len(colors)]
        fig.add_trace(go.Scatter(
            x=sub[time_col],
            y=sub[pchg_col],
            mode="lines+markers",
            name=str(sid),
            line=dict(color=color, width=1),
            marker=dict(size=5),
            opacity=0.6,
            hovertemplate=f"Subject: {sid}<br>Arm: {arm}<br>%Change: %{{y:.1f}}<extra></extra>",
            showlegend=False,
        ))

    fig.add_hline(y=-30, line_dash="dash", line_color="#22c55e")
    fig.add_hline(y=20, line_dash="dash", line_color="#ef4444")
    fig.add_hline(y=0, line_color="#64748b", line_width=1)

    fig.update_layout(
        **_layout(dark),
        title=title,
        yaxis_title="% Change from Baseline",
        xaxis_title=time_col,
    )
    return fig


# ---------------------------------------------------------------------------
# KM curve from lifelines result dict
# ---------------------------------------------------------------------------
def km_curve(
    km_results: Dict,
    title: str = "Kaplan-Meier Survival Estimate",
    y_label: str = "Probability",
    x_label: str = "Time (months)",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or not km_results:
        return None
    colors = _colors(dark)
    layout = _layout(dark)
    fig = go.Figure()

    for i, (label, res) in enumerate(km_results.items()):
        if label.startswith("_"):
            continue
        tl = res["timeline"]
        ci = res.get("ci")
        color = colors[i % len(colors)]

        time_col = tl.columns[0]
        surv_col = [c for c in tl.columns if c != time_col][0]

        fig.add_trace(go.Scatter(
            x=tl[time_col],
            y=tl[surv_col],
            mode="lines",
            name=f"{label} (median={res['median']:.1f})",
            line=dict(color=color, width=2.5),
            hovertemplate=f"{label}<br>Time: %{{x:.1f}}<br>Survival: %{{y:.3f}}<extra></extra>",
        ))

        # Confidence interval ribbon
        if ci is not None:
            ci_cols = [c for c in ci.columns if c != ci.columns[0]]
            if len(ci_cols) >= 2:
                lower_col, upper_col = ci_cols[0], ci_cols[1]
                t_col = ci.columns[0]
                fig.add_trace(go.Scatter(
                    x=pd.concat([ci[t_col], ci[t_col].iloc[::-1]]),
                    y=pd.concat([ci[upper_col], ci[lower_col].iloc[::-1]]),
                    fill="toself",
                    fillcolor=hex_to_rgba(color, 0.15),
                    line=dict(color="rgba(0,0,0,0)"),
                    name=f"{label} 95% CI",
                    showlegend=False,
                    hoverinfo="skip",
                ))

    p_val = km_results.get("_logrank_p")
    annotation = []
    if p_val is not None:
        annotation.append(dict(
            text=f"Log-rank p = {p_val:.4f}",
            xref="paper", yref="paper",
            x=0.98, y=0.98,
            showarrow=False,
            font=dict(color=layout["font"]["color"], size=11),
            align="right",
        ))

    fig.update_layout(
        **{k: v for k, v in layout.items() if k != "yaxis"},
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        yaxis=dict(range=[0, 1.05], **layout.get("yaxis", {})),
        annotations=annotation,
    )
    return fig


# ---------------------------------------------------------------------------
# Forest plot
# ---------------------------------------------------------------------------
def forest_plot(
    df: pd.DataFrame,
    subgroup_col: str,
    effect_col: str,
    lower_col: str,
    upper_col: str,
    n_col: Optional[str] = None,
    title: str = "Subgroup Analysis",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    layout = _layout(dark)
    color = _colors(dark)[0]
    text_color = layout["font"]["color"]

    fig = go.Figure()

    for i, row in df.iterrows():
        y = row[subgroup_col]
        est = row[effect_col]
        lo = row[lower_col]
        hi = row[upper_col]

        # CI line
        fig.add_trace(go.Scatter(
            x=[lo, hi], y=[y, y],
            mode="lines",
            line=dict(color=color, width=2),
            showlegend=False,
            hoverinfo="skip",
        ))
        # Point estimate
        fig.add_trace(go.Scatter(
            x=[est], y=[y],
            mode="markers",
            marker=dict(size=12, color=color, symbol="diamond"),
            name=y,
            showlegend=False,
            hovertemplate=(
                f"<b>{y}</b><br>"
                f"Effect: {est:.4f}<br>"
                f"95% CI: [{lo:.4f}, {hi:.4f}]"
                + (f"<br>N: {row[n_col]}" if n_col and n_col in row else "")
                + "<extra></extra>"
            ),
        ))

    fig.add_vline(x=0, line_dash="dash", line_color="#64748b")
    fig.update_layout(
        **layout,
        title=title,
        xaxis_title="Effect Estimate",
        height=max(350, len(df) * 45),
    )
    return fig


# ---------------------------------------------------------------------------
# AE Timeline (Gantt)
# ---------------------------------------------------------------------------
def ae_timeline(
    ae: pd.DataFrame,
    start_col: str = "AESTDTC",
    end_col: str = "AEENDTC",
    label_col: str = "AEDECOD",
    grade_col: Optional[str] = None,
    rfstdtc: Optional[pd.Timestamp] = None,
    dark: bool = True,
    title: str = "Adverse Event Timeline",
) -> Optional[Any]:
    if not HAS_PX or ae is None or ae.empty:
        return None
    df = ae.copy()
    df[start_col] = pd.to_datetime(df[start_col], errors="coerce")

    # Handle end date column — may not exist in the DataFrame
    if end_col in df.columns:
        df[end_col] = pd.to_datetime(df[end_col], errors="coerce")
    else:
        df[end_col] = pd.NaT

    df = df.dropna(subset=[start_col])
    df[end_col] = df[end_col].fillna(df[start_col] + pd.Timedelta(days=1))

    GRADE_COLORS = {
        1: "#fbbf24", 2: "#f97316", 3: "#ef4444", 4: "#9f1239", 5: "#450a0a",
    }

    layout = _layout(dark)
    fig = go.Figure()

    for _, row in df.iterrows():
        label = str(row.get(label_col, "AE"))
        start = row[start_col]
        end   = row[end_col]

        # Duration in whole days — must be ≥ 1 for visibility
        dur_days = max(int((end - start).days) + 1, 1)

        grade = None
        if grade_col and grade_col in row:
            try:
                grade = int(float(str(row[grade_col])))
            except (ValueError, TypeError):
                grade = None
        color = GRADE_COLORS.get(grade, "#38bdf8")

        hover = (f"<b>{label}</b><br>"
                 f"Start: {start.date()}<br>"
                 f"End: {end.date()}<br>"
                 + (f"Grade: {grade}" if grade else ""))

        # Convert Timestamp to ISO date string — critical for Plotly date axis.
        # Passing a raw Timestamp as `base` makes Plotly interpret it as
        # nanoseconds-since-epoch which renders as tiny fractions like 00:00:00.
        fig.add_trace(go.Bar(
            x=[dur_days],
            y=[label],
            # base must be a date string, not a Timestamp object
            base=start.strftime("%Y-%m-%d"),
            orientation="h",
            marker_color=color,
            marker_line_width=0,
            hovertext=hover,
            hoverinfo="text",
            showlegend=False,
            width=0.7,
        ))

    if rfstdtc is not None:
        try:
            x_val = rfstdtc.strftime("%Y-%m-%d") if hasattr(rfstdtc, "strftime") else str(rfstdtc)[:10]
            fig.add_vline(x=x_val, line_dash="dot", line_color="#38bdf8",
                          annotation_text="First Dose")
        except Exception:
            pass

    fig.update_layout(
        **layout,
        title=title,
        xaxis_type="date",
        xaxis_title="Date",
        barmode="overlay",
        height=max(300, len(df) * 35 + 100),
    )
    fig.update_yaxes(automargin=True, tickfont=dict(size=10))
    return fig


# ---------------------------------------------------------------------------
# Swimmer plot (multi-subject)
# ---------------------------------------------------------------------------
def swimmer_plot(
    df: pd.DataFrame,
    subj_col: str = "USUBJID",
    start_col: str = "TRTSDT",
    end_col: str = "TRTEDT",
    event_df: Optional[pd.DataFrame] = None,
    group_col: Optional[str] = None,
    title: str = "Swimmer Plot - Treatment Duration",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    df2 = df.copy()
    df2[start_col] = pd.to_datetime(df2[start_col], errors="coerce")
    df2[end_col]   = pd.to_datetime(df2[end_col],   errors="coerce")
    df2 = df2.dropna(subset=[start_col])
    df2["Duration"] = (df2[end_col] - df2[start_col]).dt.days.fillna(0)
    df2 = df2.sort_values("Duration", ascending=True)

    colors = _colors(dark)
    layout = _layout(dark)
    fig = go.Figure()

    # Build a stable group → colour mapping so each group always gets
    # the same colour regardless of iteration order.
    if group_col and group_col in df2.columns:
        groups = df2[group_col].fillna("Unknown").unique().tolist()
    else:
        groups = [None]

    group_color = {grp: colors[i % len(colors)] for i, grp in enumerate(groups)}
    # Track which groups already have a legend entry
    legend_shown: set = set()

    for _, row in df2.iterrows():
        sid = str(row[subj_col])
        dur = float(row["Duration"])

        grp = str(row[group_col]) if group_col and group_col in row else None
        color = group_color.get(grp, colors[0])

        # Show legend entry only for the FIRST bar of each group
        show_leg = grp not in legend_shown
        if show_leg:
            legend_shown.add(grp)

        hover = f"Subject: {sid}<br>Duration: {dur:.0f} days"
        if grp:
            hover += f"<br>Arm: {grp}"

        fig.add_trace(go.Bar(
            y=[sid], x=[dur], orientation="h",
            marker_color=color,
            showlegend=show_leg,
            name=grp if grp else "Duration",
            legendgroup=grp if grp else "all",
            hovertext=hover, hoverinfo="text", width=0.6,
        ))

    fig.update_layout(
        **layout,
        title=title,
        xaxis_title="Treatment Duration (days)",
        barmode="overlay",
        height=max(400, len(df2) * 20 + 100),
        showlegend=True,
    )
    return fig


# ---------------------------------------------------------------------------
# Spaghetti plot (individual trajectories)
# ---------------------------------------------------------------------------
def spaghetti_plot(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    subj_col: str = "USUBJID",
    group_col: Optional[str] = None,
    mean_overlay: bool = True,
    title: str = "",
    dark: bool = True,
) -> Optional[Any]:
    if not HAS_PX or df is None or df.empty:
        return None
    df2 = df.copy()
    df2[y_col] = pd.to_numeric(df2[y_col], errors="coerce")
    colors = _colors(dark)
    layout = _layout(dark)
    fig = go.Figure()

    subjs = df2[subj_col].dropna().unique()
    shown_legend = set()
    for sid in subjs:
        sub = df2[df2[subj_col] == sid].sort_values(x_col)
        if sub.empty:
            continue
        grp = str(sub[group_col].iloc[0]) if group_col and group_col in sub.columns else "All"
        grp_idx = list({str(g) for g in df2[group_col].dropna().unique()}).index(grp) if group_col else 0
        color = colors[grp_idx % len(colors)]
        show = grp not in shown_legend
        shown_legend.add(grp)
        fig.add_trace(go.Scatter(
            x=sub[x_col], y=sub[y_col],
            mode="lines",
            line=dict(color=color, width=1),
            opacity=0.35,
            name=grp,
            legendgroup=grp,
            showlegend=show,
            hoverinfo="skip",
        ))

    # Mean overlay per group
    if mean_overlay:
        gc = group_col if group_col else [x_col]
        grp_cols = [group_col, x_col] if group_col else [x_col]
        means = (
            df2.groupby(grp_cols)[y_col]
            .mean()
            .reset_index()
        )
        for i, grp_val in enumerate(means[group_col].dropna().unique() if group_col else [None]):
            m = means[means[group_col] == grp_val] if group_col else means
            m = m.sort_values(x_col)
            color = colors[i % len(colors)]
            fig.add_trace(go.Scatter(
                x=m[x_col], y=m[y_col],
                mode="lines+markers",
                line=dict(color=color, width=3),
                marker=dict(size=8),
                name=f"Mean ({grp_val})" if group_col else "Mean",
                legendgroup=str(grp_val),
                showlegend=True,
            ))

    fig.update_layout(**layout, title=title, yaxis_title=y_col, xaxis_title=x_col)
    return fig
