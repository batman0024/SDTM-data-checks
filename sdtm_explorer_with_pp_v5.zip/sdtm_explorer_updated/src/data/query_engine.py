# =============================================================================
# src/data/query_engine.py  -  DuckDB / Parquet performance layer (Phase 4)
# =============================================================================
# For large studies (100K+ lab records) standard pandas in-memory can be
# slow. This module optionally uses DuckDB for fast analytical SQL queries
# on SDTM domains, with Parquet as the intermediate format.
# Falls back to pandas if DuckDB/pyarrow are not installed.
# =============================================================================

import pandas as pd
import logging
import tempfile
import os
from typing import Dict, Optional, Any

logger = logging.getLogger(__name__)

try:
    import duckdb
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False

try:
    import pyarrow as pa
    import pyarrow.parquet as pq
    HAS_ARROW = True
except ImportError:
    HAS_ARROW = False


class SDTMQueryEngine:
    """
    Wraps loaded SDTM domains in a DuckDB in-process database for fast
    analytical SQL queries. Falls back to pandas if DuckDB not available.

    Usage:
        engine = SDTMQueryEngine(sdtm_data)
        df = engine.query("SELECT LBTESTCD, AVG(LBSTRESN) FROM lb GROUP BY LBTESTCD")
        df = engine.get_domain("lb")  # fast pandas wrapper
    """

    def __init__(self, sdtm_data: Dict[str, pd.DataFrame]):
        self.sdtm_data = sdtm_data
        self._conn = None
        self._parquet_dir = None
        if HAS_DUCKDB:
            self._init_duckdb()

    def _init_duckdb(self):
        """Register all domains as DuckDB views."""
        try:
            self._conn = duckdb.connect(":memory:")
            for domain, df in self.sdtm_data.items():
                if df is not None and not df.empty:
                    # Register as an in-memory table
                    self._conn.register(domain.lower(), df)
                    logger.info("DuckDB registered: %s (%d rows)", domain, len(df))
            logger.info("DuckDB engine ready with %d domains", len(self.sdtm_data))
        except Exception as exc:
            logger.warning("DuckDB init failed: %s; falling back to pandas", exc)
            self._conn = None

    def query(self, sql: str) -> pd.DataFrame:
        """
        Execute SQL against loaded domains.
        Falls back to pandas if DuckDB unavailable.
        """
        if self._conn is not None:
            try:
                return self._conn.execute(sql).df()
            except Exception as exc:
                logger.error("DuckDB query failed: %s\nSQL: %s", exc, sql)
                return pd.DataFrame()
        # Pandas fallback - limited SQL support
        logger.warning("DuckDB not available; cannot run SQL: %s", sql[:80])
        return pd.DataFrame()

    def get_domain(self, domain: str) -> Optional[pd.DataFrame]:
        """Return domain DataFrame (pandas, regardless of backend)."""
        return self.sdtm_data.get(domain.lower())

    def fast_summary(self, domain: str, group_col: str, value_col: str) -> pd.DataFrame:
        """
        Fast mean/std/n by group using DuckDB if available.
        """
        if self._conn is not None:
            sql = (
                f"SELECT {group_col}, "
                f"COUNT(*) AS N, "
                f"AVG({value_col}) AS Mean, "
                f"STDDEV({value_col}) AS SD, "
                f"MIN({value_col}) AS Min, "
                f"MAX({value_col}) AS Max "
                f"FROM {domain.lower()} "
                f"WHERE {value_col} IS NOT NULL "
                f"GROUP BY {group_col} ORDER BY {group_col}"
            )
            return self.query(sql)
        # Pandas fallback
        df = self.sdtm_data.get(domain.lower())
        if df is None:
            return pd.DataFrame()
        return (
            df.groupby(group_col)[value_col]
            .agg(N="count", Mean="mean", SD="std", Min="min", Max="max")
            .reset_index()
        )

    @property
    def available(self) -> bool:
        return self._conn is not None

    @property
    def backend(self) -> str:
        return "DuckDB" if self._conn is not None else "pandas"


# ---------------------------------------------------------------------------
# SAS / R Code Generator  (Phase 4)
# ---------------------------------------------------------------------------
def generate_sas_freq(
    domain: str,
    var: str,
    by_var: Optional[str] = None,
    pop_where: str = "SAFFL = 'Y'",
) -> str:
    """Generate SAS PROC FREQ code equivalent to a frequency table."""
    by_stmt  = f"\n  BY {by_var};" if by_var else ""
    sort_stmt = f"\nPROC SORT DATA=adsl; BY {by_var}; RUN;" if by_var else ""
    return f"""/* Frequency table: {domain}.{var} */
{sort_stmt}
PROC FREQ DATA={domain}(WHERE=({pop_where}));
  TABLES {var} / LIST MISSING;{by_stmt}
  TITLE "Frequency Table: {var}";
RUN;"""


def generate_sas_means(
    domain: str,
    var: str,
    class_var: Optional[str] = "TRT01A",
    pop_where: str = "SAFFL = 'Y'",
) -> str:
    """Generate SAS PROC MEANS code equivalent to continuous summary stats."""
    class_stmt = f"\n  CLASS {class_var};" if class_var else ""
    return f"""/* Continuous statistics: {domain}.{var} */
PROC MEANS DATA={domain}(WHERE=({pop_where})) N MEAN STD MEDIAN MIN MAX;
  VAR {var};{class_stmt}
  TITLE "Summary Statistics: {var}";
RUN;"""


def generate_sas_lifetest(
    time_var: str = "PFS_MONTHS",
    event_var: str = "EVENT",
    strata_var: str = "TRT01A",
) -> str:
    """Generate SAS PROC LIFETEST (KM) code."""
    return f"""/* Kaplan-Meier: {time_var} by {strata_var} */
PROC LIFETEST DATA=pfs_data PLOTS=SURVIVAL(CL);
  TIME {time_var} * {event_var}(0);
  STRATA {strata_var};
  TITLE "Kaplan-Meier Estimate: PFS";
RUN;"""


def generate_r_km(
    time_var: str = "PFS_MONTHS",
    event_var: str = "EVENT",
    group_var: str = "ARM",
) -> str:
    """Generate R survfit + ggsurvplot code."""
    return f"""# Kaplan-Meier with survminer
library(survival)
library(survminer)

km_fit <- survfit(
  Surv({time_var}, {event_var}) ~ {group_var},
  data = pfs_data
)

ggsurvplot(
  km_fit,
  data       = pfs_data,
  risk.table = TRUE,
  pval       = TRUE,
  conf.int   = TRUE,
  xlab       = "Time (months)",
  ylab       = "Survival probability",
  title      = "Kaplan-Meier - PFS"
)"""


def generate_r_admiral_adlb() -> str:
    """Generate R admiral ADLB skeleton code."""
    return """# ADaM ADLB derivation using admiral
library(admiral)
library(dplyr)

adlb <- lb %>%
  # Merge ADSL
  derive_vars_merged(
    dataset_add = adsl,
    by_vars     = exprs(USUBJID),
    new_vars    = exprs(TRT01A, SAFFL, TRTSDT)
  ) %>%
  # Baseline flag
  restrict_derivation(
    derivation = derive_var_extreme_flag,
    args = params(
      by_vars   = exprs(USUBJID, LBTESTCD),
      order     = exprs(LBDTC),
      new_var   = ABLFL,
      mode      = "last"
    ),
    filter = (LBDTC <= TRTSDT)
  ) %>%
  # CHG from baseline
  derive_var_chg() %>%
  # PCHG
  derive_var_pchg()"""


def generate_all_code_samples(
    analysis_type: str,
    **kwargs,
) -> Dict[str, str]:
    """
    Return {'SAS': sas_code, 'R': r_code} for a given analysis type.
    analysis_type: 'ae_freq', 'lab_means', 'km_pfs', 'adlb'
    """
    if analysis_type == "ae_freq":
        return {
            "SAS": generate_sas_freq("adae", "AEDECOD", by_var="TRT01A"),
            "R": """# AE frequency table
library(dplyr)
adae %>%
  filter(SAFFL == 'Y', TEAE == TRUE) %>%
  group_by(TRT01A, AEDECOD) %>%
  summarise(N_Subjects = n_distinct(USUBJID), .groups = 'drop') %>%
  arrange(TRT01A, desc(N_Subjects))""",
        }
    if analysis_type == "lab_means":
        return {
            "SAS": generate_sas_means("adlb", "AVAL", class_var="TRT01A"),
            "R": """# Lab summary statistics
library(dplyr)
adlb %>%
  filter(PARAMCD == 'ALT', SAFFL == 'Y') %>%
  group_by(TRT01A, AVISIT) %>%
  summarise(
    N    = n(),
    Mean = mean(AVAL, na.rm = TRUE),
    SD   = sd(AVAL, na.rm = TRUE),
    .groups = 'drop'
  )""",
        }
    if analysis_type == "km_pfs":
        return {
            "SAS": generate_sas_lifetest(),
            "R": generate_r_km(),
        }
    if analysis_type == "adlb":
        return {
            "SAS": "/* Use SAS PROC SORT + DATA step for CHG/PCHG */\n" + generate_sas_means("lb", "LBSTRESN"),
            "R": generate_r_admiral_adlb(),
        }
    return {"SAS": "/* No template for this analysis */", "R": "# No template for this analysis"}


# ---------------------------------------------------------------------------
# define.xml metadata reader  (Phase 4)
# ---------------------------------------------------------------------------
def parse_define_xml(filepath: str) -> Dict[str, Any]:
    """
    Parse a CDISC define.xml (v2.0 or v2.1) to extract:
    - Variable labels per domain
    - Codelist values
    - Variable lengths and types
    Returns dict: {domain: {var: {label, type, length, codelist}}}
    """
    import xml.etree.ElementTree as ET

    result: Dict[str, Any] = {"domains": {}, "codelists": {}, "version": "unknown"}

    try:
        tree = ET.parse(filepath)
        root = tree.getroot()

        # Handle namespaces
        ns = {}
        raw_tag = root.tag
        if raw_tag.startswith("{"):
            ns_uri = raw_tag[1:raw_tag.index("}")]
            ns = {"def": ns_uri, "odm": ns_uri}

        def find_all(node, tag):
            try:
                return node.findall(f".//{{{list(ns.values())[0]}}}{tag}") if ns else node.findall(f".//{tag}")
            except Exception:
                return []

        # Extract ItemDef (variable metadata)
        item_defs = {}
        for item in find_all(root, "ItemDef"):
            oid   = item.get("OID", "")
            label = item.get("SASLabel", item.get("Label", ""))
            dtype = item.get("DataType", "")
            length = item.get("Length", "")
            item_defs[oid] = {"label": label, "type": dtype, "length": length}

        # Extract ItemGroupDef (domain metadata)
        for ig in find_all(root, "ItemGroupDef"):
            domain = ig.get("SASDatasetName", ig.get("Name", "")).upper()
            if not domain:
                continue
            result["domains"][domain] = {}
            for item_ref in find_all(ig, "ItemRef"):
                oid = item_ref.get("ItemOID", "")
                var_name = oid.split(".")[-1] if "." in oid else oid
                meta = item_defs.get(oid, {})
                result["domains"][domain][var_name] = meta

        # Extract Codelists
        for cl in find_all(root, "CodeList"):
            cl_oid  = cl.get("OID", "")
            cl_name = cl.get("Name", "")
            values  = []
            for ci in find_all(cl, "CodeListItem"):
                val   = ci.get("CodedValue", "")
                label_el = find_all(ci, "Decode")
                lbl = label_el[0].text if label_el and label_el[0].text else val
                values.append({"value": val, "label": lbl})
            result["codelists"][cl_oid] = {"name": cl_name, "values": values}

        result["version"] = root.get("SchemaVersion", root.get("def:StandardVersion", "2.0"))
        logger.info("Parsed define.xml: %d domains, %d codelists",
                    len(result["domains"]), len(result["codelists"]))
    except Exception as exc:
        logger.error("define.xml parse failed: %s", exc)
        result["error"] = str(exc)

    return result
