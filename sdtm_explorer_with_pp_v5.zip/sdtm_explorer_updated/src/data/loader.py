# =============================================================================
# src/data/loader.py  -  Robust SDTM domain loader
# =============================================================================

import pandas as pd
import os
import hashlib
import logging
import tempfile
import gzip
import io
from pathlib import Path
from typing import Dict, List, Optional, Iterable

from src.utils.defensive import auto_merge_all_supp

logger = logging.getLogger(__name__)

ENCODINGS = ["utf-8", "latin1", "windows-1252", "cp1250"]

# Variables required per domain to pass basic validation
REQUIRED = {
    "dm": ["USUBJID", "STUDYID"],
    "ae": ["USUBJID"],
    "ex": ["USUBJID"],
    "lb": ["USUBJID"],
    "vs": ["USUBJID"],
}

# SDTM domain detection signals: column sets unique to each domain
DOMAIN_SIGNALS = {
    "dm":  ["RFSTDTC", "AGE", "SEX", "RACE", "ARM", "ARMCD"],
    "ae":  ["AETERM", "AEDECOD", "AESTDTC", "AESER"],
    "ex":  ["EXTRT", "EXDOSE", "EXSTDTC"],
    "lb":  ["LBTESTCD", "LBSTRESN", "LBSTRESU"],
    "vs":  ["VSTESTCD", "VSSTRESN", "VSSTRESU"],
    "cm":  ["CMTRT", "CMDECOD"],
    "mh":  ["MHTERM", "MHDECOD"],
    "ds":  ["DSDECOD", "DSSCAT"],
    "sv":  ["SVSTDTC", "VISITNUM"],
    "tr":  ["TRTESTCD", "TRORRES", "TRDTC"],
    "rs":  ["RSSTRESC", "RSDTC"],
    "tu":  ["TUTESTCD", "TUORRES"],
    "dv":  ["DVTERM", "DVDECOD"],
    "fa":  ["FATESTCD", "FAORRES"],
    "eg":  ["EGTESTCD", "EGSTRESN"],
    "pc":  ["PCTESTCD", "PCSTRESN"],
    "pp":  ["PPTESTCD", "PPSTRESN"],
    "ce":  ["CETERM", "CEDECOD"],
    "ml":  ["MLTESTCD", "MLORRES"],
}


def dir_fingerprint(
    path: str,
    extensions: Optional[Iterable[str]] = None,
) -> str:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Path not found: {path}")
    exts = set(extensions or [".xpt", ".sas7bdat"])
    m = hashlib.md5()
    for f in sorted(p.rglob("*")):
        if f.is_file() and f.suffix.lower() in exts:
            stat = f.stat()
            m.update(f.name.encode())
            m.update(str(stat.st_size).encode())
            m.update(str(int(stat.st_mtime)).encode())
    return m.hexdigest()


def _decode_bytes(df: pd.DataFrame) -> pd.DataFrame:
    """Decode any remaining bytes objects in object columns."""
    for col in df.select_dtypes(include="object").columns:
        if df[col].map(lambda x: isinstance(x, (bytes, bytearray))).any():
            def _dec(v):
                if isinstance(v, (bytes, bytearray)):
                    for enc in ENCODINGS:
                        try:
                            return v.decode(enc)
                        except Exception:
                            pass
                    return repr(v)
                return v
            df[col] = df[col].map(_dec)
    return df


def _convert_dates(df: pd.DataFrame) -> pd.DataFrame:
    """Auto-convert *DTC / *DT / DATE columns to datetime."""
    for col in df.columns:
        u = col.upper()
        if u.endswith("DTC") or u.endswith("DT") or "DATE" in u:
            try:
                df[col] = pd.to_datetime(df[col], errors="coerce")
            except Exception:
                pass
    return df


def _normalize(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # ── Step 1: Decode/strip/uppercase ALL column names ───────────────────────
    # pyreadstat can return bytes like b'USUBJID'; str.strip() removes spaces
    new_cols = []
    for c in df.columns:
        if isinstance(c, bytes):
            try:
                c = c.decode("latin-1")
            except Exception:
                c = repr(c)
        new_cols.append(str(c).strip().upper())
    df.columns = new_cols

    # ── Step 2: Recover USUBJID if pyreadstat placed it as the index ──────────
    if "USUBJID" not in df.columns:
        idx_name = df.index.name
        if isinstance(idx_name, bytes):
            try:
                idx_name = idx_name.decode("latin-1").strip().upper()
            except Exception:
                idx_name = ""
        elif idx_name:
            idx_name = str(idx_name).strip().upper()
        if idx_name == "USUBJID":
            df = df.reset_index()

    # ── Step 3: Normalise cell values ─────────────────────────────────────────
    # In pandas 3.x, StringDtype stores NA as float NaN, not pd.NA.
    # Using fillna('') BEFORE astype(str) prevents mixed str/float columns
    # which cause Arrow serialisation failures in st.dataframe().
    for col in df.columns:
        if not pd.api.types.is_numeric_dtype(df[col]) and \
           not pd.api.types.is_datetime64_any_dtype(df[col]):
            try:
                df[col] = (
                    df[col]
                    .fillna("")
                    .astype(str)
                    .str.strip()
                    .replace({"nan": "", "None": "", "NaT": "", "<NA>": ""})
                )
            except Exception:
                pass
    df = _decode_bytes(df)
    df = _convert_dates(df)
    return df


def _read_xpt(path: str, encoding: Optional[str] = None) -> Optional[pd.DataFrame]:
    try:
        import pyreadstat
        df, _ = pyreadstat.read_xport(path)
        return df
    except Exception:
        pass
    try:
        df = pd.read_sas(path, format="xport", encoding=encoding or "latin1")
        return df
    except Exception:
        pass
    return None


def _read_sas7bdat(path: str) -> Optional[pd.DataFrame]:
    for enc in [None] + ENCODINGS:
        try:
            import pyreadstat
            kw = {} if enc is None else {"encoding": enc}
            df, _ = pyreadstat.read_sas7bdat(path, **kw)
            return df
        except Exception:
            pass
        try:
            df = pd.read_sas(
                path,
                format="sas7bdat",
                encoding=enc or "latin1",
            )
            return df
        except Exception:
            pass
    return None


def _read_file(path: str) -> Optional[pd.DataFrame]:
    p = Path(path)
    lower = p.name.lower()

    # Handle .gz wrapper
    if lower.endswith(".gz"):
        try:
            raw = gzip.decompress(p.read_bytes())
            lower = lower[:-3]
        except Exception:
            return None
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix="." + lower.rsplit(".", 1)[-1])
        tmp.write(raw)
        tmp.flush()
        path = tmp.name
        p = Path(path)
        lower = p.name.lower()

    if lower.endswith(".xpt"):
        return _read_xpt(path)
    if lower.endswith(".sas7bdat"):
        return _read_sas7bdat(path)
    if lower.endswith(".csv"):
        for enc in ENCODINGS:
            try:
                return pd.read_csv(path, encoding=enc)
            except Exception:
                pass
    if lower.endswith((".xlsx", ".xls")):
        try:
            return pd.read_excel(path)
        except Exception:
            pass
    return None


def _detect_domain_name(filename: str, df: pd.DataFrame) -> str:
    """
    Detect SDTM domain name for a loaded DataFrame.

    Priority order (CDISC-correct):
      1. DOMAIN column inside the file  — always the authoritative source
      2. Filename stem exact / suffix match
      3. Column signature scoring
      4. First 2 chars of filename stem as last resort
    """
    stem = Path(filename).stem.upper()

    # ── 1. DOMAIN column is the CDISC ground truth — check it FIRST ──────────
    # Sponsors sometimes name files differently from the domain they contain
    # (e.g. dm.sas7bdat may hold TA data). The DOMAIN variable never lies.
    if "DOMAIN" in df.columns:
        vals = [
            str(v).strip().lower()
            for v in df["DOMAIN"].dropna().unique()
            if 1 <= len(str(v).strip()) <= 4
        ]
        if len(vals) == 1:
            # Single unique DOMAIN value — trust it unconditionally
            return vals[0]

    # ── 2. Filename stem exact match: dm.xpt -> dm, SDTM_AE_FINAL.xpt -> ae ──
    for dom in DOMAIN_SIGNALS:
        d = dom.upper()
        if stem == d:
            return dom
        for sep in ["_", "-", "/"]:
            if stem.endswith(sep + d):
                return dom

    # ── 3. Column signature scoring ───────────────────────────────────────────
    best_dom, best_count = "", 0
    for dom, signals in DOMAIN_SIGNALS.items():
        hits = sum(1 for s in signals if s in df.columns)
        if hits > best_count:
            best_count = hits
            best_dom = dom
    if best_count >= 2:
        return best_dom

    # ── 4. Last resort: first 2 chars of filename stem ────────────────────────
    if len(stem) >= 2:
        return stem[:2].lower()
    return stem.lower()


class SDTMLoader:
    def __init__(self, domain_whitelist: Optional[List[str]] = None):
        self.whitelist = (
            [d.lower() for d in domain_whitelist]
            if domain_whitelist
            else None
        )

    def load_domain(self, filepath: str) -> Optional[pd.DataFrame]:
        df = _read_file(filepath)
        if df is None or df.empty:
            return None
        df = _normalize(df)
        return df

    def load_all_domains(
        self,
        data_path: Optional[str] = None,
        extensions: Optional[Iterable[str]] = None,
    ) -> Dict[str, pd.DataFrame]:
        if data_path is None:
            raise ValueError("data_path is required")
        root = Path(data_path)
        if not root.exists():
            raise FileNotFoundError(f"Not found: {data_path}")

        exts = set(extensions or [".xpt", ".sas7bdat"])
        files = [f for f in root.iterdir() if f.is_file() and f.suffix.lower() in exts]
        # Also look one level deep
        for sub in root.iterdir():
            if sub.is_dir():
                files += [
                    f for f in sub.iterdir()
                    if f.is_file() and f.suffix.lower() in exts
                ]

        domains: Dict[str, pd.DataFrame] = {}
        for filepath in sorted(set(files)):
            df = self.load_domain(str(filepath))
            if df is None:
                logger.warning("Could not load: %s", filepath.name)
                continue
            dom = _detect_domain_name(filepath.name, df)
            if self.whitelist and dom not in self.whitelist:
                continue
            req = REQUIRED.get(dom, [])
            missing = [v for v in req if v not in df.columns]
            if missing:
                logger.warning(
                    "Domain %s missing required cols: %s", dom.upper(), missing
                )
            domains[dom] = df
            logger.info(
                "Loaded %s: %d rows, %d cols",
                dom.upper(),
                len(df),
                len(df.columns),
            )
        logger.info("Total domains loaded: %d", len(domains))
        # Auto-merge SUPPxx domains into parents
        try:
            domains = auto_merge_all_supp(domains)
        except Exception as _e:
            logger.warning("SUPP auto-merge skipped: %s", _e)
        return domains
