# =============================================================================
# src/data/demo_data.py  -  Synthetic SDTM demo datasets for testing
# =============================================================================
# Generates realistic SDTM-structured DataFrames so the tool can be
# demonstrated and tested without real clinical data.
# All numpy integer/float values cast to Python native types before use in
# datetime.timedelta or list indexing to avoid numpy.int64 errors.
# =============================================================================

import pandas as pd
import numpy as np
import datetime
from typing import Dict, Optional


def _int(v):
    """Cast numpy int to Python int safely."""
    return int(v)


def _float(v):
    """Cast numpy float to Python float safely."""
    return float(v)


def generate_demo_sdtm(
    n_subjects: int = 60,
    seed: int = 42,
    study_id: str = "DEMO001",
    arms: Optional[list] = None,
) -> Dict[str, pd.DataFrame]:
    """
    Generate synthetic SDTM domains: DM, AE, EX, LB, VS, CM, MH, DS, RS, TR
    Returns dict {domain_name: DataFrame} matching real SDTM structure.
    """
    rng = np.random.default_rng(seed)
    if arms is None:
        arms = ["DRUG A 10mg", "DRUG A 20mg", "PLACEBO"]

    ref_date = datetime.date(2022, 1, 1)

    def rand_date(start_days=0, max_days=365, n=1):
        days = rng.integers(start_days, max_days, size=n)
        return [
            (ref_date + datetime.timedelta(days=_int(d))).isoformat()
            for d in days
        ]

    def make_usubjid(i):
        site = f"{_int(rng.integers(1, 5)):02d}"
        return f"{study_id}-{site}-{i + 1:03d}"

    USUBJIDS   = [make_usubjid(i) for i in range(n_subjects)]
    ARM_ASSIGN = [arms[i % len(arms)] for i in range(n_subjects)]
    RFSTDTCS   = rand_date(0, 30, n=n_subjects)

    # ------------------------------------------------------------------ #
    # DM - Demographics
    # ------------------------------------------------------------------ #
    races  = ["WHITE", "BLACK OR AFRICAN AMERICAN", "ASIAN", "OTHER"]
    race_w = [0.65, 0.15, 0.15, 0.05]

    sex_vals  = rng.choice(["M", "F"], size=n_subjects, p=[0.52, 0.48]).tolist()
    ages      = rng.integers(25, 80, size=n_subjects).tolist()
    race_vals = rng.choice(races, size=n_subjects, p=race_w).tolist()
    ethnic    = rng.choice(
        ["HISPANIC OR LATINO", "NOT HISPANIC OR LATINO"],
        size=n_subjects, p=[0.2, 0.8]
    ).tolist()
    countries = rng.choice(
        ["USA", "GBR", "DEU", "FRA", "JPN"],
        size=n_subjects, p=[0.5, 0.2, 0.1, 0.1, 0.1]
    ).tolist()

    dm = pd.DataFrame({
        "STUDYID": study_id,
        "DOMAIN":  "DM",
        "USUBJID": USUBJIDS,
        "SUBJID":  [u.split("-")[-1] for u in USUBJIDS],
        "SITEID":  [u.split("-")[1]  for u in USUBJIDS],
        "AGE":     [_int(a) for a in ages],
        "AGEU":    "YEARS",
        "SEX":     sex_vals,
        "RACE":    race_vals,
        "ETHNIC":  ethnic,
        "ARM":     ARM_ASSIGN,
        "ARMCD":   [a[:6].replace(" ", "").upper() for a in ARM_ASSIGN],
        "ACTARM":  ARM_ASSIGN,
        "RFSTDTC": RFSTDTCS,
        "COUNTRY": countries,
    })

    # ------------------------------------------------------------------ #
    # EX - Exposure
    # ------------------------------------------------------------------ #
    ex_rows    = []
    TRTEDT_MAP = {}
    for i, uid in enumerate(USUBJIDS):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        n_cycles = _int(rng.integers(2, 13))
        arm  = ARM_ASSIGN[i]
        dose = 0 if "PLACEBO" in arm else (10 if "10mg" in arm else 20)
        for cycle in range(n_cycles):
            exstdtc = (start_dt + datetime.timedelta(days=cycle * 21)).isoformat()
            exendtc = (start_dt + datetime.timedelta(days=cycle * 21 + 1)).isoformat()
            ex_rows.append({
                "STUDYID":  study_id,
                "DOMAIN":   "EX",
                "USUBJID":  uid,
                "EXSEQ":    cycle + 1,
                "EXTRT":    arm,
                "EXDOSE":   float(dose),
                "EXDOSU":   "mg",
                "EXDOSFRQ": "Q3W",
                "EXROUTE":  "INTRAVENOUS",
                "EXSTDTC":  exstdtc,
                "EXENDTC":  exendtc,
                "EPOCH":    f"CYCLE {cycle + 1}",
            })
        TRTEDT_MAP[uid] = (
            start_dt + datetime.timedelta(days=(n_cycles - 1) * 21 + 1)
        ).isoformat()

    ex = pd.DataFrame(ex_rows)

    # ------------------------------------------------------------------ #
    # AE - Adverse Events
    # ------------------------------------------------------------------ #
    AE_DICT = [
        ("Fatigue",               "General disorders",              "MILD"),
        ("Nausea",                "Gastrointestinal disorders",      "MILD"),
        ("Headache",              "Nervous system disorders",        "MILD"),
        ("Alopecia",              "Skin and subcutaneous tissue",    "MODERATE"),
        ("Neutropenia",           "Blood and lymphatic system",      "SEVERE"),
        ("Anaemia",               "Blood and lymphatic system",      "MODERATE"),
        ("Vomiting",              "Gastrointestinal disorders",      "MILD"),
        ("Diarrhoea",             "Gastrointestinal disorders",      "MODERATE"),
        ("Pyrexia",               "General disorders",               "MILD"),
        ("Dyspnoea",              "Respiratory disorders",           "MODERATE"),
        ("Peripheral neuropathy", "Nervous system disorders",        "MODERATE"),
        ("Hypertension",          "Vascular disorders",              "MODERATE"),
        ("ALT increased",         "Investigations",                  "MILD"),
        ("AST increased",         "Investigations",                  "MILD"),
        ("Thrombocytopenia",      "Blood and lymphatic system",      "SEVERE"),
        ("Rash",                  "Skin and subcutaneous tissue",    "MILD"),
    ]
    SEV_TO_GRADE   = {"MILD": 1, "MODERATE": 2, "SEVERE": 3}
    CAUSALITY_OPTS = ["RELATED", "POSSIBLY RELATED", "NOT RELATED"]
    CAUSALITY_W    = [0.45, 0.30, 0.25]

    ae_rows = []
    ae_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS):
        trtsdt  = datetime.date.fromisoformat(RFSTDTCS[i])
        n_aes   = _int(rng.integers(0, 8))
        for _ in range(n_aes):
            idx   = _int(rng.integers(0, len(AE_DICT)))
            term, soc, sev = AE_DICT[idx]
            ae_start = trtsdt + datetime.timedelta(days=_int(rng.integers(1, 300)))
            ae_end   = ae_start + datetime.timedelta(days=_int(rng.integers(1, 30)))
            is_sae   = bool(rng.random() < 0.06)
            ae_seq[uid] += 1
            ae_rows.append({
                "STUDYID": study_id,
                "DOMAIN":  "AE",
                "USUBJID": uid,
                "AESEQ":   ae_seq[uid],
                "AETERM":  term,
                "AEDECOD": term,
                "AEBODSYS": soc,
                "AESTDTC": ae_start.isoformat(),
                "AEENDTC": ae_end.isoformat(),
                "AESEV":   sev,
                "AETOXGR": SEV_TO_GRADE[sev],
                "AESER":   "Y" if is_sae else "N",
                "AEREL":   str(rng.choice(CAUSALITY_OPTS, p=CAUSALITY_W)),
                "AEOUT":   str(rng.choice(
                    ["RECOVERED", "RECOVERING", "NOT RECOVERED"],
                    p=[0.7, 0.2, 0.1]
                )),
                "AEACN":   str(rng.choice(
                    ["DOSE NOT CHANGED", "DOSE REDUCED", "DRUG WITHDRAWN"],
                    p=[0.8, 0.15, 0.05]
                )),
            })
    ae = pd.DataFrame(ae_rows) if ae_rows else pd.DataFrame()

    # ------------------------------------------------------------------ #
    # LB - Laboratory
    # ------------------------------------------------------------------ #
    VISITS = [
        "Screening", "Day 1", "Week 3", "Week 6",
        "Week 9",    "Week 12", "End of Treatment",
    ]
    LAB_PARAMS = {
        "ALT":   {"lo": 7,   "hi": 40,  "unit": "U/L",    "mean": 25,  "sd": 10},
        "AST":   {"lo": 10,  "hi": 40,  "unit": "U/L",    "mean": 22,  "sd": 8},
        "BILI":  {"lo": 0.2, "hi": 1.2, "unit": "mg/dL",  "mean": 0.7, "sd": 0.3},
        "CREAT": {"lo": 0.6, "hi": 1.2, "unit": "mg/dL",  "mean": 0.9, "sd": 0.2},
        "HGB":   {"lo": 12,  "hi": 16,  "unit": "g/dL",   "mean": 13,  "sd": 1.5},
        "WBC":   {"lo": 4,   "hi": 11,  "unit": "10^3/uL","mean": 7,   "sd": 2},
        "PLT":   {"lo": 150, "hi": 400, "unit": "10^3/uL","mean": 250, "sd": 60},
        "NEUT":  {"lo": 1.8, "hi": 7.7, "unit": "10^3/uL","mean": 4.5, "sd": 1.5},
        "GLUC":  {"lo": 70,  "hi": 100, "unit": "mg/dL",  "mean": 90,  "sd": 12},
    }

    lb_rows = []
    lb_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        arm      = ARM_ASSIGN[i]
        for v_idx, visit in enumerate(VISITS):
            visit_dt = start_dt + datetime.timedelta(days=v_idx * 21)
            for testcd, spec in LAB_PARAMS.items():
                drift = 1.0
                if "PLACEBO" not in arm and v_idx > 2:
                    if testcd in ["ALT", "AST"]:
                        drift = 1.0 + 0.05 * v_idx
                    elif testcd in ["HGB", "WBC", "PLT", "NEUT"]:
                        drift = 1.0 - 0.03 * v_idx
                val   = max(0.01, _float(rng.normal(spec["mean"] * drift, spec["sd"])))
                nrind = "NORMAL"
                if val < spec["lo"]:
                    nrind = "LOW LOW" if val < spec["lo"] * 0.5 else "LOW"
                elif val > spec["hi"]:
                    nrind = "HIGH HIGH" if val > spec["hi"] * 2 else "HIGH"
                lb_seq[uid] += 1
                lb_rows.append({
                    "STUDYID":  study_id,
                    "DOMAIN":   "LB",
                    "USUBJID":  uid,
                    "LBSEQ":    lb_seq[uid],
                    "LBTESTCD": testcd,
                    "LBTEST":   testcd,
                    "LBCAT":    (
                        "CHEMISTRY"
                        if testcd in ["ALT", "AST", "BILI", "CREAT", "GLUC"]
                        else "HEMATOLOGY"
                    ),
                    "LBDTC":    visit_dt.isoformat(),
                    "VISIT":    visit,
                    "LBSTRESN": round(val, 3),
                    "LBSTRESC": str(round(val, 3)),
                    "LBSTRESU": spec["unit"],
                    "LBSTNRLO": spec["lo"],
                    "LBSTNRHI": spec["hi"],
                    "LBNRIND":  nrind,
                    "LBBLFL":   "Y" if visit == "Day 1" else "",
                })
    lb = pd.DataFrame(lb_rows)

    # ------------------------------------------------------------------ #
    # VS - Vital Signs
    # ------------------------------------------------------------------ #
    VS_PARAMS = {
        "SYSBP":  {"mean": 125, "sd": 12,  "unit": "mmHg"},
        "DIABP":  {"mean": 78,  "sd": 8,   "unit": "mmHg"},
        "HR":     {"mean": 74,  "sd": 10,  "unit": "beats/min"},
        "TEMP":   {"mean": 36.8,"sd": 0.4, "unit": "C"},
        "WEIGHT": {"mean": 72,  "sd": 14,  "unit": "kg"},
    }

    vs_rows = []
    vs_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        for v_idx, visit in enumerate(VISITS):
            visit_dt = start_dt + datetime.timedelta(days=v_idx * 21)
            for testcd, spec in VS_PARAMS.items():
                val = max(0.1, _float(rng.normal(spec["mean"], spec["sd"])))
                vs_seq[uid] += 1
                vs_rows.append({
                    "STUDYID":  study_id,
                    "DOMAIN":   "VS",
                    "USUBJID":  uid,
                    "VSSEQ":    vs_seq[uid],
                    "VSTESTCD": testcd,
                    "VSTEST":   testcd,
                    "VSDTC":    visit_dt.isoformat(),
                    "VISIT":    visit,
                    "VSSTRESN": round(val, 2),
                    "VSSTRESC": str(round(val, 2)),
                    "VSSTRESU": spec["unit"],
                    "VSBLFL":   "Y" if visit == "Day 1" else "",
                })
    vs = pd.DataFrame(vs_rows)

    # ------------------------------------------------------------------ #
    # CM - Concomitant Medications
    # ------------------------------------------------------------------ #
    CM_DRUGS = [
        "PARACETAMOL", "IBUPROFEN", "OMEPRAZOLE", "ONDANSETRON",
        "LORAZEPAM", "METOCLOPRAMIDE", "METFORMIN", "ATORVASTATIN",
        "LISINOPRIL", "ASPIRIN",
    ]

    cm_rows = []
    cm_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        n_cm = _int(rng.integers(0, 5))
        for _ in range(n_cm):
            drug     = CM_DRUGS[_int(rng.integers(0, len(CM_DRUGS)))]
            cm_start = (
                start_dt - datetime.timedelta(days=_int(rng.integers(0, 90)))
            ).isoformat()
            cm_end   = (
                start_dt + datetime.timedelta(days=_int(rng.integers(30, 200)))
            ).isoformat()
            cm_seq[uid] += 1
            cm_rows.append({
                "STUDYID": study_id,
                "DOMAIN":  "CM",
                "USUBJID": uid,
                "CMSEQ":   cm_seq[uid],
                "CMTRT":   drug,
                "CMDECOD": drug,
                "CMCAT":   "CONCOMITANT",
                "CMSTDTC": cm_start,
                "CMENDTC": cm_end,
                "CMINDC":  str(rng.choice(["PAIN", "NAUSEA", "PROPHYLAXIS", "OTHER"])),
                "CMROUTE": "ORAL",
            })
    cm = pd.DataFrame(cm_rows) if cm_rows else pd.DataFrame()

    # ------------------------------------------------------------------ #
    # MH - Medical History
    # ------------------------------------------------------------------ #
    MH_CONDITIONS = [
        ("Hypertension",    "Vascular disorders"),
        ("Type 2 Diabetes", "Endocrine disorders"),
        ("Hyperlipidaemia", "Metabolism disorders"),
        ("Asthma",          "Respiratory disorders"),
        ("Depression",      "Psychiatric disorders"),
        ("Osteoarthritis",  "Musculoskeletal disorders"),
    ]

    mh_rows = []
    mh_seq  = {uid: 0 for uid in USUBJIDS}
    for uid in USUBJIDS:
        n_mh = _int(rng.integers(0, 4))
        for _ in range(n_mh):
            idx       = _int(rng.integers(0, len(MH_CONDITIONS)))
            term, soc = MH_CONDITIONS[idx]
            mh_seq[uid] += 1
            mh_rows.append({
                "STUDYID": study_id,
                "DOMAIN":  "MH",
                "USUBJID": uid,
                "MHSEQ":   mh_seq[uid],
                "MHTERM":  term,
                "MHDECOD": term,
                "MHBODSYS": soc,
                "MHCAT":   "PRIOR MEDICAL HISTORY",
                "MHSTDTC": (
                    ref_date - datetime.timedelta(days=_int(rng.integers(30, 3650)))
                ).isoformat(),
            })
    mh = pd.DataFrame(mh_rows) if mh_rows else pd.DataFrame()

    # ------------------------------------------------------------------ #
    # DS - Disposition
    # ------------------------------------------------------------------ #
    DISC_REASONS = {
        "COMPLETED":             0.65,
        "ADVERSE EVENT":         0.12,
        "PROGRESSIVE DISEASE":   0.10,
        "WITHDRAWAL BY SUBJECT": 0.07,
        "LOST TO FOLLOW-UP":     0.04,
        "DEATH":                 0.02,
    }

    ds_rows = []
    ds_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        reason   = str(rng.choice(
            list(DISC_REASONS.keys()),
            p=list(DISC_REASONS.values())
        ))
        end_dt   = start_dt + datetime.timedelta(days=_int(rng.integers(60, 365)))
        ds_seq[uid] += 1
        ds_rows.append({
            "STUDYID": study_id,
            "DOMAIN":  "DS",
            "USUBJID": uid,
            "DSSEQ":   ds_seq[uid],
            "DSDECOD": reason,
            "DSTERM":  reason,
            "DSSCAT":  "DISPOSITION EVENT",
            "DSSTDTC": end_dt.isoformat(),
            "EPOCH":   "TREATMENT",
        })
    ds = pd.DataFrame(ds_rows)

    # ------------------------------------------------------------------ #
    # RS - Response (oncology subset)
    # ------------------------------------------------------------------ #
    RESPONSES = ["CR", "PR", "SD", "PD", "NE"]
    RESP_W    = [0.08, 0.22, 0.35, 0.25, 0.10]
    n_onco    = max(1, n_subjects // 2)

    rs_rows = []
    rs_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS[:n_onco]):
        start_dt = datetime.date.fromisoformat(RFSTDTCS[i])
        for v_idx, visit in enumerate(["Week 6", "Week 9", "Week 12"]):
            resp  = str(rng.choice(RESPONSES, p=RESP_W))
            rs_dt = start_dt + datetime.timedelta(days=(v_idx + 2) * 21)
            rs_seq[uid] += 1
            rs_rows.append({
                "STUDYID":  study_id,
                "DOMAIN":   "RS",
                "USUBJID":  uid,
                "RSSEQ":    rs_seq[uid],
                "RSTESTCD": "OVRLRESP",
                "RSTEST":   "Overall Response",
                "RSSTRESC": resp,
                "RSORRES":  resp,
                "RSDTC":    rs_dt.isoformat(),
                "VISIT":    visit,
                "RSEVAL":   "INVESTIGATOR",
            })
    rs_df = pd.DataFrame(rs_rows) if rs_rows else pd.DataFrame()

    # ------------------------------------------------------------------ #
    # TR - Tumor Results (oncology subset)
    # ------------------------------------------------------------------ #
    tr_rows = []
    tr_seq  = {uid: 0 for uid in USUBJIDS}
    for i, uid in enumerate(USUBJIDS[:n_onco]):
        start_dt      = datetime.date.fromisoformat(RFSTDTCS[i])
        arm           = ARM_ASSIGN[i]
        n_lesions     = _int(rng.integers(1, 4))
        baseline_sizes = [_float(v) for v in rng.uniform(10, 50, n_lesions)]

        for v_idx, visit in enumerate(["Screening", "Week 6", "Week 9", "Week 12"]):
            tr_dt = start_dt + datetime.timedelta(days=v_idx * 21)
            for l_idx in range(n_lesions):
                if "PLACEBO" not in arm and v_idx > 0:
                    shrink = 1.0 - 0.06 * v_idx + _float(rng.normal(0, 0.04))
                else:
                    shrink = 1.0 + 0.04 * v_idx + _float(rng.normal(0, 0.03))
                val = max(0.0, baseline_sizes[l_idx] * shrink)
                tr_seq[uid] += 1
                tr_rows.append({
                    "STUDYID":  study_id,
                    "DOMAIN":   "TR",
                    "USUBJID":  uid,
                    "TRSEQ":    tr_seq[uid],
                    "TRLNKID":  f"L{l_idx + 1}",
                    "TRTESTCD": "LDIAM",
                    "TRTEST":   "Longest Diameter",
                    "TRORRES":  round(val, 1),
                    "TRSTRESC": str(round(val, 1)),
                    "TRDTC":    tr_dt.isoformat(),
                    "VISIT":    visit,
                    "TREVAL":   "INVESTIGATOR",
                })
    tr_df = pd.DataFrame(tr_rows) if tr_rows else pd.DataFrame()

    # ------------------------------------------------------------------ #
    # Assemble and normalise column names
    # ------------------------------------------------------------------ #
    sdtm = {
        "dm": dm,
        "ae": ae,
        "ex": ex,
        "lb": lb,
        "vs": vs,
        "cm": cm,
        "mh": mh,
        "ds": ds,
        "rs": rs_df,
        "tr": tr_df,
    }
    return {k: _upper_cols(v) for k, v in sdtm.items() if v is not None and not v.empty}


def _upper_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip().upper() for c in df.columns]
    return df


def load_demo_data():
    """
    Convenience entry point called from app.py.
    Returns (sdtm_data, adsl) ready to put into session_state.
    """
    from src.derivations.populations import PopulationDerivation
    from src.utils.defensive import auto_merge_all_supp
    sdtm  = generate_demo_sdtm(n_subjects=60, seed=42)
    pop   = PopulationDerivation()
    adsl  = pop.create_adsl(sdtm.get("dm"), sdtm.get("ex"))
    try:
        sdtm = auto_merge_all_supp(sdtm)
    except Exception:
        pass
    return sdtm, adsl
