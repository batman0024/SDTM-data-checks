# =============================================================================
# src/utils/theme.py  -  Dark / Light mode CSS injection + toggle
# =============================================================================

import streamlit as st

DARK = {
    "bg":        "#0f172a",
    "card":      "#1e293b",
    "border":    "#334155",
    "text":      "#e2e8f0",
    "subtext":   "#94a3b8",
    "accent":    "#38bdf8",
    "accent2":   "#818cf8",
    "success":   "#22c55e",
    "warning":   "#f59e0b",
    "danger":    "#ef4444",
    "hover":     "#263147",
    "input":     "#1e293b",
    "sidebar_bg":"#0f172a",
    "metric_bg": "#1e293b",
}

LIGHT = {
    "bg":        "#f8fafc",
    "card":      "#ffffff",
    "border":    "#e2e8f0",
    "text":      "#1e293b",
    "subtext":   "#64748b",
    "accent":    "#2563eb",
    "accent2":   "#7c3aed",
    "success":   "#16a34a",
    "warning":   "#d97706",
    "danger":    "#dc2626",
    "hover":     "#f1f5f9",
    "input":     "#ffffff",
    "sidebar_bg":"#f1f5f9",
    "metric_bg": "#ffffff",
}


def apply_theme(dark: bool = True):
    c = DARK if dark else LIGHT
    css = f"""
    <style>
    /* ---- root + all descendant text ---- */
    .stApp {{
        background-color: {c["bg"]};
        color: {c["text"]};
    }}
    /* Cover every generic text node Streamlit renders */
    .stApp p, .stApp span, .stApp label,
    .stApp div, .stApp li, .stApp td, .stApp th {{
        color: {c["text"]};
    }}
    /* markdown blocks */
    .stMarkdown, .stMarkdown p, .stMarkdown li,
    [data-testid="stMarkdownContainer"] p,
    [data-testid="stMarkdownContainer"] li,
    [data-testid="stMarkdownContainer"] span {{
        color: {c["text"]} !important;
    }}
    /* ---- sidebar ---- */
    section[data-testid="stSidebar"] {{
        background-color: {c["sidebar_bg"]};
        border-right: 1px solid {c["border"]};
    }}
    section[data-testid="stSidebar"] * {{
        color: {c["text"]} !important;
    }}
    /* ---- metrics ---- */
    div[data-testid="stMetric"] {{
        background-color: {c["metric_bg"]};
        border: 1px solid {c["border"]};
        border-radius: 10px;
        padding: 14px 18px;
    }}
    div[data-testid="stMetricLabel"] p {{
        color: {c["subtext"]} !important;
        font-size: 0.78rem !important;
        font-weight: 600 !important;
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }}
    div[data-testid="stMetricValue"] {{
        color: {c["text"]} !important;
        font-size: 1.6rem !important;
        font-weight: 700 !important;
    }}
    /* ---- dataframes ---- */
    .stDataFrame {{
        border: 1px solid {c["border"]};
        border-radius: 8px;
    }}
    /* ---- inputs ---- */
    .stTextInput input, .stSelectbox div[data-baseweb="select"],
    .stTextInput label, .stSelectbox label,
    .stMultiSelect label, .stSlider label,
    .stCheckbox label, .stRadio label {{
        background-color: {c["input"]} !important;
        border-color: {c["border"]} !important;
        color: {c["text"]} !important;
    }}
    /* input typed text */
    .stTextInput input, textarea {{
        color: {c["text"]} !important;
        background-color: {c["input"]} !important;
    }}
    /* selectbox selected value */
    div[data-baseweb="select"] span,
    div[data-baseweb="select"] div {{
        color: {c["text"]} !important;
        background-color: {c["input"]} !important;
    }}
    /* multiselect tags */
    span[data-baseweb="tag"] {{
        background-color: {c["border"]} !important;
        color: {c["text"]} !important;
    }}
    /* ---- tabs ---- */
    .stTabs [data-baseweb="tab-list"] {{
        background-color: {c["card"]};
        border-radius: 8px;
        padding: 4px;
    }}
    .stTabs [data-baseweb="tab"] {{
        color: {c["subtext"]} !important;
        font-weight: 600;
    }}
    .stTabs [aria-selected="true"] {{
        color: {c["accent"]} !important;
        background-color: {c["bg"]} !important;
        border-radius: 6px;
    }}
    /* ---- divider ---- */
    hr {{
        border-color: {c["border"]};
    }}
    /* ---- headings ---- */
    h1, h2, h3, h4, h5, h6 {{
        color: {c["text"]} !important;
    }}
    /* ---- expander ---- */
    div[data-testid="stExpander"] {{
        border: 1px solid {c["border"]};
        border-radius: 8px;
        background-color: {c["card"]};
    }}
    div[data-testid="stExpander"] summary {{
        color: {c["text"]} !important;
    }}
    div[data-testid="stExpander"] summary p {{
        color: {c["text"]} !important;
    }}
    /* ---- cards utility class ---- */
    .cde-card {{
        background: {c["card"]};
        border: 1px solid {c["border"]};
        border-radius: 12px;
        padding: 20px 22px;
        margin-bottom: 14px;
    }}
    .cde-badge-ok {{
        display:inline-block;
        background:{c["success"]}22;
        color:{c["success"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    .cde-badge-warn {{
        display:inline-block;
        background:{c["warning"]}22;
        color:{c["warning"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    .cde-badge-err {{
        display:inline-block;
        background:{c["danger"]}22;
        color:{c["danger"]};
        border-radius:6px;
        padding:2px 9px;
        font-size:0.76rem;
        font-weight:700;
    }}
    /* ---- plotly chart container ---- */
    .js-plotly-plot {{
        border-radius: 10px;
    }}
    /* ---- primary button ---- */
    .stButton > button[kind="primary"] {{
        background-color: {c["accent"]};
        color: {"#0f172a" if dark else "#ffffff"};
        border: none;
        font-weight: 700;
        border-radius: 8px;
    }}
    .stButton > button[kind="primary"]:hover {{
        opacity: 0.88;
    }}
    /* ---- all other buttons ---- */
    .stButton > button {{
        color: {c["text"]} !important;
        border-color: {c["border"]} !important;
        background-color: {c["card"]} !important;
    }}
    /* ---- warning / info / error boxes ---- */
    div[data-testid="stAlert"] {{
        background-color: {c["card"]} !important;
    }}
    div[data-testid="stAlert"] p {{
        color: {c["text"]} !important;
    }}
    /* ---- caption / small text ---- */
    .stCaption, .stCaption p {{
        color: {c["subtext"]} !important;
    }}
    /* ---- download button label ---- */
    .stDownloadButton > button {{
        color: {c["text"]} !important;
        border-color: {c["border"]} !important;
        background-color: {c["card"]} !important;
    }}
    /* ---- number input ---- */
    .stNumberInput input {{
        color: {c["text"]} !important;
        background-color: {c["input"]} !important;
    }}
    /* ---- spinner text ---- */
    .stSpinner > div > span {{
        color: {c["text"]} !important;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
    # Store colors so pages can access them for plot theming
    st.session_state["_theme_colors"] = c
    st.session_state["_theme_dark"] = dark


def render_theme_toggle():
    dark = st.session_state.get("dark_mode", True)
    label = "Light Mode" if dark else "Dark Mode"
    icon = "Sun" if dark else "Moon"
    if st.button(f"{icon}  {label}", use_container_width=True, key="__theme_toggle"):
        st.session_state["dark_mode"] = not dark
        st.rerun()


def get_plotly_template(dark: bool = True) -> str:
    return "plotly_dark" if dark else "plotly_white"


def get_colors() -> dict:
    return st.session_state.get("_theme_colors", DARK)


# ---------------------------------------------------------------------------
# Color utility helpers (safe for plotly fillcolor / rgba)
# ---------------------------------------------------------------------------

def hex_to_rgba(hex_color: str, alpha: float = 1.0) -> str:
    """
    Convert a 6-digit hex color string to an rgba() string safe for plotly.
    plotly does NOT accept 8-digit hex with alpha (#rrggbbaa).
    Always use this instead of hex_str + '30' etc.
    """
    try:
        h = hex_color.lstrip('#')
        if len(h) == 6:
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return f'rgba({r},{g},{b},{alpha})'
        if len(h) == 8:  # already has alpha bytes -- convert anyway
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return f'rgba({r},{g},{b},{alpha})'
    except Exception:
        pass
    return hex_color  # fallback: return original


def color_with_alpha(hex_color: str, alpha: float = 0.15) -> str:
    """Convenience alias for hex_to_rgba."""
    return hex_to_rgba(hex_color, alpha)
