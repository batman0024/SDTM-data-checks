# =============================================================================
# src/ml/subject_clusterer.py
# Dimensionality reduction (UMAP > PCA fallback) +
# Clustering (HDBSCAN > KMeans fallback) for patient phenotyping.
#
# Design:
#   - umap-learn: preferred for 2D embedding
#   - sklearn PCA: fallback if umap not installed
#   - hdbscan: preferred density clustering
#   - sklearn KMeans: fallback
#   - All methods wrapped in try/except
#   - Silhouette score computed for quality assessment
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, Optional, Tuple, Any, List

logger = logging.getLogger(__name__)

# Graceful imports
try:
    from sklearn.decomposition import PCA
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    import umap as umap_lib
    HAS_UMAP = True
except ImportError:
    HAS_UMAP = False

try:
    import hdbscan as hdbscan_lib
    HAS_HDBSCAN = True
except ImportError:
    HAS_HDBSCAN = False

MIN_SUBJECTS_CLUSTER = 15
MIN_SUBJECTS_UMAP    = 15


# ---------------------------------------------------------------------------
# Main API
# ---------------------------------------------------------------------------
def run_clustering(
    X: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    n_components: int = 2,
    n_clusters: int = 3,
    umap_n_neighbors: int = 15,
    umap_min_dist: float = 0.1,
    hdbscan_min_cluster_size: int = 5,
    random_state: int = 42,
) -> Dict[str, Any]:
    """
    Perform dimensionality reduction and clustering.

    Returns
    -------
    dict with keys:
      'embedding'      : DataFrame (USUBJID x [dim1, dim2]) - 2D coords for plot
      'cluster_labels' : Series (USUBJID -> cluster_id, -1 = noise)
      'cluster_summary': DataFrame - per-cluster statistics
      'silhouette'     : float or None
      'method_dim'     : str - which dim reduction was used
      'method_cluster' : str - which clustering was used
      'warnings'       : list of str
      'n_clusters'     : int
    """
    result: Dict[str, Any] = {
        "embedding":       pd.DataFrame(),
        "cluster_labels":  pd.Series(dtype=int),
        "cluster_summary": pd.DataFrame(),
        "silhouette":      None,
        "method_dim":      "none",
        "method_cluster":  "none",
        "warnings":        [],
        "n_clusters":      0,
    }

    if not HAS_SKLEARN:
        result["warnings"].append("scikit-learn not installed.")
        return result

    if X is None or X.empty:
        result["warnings"].append("Empty feature matrix.")
        return result

    n_subj, n_feat = X.shape
    if n_subj < MIN_SUBJECTS_CLUSTER:
        result["warnings"].append(
            f"Only {n_subj} subjects. Need >= {MIN_SUBJECTS_CLUSTER} for clustering."
        )
        return result

    X_filled = X.fillna(0.0)

    # ---- Step 1: Dimensionality reduction ----
    embedding, dim_method = _reduce_dimensions(
        X_filled, n_components, umap_n_neighbors, umap_min_dist, random_state, n_subj
    )
    result["method_dim"] = dim_method

    if embedding is None:
        result["warnings"].append("Dimensionality reduction failed.")
        return result

    # Store embedding
    cols = [f"Dim{i+1}" for i in range(embedding.shape[1])]
    result["embedding"] = pd.DataFrame(embedding, index=X.index, columns=cols)

    # ---- Step 2: Clustering ----
    labels, cluster_method = _cluster(
        embedding, n_clusters, hdbscan_min_cluster_size, random_state, n_subj
    )
    result["method_cluster"] = cluster_method

    if labels is None:
        result["warnings"].append("Clustering failed.")
        result["cluster_labels"] = pd.Series(-1, index=X.index)
        return result

    result["cluster_labels"] = pd.Series(labels, index=X.index, name="Cluster")
    result["n_clusters"] = int(max(labels) + 1) if max(labels) >= 0 else 0

    # ---- Step 3: Silhouette score ----
    valid_mask = labels != -1
    if valid_mask.sum() >= MIN_SUBJECTS_CLUSTER and len(np.unique(labels[valid_mask])) >= 2:
        try:
            result["silhouette"] = round(
                float(silhouette_score(embedding[valid_mask], labels[valid_mask])),
                3,
            )
        except Exception as exc:
            logger.warning("Silhouette score failed: %s", exc)

    # ---- Step 4: Cluster summary ----
    if not adsl.empty:
        result["cluster_summary"] = _build_cluster_summary(
            result["cluster_labels"], adsl, trt_col, X
        )

    return result


# ---------------------------------------------------------------------------
# Dimensionality reduction
# ---------------------------------------------------------------------------
def _reduce_dimensions(
    X: np.ndarray,
    n_components: int,
    n_neighbors: int,
    min_dist: float,
    random_state: int,
    n_subj: int,
) -> Tuple[Optional[np.ndarray], str]:
    """Try UMAP first, fall back to PCA."""
    # Clamp n_neighbors
    n_neighbors = min(n_neighbors, n_subj - 1)

    if HAS_UMAP and n_subj >= MIN_SUBJECTS_UMAP:
        try:
            reducer = umap_lib.UMAP(
                n_components=n_components,
                n_neighbors=n_neighbors,
                min_dist=min_dist,
                random_state=random_state,
                low_memory=True,
            )
            embedding = reducer.fit_transform(X.values if hasattr(X, 'values') else X)
            return embedding, "UMAP"
        except Exception as exc:
            logger.warning("UMAP failed: %s - falling back to PCA", exc)

    # PCA fallback
    try:
        n_comp = min(n_components, min(X.shape[0], X.shape[1]) - 1)
        pca = PCA(n_components=n_comp, random_state=random_state)
        embedding = pca.fit_transform(X.values if hasattr(X, 'values') else X)
        var_explained = sum(pca.explained_variance_ratio_[:n_comp]) * 100
        method_str = f"PCA ({var_explained:.0f}% var explained)"
        return embedding, method_str
    except Exception as exc:
        logger.warning("PCA also failed: %s", exc)
        return None, "failed"


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------
def _cluster(
    embedding: np.ndarray,
    n_clusters: int,
    min_cluster_size: int,
    random_state: int,
    n_subj: int,
) -> Tuple[Optional[np.ndarray], str]:
    """Try HDBSCAN first, fall back to KMeans."""
    if HAS_HDBSCAN:
        try:
            min_cs = max(2, min(min_cluster_size, n_subj // 4))
            clusterer = hdbscan_lib.HDBSCAN(
                min_cluster_size=min_cs,
                min_samples=max(1, min_cs // 2),
                prediction_data=True,
            )
            labels = clusterer.fit_predict(embedding)
            n_found = int(max(labels) + 1) if max(labels) >= 0 else 0
            noise_pct = (labels == -1).mean() * 100
            method = f"HDBSCAN ({n_found} clusters, {noise_pct:.0f}% noise)"
            if n_found < 2:
                logger.info("HDBSCAN found < 2 clusters, falling back to KMeans")
            else:
                return labels, method
        except Exception as exc:
            logger.warning("HDBSCAN failed: %s - falling back to KMeans", exc)

    # KMeans fallback
    try:
        k = max(2, min(n_clusters, n_subj // 3))
        km = KMeans(n_clusters=k, random_state=random_state, n_init=10)
        labels = km.fit_predict(embedding)
        return labels, f"KMeans (k={k})"
    except Exception as exc:
        logger.warning("KMeans failed: %s", exc)
        return None, "failed"


# ---------------------------------------------------------------------------
# Cluster summary
# ---------------------------------------------------------------------------
def _build_cluster_summary(
    labels: pd.Series,
    adsl: pd.DataFrame,
    trt_col: str,
    X: pd.DataFrame,
) -> pd.DataFrame:
    """Build per-cluster demographic/feature summary."""
    df = labels.reset_index().rename(columns={"index": "USUBJID", "Cluster": "Cluster"})
    if "USUBJID" not in df.columns and labels.index.name == "USUBJID":
        df = labels.reset_index()
        df.columns = ["USUBJID", "Cluster"]

    # Merge ADSL
    demo_cols = ["USUBJID"] + [
        c for c in [trt_col, "AGE", "SEX", "SAFFL", "TRTDURD"]
        if c and c in adsl.columns
    ]
    merged = df.merge(adsl[demo_cols].drop_duplicates(), on="USUBJID", how="left")

    rows = []
    for cluster_id, grp in merged.groupby("Cluster"):
        row: Dict = {
            "Cluster": int(cluster_id),
            "Label": "Noise" if cluster_id == -1 else f"Cluster {cluster_id}",
            "N": len(grp),
        }
        if trt_col and trt_col in grp.columns:
            trt_dist = grp[trt_col].value_counts()
            row["Predominant Arm"] = trt_dist.index[0] if len(trt_dist) > 0 else ""
            row["Arm Distribution"] = "; ".join(f"{k}: {v}" for k, v in trt_dist.items())
        if "AGE" in grp.columns:
            row["Mean Age"] = round(pd.to_numeric(grp["AGE"], errors="coerce").mean(), 1)
        if "SEX" in grp.columns:
            row["Sex (M%)"] = round(
                (grp["SEX"].str.upper().isin({"M", "MALE"}).sum() / max(len(grp), 1)) * 100, 1
            )
        if "SAFFL" in grp.columns:
            row["Safety Pop (%)"] = round(
                (grp["SAFFL"] == "Y").sum() / max(len(grp), 1) * 100, 1
            )
        rows.append(row)

    return pd.DataFrame(rows).sort_values("N", ascending=False).reset_index(drop=True)
