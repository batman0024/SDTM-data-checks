# =============================================================================
# src/ml/risk_scorer.py
# Subject-level composite risk scoring with feature attribution.
#
# Two scoring modes:
#   1. Weighted Sum (transparent, fully explainable, always available)
#   2. IsolationForest anomaly score (ML-based, requires sklearn)
#
# SHAP support: if shap is installed, uses TreeExplainer on a RandomForest
# trained on the anomaly labels to produce SHAP feature attributions.
# Falls back to permutation importance if shap is unavailable.
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)

try:
    from sklearn.ensemble import RandomForestClassifier, IsolationForest
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

# ---------------------------------------------------------------------------
# Default clinical domain weights for transparent scoring
# ---------------------------------------------------------------------------
DEFAULT_WEIGHTS = {
    # Safety signals (high weight)
    "AE_n_sae":       5.0,
    "AE_max_grade":   4.0,
    "AE_n_related":   3.0,
    "AE_n_teae":      2.0,
    # Lab abnormalities (medium weight, normalised to ULN)
    "LB_ALT_mean_uln":   3.0,
    "LB_AST_mean_uln":   3.0,
    "LB_BILI_mean_uln":  3.5,
    "LB_CREAT_mean_uln": 2.5,
    "LB_HGB_mean_uln":   2.0,  # low HGB is risk (will be inverted in scoring)
    "LB_PLT_mean_uln":   2.0,
    "LB_NEUT_mean_uln":  2.0,
    # Vital sign anomalies
    "VS_SYSBP_n_flagged": 2.0,
    "VS_HR_n_flagged":    1.5,
    # Exposure (short duration may mean early discontinuation = bad outcome)
    "EX_trtdurd":    -1.0,  # longer duration = less risk, so negative weight
}

TRAFFIC_LIGHT_THRESHOLDS = {
    "green":  (0, 33),
    "amber":  (33, 66),
    "red":    (66, 100),
}


# ---------------------------------------------------------------------------
# Main scoring function
# ---------------------------------------------------------------------------
def compute_risk_scores(
    X: pd.DataFrame,
    feat_meta: Dict[str, str],
    method: str = "weighted_sum",
    custom_weights: Optional[Dict[str, float]] = None,
    contamination: float = 0.1,
    random_state: int = 42,
) -> Dict[str, Any]:
    """
    Compute composite risk scores per subject.

    Parameters
    ----------
    X              : scaled feature matrix (subjects x features)
    feat_meta      : feature descriptions
    method         : 'weighted_sum' | 'isolation_forest' | 'both'
    custom_weights : override DEFAULT_WEIGHTS for specific features

    Returns
    -------
    dict with:
      'scores'          : Series, 0-100 risk score per subject
      'traffic_light'   : Series ('green'/'amber'/'red') per subject
      'feature_contrib' : DataFrame, feature contributions per subject
      'shap_values'     : DataFrame or None (SHAP values if available)
      'method_used'     : str
      'warnings'        : list of str
    """
    result: Dict[str, Any] = {
        "scores":           pd.Series(dtype=float),
        "traffic_light":    pd.Series(dtype=str),
        "feature_contrib":  pd.DataFrame(),
        "shap_values":      None,
        "method_used":      "none",
        "warnings":         [],
    }

    if X is None or X.empty:
        result["warnings"].append("Empty feature matrix - no scores computed.")
        return result

    n_subj, n_feat = X.shape
    if n_subj < 2:
        result["warnings"].append("Need at least 2 subjects for scoring.")
        return result

    weights = {**DEFAULT_WEIGHTS, **(custom_weights or {})}

    scores_ws = None
    scores_ml = None

    # ---- Method 1: Weighted Sum ----
    if method in ("weighted_sum", "both"):
        scores_ws, contrib_ws = _weighted_sum_score(X, weights, feat_meta)
        result["feature_contrib"] = contrib_ws

    # ---- Method 2: IsolationForest ----
    if method in ("isolation_forest", "both") and HAS_SKLEARN:
        try:
            scores_ml = _isolation_forest_score(X, contamination, random_state)
        except Exception as exc:
            result["warnings"].append(f"IsolationForest scoring failed: {exc}")
            logger.warning("IsolationForest risk score failed: %s", exc)

    # Combine
    if scores_ws is not None and scores_ml is not None:
        final = (scores_ws + scores_ml) / 2
        result["method_used"] = "weighted_sum + IsolationForest (averaged)"
    elif scores_ws is not None:
        final = scores_ws
        result["method_used"] = "weighted_sum"
    elif scores_ml is not None:
        final = scores_ml
        result["method_used"] = "IsolationForest"
    else:
        result["warnings"].append("No scoring method succeeded.")
        return result

    # Scale to 0-100
    mn, mx = final.min(), final.max()
    if mx > mn:
        final = (final - mn) / (mx - mn) * 100
    else:
        final = pd.Series(50.0, index=final.index)
    final = final.round(1)

    result["scores"] = final
    result["traffic_light"] = final.map(_assign_traffic_light)

    # ---- SHAP feature attribution (optional) ----
    if HAS_SHAP and HAS_SKLEARN and n_subj >= 20:
        try:
            result["shap_values"] = _compute_shap(X, final, random_state)
        except Exception as exc:
            result["warnings"].append(f"SHAP computation failed: {exc}")
            logger.warning("SHAP failed: %s", exc)

    return result


# ---------------------------------------------------------------------------
# Weighted sum scoring
# ---------------------------------------------------------------------------
def _weighted_sum_score(
    X: pd.DataFrame,
    weights: Dict[str, float],
    feat_meta: Dict[str, str],
) -> Tuple[pd.Series, pd.DataFrame]:
    """
    Score = sum over features of (weight * normalised_value)
    where normalised_value = (x - mean) / std, clamped to [-3, 3].
    """
    contrib = pd.DataFrame(index=X.index)
    total = pd.Series(0.0, index=X.index)

    for feat in X.columns:
        weight = None
        # Exact match first
        if feat in weights:
            weight = weights[feat]
        else:
            # Prefix match (e.g. 'LB_ALT_mean_uln' matches 'LB_ALT_mean_uln')
            for key, w in weights.items():
                if feat.startswith(key):
                    weight = w
                    break

        if weight is None:
            weight = 1.0  # default: include with unit weight

        # Normalise feature
        col = X[feat]
        mu  = col.mean()
        sig = col.std()
        if sig == 0 or np.isnan(sig):
            norm = pd.Series(0.0, index=X.index)
        else:
            norm = ((col - mu) / sig).clip(-3, 3)

        contribution = norm * abs(weight)
        # For negative weights: high value = low risk (e.g. trtdurd)
        if weight < 0:
            contribution = -contribution

        contrib[feat] = contribution.round(3)
        total += contribution

    return total, contrib


# ---------------------------------------------------------------------------
# IsolationForest scoring
# ---------------------------------------------------------------------------
def _isolation_forest_score(
    X: pd.DataFrame,
    contamination: float,
    random_state: int,
) -> pd.Series:
    max_samples = min(len(X), 256)
    iso = IsolationForest(
        n_estimators=200,
        max_samples=max_samples,
        contamination=float(np.clip(contamination, 0.01, 0.49)),
        random_state=random_state,
        n_jobs=-1,
    )
    iso.fit(X.fillna(0))
    # decision_function: more negative = more anomalous
    raw = -iso.decision_function(X.fillna(0))
    return pd.Series(raw, index=X.index)


# ---------------------------------------------------------------------------
# SHAP feature attribution
# ---------------------------------------------------------------------------
def _compute_shap(
    X: pd.DataFrame,
    scores: pd.Series,
    random_state: int,
) -> Optional[pd.DataFrame]:
    """
    Train a RandomForest to predict high vs low risk, then compute SHAP values.
    """
    if not HAS_SHAP or not HAS_SKLEARN:
        return None
    # Binary label: top 25% vs rest
    threshold = scores.quantile(0.75)
    y = (scores >= threshold).astype(int)
    if y.sum() < 2 or (1 - y).sum() < 2:
        return None

    X_filled = X.fillna(0)
    rf = RandomForestClassifier(
        n_estimators=100,
        max_depth=4,
        random_state=random_state,
        n_jobs=-1,
    )
    rf.fit(X_filled, y)

    explainer = shap.TreeExplainer(rf)
    shap_vals = explainer.shap_values(X_filled)
    # For binary classification, shap_values returns list [class0, class1]
    if isinstance(shap_vals, list) and len(shap_vals) == 2:
        shap_vals = shap_vals[1]
    return pd.DataFrame(shap_vals, index=X.index, columns=X.columns)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _assign_traffic_light(score: float) -> str:
    if score >= 66:
        return "red"
    if score >= 33:
        return "amber"
    return "green"


def get_top_risk_drivers(
    subject_id: str,
    feature_contrib: pd.DataFrame,
    shap_df: Optional[pd.DataFrame],
    feat_meta: Dict[str, str],
    top_n: int = 5,
) -> List[Dict]:
    """
    Return top N features driving risk for a specific subject.
    Uses SHAP if available, else feature contribution from weighted sum.
    """
    if subject_id not in feature_contrib.index:
        return []

    if shap_df is not None and subject_id in shap_df.index:
        values = shap_df.loc[subject_id].abs().sort_values(ascending=False)
        source = "SHAP"
    else:
        values = feature_contrib.loc[subject_id].abs().sort_values(ascending=False)
        source = "Contribution"

    result = []
    for feat, val in values.head(top_n).items():
        actual_contrib = (
            float(feature_contrib.loc[subject_id, feat])
            if feat in feature_contrib.columns
            else 0.0
        )
        result.append({
            "feature":     feat,
            "description": feat_meta.get(feat, feat),
            "value":       round(float(val), 3),
            "direction":   "increases risk" if actual_contrib > 0 else "decreases risk",
            "source":      source,
        })
    return result


def build_risk_summary_table(
    scores: pd.Series,
    traffic_light: pd.Series,
    adsl: pd.DataFrame,
    trt_col: str,
) -> pd.DataFrame:
    """
    Combine risk scores with ADSL demographics for summary table.
    """
    df = pd.DataFrame({
        "Risk_Score":    scores,
        "Risk_Level":    traffic_light,
    }).reset_index().rename(columns={"index": "USUBJID"})

    if adsl is not None and not adsl.empty:
        demo_cols = ["USUBJID"] + [
            c for c in [trt_col, "AGE", "SEX", "SAFFL", "TRTDURD"]
            if c and c in adsl.columns
        ]
        df = df.merge(adsl[demo_cols].drop_duplicates(), on="USUBJID", how="left")

    return df.sort_values("Risk_Score", ascending=False).reset_index(drop=True)
