# =============================================================================
# src/ml/cross_domain_patterns.py
# Cross-domain temporal pattern mining and subject-wise linking.
#
# Three analyses:
#   1. Association rule mining (AE terms, lab flags, VS flags co-occurring)
#      - mlxtend FP-Growth preferred; pure-pandas fallback if not installed
#   2. Temporal co-occurrence: AE onset within N days of lab change
#   3. Subject similarity network: cosine similarity on feature matrix
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, Optional, List, Tuple, Any

logger = logging.getLogger(__name__)

try:
    from mlxtend.preprocessing import TransactionEncoder
    from mlxtend.frequent_patterns import fpgrowth, association_rules as mlx_assoc_rules
    HAS_MLXTEND = True
except ImportError:
    HAS_MLXTEND = False
    logger.info("mlxtend not installed - using pandas-based co-occurrence fallback")

MIN_SUBJECTS_RULES = 10


# ---------------------------------------------------------------------------
# 1. Association Rule Mining
# ---------------------------------------------------------------------------
def mine_association_rules(
    sdtm_data: Dict[str, pd.DataFrame],
    adsl: pd.DataFrame,
    min_support: float = 0.1,
    min_confidence: float = 0.5,
    min_lift: float = 1.2,
    include_ae: bool = True,
    include_lb_flags: bool = True,
    include_vs_flags: bool = True,
    include_ds: bool = True,
) -> Dict[str, Any]:
    """
    Mine association rules across domains.
    Each 'item' is a clinical event/finding per subject.

    Returns
    -------
    dict with 'rules' DataFrame, 'itemset_counts' DataFrame, 'warnings' list
    """
    result: Dict[str, Any] = {
        "rules":           pd.DataFrame(),
        "itemset_counts":  pd.DataFrame(),
        "warnings":        [],
        "n_subjects":      0,
    }

    if adsl is None or adsl.empty:
        result["warnings"].append("ADSL required.")
        return result

    n_subj = len(adsl)
    result["n_subjects"] = n_subj

    if n_subj < MIN_SUBJECTS_RULES:
        result["warnings"].append(
            f"Only {n_subj} subjects. Need >= {MIN_SUBJECTS_RULES} for association rules."
        )
        return result

    # Build transaction list: each subject = set of clinical events
    subjects = adsl["USUBJID"].dropna().tolist()
    transactions: Dict[str, set] = {sid: set() for sid in subjects}

    # AE events: each unique PT is an item
    if include_ae:
        ae = sdtm_data.get("ae")
        if ae is not None and not ae.empty and "USUBJID" in ae.columns:
            pt_col = "AEDECOD" if "AEDECOD" in ae.columns else "AETERM"
            teae = ae[ae["TEAE"].astype(bool)] if "TEAE" in ae.columns else ae
            for sid, grp in teae.groupby("USUBJID"):
                if sid in transactions:
                    for pt in grp[pt_col].dropna().unique():
                        transactions[sid].add(f"AE:{pt[:30]}")
            # Serious AE flag
            if "AESER" in ae.columns:
                sae_subjs = ae[ae["AESER"].astype(str).str.upper().isin({"Y","YES"})]["USUBJID"].unique()
                for sid in sae_subjs:
                    if sid in transactions:
                        transactions[sid].add("AE:SAE")
            # Grade 3+ flag
            grade_col = "AETOXGR" if "AETOXGR" in ae.columns else None
            if grade_col:
                from src.analysis.safety import normalize_grade
                ae2 = ae.copy()
                ae2["_grade"] = normalize_grade(ae2[grade_col])
                g3_subjs = ae2[ae2["_grade"] >= 3]["USUBJID"].unique()
                for sid in g3_subjs:
                    if sid in transactions:
                        transactions[sid].add("AE:Grade3+")

    # Lab flags: abnormal values
    if include_lb_flags:
        lb = sdtm_data.get("lb")
        if lb is not None and not lb.empty and "LBNRIND" in lb.columns:
            abn = lb[
                lb["LBNRIND"].astype(str).str.upper().isin(
                    {"HIGH", "LOW", "HIGH HIGH", "LOW LOW", "H", "L", "HH", "LL"}
                )
            ]
            if "LBTESTCD" in abn.columns:
                for sid, grp in abn.groupby("USUBJID"):
                    if sid in transactions:
                        for test in grp["LBTESTCD"].dropna().unique():
                            nrind = grp[grp["LBTESTCD"] == test]["LBNRIND"].mode()
                            direction = str(nrind.iloc[0]).upper() if len(nrind) > 0 else "ABN"
                            transactions[sid].add(f"LB:{test}:{direction[:2]}")

    # VS flags
    if include_vs_flags:
        vs = sdtm_data.get("vs")
        THRESHOLDS = {
            "SYSBP": {"high": 160, "low": 90},
            "HR": {"high": 100, "low": 50},
            "TEMP": {"high": 38.5, "low": 36.0},
        }
        if vs is not None and not vs.empty and "VSTESTCD" in vs.columns:
            vs2 = vs.copy()
            vs2["VSSTRESN"] = pd.to_numeric(vs2.get("VSSTRESN", pd.Series(dtype=float)), errors="coerce")
            for test, thr in THRESHOLDS.items():
                sub = vs2[vs2["VSTESTCD"] == test].dropna(subset=["VSSTRESN"])
                flagged = sub[
                    (sub["VSSTRESN"] > thr.get("high", np.inf)) |
                    (sub["VSSTRESN"] < thr.get("low", -np.inf))
                ]
                for sid in flagged["USUBJID"].unique():
                    if sid in transactions:
                        transactions[sid].add(f"VS:{test}:FLAG")

    # Disposition events
    if include_ds:
        ds = sdtm_data.get("ds")
        if ds is not None and not ds.empty and "DSDECOD" in ds.columns:
            for sid, grp in ds.groupby("USUBJID"):
                if sid in transactions:
                    for dec in grp["DSDECOD"].dropna().unique():
                        transactions[sid].add(f"DS:{str(dec)[:20]}")

    # Build transaction list (non-empty only)
    trans_list = [list(v) for v in transactions.values() if len(v) >= 2]

    if len(trans_list) < MIN_SUBJECTS_RULES:
        result["warnings"].append(
            f"Only {len(trans_list)} subjects with >= 2 events. Increase coverage."
        )
        return result

    # Mine rules
    if HAS_MLXTEND:
        rules_df, counts_df, warns = _mine_with_mlxtend(
            trans_list, min_support, min_confidence, min_lift
        )
        result["warnings"].extend(warns)
    else:
        rules_df, counts_df, warns = _mine_pandas_fallback(
            trans_list, min_support, min_confidence
        )
        result["warnings"].extend(warns)
        result["warnings"].append(
            "mlxtend not installed - using simple co-occurrence (no lift/confidence). "
            "Install with: pip install mlxtend"
        )

    result["rules"]          = rules_df
    result["itemset_counts"] = counts_df
    return result


def _mine_with_mlxtend(
    transactions: List[List[str]],
    min_support: float,
    min_confidence: float,
    min_lift: float,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
    warnings_out = []
    try:
        te = TransactionEncoder()
        te_arr = te.fit(transactions).transform(transactions)
        df_enc = pd.DataFrame(te_arr, columns=te.columns_)

        # Use fpgrowth (faster than apriori)
        freq_items = fpgrowth(df_enc, min_support=min_support, use_colnames=True)
        if freq_items.empty:
            return pd.DataFrame(), pd.DataFrame(), ["No frequent itemsets found at current support threshold."]

        # Itemset counts
        counts = freq_items.copy()
        counts["support_count"] = (counts["support"] * len(transactions)).round().astype(int)
        counts["itemset_str"] = counts["itemsets"].apply(lambda s: " + ".join(sorted(s)))
        counts_df = counts[["itemset_str", "support", "support_count"]].sort_values(
            "support", ascending=False
        )

        # Association rules
        rules = mlx_assoc_rules(
            freq_items,
            metric="lift",
            min_threshold=min_lift,
            num_itemsets=len(df_enc),
        )
        if not rules.empty:
            # Filter by confidence
            rules = rules[rules["confidence"] >= min_confidence]
            rules["antecedents_str"]  = rules["antecedents"].apply(lambda s: " + ".join(sorted(s)))
            rules["consequents_str"]  = rules["consequents"].apply(lambda s: " + ".join(sorted(s)))
            rules["support_count"]    = (rules["support"] * len(transactions)).round().astype(int)
            display_cols = ["antecedents_str", "consequents_str",
                            "support", "support_count", "confidence", "lift"]
            rules = rules[display_cols].sort_values("lift", ascending=False).reset_index(drop=True)
        else:
            rules = pd.DataFrame()
            warnings_out.append("No rules found at current lift/confidence thresholds.")

        return rules, counts_df, warnings_out
    except Exception as exc:
        logger.warning("mlxtend mining failed: %s", exc)
        return pd.DataFrame(), pd.DataFrame(), [f"mlxtend error: {exc}"]


def _mine_pandas_fallback(
    transactions: List[List[str]],
    min_support: float,
    min_confidence: float,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
    """Simple co-occurrence matrix without mlxtend."""
    try:
        n = len(transactions)
        # Flatten to item sets
        all_items: set = set()
        for t in transactions:
            all_items.update(t)
        items = sorted(all_items)

        # Binary matrix
        mat = pd.DataFrame(0, index=range(n), columns=items)
        for i, t in enumerate(transactions):
            for item in t:
                if item in mat.columns:
                    mat.at[i, item] = 1

        # Support per item
        item_support = mat.sum() / n
        frequent = item_support[item_support >= min_support].index.tolist()
        if not frequent:
            return pd.DataFrame(), pd.DataFrame(), ["No frequent items at current support."]

        counts = (
            item_support[frequent]
            .reset_index()
            .rename(columns={"index": "itemset_str", 0: "support"})
            .assign(support_count=(item_support[frequent] * n).round().astype(int))
            .sort_values("support", ascending=False)
        )
        counts.columns = ["itemset_str", "support", "support_count"]

        # Pairwise co-occurrence
        rows = []
        mat_f = mat[frequent]
        for i, item_a in enumerate(frequent):
            for j, item_b in enumerate(frequent):
                if j <= i:
                    continue
                co_support = (mat_f[item_a] & mat_f[item_b]).sum() / n
                if co_support >= min_support:
                    conf_ab = co_support / max(item_support[item_a], 1e-9)
                    conf_ba = co_support / max(item_support[item_b], 1e-9)
                    if max(conf_ab, conf_ba) >= min_confidence:
                        rows.append({
                            "antecedents_str": item_a,
                            "consequents_str": item_b,
                            "support": round(co_support, 4),
                            "support_count": int(co_support * n),
                            "confidence": round(max(conf_ab, conf_ba), 3),
                            "lift": round(co_support / max(item_support[item_a] * item_support[item_b], 1e-9), 2),
                        })

        rules = pd.DataFrame(rows).sort_values("lift", ascending=False).reset_index(drop=True)
        return rules, counts, []
    except Exception as exc:
        logger.warning("Pandas co-occurrence fallback failed: %s", exc)
        return pd.DataFrame(), pd.DataFrame(), [f"Fallback error: {exc}"]


# ---------------------------------------------------------------------------
# 2. Temporal AE-Lab co-occurrence
# ---------------------------------------------------------------------------
def temporal_ae_lab_cooccurrence(
    ae: pd.DataFrame,
    lb: pd.DataFrame,
    adsl: pd.DataFrame,
    window_days: int = 21,
    min_subjects: int = 3,
) -> pd.DataFrame:
    """
    Find AE terms that co-occur with lab abnormalities within window_days
    in the same subject.

    Returns DataFrame: AE_Term, Lab_Test, Direction, N_Subjects, Pct_Subjects
    """
    if ae is None or ae.empty or lb is None or lb.empty:
        return pd.DataFrame()
    if "AESTDTC" not in ae.columns or "LBDTC" not in lb.columns:
        return pd.DataFrame()

    try:
        ae2 = ae.copy()
        lb2 = lb.copy()
        ae2["AESTDTC"] = pd.to_datetime(ae2["AESTDTC"], errors="coerce")
        lb2["LBDTC"]   = pd.to_datetime(lb2["LBDTC"],   errors="coerce")

        pt_col   = "AEDECOD" if "AEDECOD" in ae2.columns else "AETERM"
        nrind_col = "LBNRIND"

        if pt_col not in ae2.columns or nrind_col not in lb2.columns:
            return pd.DataFrame()

        # Filter to abnormal lab values
        abn_lb = lb2[
            lb2[nrind_col].astype(str).str.upper().isin(
                {"HIGH", "LOW", "HIGH HIGH", "LOW LOW", "H", "L", "HH", "LL"}
            )
        ]

        pop_subjs = set(adsl["USUBJID"].dropna()) if adsl is not None else None
        if pop_subjs:
            ae2 = ae2[ae2["USUBJID"].isin(pop_subjs)]
            abn_lb = abn_lb[abn_lb["USUBJID"].isin(pop_subjs)]

        n_total = len(adsl) if adsl is not None else ae2["USUBJID"].nunique()

        # Cross-join AE x abnormal LB per subject and check temporal proximity
        rows = []
        common_sids = set(ae2["USUBJID"].dropna()) & set(abn_lb["USUBJID"].dropna())
        for sid in common_sids:
            ae_sid = ae2[ae2["USUBJID"] == sid].dropna(subset=["AESTDTC"])
            lb_sid = abn_lb[abn_lb["USUBJID"] == sid].dropna(subset=["LBDTC"])
            if ae_sid.empty or lb_sid.empty:
                continue
            for _, ae_row in ae_sid.iterrows():
                ae_date = ae_row["AESTDTC"]
                pt = str(ae_row.get(pt_col, ""))
                for _, lb_row in lb_sid.iterrows():
                    lb_date = lb_row["LBDTC"]
                    delta   = abs((ae_date - lb_date).days)
                    if delta <= window_days:
                        rows.append({
                            "USUBJID": sid,
                            "AE_Term":   pt,
                            "Lab_Test":  str(lb_row.get("LBTESTCD", "")),
                            "Direction": str(lb_row.get(nrind_col, "")),
                            "Delta_Days": delta,
                        })

        if not rows:
            return pd.DataFrame()

        df = pd.DataFrame(rows)
        summary = (
            df.groupby(["AE_Term", "Lab_Test", "Direction"])["USUBJID"]
            .nunique()
            .reset_index()
            .rename(columns={"USUBJID": "N_Subjects"})
        )
        summary = summary[summary["N_Subjects"] >= min_subjects]
        summary["Pct_Subjects"] = (summary["N_Subjects"] / n_total * 100).round(1)
        return summary.sort_values("N_Subjects", ascending=False).reset_index(drop=True)
    except Exception as exc:
        logger.warning("Temporal AE-Lab co-occurrence failed: %s", exc)
        return pd.DataFrame()


# ---------------------------------------------------------------------------
# 3. Subject similarity network
# ---------------------------------------------------------------------------
def build_subject_similarity_network(
    X: pd.DataFrame,
    adsl: pd.DataFrame,
    trt_col: str,
    top_k: int = 5,
    similarity_threshold: float = 0.7,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Compute pairwise cosine similarity between subjects.

    Returns:
        edge_df    : DataFrame with (Subject_A, Subject_B, Similarity)
        degree_df  : DataFrame with subject degree centrality in similarity network
    """
    if X is None or X.empty:
        return pd.DataFrame(), pd.DataFrame()

    try:
        from sklearn.metrics.pairwise import cosine_similarity
        X_filled = X.fillna(0.0)
        sim_matrix = cosine_similarity(X_filled)
        subjects   = X_filled.index.tolist()
        n          = len(subjects)

        edges = []
        for i in range(n):
            for j in range(i + 1, n):
                sim = float(sim_matrix[i, j])
                if sim >= similarity_threshold:
                    edges.append({
                        "Subject_A":   subjects[i],
                        "Subject_B":   subjects[j],
                        "Similarity":  round(sim, 3),
                    })

        edge_df = pd.DataFrame(edges)
        if not edge_df.empty and "Similarity" in edge_df.columns:
            edge_df = edge_df.sort_values("Similarity", ascending=False)

        # Degree centrality
        if not edge_df.empty:
            degree: Dict[str, int] = {sid: 0 for sid in subjects}
            for _, row in edge_df.iterrows():
                degree[row["Subject_A"]] = degree.get(row["Subject_A"], 0) + 1
                degree[row["Subject_B"]] = degree.get(row["Subject_B"], 0) + 1
            degree_df = pd.DataFrame([
                {"USUBJID": sid, "Degree": deg}
                for sid, deg in degree.items()
                if deg > 0
            ]).sort_values("Degree", ascending=False)
            if adsl is not None and trt_col in adsl.columns:
                degree_df = degree_df.merge(
                    adsl[["USUBJID", trt_col]].drop_duplicates(),
                    on="USUBJID", how="left",
                )
        else:
            degree_df = pd.DataFrame()

        return edge_df, degree_df
    except Exception as exc:
        logger.warning("Subject similarity network failed: %s", exc)
        return pd.DataFrame(), pd.DataFrame()
