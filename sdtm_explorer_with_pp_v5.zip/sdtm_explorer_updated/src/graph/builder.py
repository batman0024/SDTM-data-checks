# =============================================================================
# src/graph/builder.py  -  SDTM Inter-Domain Knowledge Graph (NetworkX)
# =============================================================================
# Builds a heterogeneous graph where:
#   Node types: Subject, AE_Term, Lab_Test, Drug, Visit, SOC, Response
#   Edge types: HAS_AE, RECEIVED_DRUG, HAD_LAB, AT_VISIT, BELONGS_TO_SOC,
#               HAD_RESPONSE, HAS_SAE, RELATED_AE, CONCOM_MED
# =============================================================================

import pandas as pd
import numpy as np
import logging
from typing import Dict, Optional, List, Tuple, Any

try:
    import networkx as nx
    HAS_NX = True
except ImportError:
    HAS_NX = False

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Node type constants
# ---------------------------------------------------------------------------
NT_SUBJECT  = "subject"
NT_AE_TERM  = "ae_term"
NT_SOC      = "soc"
NT_DRUG     = "drug"
NT_VISIT    = "visit"
NT_LAB_TEST = "lab_test"
NT_RESPONSE = "response"
NT_CM_DRUG  = "cm_drug"
NT_MH_COND  = "mh_condition"

# Edge type constants
ET_HAS_AE         = "HAS_AE"
ET_HAS_SAE        = "HAS_SAE"
ET_RELATED_AE     = "RELATED_AE"
ET_RECEIVED_DRUG  = "RECEIVED_DRUG"
ET_HAD_LAB        = "HAD_LAB"
ET_AT_VISIT       = "AT_VISIT"
ET_BELONGS_SOC    = "BELONGS_TO_SOC"
ET_HAD_RESPONSE   = "HAD_RESPONSE"
ET_CONCOM_MED     = "CONCOM_MED"
ET_MED_HISTORY    = "MED_HISTORY"
ET_SAME_ARM       = "SAME_ARM"


class SDTMGraphBuilder:
    """Build a NetworkX MultiDiGraph from loaded SDTM domains."""

    def __init__(self, max_subjects: int = 500):
        self.max_subjects = max_subjects
        self.G = None

    # -------------------------------------------------------------------------
    def build(
        self,
        domains: Dict[str, pd.DataFrame],
        adsl: Optional[pd.DataFrame] = None,
        subjects: Optional[List[str]] = None,
    ):
        if not HAS_NX:
            logger.warning("networkx not installed; graph features disabled")
            return None

        self.G = nx.MultiDiGraph()
        dm = domains.get("dm")
        ae = domains.get("ae")
        ex = domains.get("ex")
        lb = domains.get("lb")
        cm = domains.get("cm")
        mh = domains.get("mh")
        rs = domains.get("rs")

        # Limit subjects for performance
        all_subjs = self._get_subjects(adsl if adsl is not None else dm)
        if subjects:
            subjs = [s for s in subjects if s in all_subjs]
        else:
            subjs = all_subjs[: self.max_subjects]

        logger.info("Building graph for %d subjects", len(subjs))

        self._add_subject_nodes(adsl if adsl is not None else dm, subjs)
        if ae is not None:
            self._add_ae_edges(ae, subjs)
        if ex is not None:
            self._add_drug_edges(ex, subjs)
        if lb is not None:
            self._add_lab_edges(lb, subjs)
        if cm is not None:
            self._add_cm_edges(cm, subjs)
        if mh is not None:
            self._add_mh_edges(mh, subjs)
        if rs is not None:
            self._add_response_edges(rs, subjs)

        self._add_same_arm_edges(adsl if adsl is not None else dm, subjs)

        logger.info(
            "Graph built: %d nodes, %d edges",
            self.G.number_of_nodes(),
            self.G.number_of_edges(),
        )
        return self.G

    # -------------------------------------------------------------------------
    def _get_subjects(self, df: Optional[pd.DataFrame]) -> List[str]:
        if df is None or df.empty:
            return []
        if "USUBJID" not in df.columns:
            return []
        return df["USUBJID"].dropna().unique().tolist()

    def _subj_id(self, usubjid: str) -> str:
        return f"subj::{usubjid}"

    def _ae_id(self, term: str) -> str:
        return f"ae::{term}"

    def _soc_id(self, soc: str) -> str:
        return f"soc::{soc}"

    def _drug_id(self, drug: str) -> str:
        return f"drug::{drug}"

    def _lab_id(self, test: str) -> str:
        return f"lab::{test}"

    def _resp_id(self, resp: str) -> str:
        return f"resp::{resp}"

    def _cm_id(self, drug: str) -> str:
        return f"cm::{drug}"

    def _mh_id(self, cond: str) -> str:
        return f"mh::{cond}"

    # -------------------------------------------------------------------------
    def _add_subject_nodes(
        self, df: Optional[pd.DataFrame], subjs: List[str]
    ):
        if df is None:
            return
        sub = df[df["USUBJID"].isin(subjs)] if "USUBJID" in df.columns else df
        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            if not sid:
                continue
            attrs = {
                "node_type": NT_SUBJECT,
                "label": sid,
                "age": row.get("AGE", np.nan),
                "sex": str(row.get("SEX", "")),
                "race": str(row.get("RACE", "")),
                "arm": str(row.get("TRT01A", row.get("ARM", ""))),
                "saffl": str(row.get("SAFFL", "")),
                "ittfl": str(row.get("ITTFL", "")),
                "trtdurd": row.get("TRTDURD", np.nan),
            }
            self.G.add_node(self._subj_id(sid), **attrs)

    def _add_ae_edges(self, ae: pd.DataFrame, subjs: List[str]):
        sub = ae[ae["USUBJID"].isin(subjs)] if "USUBJID" in ae.columns else ae
        pt_col = "AEDECOD" if "AEDECOD" in ae.columns else "AETERM"
        soc_col = "AEBODSYS" if "AEBODSYS" in ae.columns else None

        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            pt  = str(row.get(pt_col, "Unknown"))
            if not sid or not pt or pt == "nan":
                continue

            # Add AE term node
            ae_node = self._ae_id(pt)
            if ae_node not in self.G:
                soc = str(row.get(soc_col, "")) if soc_col else ""
                self.G.add_node(ae_node, node_type=NT_AE_TERM, label=pt, soc=soc)

            # Subject -> AE edge
            is_sae = str(row.get("AESER", "N")).upper() in {"Y", "YES", "1"}
            is_rel = str(row.get("AEREL", "")).upper() in {
                "RELATED", "PROBABLE", "POSSIBLY RELATED",
                "PROBABLY RELATED", "DEFINITE",
            }
            grade = str(row.get("AETOXGR", row.get("AESEV", "")))

            edge_type = ET_HAS_SAE if is_sae else ET_HAS_AE
            self.G.add_edge(
                self._subj_id(sid),
                ae_node,
                rel=edge_type,
                aeser=is_sae,
                aerel=is_rel,
                grade=grade,
                aestdtc=str(row.get("AESTDTC", "")),
            )

            # AE term -> SOC hierarchy
            if soc_col and row.get(soc_col):
                soc = str(row[soc_col])
                soc_node = self._soc_id(soc)
                if soc_node not in self.G:
                    self.G.add_node(soc_node, node_type=NT_SOC, label=soc)
                if not self.G.has_edge(ae_node, soc_node):
                    self.G.add_edge(ae_node, soc_node, rel=ET_BELONGS_SOC)

    def _add_drug_edges(self, ex: pd.DataFrame, subjs: List[str]):
        sub = ex[ex["USUBJID"].isin(subjs)] if "USUBJID" in ex.columns else ex
        drug_col = "EXTRT" if "EXTRT" in ex.columns else None
        if drug_col is None:
            return

        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            drug = str(row.get(drug_col, ""))
            if not sid or not drug or drug == "nan":
                continue
            d_node = self._drug_id(drug)
            if d_node not in self.G:
                self.G.add_node(d_node, node_type=NT_DRUG, label=drug)
            self.G.add_edge(
                self._subj_id(sid),
                d_node,
                rel=ET_RECEIVED_DRUG,
                dose=row.get("EXDOSE", np.nan),
                start=str(row.get("EXSTDTC", "")),
                end=str(row.get("EXENDTC", "")),
            )

    def _add_lab_edges(self, lb: pd.DataFrame, subjs: List[str]):
        if "LBTESTCD" not in lb.columns:
            return
        sub = lb[lb["USUBJID"].isin(subjs)] if "USUBJID" in lb.columns else lb
        # Only keep abnormal labs to reduce graph size
        if "LBNRIND" in sub.columns:
            sub = sub[sub["LBNRIND"].notna() & (sub["LBNRIND"] != "NORMAL")]
        # Limit to most recent 3 records per subject per test
        if "LBDTC" in sub.columns:
            sub = (
                sub.sort_values("LBDTC", ascending=False)
                .groupby(["USUBJID", "LBTESTCD"])
                .head(3)
            )
        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            test = str(row.get("LBTESTCD", ""))
            if not sid or not test:
                continue
            lab_node = self._lab_id(test)
            if lab_node not in self.G:
                self.G.add_node(lab_node, node_type=NT_LAB_TEST, label=test)
            self.G.add_edge(
                self._subj_id(sid),
                lab_node,
                rel=ET_HAD_LAB,
                value=row.get("LBSTRESN", np.nan),
                nrind=str(row.get("LBNRIND", "")),
                visit=str(row.get("VISIT", "")),
            )

    def _add_cm_edges(self, cm: pd.DataFrame, subjs: List[str]):
        drug_col = "CMDECOD" if "CMDECOD" in cm.columns else (
            "CMTRT" if "CMTRT" in cm.columns else None
        )
        if drug_col is None:
            return
        sub = cm[cm["USUBJID"].isin(subjs)] if "USUBJID" in cm.columns else cm
        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            drug = str(row.get(drug_col, ""))
            if not sid or not drug or drug == "nan":
                continue
            cm_node = self._cm_id(drug)
            if cm_node not in self.G:
                self.G.add_node(cm_node, node_type=NT_CM_DRUG, label=drug)
            self.G.add_edge(self._subj_id(sid), cm_node, rel=ET_CONCOM_MED)

    def _add_mh_edges(self, mh: pd.DataFrame, subjs: List[str]):
        cond_col = "MHDECOD" if "MHDECOD" in mh.columns else (
            "MHTERM" if "MHTERM" in mh.columns else None
        )
        if cond_col is None:
            return
        sub = mh[mh["USUBJID"].isin(subjs)] if "USUBJID" in mh.columns else mh
        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            cond = str(row.get(cond_col, ""))
            if not sid or not cond or cond == "nan":
                continue
            mh_node = self._mh_id(cond)
            if mh_node not in self.G:
                self.G.add_node(mh_node, node_type=NT_MH_COND, label=cond)
            self.G.add_edge(self._subj_id(sid), mh_node, rel=ET_MED_HISTORY)

    def _add_response_edges(self, rs: pd.DataFrame, subjs: List[str]):
        if "RSSTRESC" not in rs.columns:
            return
        sub = rs[rs["USUBJID"].isin(subjs)] if "USUBJID" in rs.columns else rs
        for _, row in sub.iterrows():
            sid = str(row.get("USUBJID", ""))
            resp = str(row.get("RSSTRESC", ""))
            if not sid or not resp or resp == "nan":
                continue
            r_node = self._resp_id(resp)
            if r_node not in self.G:
                self.G.add_node(r_node, node_type=NT_RESPONSE, label=resp)
            self.G.add_edge(
                self._subj_id(sid),
                r_node,
                rel=ET_HAD_RESPONSE,
                visit=str(row.get("VISIT", "")),
            )

    def _add_same_arm_edges(
        self, df: Optional[pd.DataFrame], subjs: List[str]
    ):
        """Add lightweight SAME_ARM edges to allow arm-level community detection."""
        if df is None or "USUBJID" not in df.columns:
            return
        arm_col = next(
            (c for c in ["TRT01A", "ACTARM", "ARM"] if c in df.columns), None
        )
        if arm_col is None:
            return
        sub = df[df["USUBJID"].isin(subjs)][[arm_col, "USUBJID"]].dropna()
        arm_groups = sub.groupby(arm_col)["USUBJID"].apply(list)
        for arm, sids in arm_groups.items():
            # Only add edges between first pair in each arm (keeps graph sparse)
            for i in range(min(len(sids) - 1, 50)):
                s1 = self._subj_id(str(sids[i]))
                s2 = self._subj_id(str(sids[i + 1]))
                if s1 in self.G and s2 in self.G:
                    self.G.add_edge(s1, s2, rel=ET_SAME_ARM, arm=str(arm))


# ---------------------------------------------------------------------------
# Graph analytics helpers
# ---------------------------------------------------------------------------
class GraphAnalytics:
    """Query and analyse the SDTM knowledge graph."""

    def __init__(self, G):
        self.G = G

    def get_subject_neighbourhood(
        self, usubjid: str, depth: int = 2
    ):
        """Return ego-graph centred on a subject."""
        if not HAS_NX or self.G is None:
            return None
        node = f"subj::{usubjid}"
        if node not in self.G:
            return None
        return nx.ego_graph(self.G, node, radius=depth)

    def get_ae_cooccurrence(self, min_subjects: int = 2) -> pd.DataFrame:
        """
        Which AE terms co-occur in the same subjects?
        Returns edge list with weight = # subjects sharing both AEs.
        """
        if not HAS_NX or self.G is None:
            return pd.DataFrame()
        subj_aes: Dict[str, set] = {}
        for u, v, data in self.G.edges(data=True):
            if data.get("rel") in (ET_HAS_AE, ET_HAS_SAE):
                sid = u.replace("subj::", "")
                ae_term = v.replace("ae::", "")
                subj_aes.setdefault(sid, set()).add(ae_term)

        from itertools import combinations
        counts: Dict[Tuple[str, str], int] = {}
        for sid, aes in subj_aes.items():
            for a, b in combinations(sorted(aes), 2):
                key = (a, b)
                counts[key] = counts.get(key, 0) + 1

        rows = [
            {"AE_1": k[0], "AE_2": k[1], "Subjects": v}
            for k, v in counts.items()
            if v >= min_subjects
        ]
        if not rows:
            return pd.DataFrame()
        return (
            pd.DataFrame(rows)
            .sort_values("Subjects", ascending=False)
            .reset_index(drop=True)
        )

    def get_drug_ae_association(self) -> pd.DataFrame:
        """Which drugs are associated with which AE terms (via shared subjects)?"""
        if not HAS_NX or self.G is None:
            return pd.DataFrame()
        subj_drugs: Dict[str, set] = {}
        subj_aes: Dict[str, set] = {}
        for u, v, data in self.G.edges(data=True):
            rel = data.get("rel", "")
            if rel == ET_RECEIVED_DRUG:
                sid = u.replace("subj::", "")
                subj_drugs.setdefault(sid, set()).add(v.replace("drug::", ""))
            elif rel in (ET_HAS_AE, ET_HAS_SAE):
                sid = u.replace("subj::", "")
                subj_aes.setdefault(sid, set()).add(v.replace("ae::", ""))

        rows = []
        for sid in set(subj_drugs) & set(subj_aes):
            for drug in subj_drugs[sid]:
                for ae in subj_aes[sid]:
                    rows.append({"Drug": drug, "AE_Term": ae, "USUBJID": sid})
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        return (
            df.groupby(["Drug", "AE_Term"])["USUBJID"]
            .nunique()
            .reset_index()
            .rename(columns={"USUBJID": "N_Subjects"})
            .sort_values("N_Subjects", ascending=False)
        )

    def get_node_centrality(self) -> pd.DataFrame:
        """Degree centrality for all non-subject nodes (AE terms, drugs, etc.)."""
        if not HAS_NX or self.G is None:
            return pd.DataFrame()
        G_und = self.G.to_undirected()
        dc = nx.degree_centrality(G_und)
        rows = []
        for node, cent in dc.items():
            nd = self.G.nodes.get(node, {})
            ntype = nd.get("node_type", "unknown")
            if ntype == NT_SUBJECT:
                continue
            rows.append({
                "Node": nd.get("label", node),
                "Type": ntype,
                "Degree": G_und.degree(node),
                "Centrality": round(cent, 4),
            })
        if not rows:
            return pd.DataFrame()
        return (
            pd.DataFrame(rows)
            .sort_values("Degree", ascending=False)
            .head(50)
            .reset_index(drop=True)
        )

    def get_community_detection(self) -> Dict[str, int]:
        """
        Louvain community detection on undirected projection.
        Returns {node_id: community_id}.
        """
        if not HAS_NX or self.G is None:
            return {}
        try:
            import community as community_louvain
            G_und = self.G.to_undirected()
            return community_louvain.best_partition(G_und)
        except ImportError:
            pass
        # Fallback: connected component labels
        G_und = self.G.to_undirected()
        result = {}
        for i, comp in enumerate(nx.connected_components(G_und)):
            for node in comp:
                result[node] = i
        return result

    def query_subjects_with_ae(
        self, ae_term: str, related_only: bool = False
    ) -> List[str]:
        """Return USUBJID list of subjects who had the given AE term."""
        if not HAS_NX or self.G is None:
            return []
        ae_node = f"ae::{ae_term}"
        if ae_node not in self.G:
            return []
        subjects = []
        for pred, _, data in self.G.in_edges(ae_node, data=True):
            if related_only and not data.get("aerel", False):
                continue
            if pred.startswith("subj::"):
                subjects.append(pred.replace("subj::", ""))
        return subjects

    def get_graph_summary(self) -> Dict[str, Any]:
        if not HAS_NX or self.G is None:
            return {}
        node_types: Dict[str, int] = {}
        for _, data in self.G.nodes(data=True):
            nt = data.get("node_type", "unknown")
            node_types[nt] = node_types.get(nt, 0) + 1
        edge_types: Dict[str, int] = {}
        for _, _, data in self.G.edges(data=True):
            et = data.get("rel", "unknown")
            edge_types[et] = edge_types.get(et, 0) + 1
        return {
            "total_nodes": self.G.number_of_nodes(),
            "total_edges": self.G.number_of_edges(),
            "node_types": node_types,
            "edge_types": edge_types,
            "density": round(nx.density(self.G), 6),
        }
