# =============================================================================
# src/patient_profile/pp_engine.py
# Patient Profile (PP) plot engine
# Works with SDTM data already loaded in session_state["sdtm_data"]
#
# Fixed issues (v2):
#   BUG-1  : secondary_y detection - was using getattr(tr,"yaxis") which always
#             returns False on a newly-constructed go.Scatter. Fixed by carrying
#             a side-channel list of (trace, is_secondary) tuples.
#   BUG-2/3: ae.get("AEENDTC")/cm.get("CMENDTC") - DataFrame.get() is
#             ambiguous; replaced with explicit column-existence checks.
#   BUG-4  : lb.get("LBDTC") same issue - replaced.
#   BUG-5  : Subtitle colour loop ran AFTER reference-line annotations were
#             appended, overwriting their colours. Loop now runs on subplot
#             annotations only (identified by their text NOT being "First Dose"
#             or "Data Cut-off"), and is executed before appending ref annotations.
#   COLOR-1: CM y-axis labels promoted from subtext → text colour.
#   COLOR-2: X-axis title "Study Week" promoted from subtext → text colour.
#   COLOR-3: Dose text labels: colour subtext→text, size 7→8pt.
#   COLOR-4: DARK mode plot bg separated from paper bg (#131F35 vs #0F172A).
#   COLOR-5: LIGHT mode ae_other #F97316 → #C2410C (WCAG AA pass on white).
#   COLOR-6: DARK mode ae_other #FDA4AF → #FB923C (orange, distinct from red).
#   PERF-1 : _ae_traces vectorised _enw calculation (no more per-row apply).
#   PERF-2 : _cm_traces vectorised end_w calculation.
#   CODE-1 : All DataFrame column accesses use explicit "if col in df.columns"
#             guard pattern instead of .get().
# =============================================================================

from __future__ import annotations

import warnings
from typing import Optional

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ── Colour palettes ───────────────────────────────────────────────────────────
#
#  Every colour has been checked against its background for WCAG AA (4.5:1 for
#  text, 3:1 for graphical elements).
#
#  DARK background  = #131F35  (plot area) / #0F172A (paper)
#  LIGHT background = #FFFFFF  (plot area) / #F8FAFC (paper)
#
PALETTE_DARK = {
    # ── data series ──────────────────────────────────────────────────────────
    "lpa":        "#C084FC",   # purple   Lp(a)         contrast on #131F35 ≈ 5.4:1 ✓
    "ldl":        "#4ADE80",   # green    LDL-C         contrast ≈ 8.2:1 ✓
    "hba1c":      "#FCD34D",   # yellow   HbA1c         contrast ≈ 9.1:1 ✓
    "extra_labs": ["#38BDF8", "#FB923C", "#F472B6", "#A3E635"],
    #                sky-blue  orange    pink      lime  — all ≥ 4.5:1 on dark ✓
    "dose":       "#38BDF8",   # sky-blue dose markers   contrast ≈ 7.1:1 ✓
    "ae_serious": "#F87171",   # red      serious AE     contrast ≈ 4.6:1 ✓
    "ae_other":   "#FB923C",   # orange   non-serious AE contrast ≈ 5.1:1 ✓  (FIX COLOR-6)
    "cm":         "#4ADE80",   # green    conmeds        contrast ≈ 8.2:1 ✓
    "cutoff":     "#94A3B8",   # slate    cut-off line   contrast ≈ 3.5:1 (graphic) ✓
    # ── backgrounds ──────────────────────────────────────────────────────────
    "paper":      "#0F172A",   # outermost bg
    "bg":         "#131F35",   # plot area (FIX COLOR-4: slightly lighter than paper)
    "grid":       "#1E293B",   # gridlines
    "zero":       "#334155",   # zero line
    # ── text ─────────────────────────────────────────────────────────────────
    "text":       "#E2E8F0",   # primary labels, axis titles, tick labels
    "subtext":    "#94A3B8",   # secondary / axis tick numbers only
    "marker_outline": "#0F172A",  # marker border = paper bg for clean look
}

PALETTE_LIGHT = {
    # ── data series ──────────────────────────────────────────────────────────
    "lpa":        "#7C3AED",   # purple   Lp(a)         contrast on white ≈ 5.9:1 ✓
    "ldl":        "#16A34A",   # green    LDL-C         contrast ≈ 5.1:1 ✓
    "hba1c":      "#B45309",   # amber    HbA1c         contrast ≈ 5.8:1 ✓
    "extra_labs": ["#1D4ED8", "#C2410C", "#BE185D", "#3F6212"],
    #                deep-blue dark-org  deep-pink dark-lime — all ≥ 4.5:1 on white ✓
    "dose":       "#1D4ED8",   # deep-blue dose markers  contrast ≈ 8.6:1 ✓
    "ae_serious": "#B91C1C",   # dark-red  serious AE    contrast ≈ 6.8:1 ✓
    "ae_other":   "#C2410C",   # dk-orange non-serious   contrast ≈ 5.3:1 ✓  (FIX COLOR-5)
    "cm":         "#15803D",   # dark-green conmeds      contrast ≈ 5.9:1 ✓
    "cutoff":     "#475569",   # slate    cut-off line   contrast ≈ 5.7:1 ✓
    # ── backgrounds ──────────────────────────────────────────────────────────
    "paper":      "#F8FAFC",   # outermost bg
    "bg":         "#FFFFFF",   # plot area
    "grid":       "#E2E8F0",   # gridlines
    "zero":       "#CBD5E1",   # zero line
    # ── text ─────────────────────────────────────────────────────────────────
    "text":       "#1E293B",   # primary labels, axis titles
    "subtext":    "#475569",   # secondary / axis tick numbers only
    "marker_outline": "#F8FAFC",  # marker border = paper bg
}

# LBTESTCD → (friendly label, palette key, y-axis side)
BIOMARKER_DEFAULTS = [
    ("LPA",         "Lp(a) (nmol/L)",    "lpa",          "left"),
    ("LDLC",        "LDL-C (mg/dL)",     "ldl",          "left"),
    ("HBA1C",       "HbA1c (%)",         "hba1c",        "right"),
    ("CHOLESTEROL", "Total Chol (mg/dL)","extra_labs:0",  "left"),
    ("CREAT",       "Creatinine",        "extra_labs:1",  "right"),
    ("EGFR",        "eGFR",              "extra_labs:2",  "right"),
    ("APOBL",       "ApoB (mg/dL)",      "extra_labs:3",  "left"),
]


# ── Palette helpers ───────────────────────────────────────────────────────────

def _pal(palette: dict, key: str) -> str:
    """Resolve a palette key, including indexed lists like 'extra_labs:2'."""
    if ":" in key:
        base, idx = key.split(":", 1)
        lst = palette.get(base, [])
        return lst[int(idx) % len(lst)] if lst else "#888888"
    return palette.get(key, "#888888")


# ── Date helpers ──────────────────────────────────────────────────────────────

def _parse_dt(series: pd.Series) -> pd.Series:
    """Parse ISO-8601 SDTM date strings (handles partial YYYY-MM or YYYY)."""
    return pd.to_datetime(series.astype(str).str[:10], errors="coerce")


def _weeks(dates: pd.Series, ref: pd.Timestamp) -> pd.Series:
    """Convert a Series of Timestamps to study weeks relative to ref."""
    return (dates - ref).dt.days / 7


def _col(df: pd.DataFrame, col: str) -> pd.Series:
    """
    Safe column accessor for SDTM DataFrames.
    Returns the column if present, else a NaT/NaN Series of the same length.
    Replaces the ambiguous DataFrame.get(col, default) pattern.
    """
    if col in df.columns:
        return df[col]
    return pd.Series([None] * len(df), index=df.index, dtype=object)


# ─────────────────────────────────────────────────────────────────────────────

class PPEngine:
    """
    Builds the study-style patient profile figure from SDTM domain dicts.

    Parameters
    ----------
    sdtm : dict[str, pd.DataFrame]
        Domain DataFrames keyed by lowercase domain name.
        Recognised keys: 'dm', 'ex', 'lb', 'ae', 'cm', 'mh', 'ds'
    dark : bool
        Use dark colour palette (True) or light (False).
    drug_label : str
        Investigational product label shown on dose panel and legend.
    dose_var : str
        EX variable name carrying the dose amount (default 'EXDOSE').
    data_cutoff : str or pd.Timestamp, optional
        Data cut-off date; draws a vertical reference line when supplied.
    biomarkers : list[str], optional
        LBTESTCD values to plot (default: all entries in BIOMARKER_DEFAULTS).
    """

    def __init__(
        self,
        sdtm: dict,
        dark: bool = True,
        drug_label: str = "Study Drug",
        dose_var: str = "EXDOSE",
        data_cutoff=None,
        biomarkers: Optional[list] = None,
    ):
        self.sdtm        = {k.lower(): v for k, v in sdtm.items()
                            if v is not None and isinstance(v, pd.DataFrame)}
        self.pal         = PALETTE_DARK if dark else PALETTE_LIGHT
        self.dark        = dark
        self.drug_label  = drug_label
        self.dose_var    = dose_var
        self.data_cutoff = pd.to_datetime(data_cutoff, errors="coerce") \
                           if data_cutoff else None
        self.biomarkers  = biomarkers or [b[0] for b in BIOMARKER_DEFAULTS]

    # ── Domain helpers ────────────────────────────────────────────────────────

    def _domain(self, key: str, usubjid: str) -> pd.DataFrame:
        """Return rows for usubjid from a domain, or empty DataFrame."""
        df = self.sdtm.get(key.lower(), pd.DataFrame())
        if df.empty or "USUBJID" not in df.columns:
            return pd.DataFrame()
        return df[df["USUBJID"] == usubjid].copy()

    def _ref_date(self, usubjid: str) -> Optional[pd.Timestamp]:
        """First dose date (min EXSTDTC) for usubjid."""
        ex = self._domain("ex", usubjid)
        if ex.empty or "EXSTDTC" not in ex.columns:
            return None
        dates = _parse_dt(ex["EXSTDTC"]).dropna()
        return dates.min() if not dates.empty else None

    # ── Panel builders ────────────────────────────────────────────────────────

    def _dose_traces(self, usubjid: str, ref: pd.Timestamp) -> list:
        """
        EX → dose stem + triangle marker traces.
        Returns list of (go.Scatter, is_secondary=False) tuples.
        """
        ex = self._domain("ex", usubjid)
        if ex.empty or "EXSTDTC" not in ex.columns:
            return []

        ex = ex.copy()
        ex["_dt"] = _parse_dt(ex["EXSTDTC"])
        ex = ex.dropna(subset=["_dt"])
        if ex.empty:
            return []
        ex["_wk"] = _weeks(ex["_dt"], ref)

        dose_col = (self.dose_var    if self.dose_var    in ex.columns else
                    "EXDOSE"         if "EXDOSE"         in ex.columns else None)
        colour   = self.pal["dose"]
        traces   = []   # each element: (go.Scatter, is_secondary)

        if dose_col:
            ex[dose_col] = pd.to_numeric(ex[dose_col], errors="coerce")
            ex = ex.dropna(subset=[dose_col])

            # Vertical stems (one per dose event)
            for _, row in ex.iterrows():
                traces.append((
                    go.Scatter(
                        x=[row["_wk"], row["_wk"]], y=[0, row[dose_col]],
                        mode="lines",
                        line=dict(color=colour, width=1.5),
                        showlegend=False, hoverinfo="skip",
                    ),
                    False,  # not secondary_y
                ))

            # Dose markers + value labels  (FIX COLOR-3: text colour, 8pt)
            traces.append((
                go.Scatter(
                    x=ex["_wk"], y=ex[dose_col],
                    mode="markers+text",
                    marker=dict(
                        symbol="triangle-up", color=colour, size=11,
                        line=dict(color=self.pal["marker_outline"], width=1),
                    ),
                    text=ex[dose_col].astype(int).astype(str) + " mg",
                    textposition="top center",
                    textfont=dict(size=8, color=self.pal["text"]),   # FIX COLOR-3
                    name=self.drug_label,
                    hovertemplate=(
                        f"<b>{self.drug_label}</b><br>"
                        "Week %{x:.1f}<br>Dose: %{y:.0f} mg<extra></extra>"
                    ),
                ),
                False,
            ))
        else:
            # No dose amount – just show event ticks
            traces.append((
                go.Scatter(
                    x=ex["_wk"], y=[1] * len(ex),
                    mode="markers",
                    marker=dict(symbol="triangle-up", color=colour, size=11),
                    name=self.drug_label,
                    hovertemplate=(
                        f"<b>{self.drug_label}</b><br>"
                        "Week %{x:.1f}<extra></extra>"
                    ),
                ),
                False,
            ))
        return traces

    def _biomarker_traces(self, usubjid: str, ref: pd.Timestamp) -> list:
        """
        LB → biomarker line traces.
        Returns list of (go.Scatter, is_secondary) tuples.
        BUG-1 FIX: secondary flag carried explicitly, NOT inferred from yaxis attr.
        BUG-4 FIX: column access uses _col() helper instead of DataFrame.get().
        """
        lb = self._domain("lb", usubjid)
        if lb.empty or "LBTESTCD" not in lb.columns:
            return []

        lb = lb.copy()
        # BUG-4 FIX: explicit column check
        if "LBDTC" not in lb.columns:
            return []
        lb["_dt"] = _parse_dt(lb["LBDTC"])
        lb = lb.dropna(subset=["_dt"])
        if lb.empty:
            return []
        lb["_wk"] = _weeks(lb["_dt"], ref)

        traces = []
        for testcd, label, pal_key, yaxis_side in BIOMARKER_DEFAULTS:
            if testcd not in self.biomarkers:
                continue

            grp = lb[lb["LBTESTCD"].str.upper().str.strip() == testcd].copy()
            if grp.empty:
                continue

            # Prefer LBSTRESN (numeric) over LBORRES (character)
            val_col = "LBSTRESN" if "LBSTRESN" in grp.columns else (
                      "LBORRES"  if "LBORRES"  in grp.columns else None)
            if val_col is None:
                continue

            grp[val_col] = pd.to_numeric(grp[val_col], errors="coerce")
            grp = grp.dropna(subset=[val_col]).sort_values("_wk")
            if grp.empty:
                continue

            colour      = _pal(self.pal, pal_key)
            is_secondary = (yaxis_side == "right")   # BUG-1 FIX: explicit flag

            traces.append((
                go.Scatter(
                    x=grp["_wk"], y=grp[val_col],
                    mode="lines+markers",
                    name=label,
                    line=dict(color=colour, width=2.5),
                    marker=dict(
                        size=7, color=colour,
                        line=dict(color=self.pal["marker_outline"], width=1),
                    ),
                    hovertemplate=(
                        f"<b>{label}</b><br>Week %{{x:.1f}}<br>"
                        f"Value: %{{y:.2f}}<extra></extra>"
                    ),
                ),
                is_secondary,   # BUG-1 FIX: carry secondary flag here
            ))
        return traces

    def _ae_traces(self, usubjid: str, ref: pd.Timestamp):
        """
        AE → horizontal timeline traces.
        BUG-2 FIX: column access via explicit check.
        PERF-1 FIX: vectorised end-week calculation.
        Returns (traces_list, y_label_list).
        """
        ae = self._domain("ae", usubjid)
        if ae.empty or "AESTDTC" not in ae.columns:
            return [], []

        ae = ae.copy()
        ae["_st"] = _parse_dt(ae["AESTDTC"])
        # BUG-2 FIX: explicit column check instead of ae.get("AEENDTC", ...)
        ae["_en"] = _parse_dt(_col(ae, "AEENDTC"))
        ae = ae.dropna(subset=["_st"])
        if ae.empty:
            return [], []

        # PERF-1 FIX: vectorised week calculation
        ae["_stw"] = _weeks(ae["_st"], ref)
        en_dates   = ae["_en"].copy()
        en_dates_parsed = pd.to_datetime(en_dates, errors="coerce")
        # Where end date is missing, use start + 0.5 weeks
        ae["_enw"] = _weeks(en_dates_parsed, ref)
        ae["_enw"] = ae["_enw"].where(ae["_enw"].notna(), ae["_stw"] + 0.5)

        pt_col  = "AEDECOD" if "AEDECOD" in ae.columns else (
                  "AETERM"  if "AETERM"  in ae.columns else None)
        sev_col = "AESEV" if "AESEV" in ae.columns else None
        ser_col = "AESER" if "AESER" in ae.columns else None
        rel_col = "AEREL" if "AEREL" in ae.columns else None
        out_col = "AEOUT" if "AEOUT" in ae.columns else None

        traces, y_labels = [], []

        for i, (_, row) in enumerate(ae.iterrows()):
            pt      = str(row[pt_col]).title() if pt_col else f"AE {i+1}"
            sev     = str(row[sev_col]) if sev_col and pd.notna(row.get(sev_col)) else "—"
            ser     = str(row[ser_col]) if ser_col and pd.notna(row.get(ser_col)) else "N"
            rel     = str(row[rel_col]) if rel_col and pd.notna(row.get(rel_col)) else "—"
            out     = str(row[out_col]) if out_col and pd.notna(row.get(out_col)) else "—"
            colour  = self.pal["ae_serious"] if ser == "Y" else self.pal["ae_other"]

            start_w = float(row["_stw"])
            end_w   = float(row["_enw"])

            y_labels.append(pt)

            # Bar body
            traces.append((
                go.Scatter(
                    x=[start_w, end_w], y=[i, i],
                    mode="lines",
                    line=dict(color=colour, width=7),
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{pt}</b><br>"
                        f"Severity: {sev}<br>Serious: {ser}<br>"
                        f"Relatedness: {rel}<br>Outcome: {out}<br>"
                        f"Start Wk: {start_w:.1f}  End Wk: {end_w:.1f}"
                        "<extra></extra>"
                    ),
                ),
                False,
            ))
            # End-point markers
            traces.append((
                go.Scatter(
                    x=[start_w, end_w], y=[i, i],
                    mode="markers",
                    marker=dict(
                        symbol=["circle", "line-ew-open"],
                        color=colour, size=[9, 9],
                        line=dict(color=colour, width=2),
                    ),
                    showlegend=False, hoverinfo="skip",
                ),
                False,
            ))
        return traces, y_labels

    def _cm_traces(self, usubjid: str, ref: pd.Timestamp):
        """
        CM → concomitant medication timeline traces.
        BUG-3 FIX: explicit column check.
        PERF-2 FIX: vectorised end-week calculation.
        Returns (traces_list, y_label_list).
        """
        cm = self._domain("cm", usubjid)
        if cm.empty or "CMSTDTC" not in cm.columns:
            return [], []

        cm = cm.copy()
        cm["_st"] = _parse_dt(cm["CMSTDTC"])
        # BUG-3 FIX: explicit column check
        cm["_en"] = _parse_dt(_col(cm, "CMENDTC"))
        cm = cm.dropna(subset=["_st"])
        if cm.empty:
            return [], []

        # PERF-2 FIX: vectorised
        cm["_stw"] = _weeks(cm["_st"], ref)
        cm["_enw"] = _weeks(pd.to_datetime(cm["_en"], errors="coerce"), ref)

        term_col  = "CMDECOD"  if "CMDECOD"  in cm.columns else (
                    "CMTRT"    if "CMTRT"    in cm.columns else None)
        dose_col  = "CMDOSE"   if "CMDOSE"   in cm.columns else None
        route_col = "CMROUTE"  if "CMROUTE"  in cm.columns else None
        colour    = self.pal["cm"]

        traces, y_labels = [], []

        for i, (_, row) in enumerate(cm.iterrows()):
            term    = str(row[term_col]).lower() if term_col and pd.notna(row.get(term_col)) else f"med {i+1}"
            dose    = str(int(row[dose_col])) if dose_col and pd.notna(row.get(dose_col)) and str(row.get(dose_col, "")).strip() != "" else ""
            route   = str(row[route_col]) if route_col and pd.notna(row.get(route_col)) else ""
            start_w = float(row["_stw"])
            end_w_raw = row["_enw"]
            ongoing = pd.isna(end_w_raw)
            end_w   = float(end_w_raw) if not ongoing else start_w + 0.4

            label = f"{term}  {dose}".rstrip()
            y_labels.append(label)

            traces.append((
                go.Scatter(
                    x=[start_w, end_w], y=[i, i],
                    mode="lines+markers",
                    line=dict(color=colour, width=2, dash="dash"),
                    marker=dict(
                        symbol=["triangle-right", "line-ew-open" if ongoing else "line-ew"],
                        color=colour, size=9,
                        line=dict(color=colour, width=2),
                    ),
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{term.title()}</b><br>"
                        + (f"Dose: {dose}  Route: {route}<br>" if dose or route else "")
                        + f"Start Wk: {start_w:.1f}"
                        + (f"  End Wk: {end_w:.1f}" if not ongoing else "  (ongoing)")
                        + "<extra></extra>"
                    ),
                ),
                False,
            ))
        return traces, y_labels

    def _mh_table(self, usubjid: str) -> pd.DataFrame:
        """MH → medical history DataFrame for display below the plot."""
        mh = self._domain("mh", usubjid)
        if mh.empty:
            return pd.DataFrame()
        col_map = {
            "MHDECOD":  "Reported Term",
            "MHBODSYS": "Body System / Organ Class",
            "MHSTDTC":  "Start Date",
            "MHENDTC":  "End Date",
        }
        present = {k: v for k, v in col_map.items() if k in mh.columns}
        if not present:
            return pd.DataFrame()
        return mh[list(present.keys())].rename(columns=present).reset_index(drop=True)

    # ── Master build ──────────────────────────────────────────────────────────

    def build(
        self,
        usubjid: str,
        height: int = 1100,
        show_dose_panel: bool = True,
        show_ae_panel:   bool = True,
        show_cm_panel:   bool = True,
    ) -> go.Figure:
        """
        Build and return the full PP Plotly figure for usubjid.

        Parameters
        ----------
        usubjid         : SDTM USUBJID value.
        height          : Figure height in pixels.
        show_dose_panel : Include the Dose + Biomarkers panel.
        show_ae_panel   : Include the Adverse Events panel.
        show_cm_panel   : Include the Concomitant Medications panel.
        """
        ref = self._ref_date(usubjid)
        if ref is None:
            ref = pd.Timestamp("1970-01-01")
            warnings.warn(f"No EX records found for {usubjid}; using 1970-01-01 as reference.")

        # Build traces (each: list of (go.Scatter, is_secondary) tuples)
        dose_traced  = self._dose_traces(usubjid, ref)     if show_dose_panel else []
        bio_traced   = self._biomarker_traces(usubjid, ref)
        ae_traced, ae_labels = self._ae_traces(usubjid, ref)
        cm_traced, cm_labels = self._cm_traces(usubjid, ref)

        has_dose = bool(dose_traced or bio_traced)
        has_ae   = bool(ae_traced) and show_ae_panel
        has_cm   = bool(cm_traced) and show_cm_panel

        active_panels = [p for p, active in [
            ("dose_bio", has_dose),
            ("ae",       has_ae),
            ("cm",       has_cm),
        ] if active]

        # Nothing to show
        if not active_panels:
            fig = go.Figure()
            fig.update_layout(
                title=dict(
                    text=f"No data available for subject {usubjid}",
                    font=dict(color=self.pal["text"]),
                ),
                paper_bgcolor=self.pal["paper"],
                plot_bgcolor=self.pal["bg"],
                font=dict(color=self.pal["text"]),
            )
            return fig

        n_rows = len(active_panels)
        rh_map = {1: [1.0], 2: [0.50, 0.50], 3: [0.42, 0.30, 0.28]}
        row_heights = rh_map.get(n_rows, [1 / n_rows] * n_rows)

        subtitle_map = {
            "dose_bio": f"{self.drug_label} — Dose & Biomarkers",
            "ae":       "Adverse Events",
            "cm":       "Concomitant Medications",
        }
        subtitles  = [subtitle_map[p] for p in active_panels]
        specs      = [[{"secondary_y": p == "dose_bio"}] for p in active_panels]
        row_idx    = {p: i + 1 for i, p in enumerate(active_panels)}

        fig = make_subplots(
            rows=n_rows, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.05,
            row_heights=row_heights,
            subplot_titles=subtitles,
            specs=specs,
        )

        # ── BUG-5 FIX: colour subplot title annotations BEFORE adding ref-line
        #   annotations, so we only recolour the subplot titles (which have no
        #   explicit font colour yet) and leave ref-line annotations untouched.
        for ann in fig.layout.annotations:
            # make_subplots generates subtitle annotations; they have text
            # matching our subtitles and no colour set yet.
            if ann.text in subtitles:
                ann.font = dict(size=11, color=self.pal["text"])   # FIX COLOR-2 / BUG-5

        # ── Add traces ────────────────────────────────────────────────────────
        if "dose_bio" in row_idx:
            r = row_idx["dose_bio"]
            for tr, is_sec in dose_traced:
                fig.add_trace(tr, row=r, col=1)          # dose = never secondary
            for tr, is_sec in bio_traced:
                fig.add_trace(tr, row=r, col=1, secondary_y=is_sec)   # BUG-1 FIX

            fig.update_yaxes(
                title_text="Dose (mg) / Lab Value",
                title_font=dict(color=self.pal["text"], size=10),   # FIX COLOR-2
                showgrid=True, gridcolor=self.pal["grid"],
                zeroline=True, zerolinecolor=self.pal["zero"],
                tickfont=dict(color=self.pal["subtext"], size=9),
                row=r, col=1, secondary_y=False,
            )
            fig.update_yaxes(
                title_text="Secondary Lab",
                title_font=dict(color=self.pal["text"], size=10),
                showgrid=False,
                tickfont=dict(color=self.pal["subtext"], size=9),
                row=r, col=1, secondary_y=True,
            )

        if "ae" in row_idx:
            r = row_idx["ae"]
            for tr, _ in ae_traced:
                fig.add_trace(tr, row=r, col=1)
            if ae_labels:
                fig.update_yaxes(
                    tickmode="array",
                    tickvals=list(range(len(ae_labels))),
                    ticktext=[f"<b>{lbl}</b>" for lbl in ae_labels],
                    tickfont=dict(size=9, color=self.pal["text"]),  # FIX COLOR-1
                    row=r, col=1,
                )

        if "cm" in row_idx:
            r = row_idx["cm"]
            for tr, _ in cm_traced:
                fig.add_trace(tr, row=r, col=1)
            if cm_labels:
                fig.update_yaxes(
                    tickmode="array",
                    tickvals=list(range(len(cm_labels))),
                    ticktext=cm_labels,
                    tickfont=dict(size=9, color=self.pal["text"]),  # FIX COLOR-1
                    row=r, col=1,
                )

        # ── X-axes ───────────────────────────────────────────────────────────
        for i in range(1, n_rows):
            fig.update_xaxes(showticklabels=False, row=i, col=1)

        fig.update_xaxes(
            title_text="Study Week",
            title_font=dict(color=self.pal["text"], size=10),  # FIX COLOR-2
            showgrid=True, gridcolor=self.pal["grid"],
            tickfont=dict(size=9, color=self.pal["subtext"]),
            row=n_rows, col=1,
        )

        # ── Reference lines (added AFTER subtitle annotation recolouring) ─────
        shapes = [dict(
            type="line", xref="x", yref="paper",
            x0=0, x1=0, y0=0, y1=1,
            line=dict(color=self.pal["dose"], width=1.5, dash="dot"),
        )]
        ref_annotations = [dict(
            x=0, y=1.02, xref="x", yref="paper",
            text="<b>First Dose</b>", showarrow=False,
            font=dict(size=8, color=self.pal["dose"]),
            xanchor="center",
        )]

        if self.data_cutoff and pd.notna(self.data_cutoff):
            cw = (self.data_cutoff - ref).days / 7
            shapes.append(dict(
                type="line", xref="x", yref="paper",
                x0=cw, x1=cw, y0=0, y1=1,
                line=dict(color=self.pal["cutoff"], width=1.5, dash="dashdot"),
            ))
            ref_annotations.append(dict(
                x=cw, y=1.02, xref="x", yref="paper",
                text="<b>Data Cut-off</b>", showarrow=False,
                font=dict(size=8, color=self.pal["cutoff"]),
                xanchor="center",
            ))

        fig.update_layout(shapes=shapes)
        # Append ref-line annotations AFTER subtitle loop (BUG-5 FIX)
        existing = list(fig.layout.annotations)
        fig.update_layout(annotations=existing + ref_annotations)

        # ── Global layout ─────────────────────────────────────────────────────
        legend_bg = "rgba(15,23,42,0.75)" if self.dark else "rgba(248,250,252,0.85)"
        fig.update_layout(
            height=height,
            paper_bgcolor=self.pal["paper"],
            plot_bgcolor=self.pal["bg"],       # FIX COLOR-4: slightly different from paper
            font=dict(family="Arial", size=10, color=self.pal["text"]),
            legend=dict(
                orientation="h",
                yanchor="bottom", y=1.01,
                xanchor="right",  x=1,
                bgcolor=legend_bg,
                bordercolor=self.pal["grid"], borderwidth=1,
                font=dict(size=9, color=self.pal["text"]),
            ),
            margin=dict(l=210, r=70, t=70, b=50),
            hovermode="x unified",
        )

        return fig
