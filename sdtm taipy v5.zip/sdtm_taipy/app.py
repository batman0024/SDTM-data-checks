"""
SDTM Clinical Integrity Suite - Taipy Edition v5.0
Beyond-P21 Validation Dashboard

Run:
    pip install taipy pandas openpyxl
    python app.py

Then open: http://127.0.0.1:5000
"""

import os
import sys
import time
import threading
import datetime
import json

import pandas as pd
from taipy.gui import Gui, State, notify, invoke_long_callback, get_state_id
import taipy.gui.builder as tgb

from modules.registry import CHECKS, get_check
from modules.engine import ValidationEngine, DEMO_POOL
from modules.parser import FileParser
from modules.reporter import make_html_report

# ---------------------------------------------------------------------------
# GLOBAL STATE VARIABLES  (Taipy binds these by name)
# ---------------------------------------------------------------------------

# --- File upload ---
uploaded_path = ""           # bound to file_selector
uploaded_files_meta = {}     # fname -> parsed meta dict
files_table_data = pd.DataFrame(columns=["Filename", "Type", "Rows", "Cols", "Size", "Status"])

# --- Check config ---
all_checks_df = pd.DataFrame(CHECKS)
enabled_check_ids = set(c["id"] for c in CHECKS)
check_filter_layer = "All"
check_filter_cat = "All"
check_search = ""
checks_display_df = all_checks_df.copy()

# --- Validation state ---
is_running = False
run_progress = 0
run_label = "Ready"
run_count = 0
last_run_ts = ""

# --- Findings ---
findings_all = []
findings_df = pd.DataFrame(
    columns=["ID", "Sev", "Risk", "Subject", "Domain", "Check", "Detail", "Source", "Layer", "Waived"]
)
risk_filter = "All"
findings_filtered_df = pd.DataFrame(
    columns=["ID", "Sev", "Risk", "Subject", "Domain", "Check", "Detail", "Source", "Layer", "Waived"]
)

# --- Summary stats ---
total_findings = 0
blocker_count = 0
medical_count = 0
structural_count = 0
advisory_count = 0
waived_count = 0

# --- Charts ---
risk_chart_df = pd.DataFrame({"Category": [], "Count": []})
sev_chart_df  = pd.DataFrame({"Severity": [], "Count": []})
domain_chart_df = pd.DataFrame({"Domain": [], "Count": []})
cat_chart_df = pd.DataFrame({"Category": [], "Count": []})

# --- Subject view ---
subject_search = ""
subject_df = pd.DataFrame(
    columns=["Subject", "Findings", "Worst Risk", "Domains", "Categories"]
)

# --- Domain map ---
domain_map_df = _build_domain_map_df = None  # built on first run

# --- Current tab ---
active_tab = 0

# --- Selected finding for detail panel ---
selected_finding_idx = []
finding_detail_text = ""
waiver_note_input = ""

# --- Notification messages ---
status_message = ""

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

RISK_ORDER = ["submission-blocker", "medical-concern", "structural", "advisory"]
RISK_LABEL = {
    "submission-blocker": "Submission Blocker",
    "medical-concern": "Medical Concern",
    "structural": "Structural Error",
    "advisory": "Advisory",
}

def _worst_risk(risk_list):
    for r in RISK_ORDER:
        if r in risk_list:
            return r
    return "advisory"

def _rebuild_files_table(meta_dict):
    rows = []
    for fname, m in meta_dict.items():
        rows.append({
            "Filename": fname,
            "Type": m.get("type", ""),
            "Rows": m.get("rows", 0),
            "Cols": m.get("cols", 0),
            "Size": f"{m.get('size', 0):,} bytes",
            "Status": "ERROR: " + m["parse_error"] if m.get("parse_error") else "OK",
        })
    if not rows:
        return pd.DataFrame(columns=["Filename", "Type", "Rows", "Cols", "Size", "Status"])
    return pd.DataFrame(rows)

def _rebuild_findings_df(flist, risk_f="All"):
    rows = []
    for f in flist:
        if risk_f != "All" and f["risk"] != risk_f:
            continue
        rows.append({
            "ID": f["fid"],
            "Sev": f["sev"],
            "Risk": RISK_LABEL.get(f["risk"], f["risk"]),
            "Subject": "GLOBAL" if f["subj"] == "ALL" else f["subj"],
            "Domain": f["domain"].split("/")[0],
            "Check": f["label"][:60] + ("..." if len(f["label"]) > 60 else ""),
            "Detail": f["detail"][:80] + ("..." if len(f["detail"]) > 80 else ""),
            "Source": f["source"],
            "Layer": f["layer"],
            "Waived": "YES" if f.get("waived") else "",
        })
    if not rows:
        return pd.DataFrame(
            columns=["ID", "Sev", "Risk", "Subject", "Domain", "Check", "Detail", "Source", "Layer", "Waived"]
        )
    return pd.DataFrame(rows)

def _rebuild_summary(flist):
    active = [f for f in flist if not f.get("waived")]
    by_risk = {}
    by_sev = {}
    by_dom = {}
    by_cat = {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"], 0) + 1
        by_sev[f["sev"]] = by_sev.get(f["sev"], 0) + 1
        d = f["domain"].split("/")[0]
        by_dom[d] = by_dom.get(d, 0) + 1
        by_cat[f["cat"]] = by_cat.get(f["cat"], 0) + 1
    return active, by_risk, by_sev, by_dom, by_cat

def _rebuild_subject_df(flist):
    sm = {}
    for f in [x for x in flist if not x.get("waived")]:
        k = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
        sm.setdefault(k, []).append(f)
    rows = []
    for subj, sf in sorted(sm.items(), key=lambda x: (0 if _worst_risk([f["risk"] for f in x[1]]) == "medical-concern" else 1, x[0])):
        doms = list(dict.fromkeys(f["domain"].split("/")[0] for f in sf))
        cats = list(dict.fromkeys(f["cat"] for f in sf))
        rows.append({
            "Subject": subj,
            "Findings": len(sf),
            "Worst Risk": RISK_LABEL.get(_worst_risk([f["risk"] for f in sf]), ""),
            "Domains": ", ".join(doms[:5]),
            "Categories": ", ".join(cats[:4]),
        })
    if not rows:
        return pd.DataFrame(columns=["Subject", "Findings", "Worst Risk", "Domains", "Categories"])
    return pd.DataFrame(rows)

def _build_domain_map():
    all_doms = sorted(set(
        d for c in CHECKS for d in c["domain"].split("/")
        if d not in ("ALL", "DEFINE", "SUPP", "RELREC")
    ))
    rows = []
    for dom in all_doms:
        dc = [c for c in CHECKS if dom in c["domain"].split("/")]
        en = len([c for c in dc if c["id"] in enabled_check_ids])
        has_crit = any(c["sev"] in ("CRITICAL", "REJECT") for c in dc)
        rows.append({
            "Domain": dom,
            "Checks": len(dc),
            "Enabled": en,
            "Critical Rules": "YES" if has_crit else "",
            "Active Findings": 0,
        })
    return pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["Domain", "Checks", "Enabled", "Critical Rules", "Active Findings"]
    )

def _update_domain_findings(flist, df):
    act = [f for f in flist if not f.get("waived")]
    counts = {}
    for f in act:
        for d in f["domain"].split("/"):
            counts[d] = counts.get(d, 0) + 1
    df2 = df.copy()
    df2["Active Findings"] = df2["Domain"].map(lambda d: counts.get(d, 0))
    return df2

def _rebuild_checks_display(checks, search, layer_f, cat_f, enabled_ids):
    df = pd.DataFrame(checks)
    if search:
        mask = df["label"].str.lower().str.contains(search.lower(), na=False) | \
               df["id"].str.lower().str.contains(search.lower(), na=False)
        df = df[mask]
    if layer_f and layer_f != "All":
        df = df[df["layer"] == layer_f]
    if cat_f and cat_f != "All":
        df = df[df["cat"] == cat_f]
    df = df[["id", "layer", "cat", "domain", "sev", "risk", "label", "source"]].copy()
    df.columns = ["ID", "Layer", "Category", "Domain", "Severity", "Risk", "Description", "Source"]
    df["Enabled"] = df["ID"].map(lambda i: "ON" if i in enabled_ids else "OFF")
    return df

# ---------------------------------------------------------------------------
# TAIPY CALLBACKS
# ---------------------------------------------------------------------------

def on_init(state: State):
    """Called once when a new client connects."""
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, "", "All", "All", state.enabled_check_ids
    )
    state.domain_map_df = _build_domain_map()
    _update_counts(state)

def on_upload(state: State, action, payload):
    """Called when files are uploaded via file_selector."""
    path = payload.get("path") or state.uploaded_path
    if not path or not os.path.exists(path):
        notify(state, "warning", "No valid file path received.")
        return

    fname = os.path.basename(path)
    ext = os.path.splitext(fname)[1].lower()
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
        meta = FileParser.analyze(raw, fname, ext)
        state.uploaded_files_meta[fname] = meta
        state.files_table_data = _rebuild_files_table(state.uploaded_files_meta)
        notify(state, "success", f"Loaded: {fname} ({meta.get('rows', 0)} rows)")
    except Exception as e:
        notify(state, "error", f"Failed to load {fname}: {e}")

def on_clear_files(state: State):
    state.uploaded_files_meta = {}
    state.files_table_data = _rebuild_files_table({})
    state.findings_all = []
    state.findings_df = _rebuild_findings_df([], "All")
    state.findings_filtered_df = state.findings_df.copy()
    _update_counts(state)
    notify(state, "info", "All files cleared.")

def on_check_search(state: State, var, val):
    state.check_search = val
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, val, state.check_filter_layer, state.check_filter_cat, state.enabled_check_ids
    )

def on_check_filter_layer(state: State, var, val):
    state.check_filter_layer = val
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, state.check_search, val, state.check_filter_cat, state.enabled_check_ids
    )

def on_check_filter_cat(state: State, var, val):
    state.check_filter_cat = val
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, state.check_search, state.check_filter_layer, val, state.enabled_check_ids
    )

def on_enable_all(state: State):
    state.enabled_check_ids = set(c["id"] for c in CHECKS)
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, state.check_search, state.check_filter_layer,
        state.check_filter_cat, state.enabled_check_ids
    )
    notify(state, "success", f"All {len(CHECKS)} checks enabled.")

def on_disable_all(state: State):
    state.enabled_check_ids = set()
    state.checks_display_df = _rebuild_checks_display(
        CHECKS, state.check_search, state.check_filter_layer,
        state.check_filter_cat, state.enabled_check_ids
    )
    notify(state, "warning", "All checks disabled.")

def on_risk_filter(state: State, var, val):
    state.risk_filter = val
    state.findings_filtered_df = _rebuild_findings_df(state.findings_all, val)

def on_subject_search(state: State, var, val):
    state.subject_search = val
    df = _rebuild_subject_df(state.findings_all)
    if val:
        df = df[df["Subject"].str.lower().str.contains(val.lower(), na=False)]
    state.subject_df = df

def on_finding_select(state: State, action, payload):
    """Row selection in findings table - show detail panel."""
    rows = payload.get("index", [])
    if not rows:
        state.finding_detail_text = ""
        return
    idx = rows[0]
    # map table row index back to findings_all
    rf = state.risk_filter
    matching = [f for f in state.findings_all if rf == "All" or f["risk"] == rf]
    if idx < len(matching):
        f = matching[idx]
        state.finding_detail_text = (
            f"**Check ID:** {f['fid']}  \n"
            f"**Check:** {f['label']}  \n"
            f"**Detail:** {f['detail']}  \n"
            f"**Subject:** {'GLOBAL' if f['subj'] == 'ALL' else f['subj']}  \n"
            f"**Domain:** {f['domain']}  \n"
            f"**Severity:** {f['sev']}  \n"
            f"**Risk:** {RISK_LABEL.get(f['risk'], f['risk'])}  \n"
            f"**Layer:** {f['layer']}  \n"
            f"**Source:** {f['source']}  \n"
            f"**Actual data:** {'Yes' if f.get('actual') else 'Demo sample'}  \n"
            + (f"**Root cause:** {f['root']}  \n" if f.get("root") else "")
            + (f"**Waived:** Yes - {f['waiver_note']}  \n" if f.get("waived") else "")
        )
        state.waiver_note_input = f.get("waiver_note", "")
        state.selected_finding_idx = [idx]

def on_waive_finding(state: State):
    """Waive or unwaive the currently selected finding."""
    if not state.selected_finding_idx:
        notify(state, "warning", "Select a finding row first.")
        return
    idx = state.selected_finding_idx[0]
    rf = state.risk_filter
    matching = [f for f in state.findings_all if rf == "All" or f["risk"] == rf]
    if idx >= len(matching):
        return
    f = matching[idx]
    f["waived"] = not f.get("waived", False)
    f["waiver_note"] = state.waiver_note_input
    # Rebuild all displays
    state.findings_df = _rebuild_findings_df(state.findings_all, "All")
    state.findings_filtered_df = _rebuild_findings_df(state.findings_all, state.risk_filter)
    state.subject_df = _rebuild_subject_df(state.findings_all)
    state.domain_map_df = _update_domain_findings(state.findings_all, _build_domain_map())
    _update_counts(state)
    action_str = "waived" if f["waived"] else "unwaived"
    notify(state, "success" if f["waived"] else "info",
           f"Finding {f['fid']} {action_str}.")

def on_download_report(state: State):
    """Generate and make report available for download."""
    report_html = make_html_report(
        findings=state.findings_all,
        files_meta=state.uploaded_files_meta,
        enabled_ids=state.enabled_check_ids,
    )
    path = os.path.join(os.path.dirname(__file__), "static", "report.html")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(report_html)
    notify(state, "success", "Report saved to static/report.html - open it in your browser.")

# ---------------------------------------------------------------------------
# VALIDATION - uses invoke_long_callback for non-blocking async
# ---------------------------------------------------------------------------

def _run_validation_job(files_meta, enabled_ids):
    """Long-running job executed in background thread by Taipy."""
    engine = ValidationEngine(files_meta, enabled_ids)
    results = {"findings": [], "progress": 0, "label": ""}

    def progress_cb(pct, label=""):
        results["progress"] = pct
        results["label"] = label

    findings = engine.run(progress_cb)
    results["findings"] = findings
    results["progress"] = 100
    results["label"] = "Complete"
    return results

def _on_validation_done(state: State, status, result):
    """Called by Taipy on the main thread when the job finishes."""
    state.is_running = False
    state.run_progress = 100
    state.run_label = "Complete"

    if not status:
        notify(state, "error", "Validation run failed. Check console.")
        return

    state.findings_all = result["findings"]
    state.run_count += 1
    state.last_run_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Rebuild all displays
    state.findings_df = _rebuild_findings_df(state.findings_all, "All")
    state.findings_filtered_df = _rebuild_findings_df(state.findings_all, state.risk_filter)
    state.subject_df = _rebuild_subject_df(state.findings_all)
    state.domain_map_df = _update_domain_findings(state.findings_all, _build_domain_map())

    # Charts
    active, by_risk, by_sev, by_dom, by_cat = _rebuild_summary(state.findings_all)
    state.risk_chart_df = pd.DataFrame(
        [{"Category": RISK_LABEL.get(k, k), "Count": v} for k, v in
         sorted(by_risk.items(), key=lambda x: -x[1])]
    )
    state.sev_chart_df = pd.DataFrame(
        [{"Severity": k, "Count": v} for k, v in sorted(by_sev.items(), key=lambda x: -x[1])]
    )
    state.domain_chart_df = pd.DataFrame(
        [{"Domain": k, "Count": v} for k, v in sorted(by_dom.items(), key=lambda x: -x[1])[:15]]
    )
    state.cat_chart_df = pd.DataFrame(
        [{"Category": k, "Count": v} for k, v in sorted(by_cat.items(), key=lambda x: -x[1])[:10]]
    )

    _update_counts(state)
    n = len(state.findings_all)
    notify(state, "success", f"Validation complete: {n} findings ({state.run_count} runs)")

def _on_validation_progress(state: State, status, result):
    """Called periodically while validation job runs."""
    if isinstance(result, dict):
        state.run_progress = result.get("progress", state.run_progress)
        state.run_label = result.get("label", state.run_label)

def on_run_validation(state: State):
    """Triggered by Run button - starts async validation."""
    state.is_running = True
    state.run_progress = 0
    state.run_label = "Initializing validation engine..."
    notify(state, "info", "Validation started...")
    invoke_long_callback(
        state,
        _run_validation_job,
        [dict(state.uploaded_files_meta), set(state.enabled_check_ids)],
        _on_validation_done,
        [],
        _on_validation_progress,
        period=500,
    )

def _update_counts(state: State):
    active = [f for f in state.findings_all if not f.get("waived")]
    by_risk = {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"], 0) + 1
    state.total_findings = len(active)
    state.blocker_count = by_risk.get("submission-blocker", 0)
    state.medical_count = by_risk.get("medical-concern", 0)
    state.structural_count = by_risk.get("structural", 0)
    state.advisory_count = by_risk.get("advisory", 0)
    state.waived_count = len([f for f in state.findings_all if f.get("waived")])

# ---------------------------------------------------------------------------
# DERIVED LISTS FOR SELECTORS
# ---------------------------------------------------------------------------
layers_lov = ["All"] + sorted(set(c["layer"] for c in CHECKS))
cats_lov = ["All"] + sorted(set(c["cat"] for c in CHECKS))
risk_filter_lov = ["All", "submission-blocker", "medical-concern", "structural", "advisory"]
risk_filter_labels = {
    "All": "All Findings",
    "submission-blocker": "Submission Blockers",
    "medical-concern": "Medical Concerns",
    "structural": "Structural Errors",
    "advisory": "Advisory",
}

# ---------------------------------------------------------------------------
# PAGE DEFINITION using tgb Page Builder API
# ---------------------------------------------------------------------------
with tgb.Page() as page:

    # -- HEADER --------------------------------------------------------------
    with tgb.part(class_name="header-bar"):
        with tgb.layout("auto 1 auto"):
            with tgb.part(class_name="logo-area"):
                tgb.text("## SDTM Clinical Integrity Suite", mode="md",
                         class_name="app-title")
                tgb.text("v5.0 | Beyond-P21 Validation | {len(CHECKS)} Checks | 35+ Domains | FDA JumpStart",
                         class_name="app-subtitle")

            with tgb.part(class_name="header-stats"):
                with tgb.layout("1 1 1 1 1 1"):
                    tgb.metric("{total_findings}", label="Active",
                               delta=None, delta_color="normal",
                               class_name="metric-card metric-total")
                    tgb.metric("{blocker_count}", label="Blockers",
                               delta=None, class_name="metric-card metric-blocker")
                    tgb.metric("{medical_count}", label="Medical",
                               delta=None, class_name="metric-card metric-medical")
                    tgb.metric("{structural_count}", label="Structural",
                               delta=None, class_name="metric-card metric-structural")
                    tgb.metric("{advisory_count}", label="Advisory",
                               delta=None, class_name="metric-card metric-advisory")
                    tgb.metric("{waived_count}", label="Waived",
                               delta=None, class_name="metric-card metric-waived")

            with tgb.part(class_name="header-actions"):
                tgb.text("Last run: {last_run_ts}", class_name="last-run-label",
                         render="{last_run_ts != ''}")
                tgb.button("Download Report", on_action=on_download_report,
                           class_name="btn-secondary")
                tgb.button(">  Run Validation", on_action=on_run_validation,
                           active="{not is_running}",
                           class_name="btn-primary")

    # -- PROGRESS BAR --------------------------------------------------------
    with tgb.part(render="{is_running}", class_name="progress-section"):
        tgb.progress("{run_progress}", class_name="val-progress")
        tgb.text("{run_label}", class_name="progress-label")

    # -- MAIN LAYOUT: sidebar + content -------------------------------------
    with tgb.layout("240px 1fr", class_name="main-layout"):

        # -- LEFT SIDEBAR ----------------------------------------------------
        with tgb.part(class_name="sidebar"):

            # File Upload section
            with tgb.expandable("File Upload", expanded=True, class_name="sidebar-section"):
                tgb.file_selector(
                    "{uploaded_path}",
                    extensions=".sas7bdat,.xpt,.csv,.xlsx,.xls,.json,.xml,.txt,.pdf",
                    drop_message="Drop SDTM files here",
                    label="Browse or Drop Files",
                    on_action=on_upload,
                    class_name="file-selector-widget",
                    multiple=True,
                )
                tgb.button("Clear All Files", on_action=on_clear_files,
                           class_name="btn-danger btn-small",
                           active="{len(uploaded_files_meta) > 0}")
                tgb.text("**Loaded: {len(uploaded_files_meta)} file(s)**", mode="md",
                         class_name="file-count-label")

            # Check Config section
            with tgb.expandable("Check Configuration", expanded=False, class_name="sidebar-section"):
                tgb.input("{check_search}", label="Search checks",
                          on_change=on_check_search, class_name="search-input")
                tgb.selector("{check_filter_layer}", lov=layers_lov,
                             label="Layer", on_change=on_check_filter_layer,
                             dropdown=True, class_name="filter-selector")
                tgb.selector("{check_filter_cat}", lov=cats_lov,
                             label="Category", on_change=on_check_filter_cat,
                             dropdown=True, class_name="filter-selector")
                with tgb.layout("1 1"):
                    tgb.button("Enable All", on_action=on_enable_all,
                               class_name="btn-success btn-small")
                    tgb.button("Disable All", on_action=on_disable_all,
                               class_name="btn-warning btn-small")
                tgb.text("**{len(enabled_check_ids)}/{len(CHECKS)} checks active**",
                         mode="md", class_name="enabled-count")

        # -- MAIN CONTENT TABS ----------------------------------------------
        with tgb.part(class_name="main-content"):
            with tgb.navbar():
                tgb.text("Dashboard")
                tgb.text("Integrity Report")
                tgb.text("Subject View")
                tgb.text("Domain Map")
                tgb.text("Check Registry")
                tgb.text("Files")

            with tgb.part(class_name="tab-content"):

                # -- TAB 1: DASHBOARD ----------------------------------------
                with tgb.expandable("Overview Charts", expanded=True, class_name="chart-section"):
                    with tgb.layout("1 1"):
                        with tgb.part():
                            tgb.text("**Findings by Risk Category**", mode="md",
                                     class_name="chart-title")
                            tgb.chart(
                                "{risk_chart_df}",
                                type="bar",
                                x="Category",
                                y__1="Count",
                                color__1="#e05c5c",
                                class_name="findings-chart",
                                render="{total_findings > 0}",
                            )
                            tgb.text("*Run validation to see charts*", mode="md",
                                     class_name="no-data-hint",
                                     render="{total_findings == 0}")

                        with tgb.part():
                            tgb.text("**Findings by Severity**", mode="md",
                                     class_name="chart-title")
                            tgb.chart(
                                "{sev_chart_df}",
                                type="bar",
                                x="Severity",
                                y__1="Count",
                                color__1="#e08a2e",
                                class_name="findings-chart",
                                render="{total_findings > 0}",
                            )

                    with tgb.layout("2 1"):
                        with tgb.part():
                            tgb.text("**Findings by SDTM Domain**", mode="md",
                                     class_name="chart-title")
                            tgb.chart(
                                "{domain_chart_df}",
                                type="bar",
                                x="Domain",
                                y__1="Count",
                                color__1="#5a8fe0",
                                class_name="findings-chart",
                                render="{total_findings > 0}",
                            )
                        with tgb.part():
                            tgb.text("**Findings by Category**", mode="md",
                                     class_name="chart-title")
                            tgb.chart(
                                "{cat_chart_df}",
                                type="pie",
                                values="Count",
                                labels="Category",
                                class_name="findings-chart",
                                render="{total_findings > 0}",
                            )

                # -- TAB 2: INTEGRITY REPORT ---------------------------------
                with tgb.expandable("Integrity Report", expanded=True, class_name="report-section"):
                    with tgb.layout("auto 1"):
                        tgb.selector(
                            "{risk_filter}",
                            lov=risk_filter_lov,
                            label="Filter by Risk",
                            on_change=on_risk_filter,
                            dropdown=True,
                            class_name="risk-filter-selector",
                        )
                        tgb.text(
                            "**{len(findings_filtered_df)} findings shown** | "
                            "Run: {last_run_ts if last_run_ts else 'Not run yet'}",
                            mode="md", class_name="report-stats",
                        )

                    tgb.table(
                        "{findings_filtered_df}",
                        class_name="findings-table",
                        on_action=on_finding_select,
                        selected="{selected_finding_idx}",
                        filter=True,
                        show_all=False,
                        page_size=20,
                        height="380px",
                    )

                    # Detail panel
                    with tgb.part(render="{finding_detail_text != ''}",
                                  class_name="detail-panel"):
                        tgb.text("**Finding Detail**", mode="md",
                                 class_name="detail-title")
                        tgb.text("{finding_detail_text}", mode="md",
                                 class_name="detail-body")
                        with tgb.layout("1 auto auto"):
                            tgb.input("{waiver_note_input}", label="cSDRG Waiver Note",
                                      class_name="waiver-input")
                            tgb.button("Waive / Unwaive", on_action=on_waive_finding,
                                       class_name="btn-warning")

                # -- TAB 3: SUBJECT VIEW -------------------------------------
                with tgb.expandable("Subject Timeline", expanded=True,
                                    class_name="subject-section"):
                    tgb.input("{subject_search}", label="Filter by Subject ID",
                              on_change=on_subject_search,
                              class_name="search-input")
                    tgb.table(
                        "{subject_df}",
                        class_name="subject-table",
                        filter=True,
                        show_all=False,
                        page_size=25,
                        height="420px",
                    )

                # -- TAB 4: DOMAIN MAP ---------------------------------------
                with tgb.expandable("Domain Coverage Map", expanded=True,
                                    class_name="domain-section"):
                    tgb.table(
                        "{domain_map_df}",
                        class_name="domain-table",
                        filter=True,
                        show_all=False,
                        page_size=40,
                        height="480px",
                    )

                # -- TAB 5: CHECK REGISTRY -----------------------------------
                with tgb.expandable("Check Registry", expanded=True,
                                    class_name="registry-section"):
                    tgb.table(
                        "{checks_display_df}",
                        class_name="registry-table",
                        filter=True,
                        show_all=False,
                        page_size=25,
                        height="480px",
                    )

                # -- TAB 6: FILES --------------------------------------------
                with tgb.expandable("Loaded Files", expanded=True,
                                    class_name="files-section"):
                    tgb.table(
                        "{files_table_data}",
                        class_name="files-table",
                        filter=True,
                        show_all=True,
                        height="320px",
                    )

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Initial computed values
    domain_map_df = _build_domain_map()
    checks_display_df = _rebuild_checks_display(CHECKS, "", "All", "All", enabled_check_ids)

    gui = Gui(page=page, css_file="static/style.css")
    gui.run(
        title="SDTM Clinical Integrity Suite v5.0",
        dark_mode=True,
        host="127.0.0.1",
        port=5000,
        use_reloader=False,
        debug=False,
    )
