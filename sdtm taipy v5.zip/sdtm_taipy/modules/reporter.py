"""modules/reporter.py - Standalone HTML report generator"""
import datetime

RISK_LABEL = {
    "submission-blocker": "Submission Blocker",
    "medical-concern": "Medical Concern",
    "structural": "Structural Error",
    "advisory": "Advisory",
}
RISK_C = {
    "submission-blocker": "#ff3a3a",
    "medical-concern": "#e05c5c",
    "structural": "#e08a2e",
    "advisory": "#5a8fe0",
}
SEV_C = {
    "REJECT": "#ff3a3a",
    "CRITICAL": "#e05c5c",
    "ERROR": "#e08a2e",
    "WARNING": "#c4b400",
    "NOTICE": "#4a7bc8",
}


def _esc(s):
    if not s:
        return ""
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))


def _bar_chart_html(obj, cmap=None):
    if not obj:
        return "<p style='color:#2a2e45;font-size:10px'>No data</p>"
    mx = max(obj.values()) if obj else 1
    rows = ""
    for k, v in sorted(obj.items(), key=lambda x: -x[1]):
        pct = int(v / mx * 100) if mx else 0
        c = (cmap or {}).get(k, "#3a6ab0")
        lbl = _esc(str(k)[:18])
        rows += (
            f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">'
            f'<div style="width:120px;font-size:10px;color:#7a7e98;text-align:right;'
            f'flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'
            f'{lbl}</div>'
            f'<div style="flex:1;background:#0f1018;border-radius:2px;height:14px;'
            f'overflow:hidden;border:1px solid #16182a">'
            f'<div style="height:100%;width:{pct}%;background:{c};border-radius:2px"></div></div>'
            f'<div style="width:24px;font-size:10px;color:#7a7e98">{v}</div></div>'
        )
    return rows


def make_html_report(findings: list, files_meta: dict, enabled_ids: set) -> str:
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    active = [f for f in findings if not f.get("waived")]
    waived = [f for f in findings if f.get("waived")]

    by_risk: dict = {}
    by_sev: dict = {}
    by_dom: dict = {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"], 0) + 1
        by_sev[f["sev"]] = by_sev.get(f["sev"], 0) + 1
        d = f["domain"].split("/")[0]
        by_dom[d] = by_dom.get(d, 0) + 1

    def sc(label, val, color):
        return (
            f'<div style="background:#0d0f18;border:1px solid {color}22;border-radius:5px;'
            f'padding:12px 10px;text-align:center">'
            f'<div style="font-size:22px;font-weight:700;color:{color};font-family:sans-serif">{val}</div>'
            f'<div style="font-size:9px;color:#2a2e45;text-transform:uppercase;letter-spacing:.07em;margin-top:2px">{label}</div></div>'
        )

    scores = (
        sc("Active", len(active), "#b0b5c8") +
        sc("Blockers", by_risk.get("submission-blocker", 0), "#ff3a3a") +
        sc("Medical", by_risk.get("medical-concern", 0), "#e05c5c") +
        sc("Structural", by_risk.get("structural", 0), "#e08a2e") +
        sc("Advisory", by_risk.get("advisory", 0), "#5a8fe0") +
        sc("Waived", len(waived), "#3a8050")
    )

    def findings_table(flist):
        if not flist:
            return "<p style='color:#2a2e45;font-size:10px;padding:12px'>No findings.</p>"
        rows = ""
        for f in flist[:500]:
            sc2 = SEV_C.get(f.get("sev", ""), "#666")
            rc = RISK_C.get(f.get("risk", ""), "#666")
            rl = RISK_LABEL.get(f.get("risk", ""), f.get("risk", ""))
            ab = (
                '<span style="font-size:8px;background:rgba(32,128,80,.3);color:#3a9060;'
                'border:1px solid #1a5030;border-radius:2px;padding:0 3px">ACTUAL</span>'
                if f.get("actual") else
                '<span style="font-size:8px;background:rgba(74,123,200,.15);color:#4a7bc8;'
                'border:1px solid #1a2a5a;border-radius:2px;padding:0 3px">DEMO</span>'
            )
            root_td = f' <span style="font-size:9px;color:#3a3e58">Root: {_esc(f.get("root",""))}</span>' if f.get("root") else ""
            rows += (
                f'<tr>'
                f'<td style="font-size:9px;color:#3a3e58">{_esc(f.get("fid",""))}</td>'
                f'<td><span style="font-size:9px;border:1px solid {sc2};color:{sc2};'
                f'padding:1px 4px;border-radius:2px">{_esc(f.get("sev",""))}</span></td>'
                f'<td style="color:{rc};font-size:10px">{_esc(rl)}</td>'
                f'<td style="color:#5a8fe0;font-weight:600">{"GLOBAL" if f.get("subj")=="ALL" else f.get("subj","")}</td>'
                f'<td style="color:#3a3e58;font-size:10px">{_esc(f.get("domain",""))}</td>'
                f'<td>{_esc(f.get("label",""))} {ab}{root_td}</td>'
                f'<td style="color:#7a7e98;font-size:10px">{_esc(f.get("detail",""))}</td>'
                f'<td style="font-size:9px;color:#2a2e45">{_esc(f.get("source",""))}</td>'
                f'</tr>'
            )
        cols = ["ID", "Sev", "Risk", "Subject", "Domain", "Check", "Detail", "Source"]
        thead = "".join(
            f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;'
            f'text-align:left;color:#5a8fe0;font-size:10px;text-transform:uppercase">{c}</th>'
            for c in cols
        )
        return f'<table style="width:100%;border-collapse:collapse;font-size:11px"><thead><tr>{thead}</tr></thead><tbody>{rows}</tbody></table>'

    files_rows = ""
    for fname, m in files_meta.items():
        vs = ", ".join((m.get("variables") or [])[:6])
        if len(m.get("variables") or []) > 6:
            vs += " ..."
        err = m.get("parse_error", "")
        files_rows += (
            f'<tr><td style="color:#5a8fe0">{_esc(fname)}</td>'
            f'<td>{_esc(m.get("type",""))}</td>'
            f'<td style="text-align:right">{m.get("rows",0)}</td>'
            f'<td style="text-align:right">{m.get("cols",0)}</td>'
            f'<td style="text-align:right">{m.get("size",0):,}</td>'
            f'<td style="font-size:10px;color:#3a3e58">{_esc(vs)}</td>'
            f'<td style="color:#e05c5c;font-size:10px">{_esc(err)}</td></tr>'
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Clinical Integrity Report - SDTM Suite Taipy v5.0</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#09090e;color:#b0b5c8;font-family:"Courier New",monospace;
     font-size:12px;line-height:1.6;padding:32px 24px}}
.page{{max-width:1200px;margin:0 auto}}
h1{{font-family:sans-serif;font-size:22px;font-weight:800;color:#d0d5e8;margin-bottom:4px}}
h2{{font-family:sans-serif;font-size:15px;font-weight:700;color:#d0d5e8;
    margin:28px 0 12px;padding-bottom:7px;border-bottom:1px solid #16182a}}
table{{width:100%;border-collapse:collapse}}
th{{background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;
    color:#5a8fe0;font-size:10px;text-transform:uppercase}}
td{{border:1px solid #16182a;padding:7px 9px;vertical-align:top}}
tr:hover td{{background:rgba(255,255,255,.02)}}
.grid6{{display:grid;grid-template-columns:repeat(6,1fr);gap:9px;margin-bottom:20px}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}}
.chart-box{{background:#0c0c14;border:1px solid #16182a;border-radius:5px;padding:14px}}
.ch-lbl{{font-size:9px;color:#2a2e45;text-transform:uppercase;letter-spacing:.1em;margin-bottom:9px}}
</style>
</head>
<body>
<div class="page">
<div style="font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase;margin-bottom:10px">
  SDTM Clinical Integrity Suite Taipy v5.0 - Beyond-P21 Validation Engine
</div>
<h1>Clinical Integrity Report</h1>
<div style="font-size:11px;color:#3a3e58;margin-bottom:20px">
  Generated: {now} &bull; {len(findings)} total findings &bull;
  {len(active)} active &bull; {len(waived)} waived &bull;
  {len(enabled_ids)} checks enabled
</div>

<h2>Executive Summary</h2>
<div class="grid6">{scores}</div>

<h2>Findings by Risk and Severity</h2>
<div class="grid2">
  <div class="chart-box">
    <div class="ch-lbl">By Risk Category</div>
    {_bar_chart_html(by_risk, RISK_C)}
  </div>
  <div class="chart-box">
    <div class="ch-lbl">By Severity Level</div>
    {_bar_chart_html(by_sev, SEV_C)}
  </div>
</div>
<div class="chart-box" style="margin-bottom:20px">
  <div class="ch-lbl">By SDTM Domain</div>
  {_bar_chart_html(by_dom)}
</div>

<h2>Medical Concerns and Submission Blockers ({by_risk.get("medical-concern",0) + by_risk.get("submission-blocker",0)})</h2>
{findings_table([f for f in active if f["risk"] in ("medical-concern","submission-blocker")])}

<h2>Structural Errors and Advisory ({by_risk.get("structural",0) + by_risk.get("advisory",0)})</h2>
{findings_table([f for f in active if f["risk"] in ("structural","advisory")])}

<h2>All Active Findings ({len(active)})</h2>
{findings_table(active)}

<h2>Waived Findings ({len(waived)})</h2>
<div style="opacity:.5">{findings_table(waived)}</div>

<h2>Loaded Files ({len(files_meta)})</h2>
<table>
<thead><tr>
<th>Filename</th><th>Type</th><th>Rows</th><th>Cols</th><th>Size</th><th>Variables</th><th>Error</th>
</tr></thead>
<tbody>
{files_rows if files_rows else '<tr><td colspan="7" style="color:#2a2e45;text-align:center;padding:14px">No files loaded</td></tr>'}
</tbody>
</table>

<div style="margin-top:36px;padding-top:14px;border-top:1px solid #16182a;
            font-size:9px;color:#2a2e45;text-align:center">
  SDTM Clinical Integrity Suite Taipy v5.0 &bull; Beyond-P21 Validation Engine &bull;
  Sources: FDA TCG 2024, SDTMIG v3.4, PharmaSUG 2012-2024, ICH E2A/E3/E6/E14,
  CDISC CT, RECIST 1.1, FDA DILI Guidance, NCI CTCAE v5
</div>
</div>
</body>
</html>"""
