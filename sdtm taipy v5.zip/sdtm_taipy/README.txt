SDTM Clinical Integrity Suite - Taipy Edition v5.0
===================================================
Beyond-P21 Validation Dashboard | 124 Checks | 35+ Domains | FDA JumpStart Ready

=======================================================================
SYSTEM REQUIREMENTS
=======================================================================

  Python  : 3.9, 3.10, 3.11, or 3.12  (Taipy does NOT support 3.13+)
  OS      : Windows 10+, macOS 12+, Ubuntu 20.04+
  RAM     : 4 GB minimum, 8 GB recommended
  Browser : Chrome 90+, Firefox 88+, Edge 90+, Safari 15+

=======================================================================
INSTALLATION (step by step)
=======================================================================

STEP 1 - Check your Python version:
    python --version
    # Must show 3.9.x / 3.10.x / 3.11.x / 3.12.x
    # If 3.13 or higher, install 3.12 from python.org first

STEP 2 - Create a virtual environment (STRONGLY recommended):
    python -m venv sdtm_env

    On macOS / Linux:
        source sdtm_env/bin/activate

    On Windows (Command Prompt):
        sdtm_env\Scripts\activate

    On Windows (PowerShell):
        sdtm_env\Scripts\Activate.ps1

STEP 3 - Install all dependencies:
    pip install -r requirements.txt

    This installs:
        taipy >= 4.0.0      Full framework (GUI + Core + scheduling)
        pandas >= 1.5.0     DataFrames for tables and charts
        openpyxl >= 3.0.0   Excel file reading (.xlsx)

    The taipy package is ~50-100 MB. Installation takes 1-3 minutes.

STEP 4 - Verify installation:
    python -c "import taipy; print('Taipy', taipy.__version__)"
    python -c "import pandas; print('pandas', pandas.__version__)"

=======================================================================
HOW TO RUN
=======================================================================

    python app.py

The app starts a local web server and prints the URL in the terminal:
    http://127.0.0.1:5000

Open this URL in your browser. The dashboard loads in ~3 seconds.

To stop: press Ctrl+C in the terminal.

=======================================================================
USING THE DASHBOARD
=======================================================================

1. FILES PANEL (left sidebar, Files tab)
   - Drag and drop or click to browse:
       .sas7bdat   SAS dataset files
       .xpt        SAS v5 transport files
       .csv        Comma-separated datasets
       .xlsx       Excel workbooks
       .json       JSON datasets
       .xml        Define-XML files
       .pdf        Protocol/spec documents
   - Files are mapped to SDTM domains by filename:
       ae.csv      -> AE domain
       DM.sas7bdat -> DM domain
       my_lb.xpt   -> LB domain
   - Without files, the app runs with 40 pre-loaded demo findings

2. CHECKS PANEL (left sidebar, Checks tab)
   - Search by check ID or description
   - Filter by Layer (Structure / Trial Design / P21-Base / Beyond-P21)
   - Filter by Category
   - Enable All / Disable All buttons

3. RUN VALIDATION
   - Click "Run Validation" in the top-right header
   - Taipy runs the engine in a BACKGROUND THREAD (UI stays responsive)
   - Real-time progress bar shows current check and percentage
   - When complete: findings populate all tabs automatically

4. DASHBOARD TAB
   - 6-card scoreboard: Active / Blockers / Medical / Structural / Advisory / Waived
   - 4 charts: by Risk, by Severity, by Domain, by Category

5. INTEGRITY REPORT TAB
   - Full sortable/filterable findings table (20 per page)
   - Filter by Risk: All / Submission Blockers / Medical Concerns / Structural / Advisory
   - Click any row to expand the Detail Panel below the table
   - Enter a cSDRG waiver note and click "Waive / Unwaive"
   - Waived findings are excluded from all counts

6. SUBJECT VIEW TAB
   - All subjects with findings, sorted by worst risk
   - Shows finding count, highest risk, domains affected, categories
   - Search/filter by subject ID

7. DOMAIN MAP TAB
   - All 35+ SDTM domains with check counts and active finding counts
   - Sortable and filterable

8. CHECK REGISTRY TAB
   - All 124 registered checks with ID, layer, category, domain, severity, risk
   - Searchable and filterable

9. FILES TAB
   - All loaded files with row/column counts and parse status

10. DOWNLOAD REPORT
    - Click "Download Report" in the header
    - Generates static/report.html in the project folder
    - Open it in any browser - standalone dark-mode HTML report
    - Contains: scoreboard, bar charts, 4 findings tables, file list

=======================================================================
PROJECT STRUCTURE
=======================================================================

    sdtm_taipy/
    app.py                    Main Taipy application (all pages + callbacks)
    requirements.txt          Python dependencies
    README.txt                This file
    modules/
      __init__.py             Package init
      registry.py             124 SDTM check definitions
      engine.py               Validation engine (actual + demo)
      parser.py               Multi-format file parser
      reporter.py             HTML report generator
    static/
      style.css               Custom dark-mode CSS theme (Orbitron + JetBrains Mono)
      report.html             Generated report (created by Download Report)

=======================================================================
WHY TAIPY OVER STREAMLIT
=======================================================================

  Feature                 Streamlit         Taipy
  ----------------------  ----------------  ----------------------------
  UI on long task         FREEZES           Background thread, stays live
  Re-render on click      Full script       Callback only (partial update)
  Async support           No                Yes - invoke_long_callback
  Performance             Slow past 100k    Downsampling, faster render
  Session isolation       Fragile           Proper multi-user sessions
  Pipeline management     None              Full Taipy Core (scenario mgmt)
  Boot time               15-30 seconds     2-3 seconds

=======================================================================
TROUBLESHOOTING
=======================================================================

Problem: "taipy not found" after pip install
Solution: Make sure your virtual environment is activated before pip install

Problem: "Python 3.13 not supported"
Solution: Install Python 3.12 from python.org and use it for the venv:
    python3.12 -m venv sdtm_env

Problem: Port 5000 already in use
Solution: Edit app.py last line, change port=5000 to port=5001 (or any free port)

Problem: Browser shows blank page
Solution: Wait 3 seconds and refresh. Taipy serves its React bundle on first load.

Problem: Charts not rendering
Solution: Run validation first to generate data. Charts need findings to display.

Problem: File not recognized as a domain
Solution: Rename file to match the 2-letter SDTM domain: ae.csv, vs.csv, dm.csv etc.

Problem: openpyxl ImportError
Solution: pip install openpyxl

Problem: Windows PowerShell execution policy error
Solution: Run: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

=======================================================================
ADDING CUSTOM CHECKS
=======================================================================

1. Open modules/registry.py
   Add a dict to the CHECKS list:
   {
       "id": "CUST001",
       "layer": "Beyond-P21",
       "cat": "My Category",
       "domain": "LB",
       "sev": "ERROR",
       "label": "My check description",
       "risk": "medical-concern",
       "source": "My Source",
   }

2. Open modules/engine.py
   In _run_actual(), add:
   elif cid == "CUST001":
       for r in dd.get("LB", []):
           subj = r.get("USUBJID", "?")
           if your_condition(r):
               out.append(self._new(check, subj, "Your finding detail"))

3. Optionally add demo entry to DEMO_POOL in engine.py

=======================================================================
CHECK SOURCES
=======================================================================

  FDA TCG 2024        FDA Technical Conformance Guide for Electronic Study Data
  SDTMIG v3.3/3.4     CDISC Study Data Tabulation Model Implementation Guide
  P21                 Pinnacle 21 Community baseline rules
  PharmaSUG 2012-24   Pharmaceutical SAS Users Group conference papers
  ICH E2A             Clinical Safety Data Management definitions
  ICH E3              Structure and Content of Clinical Study Reports
  ICH E6 (GCP)        Good Clinical Practice guideline
  ICH E14             Clinical Evaluation of QT/QTc Interval Prolongation
  MedDRA              Medical Dictionary for Regulatory Activities
  WHO Drug            WHO Drug standardized medication terminology
  RECIST 1.1          Response Evaluation Criteria in Solid Tumors
  FDA DILI Guidance   Drug-Induced Liver Injury / Hy's Law
  NCI CTCAE v5        Common Terminology Criteria for Adverse Events
  CDISC PK Model      CDISC pharmacokinetics domain model

=======================================================================
