SDTM Clinical Integrity Suite v4.0
====================================
Futuristic Beyond-P21 Validation Dashboard
No Streamlit required - pure Python stdlib + pandas + openpyxl

HOW TO RUN
----------
1. Extract this zip:
   unzip sdtm_clinical_integrity_suite_v4.zip
   cd sdtm_v4

2. Install the 2 dependencies:
   pip install pandas openpyxl

3. Start the server:
   python app.py

4. Browser opens automatically at: http://127.0.0.1:8888
   (If it does not open, navigate there manually)

5. In the dashboard:
   - Drop SDTM datasets in the Files panel (SAS7BDAT, XPT, CSV, XLSX, XML, JSON)
   - Toggle checks on/off in the Checks panel
   - Click "Run Validation"
   - Explore findings in the 4 tabs

WHAT MAKES THIS "BETTER THAN STREAMLIT"
-----------------------------------------
- Zero cold-start delay (Streamlit takes 20-30s to boot)
- Server-Sent Events for real-time progress updates
- Custom Orbitron + JetBrains Mono futuristic dark UI
- Sub-50ms UI response (no Python re-render on every click)
- Works without any Streamlit installation
- Single python app.py - no config files, no TOML files

PROJECT FILES
-------------
app.py                        Main server (http.server + SSE)
requirements.txt              pandas, openpyxl only
modules/
  __init__.py                 Package init
  registry.py                 124 check definitions
  engine.py                   Validation engine (actual + demo)
  parser.py                   Multi-format file parser
  ui.py                       Futuristic dashboard HTML/CSS/JS
  reporter.py                 Downloadable HTML report generator

CHECKS: 124 across 35+ domains
- Structure / Define-XML / SUPPQUAL (18)
- Trial Design / TS / TA / TE / TI / TV (8)
- P21-Base: DM, AE, DS, EX, LB, VS, CM, MH, SS, TR, TU, RS, SV, EG (69)
- Beyond-P21: Temporal, Cross-Domain, PK, QS, IE, Oncology, Metadata (29)

SOURCES
-------
FDA TCG 2024, SDTMIG v3.4, P21 Community, PharmaSUG 2012-2024,
ICH E2A/E3/E6/E14, CDISC CT, RECIST 1.1, FDA DILI Guidance,
NCI CTCAE v5, MedDRA, WHO Drug, CDISC PK Model, QRS Specification

CHANGE PORT
-----------
Edit app.py line: PORT = 8888
Change to any free port number.

ADDING CUSTOM CHECKS
--------------------
1. Add dict to CHECKS list in modules/registry.py
2. Add elif cid == "MYID": block in engine.py _run_actual()
3. Optionally add demo finding to DEMO_POOL in engine.py
