"""modules/ui.py - Builds the full futuristic dashboard HTML"""

def build_ui(check_count):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>SDTM Clinical Integrity Suite v4.0</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,700;1,400&family=Orbitron:wght@400;600;700;900&display=swap');

:root{{
  --bg0:#05060a; --bg1:#08090e; --bg2:#0c0d14; --bg3:#10111a;
  --b0:#14162a; --b1:#1c1f38; --b2:#252850;
  --t0:#d0d8f0; --t1:#8890b0; --t2:#454870; --t3:#252840;
  --acc:#2060e0; --acc2:#4080ff; --acc3:#60a0ff;
  --red:#e03030; --red2:#ff5050; --ora:#c06010; --ora2:#e08030;
  --yel:#a09000; --yel2:#c0b000; --grn:#206040; --grn2:#30a060;
  --blu:#204080; --blu2:#3060c0;
  --med:#c03040; --str:#c06020; --blk:#d02020; --adv:#204090;
  --glow:0 0 20px rgba(32,96,224,0.3);
  --glow2:0 0 40px rgba(32,96,224,0.15);
}}

*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{height:100%;background:var(--bg0);color:var(--t0);overflow:hidden;
  font-family:'JetBrains Mono',monospace;font-size:12px}}
::-webkit-scrollbar{{width:3px;height:3px}}
::-webkit-scrollbar-track{{background:var(--bg0)}}
::-webkit-scrollbar-thumb{{background:var(--b1);border-radius:2px}}

/* GRID */
#app{{display:grid;grid-template-rows:56px 1fr;height:100vh}}
#body{{display:grid;grid-template-columns:240px 1fr;overflow:hidden}}

/* HEADER */
#hdr{{
  background:linear-gradient(90deg,var(--bg1) 0%,rgba(8,9,14,0.95) 100%);
  border-bottom:1px solid var(--b1);
  display:flex;align-items:center;gap:14px;padding:0 20px;
  position:relative;z-index:200;
  box-shadow:0 2px 30px rgba(0,0,0,0.5);
}}
#hdr::before{{
  content:'';position:absolute;bottom:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--acc),var(--acc2),var(--acc),transparent);
  opacity:.6;
}}
.logo{{
  width:32px;height:32px;border-radius:6px;flex-shrink:0;
  background:linear-gradient(135deg,#0a1840,#1840a0);
  border:1px solid var(--acc);
  display:flex;align-items:center;justify-content:center;
  font-size:16px;box-shadow:var(--glow);
  animation:logoPulse 3s ease-in-out infinite;
}}
@keyframes logoPulse{{0%,100%{{box-shadow:0 0 12px rgba(32,96,224,0.4)}}50%{{box-shadow:0 0 24px rgba(64,128,255,0.7)}}}}
.hdr-title{{font-family:'Orbitron',monospace;font-size:13px;font-weight:700;color:var(--t0);letter-spacing:.06em}}
.hdr-ver{{font-size:9px;color:var(--acc2);margin-left:6px;letter-spacing:.08em}}
.hdr-sub{{font-size:9px;color:var(--t2);letter-spacing:.12em;text-transform:uppercase;margin-top:1px}}
#hdr-pills{{display:flex;gap:7px;align-items:center;margin-left:20px}}
.pill{{
  font-size:9px;padding:3px 9px;border-radius:12px;letter-spacing:.06em;
  border:1px solid currentColor;font-weight:500;
}}
#hdr-actions{{margin-left:auto;display:flex;gap:9px;align-items:center}}
#run-btn{{
  background:linear-gradient(135deg,#0a2060,#1840c0);
  border:1px solid var(--acc);border-radius:5px;
  padding:7px 20px;color:var(--acc3);font-family:'JetBrains Mono',monospace;
  font-size:11px;font-weight:700;cursor:pointer;letter-spacing:.08em;
  text-transform:uppercase;transition:all .2s;
  box-shadow:0 0 15px rgba(32,96,224,0.2);
}}
#run-btn:hover:not(:disabled){{
  transform:translateY(-1px);
  box-shadow:0 0 25px rgba(64,128,255,0.5);
  border-color:var(--acc2);
}}
#run-btn:disabled{{opacity:.3;cursor:not-allowed;transform:none}}
.hdr-btn{{
  font-size:10px;color:var(--t1);padding:5px 12px;
  border:1px solid var(--b1);border-radius:4px;cursor:pointer;
  background:transparent;font-family:inherit;transition:all .15s;
}}
.hdr-btn:hover{{border-color:var(--acc);color:var(--acc2);background:rgba(32,96,224,.06)}}
#pb{{position:absolute;bottom:0;left:0;height:2px;width:0%;
  background:linear-gradient(90deg,var(--acc),var(--acc2),var(--acc3));
  transition:width .08s linear;box-shadow:0 0 8px var(--acc2);}}

/* SIDEBAR */
#sb{{
  background:var(--bg1);border-right:1px solid var(--b0);
  display:flex;flex-direction:column;overflow:hidden;
  box-shadow:2px 0 20px rgba(0,0,0,0.3);
}}
#sb-tabs{{display:flex;border-bottom:1px solid var(--b0)}}
.sb-tab{{
  flex:1;padding:9px 0;text-align:center;font-size:9px;cursor:pointer;
  color:var(--t2);border-bottom:2px solid transparent;transition:all .15s;
  text-transform:uppercase;letter-spacing:.1em;
}}
.sb-tab.on{{color:var(--acc2);border-color:var(--acc)}}
#sb-body{{flex:1;overflow-y:auto;padding:12px}}

/* UPLOAD */
#dz{{
  border:1px dashed var(--b1);border-radius:6px;padding:24px 14px;
  text-align:center;cursor:pointer;transition:all .2s;margin-bottom:12px;
  background:linear-gradient(135deg,rgba(8,9,14,.8),rgba(12,13,20,.8));
}}
#dz:hover,#dz.drag{{
  border-color:var(--acc);
  background:rgba(32,96,224,.04);
  box-shadow:inset 0 0 20px rgba(32,96,224,.05);
}}
.dz-ico{{font-size:24px;margin-bottom:8px;opacity:.6}}
.dz-t{{font-family:'Orbitron',monospace;font-size:11px;color:var(--t0);font-weight:600;margin-bottom:4px}}
.dz-s{{font-size:9px;color:var(--t2);line-height:1.5}}
.fc{{
  background:var(--bg2);border:1px solid var(--b0);border-radius:4px;
  padding:7px 10px;margin-bottom:5px;display:flex;align-items:center;gap:8px;
  transition:border-color .15s;
}}
.fc:hover{{border-color:var(--b1)}}
.fc-dot{{width:6px;height:6px;border-radius:50%;background:var(--grn2);flex-shrink:0}}
.fc-name{{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;color:var(--acc2)}}
.fc-meta{{font-size:9px;color:var(--t2);white-space:nowrap}}

/* CHECK LIST */
.cc{{border:1px solid var(--b0);border-radius:4px;overflow:hidden;margin-bottom:7px}}
.cc-hd{{
  background:var(--bg3);padding:7px 11px;display:flex;align-items:center;
  border-bottom:1px solid var(--b0);
}}
.cc-lbl{{font-size:9px;font-weight:700;color:var(--acc2);text-transform:uppercase;letter-spacing:.07em}}
.cr{{display:flex;gap:8px;padding:7px 11px;border-bottom:1px solid var(--bg3);align-items:flex-start}}
.cr:last-child{{border-bottom:none}}
.cr:hover{{background:rgba(255,255,255,.015)}}
.tog{{position:relative;width:28px;height:16px;flex-shrink:0;cursor:pointer;margin-top:2px}}
.tog input{{opacity:0;width:0;height:0}}
.sl{{position:absolute;inset:0;border-radius:16px;background:#0e1022;transition:.2s}}
.sl:before{{content:'';position:absolute;height:10px;width:10px;left:3px;bottom:3px;
  border-radius:50%;background:#252840;transition:.2s}}
.tog input:checked+.sl{{background:rgba(32,96,224,.3);border:1px solid var(--acc)}}
.tog input:checked+.sl:before{{transform:translateX(12px);background:var(--acc2)}}

/* MAIN */
#main{{overflow:hidden;display:flex;flex-direction:column}}
#tabs{{display:flex;border-bottom:1px solid var(--b0);background:var(--bg1);padding:0 18px}}
.tab{{
  padding:10px 16px;font-size:10px;cursor:pointer;color:var(--t2);
  border-bottom:2px solid transparent;transition:all .15s;letter-spacing:.06em;
  text-transform:uppercase;
}}
.tab.on{{color:var(--acc2);border-color:var(--acc);font-weight:600}}
#cnt{{flex:1;overflow-y:auto;padding:18px}}

/* SCOREBOARD */
.sb-grid{{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-bottom:18px}}
.sc{{
  border-radius:5px;padding:12px 10px;text-align:center;
  border:1px solid;position:relative;overflow:hidden;
  transition:transform .2s;cursor:default;
}}
.sc:hover{{transform:translateY(-2px)}}
.sc::before{{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(255,255,255,.03),transparent);
  pointer-events:none;
}}
.sc-val{{font-family:'Orbitron',monospace;font-size:22px;font-weight:700;line-height:1}}
.sc-lbl{{font-size:8px;color:var(--t2);text-transform:uppercase;letter-spacing:.09em;margin-top:4px}}

/* CHARTS */
.chart-panel{{
  background:var(--bg1);border:1px solid var(--b0);border-radius:6px;
  padding:14px;position:relative;overflow:hidden;
}}
.chart-panel::before{{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--acc),transparent);
  opacity:.3;
}}
.ch-lbl{{font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px}}
.br{{display:flex;align-items:center;gap:8px;margin-bottom:5px}}
.br-lbl{{width:100px;font-size:9px;color:var(--t1);text-align:right;flex-shrink:0;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.br-track{{flex:1;background:var(--bg3);border-radius:2px;height:14px;overflow:hidden;border:1px solid var(--b0)}}
.br-fill{{height:100%;border-radius:1px;transition:width .6s cubic-bezier(.4,0,.2,1)}}
.br-cnt{{width:24px;font-size:10px;color:var(--t1)}}

/* FINDINGS */
.gc{{
  border:1px solid var(--b0);border-radius:6px;overflow:hidden;
  margin-bottom:7px;transition:border-color .15s;
}}
.gc:hover{{border-color:var(--b1)}}
.gh{{
  padding:10px 14px;display:flex;align-items:center;gap:10px;
  cursor:pointer;background:var(--bg2);
  transition:background .15s;
}}
.gh:hover{{background:var(--bg3)}}
.fr{{
  border-top:1px solid var(--bg3);display:flex;align-items:center;
  gap:7px;padding:7px 14px;cursor:pointer;transition:background .1s;
}}
.fr:hover{{background:rgba(255,255,255,.02)}}
.fd{{
  border-top:1px solid var(--bg3);padding:12px 14px 14px 38px;
  background:rgba(5,6,10,.6);
  animation:fadeIn .15s ease-out;
}}
@keyframes fadeIn{{from{{opacity:0;transform:translateY(-3px)}}to{{opacity:1;transform:translateY(0)}}}}
.fd-grid{{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:8px}}
.fl2{{font-size:9px;color:var(--t2);letter-spacing:.09em;text-transform:uppercase;margin-bottom:4px}}
.fv{{font-size:10px;color:var(--t1);line-height:1.6}}
.tag{{
  display:inline-block;font-size:8px;padding:2px 6px;border-radius:2px;
  border:1px solid currentColor;white-space:nowrap;font-weight:700;
  letter-spacing:.05em;
}}

/* FILTERS */
.fb{{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;align-items:center}}
.fb-btn{{
  font-size:9px;padding:3px 11px;border-radius:2px;cursor:pointer;
  font-family:inherit;border:1px solid var(--b0);background:transparent;
  color:var(--t2);transition:all .15s;text-transform:uppercase;letter-spacing:.05em;
}}
.fb-btn.on{{font-weight:700}}

/* DOMAIN GRID */
.dgrid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:7px}}
.dc{{
  background:var(--bg1);border:1px solid var(--b0);border-radius:5px;
  padding:10px 12px;transition:all .2s;cursor:default;
}}
.dc:hover{{transform:translateY(-1px);border-color:var(--b1)}}
.dc.hot{{background:rgba(224,48,48,.04);border-color:rgba(224,48,48,.3)}}
.dc-name{{font-family:'Orbitron',monospace;font-size:11px;font-weight:600;margin-bottom:3px}}
.dc-sub{{font-size:9px;color:var(--t2);line-height:1.4}}

/* SUBJECT VIEW */
.subj-card{{border:1px solid var(--b0);border-radius:6px;overflow:hidden;margin-bottom:10px}}
.subj-hdr{{background:var(--bg2);padding:9px 14px;border-bottom:1px solid var(--b0);
  display:flex;align-items:center;gap:10px}}
.tl-row{{display:flex;border-bottom:1px solid var(--bg3)}}
.tl-bar{{width:3px;flex-shrink:0}}
.tl-body{{flex:1;padding:8px 14px}}

/* EMPTY STATE */
.empty{{text-align:center;padding:90px 0}}
.empty-ico{{font-size:40px;margin-bottom:14px;opacity:.2}}
.empty-t{{font-family:'Orbitron',monospace;font-size:14px;color:var(--t2);margin-bottom:8px}}
.empty-s{{font-size:10px;color:var(--t2);opacity:.6}}
.empty-btn{{
  margin-top:20px;background:linear-gradient(135deg,#0a2060,#1840c0);
  border:1px solid var(--acc);border-radius:5px;padding:9px 24px;
  color:var(--acc2);font-family:'JetBrains Mono',monospace;font-size:11px;
  font-weight:700;cursor:pointer;letter-spacing:.08em;text-transform:uppercase;
  transition:all .2s;
}}
.empty-btn:hover{{box-shadow:0 0 20px rgba(64,128,255,.4);transform:translateY(-1px)}}
.badge-cnt{{background:rgba(224,48,48,.2);color:var(--red2);border-radius:8px;
  padding:0 7px;font-size:9px;margin-left:5px;border:1px solid rgba(224,48,48,.3)}}

/* INPUTS */
input[type=text],input[type=search],select,textarea{{
  background:var(--bg2);border:1px solid var(--b0);border-radius:3px;
  color:var(--t0);font-family:'JetBrains Mono',monospace;font-size:10px;
  padding:5px 9px;outline:none;transition:border-color .15s;
}}
input:focus,select:focus{{border-color:var(--acc)}}

/* RUNNING STATE */
.running-overlay{{text-align:center;padding:80px 0}}
.run-ico{{font-size:30px;animation:spin 2s linear infinite;display:inline-block;margin-bottom:16px}}
@keyframes spin{{to{{transform:rotate(360deg)}}}}
.run-t{{font-family:'Orbitron',monospace;font-size:14px;color:var(--acc2);margin-bottom:8px}}
.run-lbl{{font-size:10px;color:var(--t2);min-height:18px}}
.progress-track{{width:300px;margin:14px auto 0;background:var(--bg2);
  border-radius:2px;height:3px;overflow:hidden;border:1px solid var(--b0)}}
.progress-fill{{height:100%;background:linear-gradient(90deg,var(--acc),var(--acc2),var(--acc3));
  transition:width .1s linear;box-shadow:0 0 6px var(--acc2);width:0%}}

/* GLOW EFFECTS */
.glow-red{{box-shadow:0 0 15px rgba(224,48,48,.2)}}
.glow-ora{{box-shadow:0 0 15px rgba(192,96,16,.2)}}
.glow-blu{{box-shadow:0 0 15px rgba(32,96,224,.2)}}

/* SCAN LINE EFFECT */
#cnt::before{{
  content:'';position:fixed;top:0;left:0;right:0;bottom:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,.03) 2px,rgba(0,0,0,.03) 4px);
  pointer-events:none;z-index:0;
}}
#cnt > *{{position:relative;z-index:1}}
</style>
</head>
<body>
<div id="app">

<!-- HEADER -->
<div id="hdr">
  <div class="logo">+</div>
  <div>
    <div class="hdr-title">Clinical Integrity Suite <span class="hdr-ver">v4.0</span></div>
    <div class="hdr-sub">Beyond-P21 &bull; {check_count} Checks &bull; 35+ Domains &bull; FDA JumpStart</div>
  </div>
  <div id="hdr-pills">
    <span class="pill" style="color:#3a8050" id="pill-files">0 files</span>
    <span class="pill" style="color:var(--acc)" id="pill-checks">{check_count} checks</span>
    <span class="pill" id="pill-findings" style="display:none;color:var(--red2)">0 findings</span>
  </div>
  <div id="hdr-actions">
    <span id="run-ts" style="font-size:9px;color:var(--t2);display:none"></span>
    <button class="hdr-btn" onclick="dlReport()">Download Report</button>
    <button id="run-btn" onclick="startRun()">Run Validation</button>
  </div>
  <div id="pb"></div>
</div>

<!-- BODY -->
<div id="body">

<!-- SIDEBAR -->
<div id="sb">
  <div id="sb-tabs">
    <div class="sb-tab on" id="stab-up" onclick="switchSB('up')">Files</div>
    <div class="sb-tab" id="stab-ch" onclick="switchSB('ch')">Checks</div>
  </div>
  <div id="sb-body">

    <!-- UPLOAD PANEL -->
    <div id="panel-up">
      <div id="dz" onclick="document.getElementById('fi').click()"
           ondragover="dzOver(event)" ondragleave="dzLeave(event)" ondrop="dzDrop(event)">
        <div class="dz-ico">+</div>
        <div class="dz-t">Drop Files Here</div>
        <div class="dz-s">SAS7BDAT &bull; XPT &bull; CSV &bull; XLSX<br>XML/Define &bull; JSON &bull; PDF</div>
        <div class="dz-s" style="margin-top:5px;color:var(--acc2)">or click to browse</div>
      </div>
      <input type="file" id="fi" multiple
        accept=".sas7bdat,.xpt,.csv,.xlsx,.xls,.json,.xml,.txt,.pdf"
        onchange="addFiles(this.files)" style="display:none">
      <div id="flist"></div>
      <div id="f-actions" style="display:none;margin-top:7px;display:flex;gap:6px">
        <button class="hdr-btn" style="font-size:9px;color:var(--red2);border-color:rgba(224,48,48,.3)"
          onclick="clearFiles()">Clear All</button>
      </div>
    </div>

    <!-- CHECKS PANEL -->
    <div id="panel-ch" style="display:none">
      <div style="display:flex;gap:5px;margin-bottom:7px">
        <input type="search" id="csrch" placeholder="Search checks..." style="width:100%" oninput="renderChecks()">
      </div>
      <div style="display:flex;gap:4px;margin-bottom:7px">
        <select id="clf" style="flex:1;font-size:9px" onchange="renderChecks()">
          <option value="">All Layers</option>
          <option>Structure</option>
          <option>Trial Design</option>
          <option>P21-Base</option>
          <option>Beyond-P21</option>
        </select>
        <select id="cdf" style="flex:1;font-size:9px" onchange="renderChecks()">
          <option value="">All Domains</option>
          <option>DM</option><option>AE</option><option>DS</option><option>EX</option>
          <option>LB</option><option>VS</option><option>CM</option><option>EG</option>
          <option>TR</option><option>TU</option><option>RS</option><option>SS</option>
          <option>SV</option><option>PC</option><option>PP</option><option>QS</option>
          <option>MH</option><option>PR</option><option>TS</option><option>SE</option>
        </select>
      </div>
      <div style="display:flex;gap:5px;margin-bottom:10px">
        <button class="hdr-btn" style="font-size:9px" onclick="tgAll(true)">Enable All</button>
        <button class="hdr-btn" style="font-size:9px" onclick="tgAll(false)">Disable All</button>
        <span id="en-count" style="font-size:9px;color:var(--t2);align-self:center;margin-left:auto"></span>
      </div>
      <div id="chlist"></div>
    </div>
  </div>
</div>

<!-- MAIN -->
<div id="main">
  <div id="tabs">
    <div class="tab on" id="tab-dash" onclick="switchTab('dash')">Dashboard</div>
    <div class="tab" id="tab-rep" onclick="switchTab('rep')">Integrity Report <span id="fbadge" class="badge-cnt" style="display:none"></span></div>
    <div class="tab" id="tab-subj" onclick="switchTab('subj')">Subject View</div>
    <div class="tab" id="tab-dom" onclick="switchTab('dom')">Domain Map</div>
  </div>
  <div id="cnt">

    <!-- DASHBOARD -->
    <div id="view-dash">
      <div id="d-empty" class="empty">
        <div class="empty-ico">+</div>
        <div class="empty-t">SDTM Clinical Integrity Suite</div>
        <div class="empty-s">{check_count} validation checks &bull; 35+ domains &bull; FDA JumpStart</div>
        <div class="empty-s" style="margin-top:6px">Upload datasets or run with pre-loaded sample findings</div>
        <button class="empty-btn" onclick="startRun()">Run Validation</button>
      </div>
      <div id="d-running" class="running-overlay" style="display:none">
        <div class="run-ico">*</div>
        <div class="run-t">Executing Validation Engine</div>
        <div class="run-lbl" id="run-lbl">Initializing...</div>
        <div class="progress-track"><div class="progress-fill" id="pbar"></div></div>
        <div id="run-pct" style="margin-top:9px;font-size:10px;color:var(--t2)">0%</div>
      </div>
      <div id="d-res" style="display:none">
        <div class="sb-grid" id="scoreboard"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
          <div class="chart-panel"><div class="ch-lbl">By Risk Category</div><div id="ch-risk"></div></div>
          <div class="chart-panel"><div class="ch-lbl">By Severity Level</div><div id="ch-sev"></div></div>
        </div>
        <div style="display:grid;grid-template-columns:2fr 1fr;gap:14px">
          <div class="chart-panel"><div class="ch-lbl">By SDTM Domain</div><div id="ch-dom"></div></div>
          <div class="chart-panel"><div class="ch-lbl">By Category</div><div id="ch-cat"></div></div>
        </div>
      </div>
    </div>

    <!-- REPORT -->
    <div id="view-rep" style="display:none">
      <div id="rep-empty" class="empty">
        <div class="empty-ico">!</div>
        <div class="empty-t">No Validation Run Yet</div>
        <div class="empty-s">Click Run Validation to generate findings</div>
      </div>
      <div id="rep-cnt" style="display:none">
        <div class="fb" id="rfb">
          <button class="fb-btn on" id="rfb-ALL" onclick="setRF('ALL',this)">All</button>
          <button class="fb-btn" onclick="setRF('submission-blocker',this)"
            style="color:var(--red2);border-color:rgba(224,48,48,.3)" id="rfb-sb">Blockers</button>
          <button class="fb-btn" onclick="setRF('medical-concern',this)"
            style="color:var(--med);border-color:rgba(192,48,64,.3)" id="rfb-mc">Medical</button>
          <button class="fb-btn" onclick="setRF('structural',this)"
            style="color:var(--ora2);border-color:rgba(192,96,32,.3)" id="rfb-st">Structural</button>
          <button class="fb-btn" onclick="setRF('advisory',this)"
            style="color:var(--acc2);border-color:rgba(32,96,224,.3)" id="rfb-ad">Advisory</button>
          <label style="font-size:9px;color:var(--t2);display:flex;align-items:center;gap:5px;margin-left:auto;cursor:pointer">
            <input type="checkbox" id="hw" onchange="renderRep()"> Hide waived
          </label>
          <span id="fc-count" style="font-size:9px;color:var(--t2)"></span>
        </div>
        <div id="r-roots"></div>
        <div id="r-subjs"></div>
      </div>
    </div>

    <!-- SUBJECT VIEW -->
    <div id="view-subj" style="display:none">
      <div id="subj-empty" class="empty">
        <div class="empty-ico">~</div>
        <div class="empty-t">Subject Timeline View</div>
        <div class="empty-s">Mirrors how FDA medical reviewers read a subject narrative</div>
      </div>
      <div id="subj-cnt" style="display:none">
        <div class="fb">
          <input type="search" id="ss" placeholder="Filter by subject ID..." style="width:200px" oninput="renderSubj()">
          <span id="subj-ct" style="font-size:9px;color:var(--t2);margin-left:auto"></span>
        </div>
        <div id="stml"></div>
      </div>
    </div>

    <!-- DOMAIN MAP -->
    <div id="view-dom" style="display:none">
      <div style="font-family:'Orbitron',monospace;font-size:14px;color:var(--t0);font-weight:700;margin-bottom:4px">Domain Coverage Matrix</div>
      <div style="font-size:9px;color:var(--t2);margin-bottom:14px;text-transform:uppercase;letter-spacing:.1em">{check_count} checks registered across 35+ SDTM domains</div>
      <div class="dgrid" id="dgrid"></div>
    </div>

  </div>
</div>
</div>
</div>

<script>
// ============================================================
// STATE
// ============================================================
var checks = [];
var findings = [];
var enabled = {{}};
var rf = 'ALL';
var expG = {{}};
var expF = {{}};
var sse = null;

var RISK_C = {{'submission-blocker':'#e03030','medical-concern':'#c03040','structural':'#c06010','advisory':'#204090'}};
var SEV_C = {{'REJECT':'#e03030','CRITICAL':'#c03040','ERROR':'#c06010','WARNING':'#a09000','NOTICE':'#204090'}};

function esc(s){{
  if(!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}}
function rc(r){{return RISK_C[r]||'#444'}}
function sc(s){{return SEV_C[s]||'#444'}}
function si(s){{return {{REJECT:'!',CRITICAL:'x',ERROR:'^',WARNING:'~',NOTICE:'i'}}[s]||'?'}}

// ============================================================
// INIT
// ============================================================
window.addEventListener('DOMContentLoaded', function(){{
  loadChecks();
  loadFiles();
  renderDomGrid();
  setupSSE();
}});

function setupSSE(){{
  try{{
    sse = new EventSource('/api/events');
    sse.addEventListener('progress', function(e){{
      var d = JSON.parse(e.data);
      document.getElementById('pb').style.width = d.pct + '%';
      document.getElementById('pbar').style.width = d.pct + '%';
      document.getElementById('run-pct').textContent = Math.round(d.pct) + '%';
      if(d.label) document.getElementById('run-lbl').textContent = d.label.slice(0,60);
    }});
    sse.addEventListener('done', function(e){{
      var d = JSON.parse(e.data);
      finishRun(d);
    }});
  }} catch(e){{}}
}}

// ============================================================
// CHECKS
// ============================================================
function loadChecks(){{
  fetch('/api/checks').then(function(r){{return r.json();}}).then(function(data){{
    checks = data;
    data.forEach(function(c){{enabled[c.id] = c.enabled;}});
    renderChecks();
    updatePills();
  }});
}}

function renderChecks(){{
  var srch = (document.getElementById('csrch').value||'').toLowerCase();
  var lf = document.getElementById('clf').value;
  var df = document.getElementById('cdf').value;
  var filt = checks.filter(function(c){{
    if(lf && c.layer !== lf) return false;
    if(df && !c.domain.split('/').includes(df)) return false;
    if(srch && !c.label.toLowerCase().includes(srch) && !c.id.toLowerCase().includes(srch)) return false;
    return true;
  }});
  var cats = {{}};
  filt.forEach(function(c){{if(!cats[c.cat])cats[c.cat]=[];cats[c.cat].push(c);}});
  var en = Object.values(enabled).filter(Boolean).length;
  document.getElementById('en-count').textContent = en + '/' + checks.length;
  document.getElementById('chlist').innerHTML = Object.entries(cats).map(function(e){{
    var cat=e[0], cs=e[1];
    var onCnt = cs.filter(function(c){{return enabled[c.id];}}).length;
    return '<div class="cc"><div class="cc-hd">'
      +'<span class="cc-lbl">'+esc(cat)+'</span>'
      +'<span style="margin-left:auto;font-size:9px;color:var(--t2)">'+onCnt+'/'+cs.length+'</span></div>'
      +cs.map(function(c){{
        return '<div class="cr" style="opacity:'+(enabled[c.id]?1:0.35)+'">'
          +'<label class="tog"><input type="checkbox" '+(enabled[c.id]?'checked':'')+' onchange="tgCheck(\''+c.id+'\',this.checked)"><span class="sl"></span></label>'
          +'<div style="flex:1;min-width:0">'
          +'<div style="font-size:9px;color:var(--t0);font-weight:500;line-height:1.4">'+esc(c.label)+'</div>'
          +'<div style="display:flex;gap:3px;margin-top:3px;flex-wrap:wrap">'
          +'<span class="tag" style="color:'+sc(c.sev)+'">'+c.sev+'</span>'
          +'<span style="font-size:8px;color:var(--t2)">'+c.id+'</span>'
          +'<span style="font-size:8px;color:var(--t2)">'+c.domain+'</span>'
          +'</div></div></div>';
      }}).join('')+'</div>';
  }}).join('');
}}

function tgCheck(id, v){{
  enabled[id] = v;
  fetch('/api/toggle',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{id:id,enabled:v}})}});
  renderChecks();updatePills();
}}
function tgAll(v){{
  Object.keys(enabled).forEach(function(k){{enabled[k]=v;}});
  fetch('/api/toggle',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{id:'__all__',enabled:v}})}});
  renderChecks();updatePills();
}}

// ============================================================
// FILES
// ============================================================
function dzOver(e){{e.preventDefault();document.getElementById('dz').classList.add('drag');}}
function dzLeave(e){{document.getElementById('dz').classList.remove('drag');}}
function dzDrop(e){{e.preventDefault();document.getElementById('dz').classList.remove('drag');addFiles(e.dataTransfer.files);}}

function addFiles(files){{
  if(!files||!files.length) return;
  var fd = new FormData();
  for(var i=0;i<files.length;i++) fd.append('files', files[i], files[i].name);
  fetch('/api/upload',{{method:'POST',body:fd}}).then(function(r){{return r.json();}}).then(function(r){{
    if(r.ok) loadFiles();
  }});
}}

function loadFiles(){{
  fetch('/api/files').then(function(r){{return r.json();}}).then(function(data){{
    var names = Object.keys(data);
    var el = document.getElementById('flist');
    var fa = document.getElementById('f-actions');
    fa.style.display = names.length ? 'flex' : 'none';
    var icons = {{sas7bdat:'[D]',xpt:'[X]',csv:'[C]',xlsx:'[E]',xls:'[E]',json:'[J]',xml:'[M]',pdf:'[P]'}};
    el.innerHTML = names.map(function(n){{
      var m = data[n];
      var ext = (n.split('.').pop()||'').toLowerCase();
      var ico = icons[ext]||'[?]';
      var sz = m.size<1024?m.size+' B':m.size<1048576?(m.size/1024).toFixed(1)+' KB':(m.size/1048576).toFixed(1)+' MB';
      return '<div class="fc"><span style="color:var(--acc2);flex-shrink:0;font-size:10px">'+ico+'</span>'
        +'<div class="fc-name">'+esc(n)+'</div>'
        +'<div class="fc-meta">'+m.rows+' rows &bull; '+sz+'</div></div>';
    }}).join('');
    updatePills();
    renderDomGrid();
  }});
}}

function clearFiles(){{
  fetch('/api/clear',{{method:'POST'}}).then(function(){{
    loadFiles();findings=[];resetViews();updatePills();
  }});
}}
function resetViews(){{
  document.getElementById('d-empty').style.display='block';
  document.getElementById('d-res').style.display='none';
  document.getElementById('rep-empty').style.display='block';
  document.getElementById('rep-cnt').style.display='none';
  document.getElementById('subj-empty').style.display='block';
  document.getElementById('subj-cnt').style.display='none';
  document.getElementById('fbadge').style.display='none';
  document.getElementById('pill-findings').style.display='none';
}}

// ============================================================
// VALIDATION
// ============================================================
function startRun(){{
  document.getElementById('run-btn').disabled = true;
  document.getElementById('d-empty').style.display = 'none';
  document.getElementById('d-res').style.display = 'none';
  document.getElementById('d-running').style.display = 'block';
  document.getElementById('pbar').style.width = '0%';
  document.getElementById('pb').style.width = '0%';
  document.getElementById('run-pct').textContent = '0%';
  document.getElementById('run-lbl').textContent = 'Initializing...';
  fetch('/api/run',{{method:'POST'}});
  // Fallback polling if SSE fails
  var poll = setInterval(function(){{
    fetch('/api/status').then(function(r){{return r.json();}}).then(function(s){{
      if(!s.running && s.run_count > 0){{
        clearInterval(poll);
        if(findings.length === 0) loadFindings(s);
      }}
    }});
  }}, 800);
}}

function finishRun(d){{
  document.getElementById('run-btn').disabled = false;
  document.getElementById('pb').style.width = '0%';
  document.getElementById('d-running').style.display = 'none';
  if(d.ts){{
    var ts = document.getElementById('run-ts');
    ts.textContent = 'Run: '+d.ts; ts.style.display='inline';
  }}
  loadFindings(d);
}}

function loadFindings(status){{
  fetch('/api/findings').then(function(r){{return r.json();}}).then(function(data){{
    findings = data;
    renderDash();
    renderRep();
    renderSubj();
    renderDomGrid();
    updatePills();
    var act = findings.filter(function(f){{return !f.waived;}}).length;
    var badge = document.getElementById('fbadge');
    if(act){{badge.textContent=act;badge.style.display='inline';}}
  }});
}}

// ============================================================
// DASHBOARD
// ============================================================
function renderDash(){{
  document.getElementById('d-res').style.display = 'block';
  var act = findings.filter(function(f){{return !f.waived;}});
  var w = findings.filter(function(f){{return f.waived;}});
  var br = cntBy(act,'risk'), bs = cntBy(act,'sev');
  var bd = cntDom(act), bc = cntBy(act,'cat');

  // Scoreboard
  var cards = [
    {{l:'Active',v:act.length,c:'#b0b5c8',bg:'rgba(176,181,200,0.06)'}},
    {{l:'Blockers',v:br['submission-blocker']||0,c:'#e03030',bg:'rgba(224,48,48,0.08)'}},
    {{l:'Medical',v:br['medical-concern']||0,c:'#c03040',bg:'rgba(192,48,64,0.08)'}},
    {{l:'Structural',v:br['structural']||0,c:'#c06010',bg:'rgba(192,96,16,0.08)'}},
    {{l:'Advisory',v:br['advisory']||0,c:'#3060c0',bg:'rgba(48,96,192,0.08)'}},
    {{l:'Waived',v:w.length,c:'#208050',bg:'rgba(32,128,80,0.08)'}},
  ];
  document.getElementById('scoreboard').innerHTML = cards.map(function(s){{
    return '<div class="sc" style="border-color:'+s.c+'33;background:'+s.bg+'">'
      +'<div class="sc-val" style="color:'+s.c+'">'+s.v+'</div>'
      +'<div class="sc-lbl">'+s.l+'</div></div>';
  }}).join('');
  document.getElementById('ch-risk').innerHTML = barChart(br,RISK_C);
  document.getElementById('ch-sev').innerHTML = barChart(bs,SEV_C);
  document.getElementById('ch-dom').innerHTML = barChart(bd,null);
  document.getElementById('ch-cat').innerHTML = barChart(bc,null,8);
}}

function barChart(obj,cm,maxItems){{
  var ents = Object.entries(obj).sort(function(a,b){{return b[1]-a[1];}});
  if(maxItems) ents = ents.slice(0,maxItems);
  if(!ents.length) return '<div style="color:var(--t2);font-size:10px;padding:6px">No data</div>';
  var mx = ents[0][1];
  return ents.map(function(e){{
    var pct = mx ? Math.round(e[1]/mx*100) : 0;
    var c = (cm||{{}})[e[0]]||'var(--acc)';
    var lbl = e[0].length>14?e[0].slice(0,13)+'..':e[0];
    return '<div class="br">'
      +'<div class="br-lbl">'+esc(lbl)+'</div>'
      +'<div class="br-track"><div class="br-fill" style="width:'+pct+'%;background:'+c+'"></div></div>'
      +'<div class="br-cnt">'+e[1]+'</div></div>';
  }}).join('');
}}

function cntBy(arr,k){{var m={{}};arr.forEach(function(x){{var v=x[k];m[v]=(m[v]||0)+1;}});return m;}}
function cntDom(arr){{var m={{}};arr.forEach(function(f){{var d=f.domain.split('/')[0];m[d]=(m[d]||0)+1;}});return m;}}
function worst(arr){{
  if(arr.some(function(f){{return f.risk==='submission-blocker';}})) return 'submission-blocker';
  if(arr.some(function(f){{return f.risk==='medical-concern';}})) return 'medical-concern';
  if(arr.some(function(f){{return f.risk==='structural';}})) return 'structural';
  return 'advisory';
}}

// ============================================================
// INTEGRITY REPORT
// ============================================================
function renderRep(){{
  if(!findings.length) return;
  document.getElementById('rep-empty').style.display='none';
  document.getElementById('rep-cnt').style.display='block';
  var hw = document.getElementById('hw').checked;
  var vis = rf==='ALL' ? findings : findings.filter(function(f){{return f.risk===rf;}});
  if(hw) vis = vis.filter(function(f){{return !f.waived;}});
  document.getElementById('fc-count').textContent = vis.length + ' findings';

  // Root groups
  var roots={{}};
  var solo=[];
  vis.forEach(function(f){{
    if(f.root){{if(!roots[f.root])roots[f.root]=[];roots[f.root].push(f);}}
    else solo.push(f);
  }});

  var rh='';
  if(Object.keys(roots).length){{
    rh='<div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;display:flex;align-items:center;gap:6px"><span style="height:1px;width:14px;background:var(--b0)"></span>Root-Cause Clusters<span style="height:1px;flex:1;background:var(--b0)"></span></div>';
    Object.entries(roots).forEach(function(e){{
      var root=e[0],rf2=e[1];
      var w=worst(rf2), wc=rc(w);
      var gid='r-'+root.replace(/[^a-z0-9]/gi,'_');
      var open=expG[gid];
      var subjs=[...new Set(rf2.map(function(f){{return f.subj;}}))]
                 .map(function(s){{return s==='ALL'?'GLOBAL':'SUBJ-'+s;}}).join(', ');
      rh+='<div class="gc" style="border-color:'+wc+'44;margin-bottom:7px">'
        +'<div class="gh" onclick="tgG(\''+gid+'\')">'
        +'<div style="width:5px;height:5px;border-radius:50%;background:'+wc+';flex-shrink:0;box-shadow:0 0 6px '+wc+'"></div>'
        +'<div style="flex:1"><div style="font-size:11px;color:var(--t0);font-weight:600">Root: '+esc(root)+'</div>'
        +'<div style="font-size:9px;color:var(--t2);margin-top:1px">'+rf2.length+' findings &bull; '+esc(subjs.slice(0,60))+'</div></div>'
        +'<span class="tag" style="color:'+wc+'">'+w.replace(/-/g,' ').toUpperCase()+'</span>'
        +'<span style="color:var(--t2);font-size:10px;margin-left:5px">'+(open?'v':'^')+'</span></div>'
        +(open?rf2.map(function(f){{return fRow(f,gid);}}).join(''):'')
        +'</div>';
    }});
  }}
  document.getElementById('r-roots').innerHTML=rh;

  // Subject groups
  var sm={{}};
  solo.forEach(function(f){{
    var k=f.subj==='ALL'?'__global__':f.subj;
    if(!sm[k])sm[k]=[];sm[k].push(f);
  }});
  var sk=Object.keys(sm).sort(function(a,b){{
    return (worst(sm[a])==='medical-concern'?0:1)-(worst(sm[b])==='medical-concern'?0:1);
  }});
  var sh='';
  if(sk.length){{
    sh='<div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;display:flex;align-items:center;gap:6px"><span style="height:1px;width:14px;background:var(--b0)"></span>Subject Groups<span style="height:1px;flex:1;background:var(--b0)"></span></div>';
    sk.forEach(function(s){{
      var sf=sm[s];
      var w=worst(sf), wc=rc(w);
      var gid='s-'+s;
      var open=expG[gid];
      var doms=[...new Set(sf.map(function(f){{return f.domain.split('/')[0];}}))]
                .slice(0,5);
      var lbl=s==='__global__'?'GLOBAL / Systematic':'SUBJ-'+s;
      sh+='<div class="gc" style="border-color:'+(w!=='structural'?wc+'33':'var(--b0)')+';margin-bottom:5px">'
        +'<div class="gh" onclick="tgG(\''+gid+'\')">'
        +'<div style="width:4px;height:20px;border-radius:2px;background:'+wc+';flex-shrink:0;opacity:.8;box-shadow:0 0 4px '+wc+'"></div>'
        +'<div style="flex:1;min-width:0">'
        +'<div style="display:flex;align-items:center;gap:8px">'
        +'<span style="font-size:11px;color:var(--acc2);font-weight:700;letter-spacing:.03em">'+esc(lbl)+'</span>'
        +'<span style="font-size:10px;color:'+wc+'">'+sf.length+' finding'+(sf.length>1?'s':'')+'</span></div>'
        +'<div style="display:flex;gap:3px;margin-top:2px">'+doms.map(function(d){{return '<span class="tag" style="color:var(--t2);font-size:8px">'+esc(d)+'</span>';}}).join('')+'</div>'
        +'</div>'
        +'<span class="tag" style="color:'+wc+'">'+w.replace(/-/g,' ').toUpperCase()+'</span>'
        +'<span style="color:var(--t2);font-size:10px;margin-left:5px">'+(open?'v':'^')+'</span></div>'
        +(open?sf.map(function(f){{return fRow(f,gid);}}).join(''):'')
        +'</div>';
    }});
  }} else {{
    sh='<div class="empty"><div class="empty-s">No findings match current filter</div></div>';
  }}
  document.getElementById('r-subjs').innerHTML=sh;
}}

function fRow(f,gid){{
  var fid=f.fid;
  var open=expF[fid];
  var wc=rc(f.risk), sc2=sc(f.sev);
  var op=f.waived?'opacity:.3':'';
  var ab=f.actual
    ?'<span style="font-size:8px;background:rgba(32,128,80,.2);color:#30a060;border:1px solid rgba(32,128,80,.4);border-radius:2px;padding:0 3px;margin-left:3px">ACTUAL</span>'
    :'<span style="font-size:8px;background:rgba(32,64,192,.1);color:var(--acc2);border:1px solid rgba(32,64,192,.3);border-radius:2px;padding:0 3px;margin-left:3px">DEMO</span>';
  var r='<div class="fr" style="'+op+'" onclick="tgF(\''+fid+'\',\''+gid+'\')">'
    +'<span style="font-size:9px;flex-shrink:0;font-weight:700;color:'+sc2+'">'+si(f.sev)+'</span>'
    +'<span class="tag" style="color:'+sc2+';flex-shrink:0;font-size:8px">'+esc(f.sev)+'</span>'
    +'<span style="color:var(--acc2);font-size:10px;font-weight:700;flex-shrink:0;min-width:68px;letter-spacing:.02em">'+(f.subj==='ALL'?'GLOBAL':'SUBJ-'+f.subj)+'</span>'
    +'<span style="color:var(--t2);font-size:9px;flex-shrink:0;min-width:36px">'+esc(f.domain.split('/')[0])+'</span>'
    +'<span style="flex:1;color:var(--t1);font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:'+(open?'normal':'nowrap')+'">'+esc(f.label)+' &mdash; '+esc(f.detail)+'</span>'
    +(f.waived?'<span class="tag" style="color:var(--grn2);font-size:8px;flex-shrink:0">WAIVED</span>':'')+ab
    +'<span style="color:var(--t3);font-size:10px;flex-shrink:0;margin-left:4px">'+(open?'v':'^')+'</span></div>';
  if(open){{
    r+='<div class="fd">'
      +'<div class="fd-grid">'
      +'<div><div class="fl2">Check Definition</div><div class="fv">'+esc(f.label)+'</div>'
      +'<div style="margin-top:6px;display:flex;gap:3px;flex-wrap:wrap">'
      +'<span class="tag" style="color:'+sc2+'">'+esc(f.sev)+'</span>'
      +'<span class="tag" style="color:'+wc+'">'+f.risk.replace(/-/g,' ').toUpperCase()+'</span>'
      +'<span class="tag" style="color:var(--t2)">'+esc(f.layer)+'</span>'
      +'<span class="tag" style="color:var(--t2)">'+esc(f.checkId)+'</span>'
      +f.domain.split('/').map(function(d){{return '<span class="tag" style="color:var(--t2)">'+esc(d)+'</span>';}}).join('')
      +'</div>'
      +'<div style="margin-top:5px;font-size:9px;color:var(--t2)">Source: '+esc(f.source)+'</div></div>'
      +'<div><div class="fl2">Finding Detail</div><div class="fv" style="color:#9098b8">'+esc(f.detail)+'</div>'
      +(f.root?'<div style="margin-top:5px;font-size:9px;color:var(--t2)">Root Cause: '+esc(f.root)+'</div>':'')
      +'</div></div>'
      +'<div style="margin-top:10px;border-top:1px solid var(--b0);padding-top:9px;display:flex;gap:8px;align-items:center">'
      +'<div style="font-size:9px;color:var(--t2);flex-shrink:0;text-transform:uppercase;letter-spacing:.06em">cSDRG Note:</div>'
      +'<input type="text" id="note-'+fid+'" placeholder="Document waiver explanation for cSDRG Section 4..." value="'+esc(f.waiver_note||'')+'" style="flex:1;font-size:10px">'
      +'<button onclick="waiveF(\''+fid+'\')" style="font-size:9px;padding:4px 12px;border-radius:3px;cursor:pointer;font-family:inherit;'
      +'border:1px solid '+(f.waived?'rgba(32,128,80,.5)':'rgba(192,48,48,.5)')+';'
      +'color:'+(f.waived?'#30a060':'#c03040')+';'
      +'background:'+(f.waived?'rgba(32,128,80,.1)':'rgba(192,48,64,.1)')+'">'+(f.waived?'Unwaive':'Waive')+'</button>'
      +'</div></div>';
  }}
  return r;
}}

function tgG(gid){{expG[gid]=!expG[gid];renderRep();}}
function tgF(fid,gid){{expF[fid]=!expF[fid];renderRep();}}

function setRF(r,btn){{
  rf=r;
  document.querySelectorAll('.fb-btn').forEach(function(b){{b.classList.remove('on');}});
  if(btn)btn.classList.add('on');
  renderRep();
}}

function waiveF(fid){{
  var note=(document.getElementById('note-'+fid)||{{}}).value||'';
  var f=findings.find(function(x){{return x.fid===fid;}});
  if(f){{f.waived=!f.waived;f.waiver_note=note;}}
  fetch('/api/waive',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{fid:fid,note:note}})}});
  renderDash();renderRep();renderSubj();updatePills();
}}

// ============================================================
// SUBJECT VIEW
// ============================================================
function renderSubj(){{
  if(!findings.length) return;
  document.getElementById('subj-empty').style.display='none';
  document.getElementById('subj-cnt').style.display='block';
  var srch=(document.getElementById('ss').value||'').toLowerCase();
  var act=findings.filter(function(f){{return !f.waived;}});
  var sm={{}};
  act.forEach(function(f){{
    var k=f.subj==='ALL'?'GLOBAL':f.subj;
    if(!sm[k])sm[k]=[];sm[k].push(f);
  }});
  var filt=Object.entries(sm).filter(function(e){{return !srch||e[0].toLowerCase().includes(srch);}});
  document.getElementById('subj-ct').textContent = filt.length+' subjects';
  document.getElementById('stml').innerHTML = filt.map(function(e){{
    var subj=e[0],sf=e[1];
    var w=worst(sf),wc=rc(w);
    var doms=[...new Set(sf.map(function(f){{return f.domain.split('/')[0];}}))]
              .slice(0,6);
    return '<div class="subj-card" style="border-color:'+wc+'33;margin-bottom:10px">'
      +'<div class="subj-hdr">'
      +'<div style="width:7px;height:7px;border-radius:50%;background:'+wc+';box-shadow:0 0 6px '+wc+'"></div>'
      +'<span style="font-family:Orbitron,monospace;font-size:12px;color:var(--t0);font-weight:600">Subject '+esc(subj)+'</span>'
      +'<span style="font-size:10px;color:'+wc+'">'+sf.length+' finding'+(sf.length>1?'s':'')+'</span>'
      +'<div style="margin-left:auto;display:flex;gap:3px">'+doms.map(function(d){{return '<span class="tag" style="color:var(--t2);font-size:8px">'+esc(d)+'</span>';}}).join('')+'</div></div>'
      +sf.map(function(f){{
        return '<div class="tl-row">'
          +'<div class="tl-bar" style="background:'+rc(f.risk)+'80"></div>'
          +'<div class="tl-body">'
          +'<div style="display:flex;align-items:flex-start;gap:7px">'
          +'<span style="font-size:9px;flex-shrink:0;color:'+sc(f.sev)+';font-weight:700">'+si(f.sev)+'</span>'
          +'<div style="flex:1">'
          +'<div style="font-size:10px;color:var(--t0);font-weight:500">'+esc(f.label)+'</div>'
          +'<div style="font-size:9px;color:var(--t2);margin-top:2px;line-height:1.5">'+esc(f.detail)+'</div>'
          +'<div style="font-size:8px;color:var(--t3);margin-top:2px">'+esc(f.checkId)+' &bull; '+esc(f.domain)+' &bull; '+esc(f.cat)+'</div>'
          +'</div><span class="tag" style="color:'+sc(f.sev)+';font-size:8px;flex-shrink:0">'+esc(f.sev)+'</span>'
          +'</div></div></div>';
      }}).join('')+'</div>';
  }}).join('');
}}

// ============================================================
// DOMAIN MAP
// ============================================================
function renderDomGrid(){{
  var allDoms=[...new Set(checks.flatMap(function(c){{return c.domain.split('/');}}))]
               .filter(function(d){{return d && d!=='ALL' && d!=='DEFINE' && d!=='SUPP' && d!=='RELREC';}})
               .sort();
  var actDoms={{}};
  findings.filter(function(f){{return !f.waived;}}).forEach(function(f){{
    f.domain.split('/').forEach(function(d){{actDoms[d]=(actDoms[d]||0)+1;}});
  }});
  document.getElementById('dgrid').innerHTML=allDoms.map(function(d){{
    var dc=checks.filter(function(c){{return c.domain.split('/').includes(d);}});
    var en=dc.filter(function(c){{return enabled[c.id];}}).length;
    var hasCrit=dc.some(function(c){{return c.sev==='CRITICAL'||c.sev==='REJECT';}});
    var fc=actDoms[d]||0;
    var hot=fc>0;
    return '<div class="dc'+(hot?' hot':'')+'">'
      +'<div class="dc-name" style="color:'+(hot?'#e05050':'var(--acc2)')+'">'+esc(d)+'</div>'
      +'<div class="dc-sub">'+dc.length+' checks &bull; '+en+' on</div>'
      +(hasCrit?'<div class="dc-sub" style="color:#e03030;margin-top:2px">! CRITICAL rules</div>':'')
      +(hot?'<div class="dc-sub" style="color:#e05050;margin-top:2px">^ '+fc+' active</div>'
           :'<div class="dc-sub" style="color:var(--grn2);margin-top:2px">ok Clear</div>')
      +'</div>';
  }}).join('');
}}

// ============================================================
// TABS / SIDEBAR
// ============================================================
function switchTab(t){{
  ['dash','rep','subj','dom'].forEach(function(v){{
    document.getElementById('view-'+v).style.display=v===t?'block':'none';
    document.getElementById('tab-'+v).classList.toggle('on',v===t);
  }});
  if(t==='rep') renderRep();
  if(t==='subj') renderSubj();
  if(t==='dom') renderDomGrid();
}}
function switchSB(p){{
  ['up','ch'].forEach(function(v){{
    document.getElementById('panel-'+v).style.display=v===p?'block':'none';
    document.getElementById('stab-'+v).classList.toggle('on',v===p);
  }});
  if(p==='ch') renderChecks();
}}

// ============================================================
// PILLS / STATS
// ============================================================
function updatePills(){{
  fetch('/api/status').then(function(r){{return r.json();}}).then(function(s){{
    var fp=document.getElementById('pill-files');
    fp.textContent=s.files+' file'+(s.files!==1?'s':'');
    var pp=document.getElementById('pill-findings');
    if(s.findings){{
      pp.textContent=s.findings+' findings';
      pp.style.display='inline';
    }} else {{
      pp.style.display='none';
    }}
    var en=Object.values(enabled).filter(Boolean).length;
    document.getElementById('pill-checks').textContent=en+' checks';
  }}).catch(function(){{}});
}}

// ============================================================
// REPORT DOWNLOAD
// ============================================================
function dlReport(){{
  window.open('/api/report','_blank');
}}
</script>
</body>
</html>"""
