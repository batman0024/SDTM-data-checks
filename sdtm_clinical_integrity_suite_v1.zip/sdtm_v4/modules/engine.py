"""modules/engine.py"""
import re, time, datetime
from modules.registry import CHECKS, get_check

DEMO_POOL = [
    {"checkId":"DS006","subj":"001-007","domain":"VS","detail":"VS.SYSBP on 2024-09-14 - 3 days after DS death (DSSTDTC=2024-09-11, DSDECOD=DEATH)","root":"Missing DS death propagation"},
    {"checkId":"DS006","subj":"001-031","domain":"LB","detail":"LB.ALT on 2024-11-02 - 7 days after death (DSSTDTC=2024-10-26)","root":"Missing DS death propagation"},
    {"checkId":"AE005","subj":"001-007","domain":"AE","detail":"AE Pneumonia AESTDTC=2024-09-12 - 1 day after death 2024-09-11","root":"Missing DS death propagation"},
    {"checkId":"DS003","subj":"001-007","domain":"DS","detail":"DS contains 2 death dates: 2024-09-11 and 2024-09-13 (non-matching)","root":"Missing DS death propagation"},
    {"checkId":"DS008","subj":"001-004","domain":"LB","detail":"LB draw LBDTC=2024-01-10 precedes consent RFICDTC=2024-01-12 by 2 days","root":None},
    {"checkId":"DS008","subj":"002-003","domain":"VS","detail":"VS measurement 2024-02-08 before RFICDTC=2024-02-10","root":None},
    {"checkId":"DS007","subj":"001-019","domain":"LB","detail":"LB record 2024-08-05 is 8 days after DM.RFPENDTC=2024-07-28","root":None},
    {"checkId":"AE015","subj":"001-012","domain":"LB/AE","detail":"LB ALT Grade 4 (>10xULN) on 2024-06-15 - no AE within +/-7 days","root":"Possible under-reporting"},
    {"checkId":"AE015","subj":"001-028","domain":"LB/AE","detail":"LB POTASSIUM 8.1 mEq/L Grade 3 on 2024-09-03 - no corresponding AE","root":"Possible under-reporting"},
    {"checkId":"LB011","subj":"001-012","domain":"LB","detail":"ALT 480 U/L (>3xULN) + TBili 2.1xULN at Visit 6 - Hy's Law signal","root":"Possible under-reporting"},
    {"checkId":"AE016","subj":"001-022","domain":"AE/CM","detail":"AE Hypertension AESEV=SEVERE (2024-04-18) - no anti-hypertensive in CM +/-14d","root":None},
    {"checkId":"VS001","subj":"002-003","domain":"VS","detail":"Visit 8 (2024-07-22): DIABP=92 > SYSBP=88 mmHg - impossible physiology","root":None},
    {"checkId":"VS001","subj":"001-041","domain":"VS","detail":"Screening 2024-02-05: DIABP=110 > SYSBP=105 mmHg","root":None},
    {"checkId":"VS003","subj":"002-016","domain":"VS","detail":"Weight 82 kg (Wk4) to 61 kg (Wk5) = 25.6 pct drop in 7 days","root":None},
    {"checkId":"VS004","subj":"002-027","domain":"VS","detail":"Height 178 cm (BL) to 162 cm (Month 6) = 16 cm decrease","root":None},
    {"checkId":"DS005","subj":"001-055","domain":"DS/EX","detail":"DSDECOD=Screen Failure but 2 EX dosing records exist (2024-01-14, 2024-01-21)","root":None},
    {"checkId":"BL001","subj":"002-008","domain":"LB","detail":"LB GLUC --BLFL=Y at 08:30; first dose (EXSTDTC) at 07:00 same day - post-dose","root":None},
    {"checkId":"TD006","subj":"001-033","domain":"SE","detail":"Screening SEENDTC=2024-03-15; Treatment SESTDTC=2024-03-17 - 1-day gap","root":None},
    {"checkId":"BL002","subj":"ALL","domain":"ALL","detail":"14 LB records with LBTESTCD=POTASSM - not in CDISC CT; expected POTASSIUM","root":"Systematic CT error"},
    {"checkId":"AE012","subj":"001-044","domain":"AE","detail":"AETRTEM=Y but AE start 2024-10-30 is 59 days after last dose 2024-09-01","root":None},
    {"checkId":"DM001","subj":"002-017","domain":"DM","detail":"DM.ARMCD=PLACEBO but EXTRT=Drug A 100mg in 2 EX records","root":None},
    {"checkId":"SV003","subj":"001-038","domain":"ALL/TV","detail":"Visit 4 VISITDY=28; actual VSDY=35 - 7-day deviation exceeds +/-3d window","root":None},
    {"checkId":"CM005","subj":"001-033","domain":"CM","detail":"CM record shows Warfarin - excluded per protocol Section 5.3","root":None},
    {"checkId":"LB009","subj":"001-012","domain":"LB/EX","detail":"LB pre-dose LBDTM=2024-06-15T09:45 but EXSTDTC=2024-06-15T08:00 - draw post-infusion","root":None},
    {"checkId":"EG002","subj":"002-011","domain":"EG","detail":"QTcF=530 ms at Visit 4 - no cardiac AE within +/-3 days","root":None},
    {"checkId":"EG003","subj":"002-019","domain":"EG","detail":"QTcF increased from 390ms (BL) to 465ms (Wk4) = 75ms increase without TEAE","root":None},
    {"checkId":"PK003","subj":"ALL","domain":"PP","detail":"PP RELREC missing for 8 subjects - Cmax/AUC not traceable to PC concentrations","root":None},
    {"checkId":"QS003","subj":"002-015","domain":"QS","detail":"SF-36 Physical Score total=82 but sum of components=61 (21-point discrepancy)","root":None},
    {"checkId":"ONC003","subj":"002-016","domain":"TU","detail":"TU new lesion 2024-07-10 but RS.RSORRES=PR (not PD) at same timepoint","root":None},
    {"checkId":"ONC005","subj":"003-001","domain":"TR","detail":"RECIST sum of diameters=68mm but sum of TRSTRESN values=52mm","root":None},
    {"checkId":"TD001","subj":"ALL","domain":"TS","detail":"TS missing TSPARMCD=PCLAS (Pharmacological Class) - FDA Desired parameter absent","root":None},
    {"checkId":"TD002","subj":"ALL","domain":"TS","detail":"TS TSPARMCD=DOSE TSVAL=100 mg - unit in DOSE field (should be DOSU record)","root":None},
    {"checkId":"DM008","subj":"003-006","domain":"DM","detail":"SDTM AGE=16 (AGEU=YEARS) in adult Phase III trial - possible paediatric patient","root":None},
    {"checkId":"IE002","subj":"001-009","domain":"IE","detail":"IE exclusion criterion 3 failure but DSDECOD=ENROLLED for same subject","root":None},
    {"checkId":"S008","subj":"ALL","domain":"ALL","detail":"LBTESTCD=SODIUM maps to Sodium Serum and Serum Sodium - 1:1 violation","root":"Systematic CT error"},
    {"checkId":"LB012","subj":"003-012","domain":"LB","detail":"LBTESTCD=ALT LBDTC=2024-05-10 appears 3 times for same subject - possible double entry","root":None},
    {"checkId":"VS005","subj":"002-033","domain":"VS","detail":"VSTESTCD=PULSE VSSTRESN=8 BPM at Visit 3 - physiologically implausible","root":None},
    {"checkId":"EX007","subj":"001-018","domain":"EX","detail":"Subject received 2400mg cumulative dose vs. protocol maximum of 1800mg","root":None},
    {"checkId":"PK004","subj":"003-004","domain":"PP","detail":"PPTESTCD=CMAX=0.2 ng/mL but all PC concentrations for this subject > 15 ng/mL","root":None},
    {"checkId":"DV001","subj":"001-025","domain":"DV","detail":"DVTERM=Protocol deviation - unblinding but no DS discontinuation record found","root":None},
]


class ValidationEngine:
    def __init__(self, files, enabled):
        self.files = files
        self.enabled = enabled
        self._seq = 0

    def run(self, progress_cb=None):
        enabled_checks = [c for c in CHECKS if self.enabled.get(c["id"], True)]
        total = len(enabled_checks)
        findings = []
        domain_data = self._map_domains()

        for i, check in enumerate(enabled_checks):
            if progress_cb:
                progress_cb(int((i / total) * 98),
                            f"Checking {check['id']}: {check['label'][:50]}...")
            time.sleep(0.005)
            findings.extend(self._run_actual(check, domain_data))
            findings.extend(self._run_demo(check, domain_data))

        if progress_cb:
            progress_cb(100, "Complete")
        return findings

    def _map_domains(self):
        """Map uploaded files to SDTM domain codes."""
        result = {}
        dom_codes = ["AE","CM","DM","DS","EG","EX","LB","MH","PR","QS",
                     "TR","TU","RS","SE","SV","SS","VS","TS","TA","TE",
                     "TV","TI","IE","PC","PP","DV","MH","FA","RE","SU","SC"]
        for fname, meta in self.files.items():
            data = meta.get("data", [])
            if not data:
                continue
            base = fname.upper()
            for ext in [".XPT",".SAS7BDAT",".CSV",".XLSX",".XLS",".JSON"]:
                base = base.replace(ext, "")
            base = base.split("/")[-1].split("\\")[-1].strip()
            matched = False
            for dom in dom_codes:
                if base == dom or base.startswith(dom + "_") or base.endswith("_" + dom):
                    result.setdefault(dom, []).extend(data)
                    matched = True
                    break
            if not matched:
                for dom in dom_codes:
                    if dom in base:
                        result.setdefault(dom, []).extend(data)
                        break
            # Also check DOMAIN column
            if data and isinstance(data[0], dict) and "DOMAIN" in data[0]:
                dv = str(data[0].get("DOMAIN", "")).strip().upper()
                if dv:
                    result.setdefault(dv, []).extend(data)
        return result

    def _new_finding(self, check, subj, detail, root=None, actual=True):
        self._seq += 1
        return {
            "fid": f"F{self._seq:04d}",
            "checkId": check["id"],
            "label": check["label"],
            "layer": check["layer"],
            "cat": check["cat"],
            "domain": check["domain"],
            "sev": check["sev"],
            "risk": check["risk"],
            "source": check["source"],
            "subj": subj,
            "detail": detail,
            "root": root,
            "actual": actual,
            "waived": False,
            "waiver_note": "",
            "ts": datetime.datetime.now().isoformat(),
        }

    def _run_actual(self, check, dd):
        cid = check["id"]
        results = []
        try:
            if cid == "DM001":
                for r in dd.get("DM", []):
                    arm = r.get("ARM","").strip()
                    actarm = r.get("ACTARM","").strip()
                    s = r.get("USUBJID","?")
                    if arm and actarm and arm != actarm and "SCRNFAIL" not in arm.upper():
                        results.append(self._new_finding(check, s, f"ARM='{arm}' vs ACTARM='{actarm}'"))
            elif cid == "DM003":
                for r in dd.get("DM", []):
                    s = r.get("USUBJID","?")
                    fl = r.get("DTHFL","").strip().upper()
                    dtc = r.get("DTHDTC","").strip()
                    if fl == "Y" and not dtc:
                        results.append(self._new_finding(check, s, "DTHFL=Y but DTHDTC missing"))
                    elif dtc and fl != "Y":
                        results.append(self._new_finding(check, s, f"DTHDTC='{dtc}' present but DTHFL != Y"))
            elif cid == "DM004":
                seen = {}
                for r in dd.get("DM", []):
                    s = r.get("USUBJID","")
                    if s and s in seen:
                        results.append(self._new_finding(check, s, f"Duplicate USUBJID='{s}' in DM"))
                    seen[s] = True
            elif cid == "AE001":
                for r in dd.get("AE", []):
                    s = r.get("USUBJID","?")
                    if not r.get("AEDECOD","").strip():
                        results.append(self._new_finding(check, s, f"AEDECOD missing for AETERM='{r.get('AETERM','?')}'"))
            elif cid == "AE004":
                for r in dd.get("AE", []):
                    s = r.get("USUBJID","?")
                    st = r.get("AESTDTC","").strip()
                    en = r.get("AEENDTC","").strip()
                    if st and en and len(st) >= 10 and len(en) >= 10 and st[:10] > en[:10]:
                        results.append(self._new_finding(check, s, f"AESTDTC='{st}' after AEENDTC='{en}'"))
            elif cid == "AE008":
                seen = {}
                for r in dd.get("AE", []):
                    s = r.get("USUBJID","")
                    ad = r.get("AEDECOD","")
                    at = r.get("AESTDTC","")
                    k = f"{s}|{ad}|{at}"
                    if k in seen and ad:
                        results.append(self._new_finding(check, s, f"Duplicate AE: AEDECOD='{ad}' AESTDTC='{at}'"))
                    seen[k] = True
            elif cid == "EX001":
                seen = {}
                for r in dd.get("EX", []):
                    s = r.get("USUBJID","")
                    k = f"{s}|{r.get('EXTRT','')}|{r.get('EXSTDTC','')}|{r.get('EXDOSE','')}"
                    if k in seen and r.get("EXTRT"):
                        results.append(self._new_finding(check, s, f"Duplicate EX: EXTRT='{r.get('EXTRT')}' EXSTDTC='{r.get('EXSTDTC')}'"))
                    seen[k] = True
            elif cid == "EX002":
                for r in dd.get("EX", []):
                    s = r.get("USUBJID","?")
                    if r.get("EXOCCUR","").strip().upper() == "Y" and not r.get("EXDOSE","").strip():
                        results.append(self._new_finding(check, s, f"EXOCCUR=Y but EXDOSE missing for EXTRT='{r.get('EXTRT','')}'"))
            elif cid == "LB003":
                for r in dd.get("LB", []):
                    s = r.get("USUBJID","?")
                    if r.get("LBSTRESN","").strip() and not r.get("LBORNRLO","").strip() and not r.get("LBORNRHI","").strip():
                        results.append(self._new_finding(check, s, f"LBTESTCD='{r.get('LBTESTCD','')}' LBSTRESN={r.get('LBSTRESN')} but ref range missing"))
            elif cid == "LB004":
                for r in dd.get("LB", []):
                    s = r.get("USUBJID","?")
                    lo = r.get("LBORRES","").strip()
                    if lo and (lo.startswith(">") or lo.startswith("<")) and not r.get("LBSTRESN","").strip():
                        results.append(self._new_finding(check, s, f"LBORRES='{lo}' starts with >/< but LBSTRESN missing, LBTESTCD='{r.get('LBTESTCD','')}'"))
            elif cid == "LB007":
                for r in dd.get("LB", []):
                    s = r.get("USUBJID","?")
                    d = r.get("LBDTC","").strip()
                    if d and re.match(r"^\d{4}$", d):
                        results.append(self._new_finding(check, s, f"LBDTC='{d}' - year only, missing month and day"))
                    elif d and re.match(r"^\d{4}-\d{2}$", d):
                        results.append(self._new_finding(check, s, f"LBDTC='{d}' - missing day component"))
            elif cid == "VS001":
                sbp, dbp = {}, {}
                for r in dd.get("VS", []):
                    s = r.get("USUBJID","?")
                    tc = r.get("VSTESTCD","").strip().upper()
                    vn = r.get("VISITNUM", r.get("VISIT",""))
                    val = r.get("VSSTRESN","").strip()
                    k = f"{s}|{vn}"
                    if tc == "SYSBP" and val:
                        sbp[k] = (val, s)
                    elif tc == "DIABP" and val:
                        dbp[k] = (val, s)
                for k, (dv, s) in dbp.items():
                    if k in sbp:
                        sv = sbp[k][0]
                        try:
                            if float(dv) > float(sv):
                                results.append(self._new_finding(check, s, f"DIABP={dv} > SYSBP={sv} at VISIT='{k.split('|')[1]}'"))
                        except ValueError:
                            pass
            elif cid == "CM001":
                for r in dd.get("CM", []):
                    s = r.get("USUBJID","?")
                    if not r.get("CMDECOD","").strip():
                        results.append(self._new_finding(check, s, f"CMDECOD missing for CMTRT='{r.get('CMTRT','')}'"))
            elif cid == "CM003":
                for r in dd.get("CM", []):
                    s = r.get("USUBJID","?")
                    for dv in ["CMSTDTC","CMENDTC"]:
                        d = r.get(dv,"").strip()
                        if d and re.match(r"^\d{4}$", d):
                            results.append(self._new_finding(check, s, f"{dv}='{d}' - year only, missing month"))
            elif cid == "S010":
                pat = re.compile(r"^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2})?)?)?)?$")
                for dom, rows in dd.items():
                    for r in rows[:100]:
                        for col, val in r.items():
                            if col.endswith("DTC") and val and val.strip():
                                if not pat.match(val.strip()):
                                    s = r.get("USUBJID","?")
                                    results.append(self._new_finding(check, s, f"{dom}.{col}='{val}' - invalid ISO 8601"))
        except Exception:
            pass
        return results

    def _run_demo(self, check, dd):
        """Return demo findings only when no real data available for required domains."""
        required = check.get("requires", [check["domain"].split("/")[0]])
        has_real = any(d in dd for d in required if d not in ("ALL","DEFINE","SUPP","RELREC"))
        if has_real:
            return []
        results = []
        for entry in DEMO_POOL:
            if entry["checkId"] == check["id"]:
                c = get_check(check["id"])
                if c:
                    self._seq += 1
                    results.append({
                        "fid": f"F{self._seq:04d}",
                        "checkId": c["id"],
                        "label": c["label"],
                        "layer": c["layer"],
                        "cat": c["cat"],
                        "domain": entry["domain"],
                        "sev": c["sev"],
                        "risk": c["risk"],
                        "source": c["source"],
                        "subj": entry["subj"],
                        "detail": entry["detail"],
                        "root": entry.get("root"),
                        "actual": False,
                        "waived": False,
                        "waiver_note": "",
                        "ts": datetime.datetime.now().isoformat(),
                    })
        return results
