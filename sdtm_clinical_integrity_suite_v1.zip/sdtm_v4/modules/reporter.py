"""modules/reporter.py - HTML report generation"""
import datetime

SEV_C = {"REJECT":"#ff3a3a","CRITICAL":"#e05c5c","ERROR":"#e08a2e","WARNING":"#c4b400","NOTICE":"#4a7bc8"}
RISK_C = {"submission-blocker":"#ff3a3a","medical-concern":"#e05c5c","structural":"#e08a2e","advisory":"#5a8fe0"}

def _esc(s):
    if not s: return ""
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")

def _bar(obj, cmap=None):
    if not obj: return "<p style='color:#2a2e45;font-size:10px'>No data</p>"
    mx = max(obj.values())
    rows = ""
    for k,v in sorted(obj.items(), key=lambda x:-x[1]):
        pct = int(v/mx*100) if mx else 0
        c = (cmap or {}).get(k,"#3a6ab0")
        rows += (f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">'
                 f'<div style="width:110px;font-size:10px;color:#7a7e98;text-align:right;flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{_esc(k[:16])}</div>'
                 f'<div style="flex:1;background:#0f1018;border-radius:2px;height:14px;overflow:hidden">'
                 f'<div style="height:100%;width:{pct}%;background:{c};border-radius:2px"></div></div>'
                 f'<div style="width:24px;font-size:10px;color:#7a7e98">{v}</div></div>')
    return rows

def make_report(state):
    findings = state.get("findings", [])
    files = state.get("files", {})
    enabled = state.get("enabled", {})
    active = [f for f in findings if not f.get("waived")]
    waived = [f for f in findings if f.get("waived")]

    by_risk, by_sev, by_dom = {}, {}, {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"],0)+1
        by_sev[f["sev"]] = by_sev.get(f["sev"],0)+1
        d = f["domain"].split("/")[0]
        by_dom[d] = by_dom.get(d,0)+1

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def score_card(label, val, color):
        return (f'<div style="background:#0d0f18;border:1px solid {color}22;border-radius:5px;padding:12px 10px;text-align:center">'
                f'<div style="font-size:22px;font-weight:700;color:{color};font-family:sans-serif">{val}</div>'
                f'<div style="font-size:9px;color:#2a2e45;text-transform:uppercase;letter-spacing:.07em;margin-top:2px">{label}</div></div>')

    scores = (
        score_card("Active", len(active), "#b0b5c8") +
        score_card("Blockers", by_risk.get("submission-blocker",0), "#ff3a3a") +
        score_card("Medical", by_risk.get("medical-concern",0), "#e05c5c") +
        score_card("Structural", by_risk.get("structural",0), "#e08a2e") +
        score_card("Advisory", by_risk.get("advisory",0), "#5a8fe0") +
        score_card("Waived", len(waived), "#3a8050")
    )

    def findings_table(flist, title):
        if not flist:
            return f"<p style='color:#2a2e45;font-size:10px;padding:12px'>No findings in this category.</p>"
        rows = ""
        for f in flist[:500]:
            sc = SEV_C.get(f.get("sev",""),"#666")
            rc = RISK_C.get(f.get("risk",""),"#666")
            ab = ('<span style="font-size:8px;background:rgba(42,80,48,.3);color:#3a8050;border:1px solid #1a5030;border-radius:2px;padding:0 3px">ACTUAL</span>'
                  if f.get("actual") else
                  '<span style="font-size:8px;background:rgba(74,123,200,.15);color:#4a7bc8;border:1px solid #1a2a5a;border-radius:2px;padding:0 3px">DEMO</span>')
            wr = (f'<br><span style="color:#3a8050;font-size:9px">WAIVED: {_esc(f.get("waiver_note",""))}</span>'
                  if f.get("waived") else "")
            rt = (f'<br><span style="color:#3a3e58;font-size:9px">Root: {_esc(f.get("root",""))}</span>'
                  if f.get("root") else "")
            s = f.get("subj","")
            rows += (f'<tr><td style="font-size:9px;color:#3a3e58">{_esc(f.get("fid",""))}</td>'
                     f'<td><span style="font-size:9px;border:1px solid {sc};color:{sc};padding:1px 4px;border-radius:2px">{_esc(f.get("sev",""))}</span></td>'
                     f'<td style="color:{rc};font-size:10px">{f.get("risk","").replace("-"," ").title()}</td>'
                     f'<td style="color:#5a8fe0;font-weight:600">{"GLOBAL" if s=="ALL" else "SUBJ-"+s}</td>'
                     f'<td style="color:#3a3e58;font-size:10px">{_esc(f.get("domain",""))}</td>'
                     f'<td>{_esc(f.get("label",""))} {ab}{rt}</td>'
                     f'<td style="color:#7a7e98;font-size:10px">{_esc(f.get("detail",""))}{wr}</td>'
                     f'<td style="font-size:9px;color:#2a2e45">{_esc(f.get("source",""))}</td></tr>')
        return (f'<table style="width:100%;border-collapse:collapse;font-size:11px">'
                f'<thead><tr>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">ID</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Sev</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Risk</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Subject</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Domain</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Check</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Finding Detail</th>'
                f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:9px;text-transform:uppercase">Source</th>'
                f'</tr></thead><tbody>{rows}</tbody></table>')

    files_rows = ""
    for fname, m in files.items():
        vs = ", ".join((m.get("variables") or [])[:6])
        if len(m.get("variables") or []) > 6: vs += " ..."
        files_rows += (f'<tr><td style="color:#5a8fe0">{_esc(fname)}</td>'
                       f'<td>{_esc(m.get("type",""))}</td>'
                       f'<td style="text-align:right">{m.get("rows",0)}</td>'
                       f'<td style="text-align:right">{m.get("cols",0)}</td>'
                       f'<td style="text-align:right">{m.get("size",0):,}</td>'
                       f'<td style="font-size:10px;color:#3a3e58">{_esc(vs)}</td>'
                       f'<td style="color:#e05c5c;font-size:10px">{_esc(m.get("parse_error",""))}</td></tr>')

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<title>Clinical Integrity Report - SDTM Suite v4.0</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#09090e;color:#b0b5c8;font-family:"Courier New",monospace;font-size:12px;line-height:1.6;padding:32px 24px}}
h1{{font-family:sans-serif;font-size:22px;font-weight:800;color:#d0d5e8;margin-bottom:4px}}
h2{{font-family:sans-serif;font-size:15px;font-weight:700;color:#d0d5e8;margin:28px 0 12px;padding-bottom:7px;border-bottom:1px solid #16182a}}
.page{{max-width:1200px;margin:0 auto}}
table{{width:100%;border-collapse:collapse}}
th{{background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;color:#5a8fe0;font-size:10px;text-transform:uppercase}}
td{{border:1px solid #16182a;padding:7px 9px;vertical-align:top}}
tr:hover td{{background:rgba(255,255,255,.02)}}
@media print{{body{{background:#fff;color:#111}}}}
</style></head>
<body><div class="page">
<div style="margin-bottom:4px;font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase">SDTM Clinical Integrity Suite v4.0 - Beyond-P21 Validation Engine</div>
<h1>Clinical Integrity Report</h1>
<div style="font-size:11px;color:#3a3e58;margin-bottom:20px">Generated: {now} &bull; {len(findings)} total findings &bull; {len(active)} active &bull; {len(waived)} waived</div>

<h2>Executive Summary</h2>
<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:9px;margin-bottom:20px">{scores}</div>

<h2>Findings by Risk</h2>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
<div style="background:#0c0c14;border:1px solid #16182a;border-radius:5px;padding:14px">
<div style="font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase;margin-bottom:9px">By Risk Category</div>
{_bar(by_risk, RISK_C)}</div>
<div style="background:#0c0c14;border:1px solid #16182a;border-radius:5px;padding:14px">
<div style="font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase;margin-bottom:9px">By Severity</div>
{_bar(by_sev, SEV_C)}</div></div>
<div style="background:#0c0c14;border:1px solid #16182a;border-radius:5px;padding:14px;margin-bottom:20px">
<div style="font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase;margin-bottom:9px">By Domain</div>
{_bar(by_dom)}</div>

<h2>Medical Concerns &amp; Blockers ({by_risk.get("medical-concern",0) + by_risk.get("submission-blocker",0)})</h2>
{findings_table([f for f in active if f["risk"] in ("medical-concern","submission-blocker")], "Medical")}

<h2>Structural Errors &amp; Advisory ({by_risk.get("structural",0) + by_risk.get("advisory",0)})</h2>
{findings_table([f for f in active if f["risk"] in ("structural","advisory")], "Structural")}

<h2>All Active Findings ({len(active)})</h2>
{findings_table(active, "All")}

<h2>Waived Findings ({len(waived)})</h2>
<div style="opacity:.5">{findings_table(waived, "Waived")}</div>

<h2>Loaded Files ({len(files)})</h2>
<table><thead><tr>
<th>Filename</th><th>Type</th><th>Rows</th><th>Cols</th><th>Size (bytes)</th><th>Variables (preview)</th><th>Parse Error</th>
</tr></thead><tbody>{"<tr><td colspan='7' style='color:#2a2e45;text-align:center;padding:14px'>No files loaded</td></tr>" if not files_rows else files_rows}</tbody></table>

<div style="margin-top:36px;padding-top:14px;border-top:1px solid #16182a;font-size:9px;color:#2a2e45;text-align:center">
SDTM Clinical Integrity Suite v4.0 &bull; Beyond-P21 Validation Engine &bull;
Sources: FDA TCG 2024, SDTMIG v3.4, PharmaSUG 2012-2024, ICH E2A/E3/E6/E14, CDISC CT, RECIST 1.1, FDA DILI Guidance
</div>
</div></body></html>"""
