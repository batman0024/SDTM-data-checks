"""
SDTM Clinical Integrity Suite v4.0
Futuristic dark-mode dashboard - no Streamlit required
Run: python app.py
Then open: http://127.0.0.1:8888
"""
import os, sys, json, threading, time, datetime, webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, os.path.dirname(__file__))

from modules.registry import CHECKS, get_check
from modules.engine import ValidationEngine
from modules.parser import FileParser
from modules.reporter import make_report

HOST, PORT = "127.0.0.1", 8888

STATE = {
    "files": {},          # fname -> meta dict
    "findings": [],       # list of finding dicts
    "enabled": {},        # check_id -> bool
    "running": False,
    "progress": 0,
    "run_ts": None,
    "run_count": 0,
    "sse_clients": [],    # for server-sent events
}

def _init():
    for c in CHECKS:
        STATE["enabled"][c["id"]] = True

def _broadcast(event_type, data):
    msg = f"event: {event_type}\ndata: {json.dumps(data)}\n\n"
    dead = []
    for q in STATE["sse_clients"]:
        try:
            q.put_nowait(msg)
        except Exception:
            dead.append(q)
    for q in dead:
        try: STATE["sse_clients"].remove(q)
        except: pass

def _run_validation():
    STATE["running"] = True
    STATE["progress"] = 0
    STATE["findings"] = []
    _broadcast("status", {"running": True, "progress": 0})

    engine = ValidationEngine(STATE["files"], STATE["enabled"])

    def progress_cb(pct, label=""):
        STATE["progress"] = pct
        _broadcast("progress", {"pct": pct, "label": label})

    findings = engine.run(progress_cb)
    STATE["findings"] = findings
    STATE["running"] = False
    STATE["progress"] = 100
    STATE["run_ts"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    STATE["run_count"] += 1
    _broadcast("done", {
        "count": len(findings),
        "ts": STATE["run_ts"],
        "run_count": STATE["run_count"],
    })


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, data, code=200):
        b = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b)

    def _html(self, html, code=200):
        b = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path

        if p in ("/", "/index.html"):
            from modules.ui import build_ui
            self._html(build_ui(len(CHECKS)))

        elif p == "/api/checks":
            out = []
            for c in CHECKS:
                d = dict(c)
                d["enabled"] = STATE["enabled"].get(c["id"], True)
                out.append(d)
            self._json(out)

        elif p == "/api/findings":
            self._json(STATE["findings"])

        elif p == "/api/files":
            info = {}
            for k, v in STATE["files"].items():
                info[k] = {
                    "size": v.get("size", 0),
                    "type": v.get("type", ""),
                    "rows": v.get("rows", 0),
                    "cols": v.get("cols", 0),
                    "variables": (v.get("variables") or [])[:30],
                    "error": v.get("parse_error", ""),
                }
            self._json(info)

        elif p == "/api/status":
            self._json({
                "running": STATE["running"],
                "progress": STATE["progress"],
                "findings": len(STATE["findings"]),
                "files": len(STATE["files"]),
                "run_ts": STATE["run_ts"],
                "run_count": STATE["run_count"],
            })

        elif p == "/api/summary":
            f = [x for x in STATE["findings"] if not x.get("waived")]
            by_risk, by_sev, by_dom, by_layer, by_cat = {}, {}, {}, {}, {}
            for x in f:
                for d, k in [(by_risk,"risk"),(by_sev,"sev"),
                              (by_layer,"layer"),(by_cat,"cat")]:
                    v = x.get(k,"?")
                    d[v] = d.get(v,0)+1
                dom = x.get("domain","?").split("/")[0]
                by_dom[dom] = by_dom.get(dom,0)+1
            self._json({"by_risk":by_risk,"by_sev":by_sev,
                        "by_domain":by_dom,"by_layer":by_layer,
                        "by_cat":by_cat,"total":len(f),
                        "waived": len([x for x in STATE["findings"] if x.get("waived")])})

        elif p == "/api/report":
            html = make_report(STATE)
            b = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Disposition",
                             "attachment; filename=clinical_integrity_report.html")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        elif p == "/api/events":
            # Server-Sent Events for real-time progress
            import queue
            q = queue.Queue(maxsize=100)
            STATE["sse_clients"].append(q)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            try:
                while True:
                    try:
                        msg = q.get(timeout=15)
                        self.wfile.write(msg.encode())
                        self.wfile.flush()
                    except Exception:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
            except Exception:
                try: STATE["sse_clients"].remove(q)
                except: pass

        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        p = urlparse(self.path).path
        clen = int(self.headers.get("Content-Length", 0))

        if p == "/api/upload":
            ct = self.headers.get("Content-Type", "")
            raw = self.rfile.read(clen)
            try:
                results = FileParser.parse_multipart(raw, ct)
                for name, meta in results.items():
                    STATE["files"][name] = meta
                self._json({"ok": True, "files": list(results.keys())})
            except Exception as e:
                self._json({"ok": False, "error": str(e)}, 400)

        elif p == "/api/run":
            if not STATE["running"]:
                threading.Thread(target=_run_validation, daemon=True).start()
            self._json({"started": True})

        elif p == "/api/toggle":
            body = json.loads(self.rfile.read(clen))
            cid = body.get("id")
            val = body.get("enabled", True)
            if cid == "__all__":
                for k in STATE["enabled"]:
                    STATE["enabled"][k] = val
            elif cid in STATE["enabled"]:
                STATE["enabled"][cid] = val
            self._json({"ok": True})

        elif p == "/api/waive":
            body = json.loads(self.rfile.read(clen))
            fid = body.get("fid")
            note = body.get("note", "")
            for f in STATE["findings"]:
                if f.get("fid") == fid:
                    f["waived"] = not f.get("waived", False)
                    f["waiver_note"] = note
                    break
            self._json({"ok": True})

        elif p == "/api/clear":
            STATE["files"] = {}
            STATE["findings"] = []
            STATE["run_ts"] = None
            self._json({"ok": True})

        else:
            self._json({"error": "not found"}, 404)


def main():
    _init()
    server = HTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}"
    print("\n" + "="*56)
    print("  SDTM Clinical Integrity Suite v4.0")
    print("  Futuristic Validation Dashboard")
    print("="*56)
    print(f"  URL  : {url}")
    print(f"  Checks registered: {len(CHECKS)}")
    print("  Press Ctrl+C to stop")
    print("="*56 + "\n")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")

if __name__ == "__main__":
    main()
