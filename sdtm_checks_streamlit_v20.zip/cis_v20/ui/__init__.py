"""
CIS UI Package
Provides theme injection, chart helpers, and component renderers.
Import via:  from ui import inject_theme, render_charts, RISK_COLORS
"""
from .theme   import inject_theme, inject_scroll_fab
from .charts  import render_dashboard_charts
from .tokens  import RISK_COLORS, RISK_LABELS, SEV_COLORS, SEV_BADGE, RISK_BADGE

__all__ = [
    "inject_theme", "inject_scroll_fab",
    "render_dashboard_charts",
    "RISK_COLORS", "RISK_LABELS", "SEV_COLORS", "SEV_BADGE", "RISK_BADGE",
]
