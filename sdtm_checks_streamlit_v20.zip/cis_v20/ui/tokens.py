"""
CIS Design Tokens
All colour constants and label maps used across the app.
"""

# ── Risk hierarchy ────────────────────────────────────────────────────────────
RISK_COLORS = {
    "submission-blocker": "#e84040",
    "medical-concern":    "#e07070",
    "structural":         "#e09040",
    "advisory":           "#5080e0",
}

RISK_LABELS = {
    "submission-blocker": "Submission Blocker",
    "medical-concern":    "Medical Concern",
    "structural":         "Structural Error",
    "advisory":           "Advisory",
}

# ── Severity ──────────────────────────────────────────────────────────────────
SEV_COLORS = {
    "REJECT":   "#e84040",
    "CRITICAL": "#e07070",
    "ERROR":    "#e09040",
    "WARNING":  "#d4b830",
    "NOTICE":   "#5080e0",
}

SEV_BADGE = {
    "REJECT":   "badge-reject",
    "CRITICAL": "badge-critical",
    "ERROR":    "badge-error",
    "WARNING":  "badge-warning",
}

RISK_BADGE = {
    "submission-blocker": "badge-blocker",
    "medical-concern":    "badge-medical",
    "structural":         "badge-struct",
    "advisory":           "badge-advisory",
}

# ── Chart palette ─────────────────────────────────────────────────────────────
CHART_DARK_BG   = "#090c1e"
CHART_AXIS_CLR  = "#6878a8"
CHART_GRID_CLR  = "#1a2040"

RISK_CHART_PALETTE = {
    "Submission Blocker": "#e84040",
    "Medical Concern":    "#e07070",
    "Structural Error":   "#e09040",
    "Advisory":           "#5080e8",
}

SEV_CHART_PALETTE = {
    "REJECT":   "#e84040",
    "CRITICAL": "#e07070",
    "ERROR":    "#e09040",
    "WARNING":  "#d4b830",
}

OUTCOME_CHART_PALETTE = {
    "Violation": "#e84040",
    "Signal":    "#d4b830",
    "Inquiry":   "#5080e8",
    "Other":     "#4060a0",
}

LAYER_CHART_COLORS = ["#5080e0", "#3060b8", "#7090e8", "#4870c8", "#60a0f8"]
DOMAIN_CHART_RANGE = ["#2848a0", "#3870d8", "#60a0ff"]
