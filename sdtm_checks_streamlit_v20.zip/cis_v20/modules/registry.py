"""
modules/registry.py  v15.0
- YAML-backed hot-reloadable check registry
- outcome_class: Violation | Signal | Inquiry  (v8.1 §2)
- clinical_note: explainability annotation       (v8.0 §4)
- Language-hardened labels                        (v8.1 §8)
- DATE007: Context-aware partial date criticality (v8.0 §2 / v8.1 §4)
- study_config.yaml: protocol-aware parameters   (v8.0 §1)
"""

import os
import threading
import logging
log = logging.getLogger(__name__)

_registry_lock = threading.Lock()

# ---------------------------------------------------------------------------
# SUG-004: Required domains per check
# ---------------------------------------------------------------------------
CHECK_REQUIRES = {
    "DM001":["DM","EX"],  "DM003":["DM"],    "DM004":["DM"],
    "AE001":["AE"],        "AE004":["AE"],    "AE005":["AE","DM"],
    "AE006":["AE"],        "AE008":["AE"],
    "EX001":["EX"],        "EX002":["EX"],
    "LB001":["LB","DM"],   "LB003":["LB"],    "LB004":["LB"],
    "LB007":["LB"],        "LB011":["LB"],
    "VS001":["VS"],
    "CM001":["CM"],        "CM003":["CM"],
    "DS005":["DS","EX"],   "DS006":["DS","AE"],  "DS008":["DS","LB"],
    "AE015":["LB","AE"],   "AE016":["AE","CM"],  "LB009":["LB","EX"],
    "S010": [],
    "INT001":["DM"],
    "INT002":["DM"],
    "INT003":["EX","DS"],
    "INT004":["DM","LB"],
    "INT005":["DM"],
    "DATE001":[],
    "DATE002":["DS"],
    "DATE003":[],
    "DATE004":["DM"],
    "DATE005":["EX","DM"],
    "DATE006":["EX","DS"],
    "DATE007":["DM"],
}

# ---------------------------------------------------------------------------
# Clinical explainability notes  (v8.0 §4 / v8.1)
# ---------------------------------------------------------------------------
CLINICAL_NOTES = {
    "AE001": "Missing MedDRA PT is a submission-blocking error. FDA reviewers cannot assess causality or coding accuracy without AEDECOD. Remediation: code all AE terms to MedDRA.",
    "AE005": "Clinical records after a subject\'s death date suggest data entry errors or system synchronisation failures. FDA safety reviewers routinely cross-check AE and DS domains.",
    "AE015": "Silent CTCAE Grade 3/4 lab toxicities without corresponding AE entries may indicate under-reporting of clinically significant events. This is a key FDA DILI/safety signal cross-check.",
    "AE016": "Severe AEs without concomitant medications may indicate incomplete medical history recording or treatment documentation gaps. Review for potential causality assessment impact.",
    "DS005": "Dosing in screen failure subjects represents a serious GCP deviation. First-dose eligibility must be confirmed prior to exposure.",
    "DS006": "Any clinical activity after a confirmed death date is a critical data integrity flag. This pattern is reviewed by FDA as evidence of poor data management.",
    "DATE005": "Dosing before informed consent is a GCP violation (ICH E6 §4.8). This finding requires immediate medical monitor review and potential protocol deviation reporting.",
    "INT001": "Subjects present in observation domains but absent from DM are \'orphan\' records that undermine the integrity of safety analyses. Submission with orphan records typically triggers FDA queries.",
    "INT002": "Baseline flags set after first dose date create incorrect reference values for all derived change-from-baseline analyses, potentially invalidating primary efficacy endpoints.",
    "INT005": "Assessments before informed consent are GCP violations. They require regulatory disclosure and may affect study eligibility determinations.",
    "LB003": "Missing reference ranges prevent normal/abnormal classification and disable all NCI-CTCAE grading. FDA reviewers expect reference ranges for all quantitative lab tests.",
    "LB011": "Hy\'s Law (ALT >3xULN + TBili >2xULN within 30 days) is the FDA-required DILI signal. All cases must be narratively documented in the CSR safety section.",
    "VS001": "Diastolic BP exceeding systolic BP is physiologically impossible and indicates a data collection or transcription error requiring source data verification (SDV).",
    "DM001": "Arm/treatment assignment discrepancies affect the validity of all treatment-related analyses. Unresolved mismatches will be queried in the FDA clinical review.",
    "DM003": "Inconsistency between death flag and death date is a safety data integrity issue. FDA reviewers cross-check DTHFL, DTHDTC, AE AESDTH, and DS DSDECOD=DEATH.",
    "DM008": "Paediatric-age subjects in adult trials require protocol-specific eligibility review and potential protocol deviation assessment per ICH E6.",
    "DATE002": "Post-mortem clinical activity is a critical data integrity finding. FDA safety reviewers specifically flag this pattern as indicative of systemic data management issues.",
    "INT003": "Subjects with clinical activity but no disposition record create incomplete study participation histories, affecting safety population definitions.",
    "CM005": "Prohibited concomitant medications may affect study eligibility, primary endpoint interpretation, or safety assessment. Protocol deviation assessment required.",
    "EX007": "Cumulative dose exceeding the protocol maximum requires immediate safety assessment and protocol deviation documentation.",
    "QS003": "Total score inconsistency with component scores invalidates the questionnaire result and may affect patient-reported outcome analyses.",
    "ONC003": "New lesion without PD response assessment is a critical RECIST 1.1 compliance issue in oncology trials. FDA oncology reviewers specifically check this cross-domain consistency.",
}

# ---------------------------------------------------------------------------
# outcome_class map:  Violation | Signal | Inquiry  (v8.1 §2)
# ---------------------------------------------------------------------------
OUTCOME_CLASS = {
    # Violations: direct SDTM/protocol non-compliance
    "S001":"Violation", "S002":"Violation", "S003":"Violation", "S004":"Violation",
    "S005":"Violation", "S006":"Violation", "S012":"Violation",
    "DM004":"Violation", "DM005":"Violation", "AE001":"Violation",
    "DATE005":"Violation", "DATE006":"Violation", "DS005":"Violation", "DS008":"Violation",
    "INT001":"Violation", "INT005":"Violation", "DATE002":"Violation",
    "TD001":"Violation", "S017":"Violation", "S018":"Violation",
    # Signals: patterns requiring medical review
    "AE005":"Signal", "AE015":"Signal", "AE016":"Signal", "DS006":"Signal",
    "DM001":"Signal", "DM003":"Signal", "DM008":"Signal", "LB011":"Signal",
    "VS001":"Signal", "INT002":"Signal", "DATE004":"Signal",
    "EG002":"Signal", "EG003":"Signal", "ONC003":"Signal", "ONC005":"Signal",
    "DS003":"Signal", "DS006":"Signal", "EX007":"Signal",
    "CM005":"Signal", "DV001":"Signal",
    # Inquiry: ambiguity due to partial/missing data
    "LB003":"Inquiry", "LB004":"Inquiry", "LB007":"Inquiry", "LB010":"Inquiry",
    "CM003":"Inquiry", "MH001":"Inquiry", "DM007":"Inquiry", "DM009":"Inquiry",
    "DATE003":"Inquiry", "DATE007":"Inquiry",
    "AE006":"Inquiry", "AE009":"Inquiry", "AE013":"Inquiry",
    "INT003":"Inquiry", "INT004":"Inquiry",
    "QS001":"Inquiry", "QS002":"Inquiry",
}

def get_outcome_class(check_id: str) -> str:
    return OUTCOME_CLASS.get(check_id, "Violation")

# ---------------------------------------------------------------------------
# DEFAULT CHECKS  (language-hardened per v8.1 §8)
# ---------------------------------------------------------------------------
DEFAULT_CHECKS = [
    # __ STRUCTURAL __________________________________________________________
    {"id":"S001","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT",
     "label":"Dataset file missing for domain declared in Define-XML — review required","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"S002","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT",
     "label":"XPT variable name exceeds 8 characters — SDTM conformance issue","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S003","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT",
     "label":"Variable label exceeds 40 characters (SAS v5 transport limit) — review required","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S004","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"ERROR",
     "label":"DOMAIN value inconsistent with 2-char dataset name — structural review needed","risk":"structural","source":"SDTMIG"},
    {"id":"S005","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"ERROR",
     "label":"--SEQ not unique within USUBJID — possible duplicate record pattern","risk":"structural","source":"SDTMIG"},
    {"id":"S006","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT",
     "label":"Required variable null for one or more records — submission readiness review","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S007","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"WARNING",
     "label":"Permissible variable entirely null — consider dropping per SDTMIG guidance","risk":"structural","source":"SDTMIG"},
    {"id":"S008","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR",
     "label":"--TESTCD/--TEST mapping inconsistency — same TESTCD maps to multiple TEST values","risk":"structural","source":"PharmaSUG-2018"},
    {"id":"S009","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR",
     "label":"VISITNUM/VISIT mapping inconsistent across domains — review recommended","risk":"structural","source":"SDTMIG"},
    {"id":"S010","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR",
     "label":"ISO 8601 date format pattern inconsistency in --DTC variable","risk":"structural","source":"SDTMIG"},
    {"id":"S011","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR",
     "label":"--DY appears to use Day 0 (No-Day-0 convention may not be applied)","risk":"structural","source":"SDTMIG"},
    {"id":"S012","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"REJECT",
     "label":"Define-XML v2.0/2.1 absent from submission package — required by FDA TCG","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"S013","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"ERROR",
     "label":"Variable in dataset not described in Define-XML ItemDef — traceability gap","risk":"structural","source":"FDA TCG"},
    {"id":"S014","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"ERROR",
     "label":"Origin=CRF variable absent from annotated CRF page list","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"S015","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"WARNING",
     "label":"Origin=Derived with Method column blank — derivation traceability gap","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"S016","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"WARNING",
     "label":"QNAM in SUPP-- uses reserved standard variable name — naming conflict","risk":"structural","source":"SDTMIG"},
    {"id":"S017","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"ERROR",
     "label":"SUPP-- RDOMAIN inconsistent with parent domain code — linkage review needed","risk":"structural","source":"SDTMIG"},
    {"id":"S018","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"ERROR",
     "label":"SUPP-- IDVAR/IDVARVAL does not resolve to an existing parent record","risk":"structural","source":"SDTMIG"},
    # __ TRIAL DESIGN ________________________________________________________
    {"id":"TD001","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR",
     "label":"FDA-requested TS parameter missing (TTYPE, INTMODEL, or PCLAS) — review required","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"TD002","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR",
     "label":"TSPARMCD=DOSE appears to contain unit in TSVAL — consider separate DOSU record","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"TD003","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR",
     "label":"TSPARMCD=ACTSUBJ missing or 0 at study end — subject count traceability gap","risk":"structural","source":"FDA TCG"},
    {"id":"TD004","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"WARNING",
     "label":"TS study start date (SSTDTC) appears after first subject RFSTDTC in DM","risk":"structural","source":"PharmaSUG-2016"},
    {"id":"TD005","layer":"Trial Design","cat":"TA/TE/SE","domain":"TA","sev":"ERROR",
     "label":"ARMCD/ARM in DM not found in TA domain — treatment arm traceability gap","risk":"structural","source":"SDTMIG"},
    {"id":"TD006","layer":"Trial Design","cat":"TA/TE/SE","domain":"SE","sev":"ERROR",
     "label":"SE epoch gap observed — SESTDTC does not immediately follow preceding SEENDTC","risk":"structural","source":"PharmaSUG-2015"},
    {"id":"TD007","layer":"Trial Design","cat":"Trial Visits","domain":"TV","sev":"ERROR",
     "label":"VISITNUM in observation domain not found in TV domain — visit traceability gap","risk":"structural","source":"SDTMIG"},
    {"id":"TD008","layer":"Trial Design","cat":"TI/IE","domain":"TI","sev":"ERROR",
     "label":"IE.IETESTCD not derived from TI domain criteria list — inclusion criteria gap","risk":"structural","source":"PharmaSUG-2024"},
    # __ DEMOGRAPHICS ________________________________________________________
    {"id":"DM001","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR",
     "label":"ARM vs ACTARM inconsistency — planned and actual treatment arm may differ; review recommended","risk":"medical-concern","source":"SDTMIG/P21"},
    {"id":"DM002","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR",
     "label":"ARMNRS required when ARMCD = SCRNFAIL — screen failure reason missing","risk":"structural","source":"P21"},
    {"id":"DM003","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR",
     "label":"DTHFL/DTHDTC inconsistency — death flag and death date require reconciliation","risk":"medical-concern","source":"P21"},
    {"id":"DM004","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"REJECT",
     "label":"Duplicate USUBJID in DM — subject uniqueness pattern inconsistency","risk":"submission-blocker","source":"P21"},
    {"id":"DM005","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR",
     "label":"USUBJID cross-domain inconsistency (DM, AE, DS, EX) — orphan subject review needed","risk":"submission-blocker","source":"P21"},
    {"id":"DM006","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"WARNING",
     "label":"RFICDTC (informed consent date) missing — GCP traceability review recommended","risk":"medical-concern","source":"P21"},
    {"id":"DM007","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING",
     "label":"AGE value appears outside plausible range (< 0 or > 120) — data entry review recommended","risk":"medical-concern","source":"Physiology"},
    {"id":"DM008","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING",
     "label":"AGE < 18 years observed in adult Phase II/III trial — eligibility review recommended","risk":"medical-concern","source":"ICH E6"},
    {"id":"DM009","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING",
     "label":"RFSTDTC appears after RFENDTC — reference date range inconsistency","risk":"structural","source":"SDTMIG"},
    # __ ADVERSE EVENTS ______________________________________________________
    {"id":"AE001","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"REJECT",
     "label":"AEDECOD (MedDRA PT) missing — AE coding required for safety analysis","risk":"submission-blocker","source":"P21"},
    {"id":"AE002","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AE death date present but AESDTH != Y — death outcome inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"AE003","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AEOUT=FATAL with inconsistent AE dates — fatal outcome traceability review","risk":"medical-concern","source":"P21"},
    {"id":"AE004","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AESTDTC appears after AEENDTC — AE date sequence inconsistency","risk":"structural","source":"P21"},
    {"id":"AE005","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AE record observed after subject death date — temporal integrity review needed","risk":"medical-concern","source":"P21"},
    {"id":"AE006","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"Both AESEV and AETOXGR missing — AE severity assessment incomplete","risk":"structural","source":"P21"},
    {"id":"AE007","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"Grade 5 AE with inconsistent death variables — fatal AE reconciliation needed","risk":"medical-concern","source":"P21"},
    {"id":"AE008","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"Duplicate AE entries observed (same USUBJID/AEDECOD/AESTDTC) — review for double entry","risk":"structural","source":"P21"},
    {"id":"AE009","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"AEREL value missing or unexpected — ICH E2A causality assessment may be incomplete","risk":"structural","source":"P21/ICH-E2A"},
    {"id":"AE010","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AE linked to study discontinuation but no DS record found — disposition gap","risk":"medical-concern","source":"P21"},
    {"id":"AE011","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"AE death date not reflected in DS disposition record — cross-domain reconciliation needed","risk":"medical-concern","source":"P21"},
    {"id":"AE012","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"ERROR",
     "label":"AETRTEM=Y but AE start > 30 days after last dose — TEAE window inconsistency","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"AE013","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"AESOC may be inconsistent with AEDECOD per MedDRA hierarchy — coding review recommended","risk":"structural","source":"MedDRA/SDTMIG"},
    {"id":"AE014","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"WARNING",
     "label":"AESER=Y but SAE narrative (SUPPAE.SAENARR) absent — ICH E3 narrative completeness","risk":"advisory","source":"ICH-E3"},
    {"id":"AE015","layer":"Beyond-P21","cat":"Cross-Domain","domain":"LB/AE","sev":"CRITICAL",
     "label":"Safety Signal: CTCAE Grade 3/4 lab toxicity with no AE record within +/-7 days — review recommended","risk":"medical-concern","source":"CTCAE/Beyond-P21"},
    {"id":"AE016","layer":"Beyond-P21","cat":"Cross-Domain","domain":"AE/CM","sev":"ERROR",
     "label":"Severe AE (AESEV=SEVERE) pattern without matching concomitant medication — review recommended","risk":"medical-concern","source":"Beyond-P21"},
    # __ DISPOSITION _________________________________________________________
    {"id":"DS001","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR",
     "label":"DSDECOD=DEATH without DSSCAT=STUDY PARTICIPATION — disposition category inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"DS002","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR",
     "label":"DSDECOD=DEATH with missing DSSTDTC — death date traceability gap","risk":"medical-concern","source":"P21"},
    {"id":"DS003","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"WARNING",
     "label":"Multiple non-matching death dates in DS — death date reconciliation needed","risk":"medical-concern","source":"P21"},
    {"id":"DS004","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR",
     "label":"Exposure observed after study discontinuation per DS record — temporal inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"DS005","layer":"Beyond-P21","cat":"DS Logic","domain":"DS/EX","sev":"CRITICAL",
     "label":"Screen Failure subject has EX dosing records — eligibility and GCP review required","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS006","layer":"Beyond-P21","cat":"Temporal","domain":"DS/ALL","sev":"CRITICAL",
     "label":"Clinical domain record observed after confirmed DSDECOD=DEATH date — data integrity review","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS007","layer":"Beyond-P21","cat":"Temporal","domain":"DM/ALL","sev":"ERROR",
     "label":"Record observed after RFPENDTC (Last Contact date) — narrative continuity review","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS008","layer":"Beyond-P21","cat":"Temporal","domain":"DS/PR","sev":"CRITICAL",
     "label":"Procedure observed before RFICDTC — informed consent timing review required (ICH E6)","risk":"medical-concern","source":"ICH-E6/Beyond-P21"},
    # __ EXPOSURE ____________________________________________________________
    {"id":"EX001","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"Duplicate dosing record pattern (same USUBJID/EXTRT/EXSTDTC/EXDOSE) — review needed","risk":"structural","source":"P21"},
    {"id":"EX002","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"EXDOSE missing when EXOCCUR=Y — dose amount traceability gap","risk":"structural","source":"P21"},
    {"id":"EX003","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"WARNING",
     "label":"EXOCCUR != Y but EXDOSE > 0 — dose occurrence inconsistency","risk":"structural","source":"P21"},
    {"id":"EX004","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"WARNING",
     "label":"EXDOSU (dose units) missing — dose unit traceability gap","risk":"structural","source":"P21"},
    {"id":"EX005","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"EXSTDTC observed after subject death date in DS — temporal inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"EX006","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"EXSTDTC > EXENDTC for same infusion record — date sequence review needed","risk":"structural","source":"P21"},
    {"id":"EX007","layer":"Beyond-P21","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"Cumulative subject dose may exceed protocol-defined maximum — safety review recommended","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"EX008","layer":"Beyond-P21","cat":"Exposure","domain":"EX","sev":"ERROR",
     "label":"Treatment-epoch subject with no EX records — dosing evidence gap","risk":"medical-concern","source":"Beyond-P21"},
    # __ LABORATORY __________________________________________________________
    {"id":"LB001","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"ERROR",
     "label":"LB record observed after subject death date — temporal integrity review","risk":"medical-concern","source":"P21"},
    {"id":"LB002","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"ERROR",
     "label":"LBDTC visit ordinal inconsistency — review recommended","risk":"structural","source":"P21"},
    {"id":"LB003","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"Reference range absent when numeric result is present — grading completeness review","risk":"structural","source":"P21"},
    {"id":"LB004","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"LBSTRESN missing; LBORRES starts with > or < — consider using LBSTRESC","risk":"structural","source":"P21"},
    {"id":"LB005","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"LBORRES populated but LBSTRESN and LBSTRESC both missing — standardised result gap","risk":"structural","source":"P21"},
    {"id":"LB006","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"LBSTRESU missing with non-missing numeric result — unit traceability gap","risk":"structural","source":"P21"},
    {"id":"LB007","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"Partial date in LBDTC — day/month component ambiguity","risk":"structural","source":"P21"},
    {"id":"LB008","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"ERROR",
     "label":"LBORRES contains range (10-20) but LBSTRESN is single value — method documentation gap","risk":"structural","source":"Beyond-P21"},
    {"id":"LB009","layer":"Beyond-P21","cat":"Cross-Domain","domain":"LB/EX","sev":"ERROR",
     "label":"Pre-dose lab draw pattern — LBDTM appears after EXSTDTC; PK timing review recommended","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"LB010","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"LBNRIND value may be inconsistent with LBSTRESN vs. reference range","risk":"structural","source":"SDTMIG"},
    {"id":"LB011","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"ERROR",
     "label":"Hy's Law Signal — ALT > 3xULN and Total Bilirubin > 2xULN within 30-day window","risk":"medical-concern","source":"FDA DILI Guidance"},
    {"id":"LB012","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"WARNING",
     "label":"Duplicate LBDTC/LBTESTCD for same subject — possible double-entry pattern","risk":"structural","source":"Beyond-P21"},
    # __ VITAL SIGNS _________________________________________________________
    {"id":"VS001","layer":"P21-Base","cat":"Vital Signs","domain":"VS","sev":"CRITICAL",
     "label":"Diastolic BP > Systolic BP — physiologically inconsistent; SDV recommended","risk":"medical-concern","source":"P21/Physiology"},
    {"id":"VS002","layer":"P21-Base","cat":"Vital Signs","domain":"VS","sev":"ERROR",
     "label":"VS record observed after subject death date — temporal review needed","risk":"medical-concern","source":"P21"},
    {"id":"VS003","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"ERROR",
     "label":"Weight change > 20% between consecutive visits — physiological plausibility review","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"VS004","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING",
     "label":"Height appears to decrease significantly over time (> 5 cm from baseline)","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"VS005","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING",
     "label":"VSTESTCD=PULSE value outside plausible range (< 20 or > 300 BPM) — review recommended","risk":"medical-concern","source":"Physiology"},
    {"id":"VS006","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING",
     "label":"VSTESTCD=TEMP — value may be in Fahrenheit but VSSTRESU=C; unit review recommended","risk":"medical-concern","source":"Physiology"},
    {"id":"VS007","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING",
     "label":"VSTESTCD=SYSBP outside plausible range (< 40 or > 300 mmHg) — review recommended","risk":"medical-concern","source":"Physiology"},
    # __ ECG / CM / PK / QS / IE / SS / ONCOLOGY / DV / MH / OTHER __________
    {"id":"EG001","layer":"P21-Base","cat":"ECG","domain":"EG","sev":"ERROR",
     "label":"EGDTC and VISITNUM ordinal inconsistency","risk":"structural","source":"P21"},
    {"id":"EG002","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"WARNING",
     "label":"QTcF > 500 ms pattern without corresponding cardiac AE record — ICH E14 review","risk":"medical-concern","source":"ICH-E14"},
    {"id":"EG003","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"WARNING",
     "label":"QTcF increase > 60 ms from baseline without TEAE record — ICH E14 signal","risk":"medical-concern","source":"ICH-E14"},
    {"id":"EG004","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"ERROR",
     "label":"EG record observed after subject death date — temporal review needed","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"CM001","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"ERROR",
     "label":"CMDECOD (WHO Drug PT) missing — concomitant medication coding gap","risk":"structural","source":"P21"},
    {"id":"CM002","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"WARNING",
     "label":"CMLAT missing or inconsistent when CMCAT indicates laterality","risk":"structural","source":"P21"},
    {"id":"CM003","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"WARNING",
     "label":"Partial date in CMSTDTC or CMENDTC — date precision ambiguity","risk":"structural","source":"P21"},
    {"id":"CM004","layer":"Beyond-P21","cat":"CM Logic","domain":"CM","sev":"WARNING",
     "label":"CMENDTC appears before CMSTDTC — date sequence review recommended","risk":"structural","source":"SDTMIG"},
    {"id":"CM005","layer":"Beyond-P21","cat":"CM Logic","domain":"CM","sev":"WARNING",
     "label":"Possibly prohibited concomitant medication per protocol exclusion criteria","risk":"medical-concern","source":"Protocol"},
    {"id":"PK001","layer":"Beyond-P21","cat":"PK Concentrations","domain":"PC","sev":"ERROR",
     "label":"PC record without corresponding EX record on same day — PK traceability gap","risk":"medical-concern","source":"CDISC-PK"},
    {"id":"PK002","layer":"Beyond-P21","cat":"PK Concentrations","domain":"PC","sev":"ERROR",
     "label":"PCRFTDTC (reference time) appears after PCDTC (sample time) — PK timing review","risk":"structural","source":"SDTMIG"},
    {"id":"PK003","layer":"Beyond-P21","cat":"PK Parameters","domain":"PP","sev":"ERROR",
     "label":"PP record not linked to PC via RELREC — PK parameter traceability gap","risk":"structural","source":"CDISC-PK"},
    {"id":"PK004","layer":"Beyond-P21","cat":"PK Parameters","domain":"PP","sev":"WARNING",
     "label":"PPTESTCD=CMAX value lower than all PC concentrations — PK parameter plausibility review","risk":"medical-concern","source":"PK Logic"},
    {"id":"QS001","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"WARNING",
     "label":"Non-validated questionnaire mapped to QS domain — PRO instrument review recommended","risk":"structural","source":"SDTMIG"},
    {"id":"QS002","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"WARNING",
     "label":"Logically skipped QS items not flagged — QSSTAT/QSREASND completeness review","risk":"structural","source":"FDA TCG"},
    {"id":"QS003","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"ERROR",
     "label":"PRO total score inconsistent with sum of component item scores — scoring integrity review","risk":"medical-concern","source":"QRS Logic"},
    {"id":"IE001","layer":"Beyond-P21","cat":"IE Criteria","domain":"IE/TI","sev":"ERROR",
     "label":"IE.IETESTCD not found in TI domain — inclusion/exclusion traceability gap","risk":"structural","source":"PharmaSUG-2024"},
    {"id":"IE002","layer":"Beyond-P21","cat":"IE Criteria","domain":"IE","sev":"WARNING",
     "label":"IE exclusion criterion failure while subject DSDECOD=ENROLLED — eligibility review","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"SS001","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"ERROR",
     "label":"SS ALIVE status date later than DM death date — survival status inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"SS002","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"ERROR",
     "label":"SS DEAD status date before DM death date — survival status inconsistency","risk":"medical-concern","source":"P21"},
    {"id":"SS003","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"WARNING",
     "label":"SSSTAT=NOT DONE but non-missing SSORRES — survival status completeness review","risk":"structural","source":"P21"},
    {"id":"ONC001","layer":"P21-Base","cat":"Oncology","domain":"TR","sev":"WARNING",
     "label":"Duplicate TR record pattern (same USUBJID/TRTESTCD/TRDTC/TULNKID) — review needed","risk":"structural","source":"P21"},
    {"id":"ONC002","layer":"P21-Base","cat":"Oncology","domain":"TR","sev":"ERROR",
     "label":"TR TRDTC visit ordinal inconsistency","risk":"structural","source":"P21"},
    {"id":"ONC003","layer":"P21-Base","cat":"Oncology","domain":"TU","sev":"ERROR",
     "label":"New lesion in TU without RS RSORRES=PD at same timepoint — RECIST 1.1 review needed","risk":"medical-concern","source":"P21/RECIST 1.1"},
    {"id":"ONC004","layer":"Beyond-P21","cat":"Oncology","domain":"TR/TU","sev":"ERROR",
     "label":"TR lesion TULNKID not found in TU — tumor assessment linkage gap","risk":"structural","source":"SDTMIG"},
    {"id":"ONC005","layer":"Beyond-P21","cat":"Oncology","domain":"TR","sev":"ERROR",
     "label":"RECIST sum of target diameters may be inconsistent with individual LDIAM records","risk":"medical-concern","source":"RECIST 1.1"},
    {"id":"DV001","layer":"Beyond-P21","cat":"Protocol Dev.","domain":"DV","sev":"WARNING",
     "label":"Major protocol deviation pattern without DS discontinuation record — review recommended","risk":"medical-concern","source":"ICH-E6"},
    {"id":"DV002","layer":"Beyond-P21","cat":"Protocol Dev.","domain":"DV","sev":"WARNING",
     "label":"DVTERM not categorised — DVCAT missing; classification review needed","risk":"structural","source":"SDTMIG"},
    {"id":"MH001","layer":"P21-Base","cat":"Medical History","domain":"MH","sev":"WARNING",
     "label":"Partial date in MHSTDTC — date precision ambiguity","risk":"structural","source":"P21"},
    {"id":"MH002","layer":"Beyond-P21","cat":"Medical History","domain":"MH/AE","sev":"WARNING",
     "label":"MH ongoing condition also recorded as new AE — possible duplicate pattern; review recommended","risk":"advisory","source":"Beyond-P21"},
    {"id":"PR001","layer":"Beyond-P21","cat":"Procedures","domain":"PR/DS","sev":"CRITICAL",
     "label":"Procedure observed before informed consent date (RFICDTC) — GCP review required (ICH E6)","risk":"medical-concern","source":"Beyond-P21/ICH-E6"},
    {"id":"REL001","layer":"Beyond-P21","cat":"RELREC","domain":"RELREC","sev":"ERROR",
     "label":"RELREC IDVAR value not a valid key variable in referenced domain — traceability gap","risk":"structural","source":"SDTMIG"},
    {"id":"REL002","layer":"Beyond-P21","cat":"RELREC","domain":"RELREC","sev":"WARNING",
     "label":"PC/PP RELREC missing — PK parameter traceability gap","risk":"structural","source":"CDISC-PK"},
    {"id":"SV001","layer":"P21-Base","cat":"Visit Logic","domain":"SV","sev":"ERROR",
     "label":"SV SVSTDTC visit ordinal inconsistency","risk":"structural","source":"P21"},
    {"id":"SV002","layer":"P21-Base","cat":"Visit Logic","domain":"SV","sev":"WARNING",
     "label":"Duplicate records in SV — review for double-entry pattern","risk":"structural","source":"P21"},
    {"id":"SV003","layer":"Beyond-P21","cat":"Visit Logic","domain":"ALL/TV","sev":"ERROR",
     "label":"Visit window deviation — actual --DY appears to deviate > +/-3 days from VISITDY","risk":"structural","source":"Beyond-P21"},
    {"id":"BL001","layer":"Beyond-P21","cat":"Metadata","domain":"ALL/EX","sev":"ERROR",
     "label":"Baseline flag pattern — --BLFL=Y on record after first dose datetime; review recommended","risk":"structural","source":"Beyond-P21"},
    {"id":"BL002","layer":"Beyond-P21","cat":"Metadata","domain":"ALL","sev":"ERROR",
     "label":"Controlled terminology inconsistency — raw value may not align with CDISC CT","risk":"structural","source":"PharmaSUG-2020"},
    # __ HIDDEN INTEGRITY (v7) _______________________________________________
    {"id":"INT001","layer":"Hidden Integrity","cat":"Subject Integrity","domain":"ALL/DM","sev":"REJECT",
     "label":"Orphan Record — USUBJID present in observation domain but absent from DM; review required",
     "risk":"submission-blocker","source":"INT001"},
    {"id":"INT002","layer":"Hidden Integrity","cat":"Baseline Logic","domain":"ALL/DM","sev":"ERROR",
     "label":"Post-dose baseline flag pattern — --BLFL=Y on record after First Dose (RFSTDTC)",
     "risk":"medical-concern","source":"INT002"},
    {"id":"INT003","layer":"Hidden Integrity","cat":"Disposition Gap","domain":"DS/EX","sev":"ERROR",
     "label":"Study activity present (EX/LB/AE) but no End of Study disposition in DS — gap review",
     "risk":"structural","source":"INT003"},
    {"id":"INT004","layer":"Hidden Integrity","cat":"Physiological Logic","domain":"LB/DM","sev":"WARNING",
     "label":"Gender-discordant lab test — pregnancy/HCG test result for male subject; review recommended",
     "risk":"advisory","source":"INT004"},
    {"id":"INT005","layer":"Hidden Integrity","cat":"GCP Compliance","domain":"ALL/DM","sev":"CRITICAL",
     "label":"Pre-consent assessment pattern — study assessment before RFICDTC; GCP review required",
     "risk":"medical-concern","source":"ICH-E6/INT005"},
    # __ TEMPORAL INTEGRITY (v7) _____________________________________________
    {"id":"DATE001","layer":"Temporal Integrity","cat":"Date Logic","domain":"ALL","sev":"ERROR",
     "label":"Start date after end date within same record (--STDTC > --ENDTC) — date review needed",
     "risk":"structural","source":"DATE001"},
    {"id":"DATE002","layer":"Temporal Integrity","cat":"Post-Mortem Activity","domain":"ALL/DS","sev":"CRITICAL",
     "label":"Post-mortem clinical activity — record exists after confirmed subject death date",
     "risk":"submission-blocker","source":"DATE002"},
    {"id":"DATE003","layer":"Temporal Integrity","cat":"Date Logic","domain":"ALL","sev":"WARNING",
     "label":"Future date pattern — assessment date appears after today's data snapshot date",
     "risk":"advisory","source":"DATE003"},
    {"id":"DATE004","layer":"Temporal Integrity","cat":"Date Logic","domain":"DM","sev":"ERROR",
     "label":"Birth date (BRTHDTC) appears after study start date (RFSTDTC) — data review needed",
     "risk":"medical-concern","source":"DATE004"},
    {"id":"DATE005","layer":"Temporal Integrity","cat":"GCP Compliance","domain":"EX/DM","sev":"CRITICAL",
     "label":"Treatment before informed consent (EXSTDTC < RFICDTC) — GCP review required (ICH E6)",
     "risk":"medical-concern","source":"ICH-E6/DATE005"},
    {"id":"DATE006","layer":"Temporal Integrity","cat":"Disposition Gap","domain":"EX/DS","sev":"ERROR",
     "label":"Dosing after study discontinuation — EXENDTC appears after DS disposition date",
     "risk":"structural","source":"DATE006"},
    {"id":"DATE007","layer":"Temporal Integrity","cat":"Partial Date Criticality","domain":"DM","sev":"CRITICAL",
     "label":"GCP-critical date is partial — RFICDTC, RFSTDTC, or DTHDTC has incomplete precision",
     "risk":"medical-concern","source":"FDA/ICH-E6/DATE007"},
]

# ---------------------------------------------------------------------------
# YAML loader and hot-reload machinery
# ---------------------------------------------------------------------------
_cache_mtime: float = 0.0
_cache_checks: list = []
YAML_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "checks.yaml")

def _load_yaml() -> list:
    try:
        import yaml
        with open(YAML_PATH, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        raw   = data.get("checks", []) if isinstance(data, dict) else []
        req   = {"id","layer","cat","domain","sev","label","risk","source"}
        valid = [c for c in raw if isinstance(c, dict) and req.issubset(c.keys())]
        if len(valid) != len(raw):
            log.warning("checks.yaml: %d checks skipped (missing fields)", len(raw)-len(valid))
        return valid
    except ImportError:
        return []
    except FileNotFoundError:
        return []
    except Exception as exc:
        log.error("checks.yaml load error: %s", exc)
        return []

def _get_checks() -> list:
    global _cache_mtime, _cache_checks
    with _registry_lock:
        try:
            mtime = os.path.getmtime(YAML_PATH) if os.path.exists(YAML_PATH) else 0.0
        except OSError:
            mtime = 0.0
        if mtime != _cache_mtime:
            yaml_checks   = _load_yaml()
            _cache_checks = yaml_checks if yaml_checks else list(DEFAULT_CHECKS)
            _cache_mtime  = mtime
        return list(_cache_checks)

def get_checks() -> list:  return _get_checks()
def get_check(cid: str):   return next((c for c in _get_checks() if c["id"] == cid), None)

class _ChecksProxy:
    def __iter__(self):       return iter(_get_checks())
    def __len__(self):        return len(_get_checks())
    def __getitem__(self, i): return _get_checks()[i]
    def __contains__(self, x): return x in _get_checks()

CHECKS     = _ChecksProxy()
LAYERS     = sorted({c["layer"] for c in DEFAULT_CHECKS})
CATEGORIES = sorted({c["cat"]   for c in DEFAULT_CHECKS})

_get_checks()  # warm cache
