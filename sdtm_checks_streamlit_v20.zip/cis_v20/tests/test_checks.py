"""
CIS v17 — Comprehensive Test Suite
Tests all new v17 checks plus regression tests for core existing checks.
Run: pytest tests/ -v
"""
import sys, os, datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
import pandas as pd
import yaml

# ── helpers ──────────────────────────────────────────────────────────────────

def make_engine(check_id, extra_checks=None):
    """Create a ValidationEngine stub wired to a single check."""
    from modules.registry import CHECKS
    from modules.engine import ValidationEngine

    check = next((c for c in CHECKS if c["id"] == check_id), None)
    if check is None and extra_checks:
        check = next((c for c in extra_checks if c["id"] == check_id), None)
    assert check is not None, f"Check {check_id} not found in registry"

    eng = ValidationEngine.__new__(ValidationEngine)
    eng.enabled_ids = {check_id}
    eng._supp_merge_log = []
    return eng, check


def run_check(check_id, dd, extra_checks=None):
    """Run a single check against domain dict dd and return findings list."""
    eng, check = make_engine(check_id, extra_checks)
    return eng._run_actual(check, dd)


def dm_row(usubjid, rficdtc="", rfstdtc="", dthdtc="", dthfl="", armcd="ACTIVE", age=45):
    return {
        "USUBJID": usubjid, "RFICDTC": rficdtc, "RFSTDTC": rfstdtc,
        "DTHDTC": dthdtc, "DTHFL": dthfl, "ARMCD": armcd, "AGE": age,
        "STUDYID": "STUDY01", "DOMAIN": "DM",
    }


def ae_row(usubjid, aeterm="HEADACHE", aestdtc="2024-03-01", aeendtc="",
           aeout="NOT RECOVERED/NOT RESOLVED", aeser="N", aeacn="NONE",
           aebodsys="NERVOUS SYSTEM DISORDERS", aelat="", aesev="MILD"):
    return {
        "USUBJID": usubjid, "AETERM": aeterm, "AESTDTC": aestdtc,
        "AEENDTC": aeendtc, "AEOUT": aeout, "AESER": aeser,
        "AEACN": aeacn, "AEBODSYS": aebodsys, "AELAT": aelat,
        "AESEV": aesev, "STUDYID": "STUDY01", "DOMAIN": "AE",
    }


# ── Registry / YAML ────────────────────────────────────────────────────────────

class TestRegistry:
    def test_checks_yaml_loads(self):
        d = yaml.safe_load(open(os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "checks.yaml")))
        assert "checks" in d
        assert len(d["checks"]) >= 159

    def test_all_new_v17_ids_present(self):
        from modules.registry import CHECKS
        ids = {c["id"] for c in CHECKS}
        new_ids = {
            "GCP001","GCP002","GCP003","GCP004","GCP005",
            "MED001","MED002","MED003","MED004",
            "DAT008","DAT009","ONC006","ONC007",
            "QS001","QS002","QS003","QS004",
            "ANL001","ANL002","ANL003",
            "META001","META002","META003",
        }
        missing = new_ids - ids
        assert not missing, f"Missing from registry: {missing}"

    def test_all_checks_have_required_fields(self):
        from modules.registry import CHECKS
        for c in CHECKS:
            assert "id" in c, f"Missing id"
            assert "sev" in c, f"{c.get('id')} missing sev"
            assert "label" in c, f"{c.get('id')} missing label"
            assert "risk" in c, f"{c.get('id')} missing risk"
            assert "source" in c, f"{c.get('id')} missing source"

    def test_no_duplicate_check_ids(self):
        from modules.registry import CHECKS
        ids = [c["id"] for c in CHECKS]
        assert len(ids) == len(set(ids)), "Duplicate check IDs found"

    def test_study_config_yaml_loads(self):
        cfg = yaml.safe_load(open(os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "study_config.yaml")))
        assert "partial_date_policy" in cfg
        assert "date_parser" in cfg
        pdp = cfg["partial_date_policy"]
        assert "allowed_patterns" in pdp
        assert "reject_patterns" in pdp
        assert "action_on_reject" in pdp
        assert pdp["action_on_reject"] == "CRITICAL"


# ── GCP Checks ────────────────────────────────────────────────────────────────

class TestGCP001:
    """PR record before RFICDTC."""

    def _dd(self, pr_date, rficdtc):
        return {
            "PR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "PRSTDTC": pr_date,
                "STUDYID": "STUDY01", "DOMAIN": "PR",
            }]),
            "DM": pd.DataFrame([dm_row("SUBJ01", rficdtc=rficdtc)]),
        }

    def test_violation_pr_before_consent(self):
        findings = run_check("GCP001", self._dd("2024-01-10", "2024-01-15"))
        assert len(findings) >= 1
        assert any("RFICDTC" in f.get("detail","") or "consent" in f.get("detail","").lower()
                   for f in findings)

    def test_clean_pr_after_consent(self):
        findings = run_check("GCP001", self._dd("2024-01-20", "2024-01-15"))
        assert len(findings) == 0

    def test_same_day_is_clean(self):
        findings = run_check("GCP001", self._dd("2024-01-15", "2024-01-15"))
        assert len(findings) == 0

    def test_missing_pr_domain(self):
        dd = {"PR": pd.DataFrame(), "DM": pd.DataFrame([dm_row("SUBJ01", rficdtc="2024-01-15")])}
        findings = run_check("GCP001", dd)
        assert len(findings) == 0

    def test_partial_pr_date_skipped(self):
        # Partial PRSTDTC (< 10 chars) should not trigger
        findings = run_check("GCP001", self._dd("2024-01", "2024-01-15"))
        assert len(findings) == 0


class TestGCP002:
    """DTHDTC in DM but no DEATH in DS."""

    def _dd(self, dthdtc, ds_dsdecod=None):
        dm = pd.DataFrame([dm_row("SUBJ01", dthdtc=dthdtc)])
        ds_rows = []
        if ds_dsdecod:
            ds_rows.append({
                "USUBJID": "SUBJ01", "DSDECOD": ds_dsdecod,
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            })
        return {"DM": dm, "DS": pd.DataFrame(ds_rows) if ds_rows else pd.DataFrame(
            columns=["USUBJID","DSDECOD","DSSTDTC"])}

    def test_death_in_dm_no_ds(self):
        findings = run_check("GCP002", self._dd("2024-06-01"))
        assert len(findings) >= 1

    def test_death_in_dm_and_ds(self):
        findings = run_check("GCP002", self._dd("2024-06-01", "DEATH"))
        assert len(findings) == 0

    def test_no_death_date_clean(self):
        findings = run_check("GCP002", self._dd(""))
        assert len(findings) == 0


class TestGCP003:
    """DEATH in DS but DTHDTC missing in DM."""

    def test_death_ds_no_dm_date(self):
        dd = {
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="")]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "DEATH",
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP003", dd)
        assert len(findings) >= 1

    def test_death_ds_with_dm_date_clean(self):
        dd = {
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="2024-06-01")]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "DEATH",
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP003", dd)
        assert len(findings) == 0

    def test_no_death_row_in_ds_clean(self):
        dd = {
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="")]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "COMPLETED",
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP003", dd)
        assert len(findings) == 0


class TestGCP004:
    """EX dosing after DS discontinuation."""

    def test_dosing_after_discontinuation(self):
        dd = {
            "EX": pd.DataFrame([{
                "USUBJID": "SUBJ01", "EXSTDTC": "2024-07-01",
                "EXTRT": "DRUG A", "STUDYID": "STUDY01", "DOMAIN": "EX",
            }]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "DISCONTINUED",
                "DSSTDTC": "2024-06-15", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP004", dd)
        assert len(findings) >= 1

    def test_dosing_before_discontinuation_clean(self):
        dd = {
            "EX": pd.DataFrame([{
                "USUBJID": "SUBJ01", "EXSTDTC": "2024-06-01",
                "EXTRT": "DRUG A", "STUDYID": "STUDY01", "DOMAIN": "EX",
            }]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "DISCONTINUED",
                "DSSTDTC": "2024-06-15", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP004", dd)
        assert len(findings) == 0


class TestGCP005:
    """AEACN=DRUG WITHDRAWN with no DS discontinuation."""

    def test_drug_withdrawn_no_ds(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeacn="DRUG WITHDRAWN")]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "COMPLETED",
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP005", dd)
        assert len(findings) >= 1

    def test_drug_withdrawn_with_ds_discontinuation(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeacn="DRUG WITHDRAWN")]),
            "DS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "DSDECOD": "DISCONTINUED",
                "DSSTDTC": "2024-06-01", "STUDYID": "STUDY01", "DOMAIN": "DS",
            }]),
        }
        findings = run_check("GCP005", dd)
        assert len(findings) == 0

    def test_normal_aeacn_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeacn="NONE")]),
            "DS": pd.DataFrame(columns=["USUBJID","DSDECOD","DSSTDTC"]),
        }
        findings = run_check("GCP005", dd)
        assert len(findings) == 0


# ── MED Checks ────────────────────────────────────────────────────────────────

class TestMED001:
    """Abnormal LB with no AE within ±7 days."""

    def _lb(self, usubjid, lbdtc, lbnrind):
        return pd.DataFrame([{
            "USUBJID": usubjid, "LBDTC": lbdtc,
            "LBNRIND": lbnrind, "LBTESTCD": "ALT",
            "STUDYID": "STUDY01", "DOMAIN": "LB",
        }])

    def test_abnormal_lb_no_ae(self):
        dd = {
            "LB": self._lb("SUBJ01", "2024-03-01", "HIGH"),
            "AE": pd.DataFrame(columns=["USUBJID","AESTDTC"]),
        }
        findings = run_check("MED001", dd)
        assert len(findings) >= 1

    def test_abnormal_lb_with_nearby_ae(self):
        dd = {
            "LB": self._lb("SUBJ01", "2024-03-01", "HIGH"),
            "AE": pd.DataFrame([ae_row("SUBJ01", aestdtc="2024-03-03")]),
        }
        findings = run_check("MED001", dd)
        assert len(findings) == 0

    def test_normal_lb_clean(self):
        dd = {
            "LB": self._lb("SUBJ01", "2024-03-01", "NORMAL"),
            "AE": pd.DataFrame(columns=["USUBJID","AESTDTC"]),
        }
        findings = run_check("MED001", dd)
        assert len(findings) == 0

    def test_ae_outside_7_day_window_flags(self):
        dd = {
            "LB": self._lb("SUBJ01", "2024-03-01", "LOW"),
            "AE": pd.DataFrame([ae_row("SUBJ01", aestdtc="2024-03-15")]),
        }
        findings = run_check("MED001", dd)
        assert len(findings) >= 1


class TestMED002:
    """AEOUT=FATAL but AEENDTC != DTHDTC."""

    def test_fatal_date_mismatch(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="FATAL", aeendtc="2024-06-02")]),
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="2024-06-01")]),
        }
        findings = run_check("MED002", dd)
        assert len(findings) >= 1

    def test_fatal_date_match_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="FATAL", aeendtc="2024-06-01")]),
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="2024-06-01")]),
        }
        findings = run_check("MED002", dd)
        assert len(findings) == 0

    def test_non_fatal_ae_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="RECOVERED/RESOLVED")]),
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="")]),
        }
        findings = run_check("MED002", dd)
        assert len(findings) == 0


class TestMED003:
    """AEOUT=RECOVERED but AEENDTC missing."""

    def test_resolved_no_enddate(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="RECOVERED/RESOLVED", aeendtc="")]),
        }
        findings = run_check("MED003", dd)
        assert len(findings) >= 1

    def test_resolved_with_enddate_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="RECOVERED/RESOLVED", aeendtc="2024-04-01")]),
        }
        findings = run_check("MED003", dd)
        assert len(findings) == 0

    def test_ongoing_ae_no_enddate_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="NOT RECOVERED/NOT RESOLVED", aeendtc="")]),
        }
        findings = run_check("MED003", dd)
        assert len(findings) == 0


class TestMED004:
    """Ocular AE without AELAT."""

    def test_ocular_ae_no_lat(self):
        dd = {
            "AE": pd.DataFrame([ae_row(
                "SUBJ01", aeterm="RETINAL DETACHMENT",
                aebodsys="EYE DISORDERS", aelat="")]),
        }
        findings = run_check("MED004", dd)
        assert len(findings) >= 1

    def test_ocular_ae_with_lat_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row(
                "SUBJ01", aeterm="RETINAL DETACHMENT",
                aebodsys="EYE DISORDERS", aelat="LEFT")]),
        }
        findings = run_check("MED004", dd)
        assert len(findings) == 0

    def test_non_ocular_ae_no_lat_clean(self):
        dd = {
            "AE": pd.DataFrame([ae_row(
                "SUBJ01", aeterm="NAUSEA",
                aebodsys="GASTROINTESTINAL DISORDERS", aelat="")]),
        }
        findings = run_check("MED004", dd)
        assert len(findings) == 0


# ── Data Checks ───────────────────────────────────────────────────────────────

class TestDAT008:
    """Record date after last SV visit date."""

    def _sv(self, usubjid, svstdtc):
        return pd.DataFrame([{
            "USUBJID": usubjid, "SVSTDTC": svstdtc,
            "VISITNUM": 1, "STUDYID": "STUDY01", "DOMAIN": "SV",
        }])

    def test_lb_after_last_visit(self):
        dd = {
            "SV": self._sv("SUBJ01", "2024-06-01"),
            "LB": pd.DataFrame([{
                "USUBJID": "SUBJ01", "LBDTC": "2024-06-15",
                "LBTESTCD": "ALT", "STUDYID": "STUDY01", "DOMAIN": "LB",
            }]),
        }
        findings = run_check("DAT008", dd)
        assert len(findings) >= 1

    def test_lb_before_last_visit_clean(self):
        dd = {
            "SV": self._sv("SUBJ01", "2024-06-01"),
            "LB": pd.DataFrame([{
                "USUBJID": "SUBJ01", "LBDTC": "2024-05-15",
                "LBTESTCD": "ALT", "STUDYID": "STUDY01", "DOMAIN": "LB",
            }]),
        }
        findings = run_check("DAT008", dd)
        assert len(findings) == 0


class TestDAT009:
    """Partial date year+day, month missing (YYYY---DD)."""

    def test_partial_date_flagged(self):
        dd = {
            "LB": pd.DataFrame([{
                "USUBJID": "SUBJ01", "LBDTC": "2024--15",
                "LBTESTCD": "ALT", "STUDYID": "STUDY01", "DOMAIN": "LB",
            }]),
        }
        findings = run_check("DAT009", dd)
        assert len(findings) >= 1

    def test_full_date_clean(self):
        dd = {
            "LB": pd.DataFrame([{
                "USUBJID": "SUBJ01", "LBDTC": "2024-03-15",
                "LBTESTCD": "ALT", "STUDYID": "STUDY01", "DOMAIN": "LB",
            }]),
        }
        findings = run_check("DAT009", dd)
        assert len(findings) == 0


# ── ONC Checks ────────────────────────────────────────────────────────────────

class TestONC006:
    """TR CR but RS PD — RECIST contradiction."""

    def test_cr_tr_pd_rs_contradiction(self):
        dd = {
            "TR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "TRORRES": "CR",
                "VISITNUM": 2, "STUDYID": "STUDY01", "DOMAIN": "TR",
            }]),
            "RS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "RSORRES": "PD",
                "VISITNUM": 2, "STUDYID": "STUDY01", "DOMAIN": "RS",
            }]),
        }
        findings = run_check("ONC006", dd)
        assert len(findings) >= 1

    def test_consistent_responses_clean(self):
        dd = {
            "TR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "TRORRES": "CR",
                "VISITNUM": 2, "STUDYID": "STUDY01", "DOMAIN": "TR",
            }]),
            "RS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "RSORRES": "CR",
                "VISITNUM": 2, "STUDYID": "STUDY01", "DOMAIN": "RS",
            }]),
        }
        findings = run_check("ONC006", dd)
        assert len(findings) == 0


class TestONC007:
    """TRSTRESN missing for LDIAM target lesion."""

    def test_ldiam_missing_trstresn(self):
        dd = {
            "TR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "TRTESTCD": "LDIAM",
                "TRSTRESN": "", "VISITNUM": 1,
                "STUDYID": "STUDY01", "DOMAIN": "TR",
            }]),
        }
        findings = run_check("ONC007", dd)
        assert len(findings) >= 1

    def test_ldiam_with_trstresn_clean(self):
        dd = {
            "TR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "TRTESTCD": "LDIAM",
                "TRSTRESN": "15.5", "VISITNUM": 1,
                "STUDYID": "STUDY01", "DOMAIN": "TR",
            }]),
        }
        findings = run_check("ONC007", dd)
        assert len(findings) == 0

    def test_non_ldiam_missing_trstresn_clean(self):
        dd = {
            "TR": pd.DataFrame([{
                "USUBJID": "SUBJ01", "TRTESTCD": "SUMDIAM",
                "TRSTRESN": "", "VISITNUM": 1,
                "STUDYID": "STUDY01", "DOMAIN": "TR",
            }]),
        }
        findings = run_check("ONC007", dd)
        assert len(findings) == 0


# ── QS Checks ────────────────────────────────────────────────────────────────

class TestQS001:
    """QSSTAT=NOT DONE but QSSTRESC not null."""

    def _qs(self, qsstat, qsstresc, qsreasnd=""):
        return pd.DataFrame([{
            "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
            "QSSTAT": qsstat, "QSSTRESC": qsstresc,
            "QSREASND": qsreasnd, "QSDTC": "2024-03-01",
            "VISITNUM": 1, "STUDYID": "STUDY01", "DOMAIN": "QS",
        }])

    def test_not_done_with_result(self):
        findings = run_check("QS001", {"QS": self._qs("NOT DONE", "Agree")})
        assert len(findings) >= 1

    def test_not_done_no_result_clean(self):
        findings = run_check("QS001", {"QS": self._qs("NOT DONE", "")})
        assert len(findings) == 0

    def test_done_with_result_clean(self):
        findings = run_check("QS001", {"QS": self._qs("", "Agree")})
        assert len(findings) == 0


class TestQS002:
    """QS date after death date."""

    def test_qs_after_death(self):
        dd = {
            "QS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
                "QSDTC": "2024-07-01", "QSSTRESC": "Yes",
                "VISITNUM": 3, "STUDYID": "STUDY01", "DOMAIN": "QS",
            }]),
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="2024-06-01")]),
        }
        findings = run_check("QS002", dd)
        assert len(findings) >= 1

    def test_qs_before_death_clean(self):
        dd = {
            "QS": pd.DataFrame([{
                "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
                "QSDTC": "2024-05-01", "QSSTRESC": "Yes",
                "VISITNUM": 2, "STUDYID": "STUDY01", "DOMAIN": "QS",
            }]),
            "DM": pd.DataFrame([dm_row("SUBJ01", dthdtc="2024-06-01")]),
        }
        findings = run_check("QS002", dd)
        assert len(findings) == 0


class TestQS003:
    """Duplicate QS records."""

    def test_duplicate_qs(self):
        row = {
            "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
            "QSDTC": "2024-03-01", "VISITNUM": 1,
            "QSSTRESC": "Agree", "STUDYID": "STUDY01", "DOMAIN": "QS",
        }
        dd = {"QS": pd.DataFrame([row, row])}
        findings = run_check("QS003", dd)
        assert len(findings) >= 1

    def test_no_duplicate_clean(self):
        rows = [
            {"USUBJID": "SUBJ01", "QSTESTCD": "Q01", "QSDTC": "2024-03-01",
             "VISITNUM": 1, "QSSTRESC": "Agree", "STUDYID": "STUDY01", "DOMAIN": "QS"},
            {"USUBJID": "SUBJ01", "QSTESTCD": "Q01", "QSDTC": "2024-04-01",
             "VISITNUM": 2, "QSSTRESC": "Agree", "STUDYID": "STUDY01", "DOMAIN": "QS"},
        ]
        dd = {"QS": pd.DataFrame(rows)}
        findings = run_check("QS003", dd)
        assert len(findings) == 0


class TestQS004:
    """QSSTAT=NOT DONE but QSREASND missing."""

    def test_not_done_no_reason(self):
        dd = {"QS": pd.DataFrame([{
            "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
            "QSSTAT": "NOT DONE", "QSREASND": "",
            "QSDTC": "2024-03-01", "VISITNUM": 1,
            "STUDYID": "STUDY01", "DOMAIN": "QS",
        }])}
        findings = run_check("QS004", dd)
        assert len(findings) >= 1

    def test_not_done_with_reason_clean(self):
        dd = {"QS": pd.DataFrame([{
            "USUBJID": "SUBJ01", "QSTESTCD": "Q01",
            "QSSTAT": "NOT DONE", "QSREASND": "SUBJECT REFUSED",
            "QSDTC": "2024-03-01", "VISITNUM": 1,
            "STUDYID": "STUDY01", "DOMAIN": "QS",
        }])}
        findings = run_check("QS004", dd)
        assert len(findings) == 0


# ── ANL / META Checks ─────────────────────────────────────────────────────────

class TestANL002:
    """TS missing MedDRA version."""

    def test_meddra_missing(self):
        dd = {"TS": pd.DataFrame([{
            "TSPARMCD": "WHODRUG", "TSVAL": "2024Q1",
            "STUDYID": "STUDY01", "DOMAIN": "TS",
        }])}
        findings = run_check("ANL002", dd)
        assert len(findings) >= 1

    def test_meddra_present_clean(self):
        dd = {"TS": pd.DataFrame([
            {"TSPARMCD": "MEDDRA", "TSVAL": "26.1",
             "STUDYID": "STUDY01", "DOMAIN": "TS"},
        ])}
        findings = run_check("ANL002", dd)
        assert len(findings) == 0

    def test_empty_ts(self):
        # Empty TS — no crash, returns empty
        dd = {"TS": pd.DataFrame(columns=["TSPARMCD","TSVAL"])}
        findings = run_check("ANL002", dd)
        assert isinstance(findings, list)


class TestANL003:
    """TS missing WHODrug version."""

    def test_whodrug_missing(self):
        dd = {"TS": pd.DataFrame([{
            "TSPARMCD": "MEDDRA", "TSVAL": "26.1",
            "STUDYID": "STUDY01", "DOMAIN": "TS",
        }])}
        findings = run_check("ANL003", dd)
        assert len(findings) >= 1

    def test_whodrug_present_clean(self):
        dd = {"TS": pd.DataFrame([
            {"TSPARMCD": "WHODRUG", "TSVAL": "2024Q1",
             "STUDYID": "STUDY01", "DOMAIN": "TS"},
        ])}
        findings = run_check("ANL003", dd)
        assert len(findings) == 0


class TestMETA002:
    """AEOUT CT value off-list."""

    def test_invalid_aeout(self):
        dd = {"AE": pd.DataFrame([
            ae_row("SUBJ01", aeout="CURED")  # not a valid CT value
        ])}
        findings = run_check("META002", dd)
        assert len(findings) >= 1

    def test_valid_aeout_clean(self):
        dd = {"AE": pd.DataFrame([
            ae_row("SUBJ01", aeout="RECOVERED/RESOLVED")
        ])}
        findings = run_check("META002", dd)
        assert len(findings) == 0


# ── Engine robustness ─────────────────────────────────────────────────────────

class TestEngineRobustness:
    """Checks must not raise exceptions on empty or malformed data."""

    NEW_IDS = [
        "GCP001","GCP002","GCP003","GCP004","GCP005",
        "MED001","MED002","MED003","MED004",
        "DAT008","DAT009","ONC006","ONC007",
        "QS001","QS002","QS003","QS004",
        "ANL001","ANL002","ANL003",
        "META001","META002","META003",
    ]

    def test_all_new_checks_handle_empty_dd(self):
        for cid in self.NEW_IDS:
            try:
                findings = run_check(cid, {})
                assert isinstance(findings, list), f"{cid} did not return list"
            except Exception as e:
                pytest.fail(f"{cid} raised {type(e).__name__}: {e}")

    def test_all_new_checks_handle_empty_dataframes(self):
        empty_dd = {
            "DM": pd.DataFrame(), "AE": pd.DataFrame(), "EX": pd.DataFrame(),
            "LB": pd.DataFrame(), "DS": pd.DataFrame(), "PR": pd.DataFrame(),
            "QS": pd.DataFrame(), "TS": pd.DataFrame(), "TR": pd.DataFrame(),
            "RS": pd.DataFrame(), "SV": pd.DataFrame(),
        }
        for cid in self.NEW_IDS:
            try:
                findings = run_check(cid, empty_dd)
                assert isinstance(findings, list), f"{cid} did not return list"
            except Exception as e:
                pytest.fail(f"{cid} raised {type(e).__name__} on empty DFs: {e}")

    def test_checks_handle_missing_columns(self):
        """Minimal DFs with only USUBJID — no domain-specific columns."""
        sparse_dd = {
            "DM": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "AE": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "EX": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "DS": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "LB": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "QS": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "TS": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "TR": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "RS": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "SV": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
            "PR": pd.DataFrame([{"USUBJID": "SUBJ01"}]),
        }
        for cid in self.NEW_IDS:
            try:
                findings = run_check(cid, sparse_dd)
                assert isinstance(findings, list), f"{cid} did not return list"
            except Exception as e:
                pytest.fail(f"{cid} raised {type(e).__name__} on sparse DFs: {e}")

    def test_findings_have_required_fields(self):
        """Each finding must contain fid, sev, subj, detail."""
        dd = {
            "AE": pd.DataFrame([ae_row("SUBJ01", aeout="CURED")]),
            "DM": pd.DataFrame([dm_row("SUBJ01")]),
        }
        findings = run_check("META002", dd)
        for f in findings:
            assert "fid" in f, "Finding missing fid"
            assert "sev" in f, "Finding missing sev"
            assert "subj" in f, "Finding missing subj"
            assert "detail" in f or "label" in f, "Finding missing detail/label"


# ── DATE007 (existing check — partial date regression) ────────────────────────

class TestDATE007Regression:
    """Regression: partial date check must not flag full dates."""

    def test_full_rficdtc_clean(self):
        dd = {"DM": pd.DataFrame([dm_row("SUBJ01", rficdtc="2024-03-15")])}
        findings = run_check("DATE007", dd)
        assert len(findings) == 0

    def test_partial_rficdtc_flagged(self):
        dd = {"DM": pd.DataFrame([dm_row("SUBJ01", rficdtc="2024-03")])}
        findings = run_check("DATE007", dd)
        assert len(findings) >= 1

    def test_year_only_rficdtc_flagged(self):
        dd = {"DM": pd.DataFrame([dm_row("SUBJ01", rficdtc="2024")])}
        findings = run_check("DATE007", dd)
        assert len(findings) >= 1

    def test_empty_rficdtc_clean(self):
        dd = {"DM": pd.DataFrame([dm_row("SUBJ01", rficdtc="")])}
        findings = run_check("DATE007", dd)
        assert len(findings) == 0


# ── app.py smoke tests ────────────────────────────────────────────────────────

class TestAppNoAgGrid:
    """Verify AgGrid has been removed from app.py."""

    def _app_src(self):
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "app.py")
        return open(path).read()

    def test_aggrid_import_removed(self):
        src = self._app_src()
        # st_aggrid should not be a hard import at module level
        assert "import st_aggrid" not in src.split("try:")[0], \
            "st_aggrid imported outside try/except at module level"

    def test_findings_table_tab_renamed(self):
        src = self._app_src()
        assert "Findings Table" in src, "Tab should be renamed to Findings Table"
        assert "AgGrid Review" not in src, "Old AgGrid Review tab name still present"

    def test_no_jscode_in_app(self):
        src = self._app_src()
        assert "JsCode" not in src, "JsCode still referenced in app.py"

    def test_native_dataframe_present(self):
        src = self._app_src()
        assert "st.dataframe" in src, "st.dataframe should be used in findings tab"
        assert "st.column_config" in src, "st.column_config should be used"

    def test_app_syntax_valid(self):
        import ast
        src = self._app_src()
        try:
            ast.parse(src)
        except SyntaxError as e:
            pytest.fail(f"app.py has syntax error: {e}")
