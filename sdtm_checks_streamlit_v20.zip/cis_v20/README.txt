SDTM Clinical Integrity Suite - Streamlit Edition v5.0
=======================================================
Beyond-P21 Validation Dashboard | 124 Checks | 35+ Domains | FDA JumpStart

=======================================================================
EXACT STEPS TO RUN (Windows CMD / Anaconda Prompt)
=======================================================================

OPTION A: Using Anaconda (RECOMMENDED)
---------------------------------------
Open "Anaconda Prompt" from the Start Menu, then:

  Step 1 - Create environment (ONCE only):
      conda create -n sdtm python=3.12 -y

  Step 2 - Activate it (every time):
      conda activate sdtm

  Step 3 - Install dependencies (ONCE only):
      pip install streamlit pandas openpyxl

  Step 4 - Navigate to this folder:
      cd C:\path\to\sdtm_streamlit

  Step 5 - Run:
      streamlit run app.py

  Browser opens automatically at: http://localhost:8501


OPTION B: Using plain CMD (if Python already installed)
--------------------------------------------------------
  Open CMD, then:

      pip install streamlit pandas openpyxl

      cd C:\path\to\sdtm_streamlit

      streamlit run app.py

  Browser opens automatically at: http://localhost:8501


=======================================================================
IF BROWSER DOES NOT OPEN AUTOMATICALLY
=======================================================================
  Open your browser manually and go to:
      http://localhost:8501

  Or the URL shown in CMD/Anaconda Prompt output.


=======================================================================
HOW TO STOP THE APP
=======================================================================
  Press Ctrl+C in the CMD / Anaconda Prompt window.


=======================================================================
USING THE DASHBOARD
=======================================================================

  SIDEBAR (left side):
    1. Upload SDTM files (SAS7BDAT, XPT, CSV, XLSX, JSON, XML)
       - Drag and drop, or click Browse Files
       - Without files: runs with 40 demo findings automatically

    2. Configure checks:
       - Enable All / Disable All buttons
       - Filter by Layer, Category, or search by keyword
       - Toggle individual checks on/off

    3. Click "Run Validation" button
       - Progress bar shows current check being executed
       - Takes 2-10 seconds depending on data size

    4. Download HTML Report
       - Appears after first run
       - Saves a standalone dark-mode HTML file

  MAIN TABS:
    Dashboard       - Scorecards + bar charts by risk/severity/domain
    Integrity Report- Grouped findings (root-cause + subject groups)
                      Click expanders to see findings
                      Enter waiver notes and click Waive button
    Subject View    - All subjects sorted by worst risk, searchable
    Domain Map      - All 35+ SDTM domains with check/finding counts
    Check Registry  - All 124 registered checks, searchable/filterable
    Files           - Loaded file metadata and variable preview


=======================================================================
TROUBLESHOOTING
=======================================================================

  Problem: "streamlit is not recognized"
  Fix: Make sure conda activate sdtm was run, then pip install streamlit

  Problem: "ModuleNotFoundError: No module named 'openpyxl'"
  Fix: pip install openpyxl

  Problem: Port 8501 already in use
  Fix: streamlit run app.py --server.port 8502

  Problem: App loads but no findings after clicking Run
  Fix: This is normal - upload SDTM files first, OR just click Run
       to see 40 pre-loaded demo findings (no files needed)

  Problem: File uploaded but shows 0 rows
  Fix: For SAS7BDAT/XPT, only variable names are extracted (no row data)
       For full row reading: pip install pyreadstat
       For CSV/XLSX: full data is read automatically

  Problem: Rename file for domain auto-detection
  Fix: Name your files matching the SDTM domain:
       ae.csv, vs.csv, lb.csv, dm.csv, ex.csv, cm.csv etc.


=======================================================================
PROJECT FILES
=======================================================================

  app.py                  Main Streamlit application
  requirements.txt        Python packages
  README.txt              This file
  .streamlit/
    config.toml           Dark theme + server config
  modules/
    __init__.py           Package init
    registry.py           124 check definitions
    engine.py             Validation engine (actual + demo)
    parser.py             File parser (CSV/XLSX/XPT/SAS7BDAT/JSON/XML)
    reporter.py           HTML report generator


=======================================================================
CHECKS REGISTERED: 124 across 35+ SDTM domains
=======================================================================

  Structure / Define-XML / SUPPQUAL    18 checks
  Trial Design (TS/TA/TE/TI/TV/SE)     8 checks
  Demographics (DM)                     9 checks
  Adverse Events (AE)                  16 checks
  Disposition (DS)                      8 checks
  Exposure (EX)                         8 checks
  Laboratory (LB)                      12 checks
  Vital Signs (VS)                      7 checks
  ECG (EG)                              4 checks
  Concomitant Medications (CM)          5 checks
  Pharmacokinetics (PC/PP)              4 checks
  Questionnaires (QS)                   3 checks
  Inclusion/Exclusion (IE/TI)           2 checks
  Subject Status (SS)                   3 checks
  Oncology (TR/TU/RS)                   5 checks
  Protocol Deviations (DV)              2 checks
  Medical History (MH) / Procedures     3 checks
  RELREC / Visit Logic / Metadata       5 checks


=======================================================================
SOURCES
=======================================================================

  FDA TCG 2024, SDTMIG v3.4, Pinnacle21 Community,
  PharmaSUG 2012-2024, ICH E2A/E3/E6/E14, CDISC CT,
  RECIST 1.1, FDA DILI Guidance, NCI CTCAE v5, MedDRA,
  WHO Drug, CDISC PK Model, QRS Specification, Beyond-P21
