## v18.1 — 2026-04-05

### SAS Code Generation (complete rewrite)
- All v17/v18 checks now have precise, ready-to-use PROC SQL templates
  replacing the generic `WHERE 1=1` fallback that appeared in Image 1
- 30+ new SAS templates added to _CROSS_DOMAIN_SQL including:
  GCP001-005, MED001-004, ONC006-011, QS001-004, ANL002-003,
  DSP009-011, S016, S018, BAS001, LB014-015, DAT008, DAY001, TMP009
- Every SAS query includes: proper multi-table JOINs, domain-specific SELECT columns,
  subject-level USUBJID filter injection, INTCK() for date arithmetic,
  NOT EXISTS subqueries for cross-domain checks, SAS macro patterns for
  multi-domain checks (TMP009, DAY001)
- Generic fallback now selects meaningful domain columns (not SELECT *)
  and extracts TESTCD, VISITNUM, date, and value filters from the detail string

### Gantt Timeline — Lab Collapse (fixes Image 2 & 3)
- Similar findings in high-noise categories are now collapsed into one row:
  Under-reporting, Lab Logic, Lab Units, Temporal, Questionnaire, Cross-Domain, Partial Date
- Collapsed rows show a larger dot with count badge (×N) in the SVG
- Worst-risk colour drives the collapsed row colour
- Event sequence (vertical list) shows ×N collapsed badge on grouped rows
- Un-collapsed rows remain individually visible for non-lab categories
- Legend updated: adds ⬤ Collapsed group marker

## v18.0 — 2026-04-05

### Improvements (A1–A14)
- A1  Demo mode controlled by study_config.yaml demo_mode.mode (disabled/auto/always)
       and DEMO_MODE environment variable. Disabled mode eliminates all synthetic findings.
- A2  AE015 (Grade 3/4 lab toxicity without AE) demoted CRITICAL → WARNING.
       Lab toxicity is a data quality signal, not a GCP violation.
- A3  Performance warning in sidebar when >500k total rows loaded across domains.
       Advises pre-filtering LB/AE/CM for large studies.
- A4  (Noted — GCP001/DATE005 and GCP004/DATE006 cross-referenced in docs;
       users can disable overlapping checks via sidebar toggle.)
- A5  TEAE window configurable: teae_window_days in study_config.yaml (default 30).
       MED001 also reads this window (was hardcoded ±7d, now configurable).
- A6  Lab exclusion list: exclude_lbtestcd_from_med001 and exclude_lbtestcd_from_lb003
       in study_config.yaml — suppresses nuisance warnings for expected abnormal labs.
- A7  allow_missing_dthdtc_if_study_ongoing in study_config.yaml — suppresses DATE007
       DTHDTC partial-date findings in ongoing studies where DTHFL=Y is provisional.
- A8  allow_missing_aeenddtc_if_sameday in study_config.yaml — suppresses MED003 when
       AE resolves same day as start (blank AEENDTC is acceptable per site practice).
- A9  required_ts_params in study_config.yaml — override default TD001 required TS list
       per study (e.g. exploratory studies may not need TTYPE, INTMODEL, PCLAS).
- A10 TD007 (VISITNUM not in TV) demoted to WARNING globally; promoted back to ERROR
       dynamically when regulatory_mode = fda_safety_review.
- A11 min_age / max_age in study_config.yaml population_rules. DM007/DM008 read these
       at runtime. allow_paediatric=true suppresses DM008 entirely.
- A12 requirements.txt documents which checks require external dictionaries (MedDRA,
       WHODrug, CDISC CT). Missing dictionaries degrade confidence to LOW, not silent skip.
- A13 requirements.txt and docs note EX007 implements simple total dose only (not mg/kg).
- A14 duplicate_tolerance_days in study_config.yaml ae_rules (AE008 fuzzy date matching).

### New Checks (20)
- S019  CRITICAL  STUDYID mismatch across domains (same USUBJID, different STUDYID)
- DAY001 ERROR   --DY uses Day 0 (SDTMIG requires Day 1 convention)
- TMP008 ERROR   Inconsistent --DY across domains for same absolute date
- TMP009 WARNING --STDTC > --ENDTC date reversal (configurable max_reversal_days)
- TMP010 ERROR   Record date outside study window (before RFSTDTC or future-dated)
- DSP009 ERROR   Subject has both DEATH and WITHDRAWAL disposition records
- DSP010 CRITICAL Screen failure (ARMCD=SCRNFAIL) has RFSTDTC populated
- DSP011 ERROR   ARMCD=NOTASSGN subject has EX dosing records
- ONC008 WARNING TRLNKID changes across visits for same anatomical location
- ONC009 ERROR   RSDTC after DTHDTC — post-mortem response assessment
- ONC010 ERROR   SUMDIAM != sum of LDIAM TRSTRESN (±configurable tolerance)
- ONC011 ERROR   New lesion (TUEVAL=NEW) recorded but RSORRES != PD
- LB014  WARNING LBSTRESU differs across records for same LBTESTCD
- LB015  ERROR   Critical lab value (life-threatening threshold) with no AE ±1 day
- QS005  ERROR   PRO total score != sum of item scores
- QS006  WARNING Protocol-expected questionnaire absent for scheduled visit
- META004 ERROR  --CAT value not in CDISC CT set for domain
- META005 WARNING Define-XML variable length >> actual data length
- BAS001 ERROR   --BLFL=Y record dated after RFSTDTC (post-dose baseline)
- BAS002 WARNING No --BLFL=Y for any LB/VS record in dosed subjects

### Total checks: 179 (was 159)

# SDTM Clinical Integrity Suite — Changelog

## v17.0 — 2026-04-05

### New Checks (23)

**GCP Cross-Domain**
- GCP001 CRITICAL — PR record before RFICDTC (ICH E6 consent violation)
- GCP002 ERROR — DTHDTC in DM but no DEATH record in DS
- GCP003 ERROR — DSDECOD=DEATH in DS but DTHDTC missing in DM
- GCP004 ERROR — EX dosing after DS discontinuation date
- GCP005 ERROR — AEACN=DRUG WITHDRAWN with no DS discontinuation record

**Medical Signals**
- MED001 WARNING — Abnormal LB with no AE within ±7 days
- MED002 ERROR — AEOUT=FATAL but AEENDTC != DTHDTC
- MED003 WARNING — AEOUT=RECOVERED/RESOLVED but AEENDTC missing
- MED004 WARNING — Ocular AE missing AELAT laterality

**Data Integrity**
- DAT008 WARNING — Record date after last SV visit date
- DAT009 WARNING — Partial date with year+day known, month missing

**Oncology / RECIST**
- ONC006 ERROR — TR response inconsistent with RS overall response
- ONC007 ERROR — TRSTRESN missing for LDIAM target lesion

**Questionnaire**
- QS001 ERROR — QSSTAT=NOT DONE but QSSTRESC not null
- QS002 ERROR — QSDTC after DTHDTC (post-mortem PRO)
- QS003 WARNING — Duplicate QS records
- QS004 WARNING — QSSTAT=NOT DONE but QSREASND missing

**Analysis / Metadata**
- ANL001 ERROR — Randomized subject missing stratification factor
- ANL002 ERROR — TS missing MedDRA version (TSPARMCD=MEDDRA)
- ANL003 ERROR — TS missing WHODrug version (TSPARMCD=WHODRUG)
- META001 ERROR — SUPP QORIG inconsistent with Define-XML Origin
- META002 ERROR — CT value not in declared CDISC CT package version
- META003 WARNING — Drug variable not following FDA TCG naming convention

### Bug Fixes / Improvements
- REMOVED: st_aggrid dependency fully eliminated. Tab 7 "AgGrid Review" renamed
  to "Findings Table" and rebuilt with native st.dataframe + st.column_config.
  Eliminates MarshallComponentException permanently.
- ADDED: Partial date policy in study_config.yaml (allowed_patterns, reject_patterns,
  action_on_reject)
- ADDED: Date parser configuration block in study_config.yaml
- UPDATED: documentation.html rebuilt for v17 (159 checks, all new check details,
  partial date policy, date parser rules, AgGrid removal notes)
- Total checks: 159 (was 136)

---

## v16.0 — 2026-03-31

### Bug Fixes
- B01 Fixed: MarshallComponentException in AgGrid — JsCode cell styles removed;
  allow_unsafe_jscode=False; compatible with all st-aggrid versions
- B02 Fixed: Regulatory mode showed as Python dict literal in header

### Features
- Gantt SVG Timeline in Subject Narrative tab
- SUPP structural checks S016–S018 (QNAM conflicts, reserved names, QORIG)
- AE014: Serious AE without SAE flag

---

## v15.0 — 2026-02-14

- Temporal Integrity checks DATE001–DATE007
- Hidden Integrity checks INT001–INT005
- SUPP back-merge with audit log
- Subject Narrative tab
- Waiver management system

---

## v14.0 — 2025-12-01

- 136 checks at launch
- Waiver management
- Excel and HTML report export
- SAS code generation
- Study config hot-reload
- Demo mode for all checks

---
