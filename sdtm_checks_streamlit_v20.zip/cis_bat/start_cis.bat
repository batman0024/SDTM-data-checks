@echo off
chcp 65001 >nul 2>&1
:: ============================================================
::  CIS Launcher  --  Streamlit + FastAPI Gateway
::  Clinical Integrity Suite v15  |  Internal Use Only
:: ============================================================
::
:: USAGE (double-click or run from cmd):
::   start_cis.bat
::   start_cis.bat --admin you@company.com
::   start_cis.bat --domains company.com
::   start_cis.bat --hours 12 --port 8080
::
:: TROUBLESHOOTING:
::   If boxes/garbled text appear, run from cmd.exe directly.
::   This script uses chcp 65001 (UTF-8) to prevent encoding issues.
:: ============================================================

title CIS Clinical Integrity Suite v15

:: ---- Edit these if needed ------------------------------------------
set STREAMLIT_PORT=8501
set GATEWAY_PORT=8000
set SESSION_HOURS=8

:: Script-relative paths (usually no need to change)
set SCRIPT_DIR=%~dp0
set APP_DIR=%SCRIPT_DIR%sdtm_v18

:: Optional: restrict login to admin email / specific domain
set ADMIN_EMAILS=
set ALLOWED_DOMAINS=

:: Python executable -- change if using conda or venv
set PYTHON_CMD=python
:: conda:  set PYTHON_CMD=C:\ProgramData\Miniconda3\envs\cis\python.exe
:: venv:   set PYTHON_CMD=%SCRIPT_DIR%.venv\Scripts\python.exe
:: --------------------------------------------------------------------

:parse_args
if "%1"=="--admin"   (set ADMIN_EMAILS=%2   & shift & shift & goto parse_args)
if "%1"=="--domains" (set ALLOWED_DOMAINS=%2& shift & shift & goto parse_args)
if "%1"=="--hours"   (set SESSION_HOURS=%2  & shift & shift & goto parse_args)
if "%1"=="--port"    (set GATEWAY_PORT=%2   & shift & shift & goto parse_args)
if "%1"=="--appdir"  (set APP_DIR=%2        & shift & shift & goto parse_args)

echo.
echo  =====================================================
echo   CIS Clinical Integrity Suite v15  --  Launcher
echo   SDTM Beyond-P21  ^|  Internal Use Only
echo  =====================================================
echo.
echo  [CONFIG]
echo    App dir   : %APP_DIR%
echo    Streamlit : http://127.0.0.1:%STREAMLIT_PORT%  (internal only)
echo    Gateway   : http://0.0.0.0:%GATEWAY_PORT%      (user-facing)
echo    Session   : %SESSION_HOURS% hours
if not "%ADMIN_EMAILS%"==""    echo    Admin     : %ADMIN_EMAILS%
if not "%ALLOWED_DOMAINS%"=="" echo    Domains   : %ALLOWED_DOMAINS%
echo.

:: Check Python
%PYTHON_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Please edit PYTHON_CMD in this script.
    echo.
    pause
    exit /b 1
)

:: Check / install packages
echo  [CHECK] Verifying required packages...
%PYTHON_CMD% -c "import streamlit,fastapi,uvicorn,httpx,altair,pandas" 2>nul
if errorlevel 1 (
    echo  [INSTALL] Installing missing packages (one-time setup)...
    %PYTHON_CMD% -m pip install streamlit fastapi "uvicorn[standard]" httpx altair pandas openpyxl --quiet
    if errorlevel 1 (
        echo  [ERROR] pip install failed. Check internet connection or run manually:
        echo    %PYTHON_CMD% -m pip install streamlit fastapi uvicorn httpx altair pandas openpyxl
        pause
        exit /b 1
    )
    echo  [INSTALL] Done.
    echo.
)

:: Set environment variables for gateway.py
set STREAMLIT_URL=http://127.0.0.1:%STREAMLIT_PORT%

:: Start Streamlit in a minimised background window
echo  [START] Launching Streamlit on port %STREAMLIT_PORT%...
start "CIS Streamlit" /min cmd /c "cd /d ""%APP_DIR%"" && %PYTHON_CMD% -m streamlit run app.py --server.port %STREAMLIT_PORT% --server.headless true --server.address 127.0.0.1 --browser.gatherUsageStats false 2>&1"

echo  [WAIT]  Giving Streamlit 6s to initialise...
timeout /t 6 /nobreak >nul

:: Start FastAPI gateway in this window (foreground)
echo  [START] Launching CIS Gateway on port %GATEWAY_PORT%...
echo.
echo  ---------------------------------------------------------
echo   Open in browser:  http://localhost:%GATEWAY_PORT%
echo   Activity log:     http://localhost:%GATEWAY_PORT%/admin
echo   Press Ctrl+C to stop both services
echo  ---------------------------------------------------------
echo.

cd /d "%SCRIPT_DIR%"
%PYTHON_CMD% -m uvicorn gateway:app --host 0.0.0.0 --port %GATEWAY_PORT% --log-level info

:: Cleanup when gateway stops
echo.
echo  [STOP] Closing background Streamlit window...
taskkill /fi "WINDOWTITLE eq CIS Streamlit" /f >nul 2>&1
echo  [DONE] All services stopped.
echo.
pause
