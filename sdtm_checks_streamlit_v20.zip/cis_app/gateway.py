"""
CIS FastAPI Gateway  –  Email-only auth + activity tracking
============================================================
• No passwords. User enters their work email → cookie issued → access granted.
• All activity logged to activity.db (SQLite, zero setup).
• Reverse-proxies authenticated requests to Streamlit on localhost:8501.
• Max ~10 concurrent users; designed for internal LAN / VPN use.

Run:
    uvicorn gateway:app --host 0.0.0.0 --port 8000 --reload
"""

import sqlite3, time, secrets, json, re, os, asyncio
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI, Request, Response, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

# ── Config ────────────────────────────────────────────────────────────────────
STREAMLIT_URL   = os.environ.get("STREAMLIT_URL", "http://127.0.0.1:8501")
DB_PATH         = Path(__file__).parent / "activity.db"
COOKIE_NAME     = "cis_session"
SESSION_HOURS   = int(os.environ.get("SESSION_HOURS", "8"))  # auto-expire
ALLOWED_DOMAINS = os.environ.get("ALLOWED_DOMAINS", "")      # e.g. "gilead.com,fda.gov" or "" for any
ADMIN_EMAILS    = set(os.environ.get("ADMIN_EMAILS", "").lower().split(","))

# ── DB init ───────────────────────────────────────────────────────────────────
def _db():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def _init_db():
    con = _db()
    con.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            token      TEXT PRIMARY KEY,
            email      TEXT NOT NULL,
            created_at REAL NOT NULL,
            expires_at REAL NOT NULL,
            ip         TEXT,
            user_agent TEXT
        );
        CREATE TABLE IF NOT EXISTS activity (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            ts         REAL    NOT NULL,
            ts_str     TEXT    NOT NULL,
            email      TEXT    NOT NULL,
            ip         TEXT,
            action     TEXT    NOT NULL,
            detail     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_act_email ON activity(email);
        CREATE INDEX IF NOT EXISTS idx_act_ts    ON activity(ts);
    """)
    con.commit(); con.close()

_init_db()

# ── Helpers ───────────────────────────────────────────────────────────────────
def _log(email: str, ip: str, action: str, detail: str = ""):
    con = _db()
    now = time.time()
    con.execute(
        "INSERT INTO activity(ts,ts_str,email,ip,action,detail) VALUES(?,?,?,?,?,?)",
        (now, datetime.utcfromtimestamp(now).strftime("%Y-%m-%d %H:%M:%S UTC"),
         email, ip, action, detail[:500])
    )
    con.commit(); con.close()

def _make_session(email: str, ip: str, ua: str) -> str:
    token = secrets.token_urlsafe(32)
    now   = time.time()
    con   = _db()
    con.execute(
        "INSERT INTO sessions(token,email,created_at,expires_at,ip,user_agent) VALUES(?,?,?,?,?,?)",
        (token, email.lower().strip(), now, now + SESSION_HOURS*3600, ip, ua[:300])
    )
    con.commit(); con.close()
    _log(email, ip, "LOGIN", f"Session created. UA={ua[:80]}")
    return token

def _validate_session(token: str) -> Optional[str]:
    """Returns email if valid, else None."""
    if not token:
        return None
    con = _db()
    row = con.execute(
        "SELECT email,expires_at FROM sessions WHERE token=?", (token,)
    ).fetchone()
    con.close()
    if not row:
        return None
    if time.time() > row["expires_at"]:
        return None
    return row["email"]

def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for","")
    return xff.split(",")[0].strip() if xff else (request.client.host if request.client else "unknown")

def _validate_email(email: str) -> bool:
    email = email.strip().lower()
    if not re.match(r"^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$", email):
        return False
    if ALLOWED_DOMAINS:
        domain = email.split("@")[-1]
        allowed = [d.strip() for d in ALLOWED_DOMAINS.split(",") if d.strip()]
        if allowed and domain not in allowed:
            return False
    return True

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="CIS Gateway", docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# ── Login page ────────────────────────────────────────────────────────────────
LOGIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CIS — Sign In</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;500;700&family=Orbitron:wght@700;900&display=swap');
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#070810;min-height:100vh;display:flex;align-items:center;
     justify-content:center;font-family:'JetBrains Mono',monospace;color:#c0cce8}}
.card{{background:linear-gradient(145deg,#0e1028,#090c1c);
       border:1px solid #1e2448;border-radius:12px;padding:2.8rem 2.4rem;
       width:100%;max-width:420px;
       box-shadow:0 8px 40px rgba(0,0,0,.6),0 0 60px rgba(30,80,200,.08)}}
.logo{{font-family:'Orbitron',monospace;font-size:1.7rem;font-weight:900;
       background:linear-gradient(120deg,#60a8ff,#a0d0ff,#c0e8ff);
       -webkit-background-clip:text;-webkit-text-fill-color:transparent;
       background-clip:text;letter-spacing:.06em;text-align:center}}
.sub{{font-size:.62rem;text-transform:uppercase;letter-spacing:.14em;
      color:#5870a8;text-align:center;margin:.4rem 0 2rem}}
.divider{{height:1px;background:linear-gradient(90deg,transparent,#2848d0,transparent);
           margin:1.4rem 0 1.6rem;opacity:.6}}
label{{font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;color:#6878a8;
       display:block;margin-bottom:.45rem}}
input[type=email]{{width:100%;background:#0b0d1c;border:1px solid #1e2448;
  border-radius:6px;padding:.75rem 1rem;font-family:'JetBrains Mono',monospace;
  font-size:.88rem;color:#d0dcf8;outline:none;transition:border-color .2s,box-shadow .2s}}
input[type=email]:focus{{border-color:#3060c0;
  box-shadow:0 0 0 3px rgba(48,96,192,.18)}}
button{{width:100%;margin-top:1.2rem;padding:.8rem 1rem;
  background:linear-gradient(135deg,#0d2070,#1840cc);
  border:1px solid #3d70e8;border-radius:6px;
  font-family:'JetBrains Mono',monospace;font-size:.82rem;font-weight:700;
  letter-spacing:.08em;text-transform:uppercase;color:#b0d0ff;cursor:pointer;
  box-shadow:0 0 18px rgba(40,100,220,.22);transition:all .2s}}
button:hover{{color:#d0e8ff;box-shadow:0 0 28px rgba(60,140,255,.45);border-color:#5a90ff}}
.msg{{font-size:.74rem;margin-top:.9rem;text-align:center;padding:.5rem .8rem;
      border-radius:5px;border:1px solid transparent}}
.msg.err{{color:#e06060;background:rgba(220,80,80,.08);border-color:rgba(220,80,80,.22)}}
.note{{font-size:.64rem;color:#3848a0;text-align:center;margin-top:1.4rem;line-height:1.6}}
.powered{{font-size:.58rem;color:#282e50;text-align:center;margin-top:1.8rem}}
</style>
</head>
<body>
<div class="card">
  <div class="logo">CIS v15</div>
  <div class="sub">SDTM Clinical Integrity Suite</div>
  <div class="divider"></div>
  <form method="post" action="/login">
    <label for="email">Work Email Address</label>
    <input type="email" id="email" name="email" placeholder="you@company.com"
           required autofocus autocomplete="email" value="{email_prefill}">
    <button type="submit">Enter &rarr;</button>
    {msg_html}
  </form>
  <div class="note">
    No password required.<br>
    Access is logged for compliance &amp; audit purposes.
  </div>
  <div class="powered">Powered by CIS Gateway &bull; Internal Use Only</div>
</div>
</body>
</html>"""

@app.get("/login", response_class=HTMLResponse)
async def login_page(error: str = ""):
    msg = f'<div class="msg err">{error}</div>' if error else ""
    return LOGIN_HTML.format(msg_html=msg, email_prefill="")

@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request, email: str = Form(...)):
    ip = _client_ip(request)
    ua = request.headers.get("user-agent","")
    email = email.strip().lower()

    if not _validate_email(email):
        domain_msg = ""
        if ALLOWED_DOMAINS:
            domain_msg = f" (allowed: {ALLOWED_DOMAINS})"
        msg = f'<div class="msg err">Invalid or unauthorised email address{domain_msg}.</div>'
        return HTMLResponse(LOGIN_HTML.format(msg_html=msg, email_prefill=email))

    token = _make_session(email, ip, ua)
    response = RedirectResponse(url="/app", status_code=303)
    response.set_cookie(
        COOKIE_NAME, token,
        max_age=SESSION_HOURS*3600,
        httponly=True, samesite="lax"
    )
    return response

@app.get("/logout")
async def logout(request: Request):
    token = request.cookies.get(COOKIE_NAME,"")
    if token:
        email = _validate_session(token) or "unknown"
        ip    = _client_ip(request)
        _log(email, ip, "LOGOUT")
        con = _db(); con.execute("DELETE FROM sessions WHERE token=?",(token,)); con.commit(); con.close()
    resp = RedirectResponse(url="/login")
    resp.delete_cookie(COOKIE_NAME)
    return resp

# ── Admin activity viewer ─────────────────────────────────────────────────────
ADMIN_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CIS — Activity Log</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');
body{{background:#070810;color:#b0bcd8;font-family:'JetBrains Mono',monospace;
     font-size:.78rem;padding:2rem}}
h2{{color:#60a8ff;margin-bottom:1rem;font-size:1rem;letter-spacing:.08em}}
table{{border-collapse:collapse;width:100%;margin-top:1rem}}
th{{background:#0e1028;color:#6878a8;text-transform:uppercase;letter-spacing:.08em;
    padding:.5rem .7rem;text-align:left;border-bottom:1px solid #1e2448;font-size:.68rem}}
td{{padding:.45rem .7rem;border-bottom:1px solid #111628;vertical-align:top}}
tr:hover td{{background:#0d0f20}}
.tag-login{{color:#50e0a0}}.tag-logout{{color:#8090b8}}
.tag-request{{color:#5080e0}}.tag-download{{color:#e0a040}}.tag-run{{color:#d04040}}
.sessions{{margin-bottom:2.5rem}}
a{{color:#5080e0;text-decoration:none}}.logout-btn{{float:right;color:#e06060}}
</style>
</head>
<body>
<h2>CIS Activity Log &nbsp;<a class="logout-btn" href="/logout">Logout</a></h2>
<div class="sessions">
<b style="color:#6878a8">Active Sessions ({n_sess})</b><br><br>
<table>
<tr><th>Email</th><th>IP</th><th>Created</th><th>Expires</th></tr>
{sess_rows}
</table>
</div>
<b style="color:#6878a8">Recent Activity (last 200)</b>
<table>
<tr><th>Time (UTC)</th><th>Email</th><th>IP</th><th>Action</th><th>Detail</th></tr>
{act_rows}
</table>
</body></html>"""

@app.get("/admin", response_class=HTMLResponse)
async def admin_view(request: Request):
    token = request.cookies.get(COOKIE_NAME,"")
    email = _validate_session(token)
    if not email:
        return RedirectResponse("/login")
    if ADMIN_EMAILS and email not in ADMIN_EMAILS:
        raise HTTPException(403, "Admin access required")

    con = _db()
    sessions = con.execute(
        "SELECT email,ip,created_at,expires_at FROM sessions WHERE expires_at>? ORDER BY created_at DESC",
        (time.time(),)
    ).fetchall()
    acts = con.execute(
        "SELECT ts_str,email,ip,action,detail FROM activity ORDER BY ts DESC LIMIT 200"
    ).fetchall()
    con.close()

    def _ts(t): return datetime.utcfromtimestamp(t).strftime("%m-%d %H:%M")
    color_map = {"LOGIN":"tag-login","LOGOUT":"tag-logout","RUN":"tag-run","DOWNLOAD":"tag-download"}

    sess_rows = "".join(
        f"<tr><td>{r['email']}</td><td>{r['ip']}</td>"
        f"<td>{_ts(r['created_at'])}</td><td>{_ts(r['expires_at'])}</td></tr>"
        for r in sessions
    )
    act_rows = "".join(
        f"<tr><td>{r['ts_str']}</td><td>{r['email']}</td><td>{r['ip']}</td>"
        f"<td class='{color_map.get(r['action'],'tag-request')}'>{r['action']}</td>"
        f"<td>{r['detail']}</td></tr>"
        for r in acts
    )
    return ADMIN_HTML.format(n_sess=len(sessions), sess_rows=sess_rows, act_rows=act_rows)

# ── Streamlit reverse proxy ────────────────────────────────────────────────────
# Activity log filter — log these url patterns
_LOG_PATTERNS = {
    "/_stcore/stream":         None,        # skip – too noisy (websocket heartbeat)
    "/run_validation":         "RUN",
    "download":                "DOWNLOAD",
    "report":                  "DOWNLOAD",
}

@app.get("/app")
@app.get("/app/{path:path}")
@app.post("/app/{path:path}")
async def proxy(request: Request, path: str = ""):
    token = request.cookies.get(COOKIE_NAME,"")
    email = _validate_session(token)
    if not email:
        return RedirectResponse(f"/login?next=/app/{path}")

    ip = _client_ip(request)

    # Selective activity logging (don't log every static asset)
    url_str = str(request.url)
    for pat, action in _LOG_PATTERNS.items():
        if pat in url_str and action:
            _log(email, ip, action, url_str[-200:])
            break
    else:
        # log first request per session only for general page loads
        if "." not in path and "_stcore" not in path:
            _log(email, ip, "PAGE", f"/{path}")

    # Forward to Streamlit
    target = f"{STREAMLIT_URL}/{path}"
    if request.url.query:
        target += f"?{request.url.query}"

    headers = {k:v for k,v in request.headers.items()
               if k.lower() not in ("host","connection","transfer-encoding")}
    headers["X-CIS-User"] = email

    body = await request.body()

    async with httpx.AsyncClient(timeout=60) as client:
        try:
            resp = await client.request(
                method=request.method,
                url=target,
                headers=headers,
                content=body,
                follow_redirects=False,
            )
        except httpx.ConnectError:
            return HTMLResponse(
                "<h3 style='color:#e06060;font-family:monospace'>Streamlit app is not running."
                "<br>Start it with: <code>streamlit run app.py</code></h3>",
                status_code=502
            )

    # Pass through response; inject logout link into HTML pages
    resp_headers = {k:v for k,v in resp.headers.items()
                    if k.lower() not in ("content-encoding","content-length","transfer-encoding","connection")}

    content = resp.content
    if "text/html" in resp.headers.get("content-type",""):
        try:
            html = content.decode("utf-8")
            # Inject a small logout banner into Streamlit pages
            banner = (
                f'<div style="position:fixed;top:0;right:0;z-index:99999;'
                f'background:rgba(7,8,16,.92);border-bottom:1px solid #1e2448;'
                f'border-left:1px solid #1e2448;padding:.3rem .8rem;'
                f'font-family:JetBrains Mono,monospace;font-size:.65rem;'
                f'color:#6878a8;border-radius:0 0 0 6px">'
                f'&#128100; {email} &nbsp;|&nbsp; '
                f'<a href="/logout" style="color:#e06060;text-decoration:none">logout</a>'
                f'</div>'
            )
            html = html.replace("</body>", banner + "</body>", 1)
            content = html.encode("utf-8")
        except Exception:
            pass

    return Response(content=content, status_code=resp.status_code, headers=resp_headers)

# ── Root redirect ─────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return RedirectResponse("/app")

# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/_health")
async def health():
    return {"status":"ok","time":datetime.utcnow().isoformat()}

# ── Cleanup expired sessions (runs on startup) ─────────────────────────────────
@app.on_event("startup")
async def _cleanup():
    con = _db()
    deleted = con.execute("DELETE FROM sessions WHERE expires_at<?", (time.time(),)).rowcount
    con.commit(); con.close()
    if deleted:
        print(f"[CIS Gateway] Cleaned {deleted} expired session(s)")
    print(f"[CIS Gateway] Ready → http://0.0.0.0:8000  |  Streamlit @ {STREAMLIT_URL}")
    print(f"[CIS Gateway] Activity DB: {DB_PATH}")
    if ALLOWED_DOMAINS:
        print(f"[CIS Gateway] Allowed email domains: {ALLOWED_DOMAINS}")
    if ADMIN_EMAILS:
        print(f"[CIS Gateway] Admin emails: {ADMIN_EMAILS}")
