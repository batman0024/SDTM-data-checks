"""
modules/engine.py
SUG-002: Pandas-vectorized checks.
SUG-004: Cross-domain dependency pre-check.
v7.0: INT001-INT005 (Hidden Integrity) + DATE001-DATE006 (Temporal Integrity)
"""

import re
import time
import datetime
import pandas as pd
from modules.registry import get_checks, get_check, CHECK_REQUIRES

# ---------------------------------------------------------------------------
# DEMO POOL
# ---------------------------------------------------------------------------
DEMO_POOL = [
    {"checkId":"DS006","subj":"001-007","domain":"VS","detail":"VS.SYSBP on 2024-09-14 - 3 days after DS death (DSSTDTC=2024-09-11)","root":"Missing DS death propagation"},
    {"checkId":"DS006","subj":"001-031","domain":"LB","detail":"LB.ALT on 2024-11-02 - 7 days after death (DSSTDTC=2024-10-26)","root":"Missing DS death propagation"},
    {"checkId":"AE005","subj":"001-007","domain":"AE","detail":"AE Pneumonia AESTDTC=2024-09-12 - 1 day after death 2024-09-11","root":"Missing DS death propagation"},
    {"checkId":"DS003","subj":"001-007","domain":"DS","detail":"DS contains 2 death dates: 2024-09-11 and 2024-09-13 (non-matching)","root":"Missing DS death propagation"},
    {"checkId":"DS008","subj":"001-004","domain":"LB","detail":"LB draw LBDTC=2024-01-10 precedes consent RFICDTC=2024-01-12 by 2 days","root":None},
    {"checkId":"DS008","subj":"002-003","domain":"VS","detail":"VS measurement 2024-02-08 before RFICDTC=2024-02-10","root":None},
    {"checkId":"DS007","subj":"001-019","domain":"LB","detail":"LB record 2024-08-05 is 8 days after DM.RFPENDTC=2024-07-28","root":None},
    {"checkId":"AE015","subj":"001-012","domain":"LB/AE","detail":"LB ALT Grade 4 (>10xULN) on 2024-06-15 - no AE within +/-7 days","root":"Possible under-reporting"},
    {"checkId":"AE015","subj":"001-028","domain":"LB/AE","detail":"LB POTASSIUM 8.1 mEq/L Grade 3 2024-09-03 - no corresponding AE","root":"Possible under-reporting"},
    {"checkId":"LB011","subj":"001-012","domain":"LB","detail":"ALT 480 U/L (>3xULN) + TBili 2.1xULN at Visit 6 - Hys Law signal","root":"Possible under-reporting"},
    {"checkId":"AE016","subj":"001-022","domain":"AE/CM","detail":"AE Hypertension AESEV=SEVERE (2024-04-18) - no anti-hypertensive in CM +/-14d","root":None},
    {"checkId":"VS001","subj":"002-003","domain":"VS","detail":"Visit 8 (2024-07-22): DIABP=92 > SYSBP=88 mmHg - impossible physiology","root":None},
    {"checkId":"VS001","subj":"001-041","domain":"VS","detail":"Screening 2024-02-05: DIABP=110 > SYSBP=105 mmHg","root":None},
    {"checkId":"VS003","subj":"002-016","domain":"VS","detail":"Weight 82 kg (Wk4) to 61 kg (Wk5) = 25.6 pct drop in 7 days","root":None},
    {"checkId":"VS004","subj":"002-027","domain":"VS","detail":"Height 178 cm (BL) to 162 cm (Month 6) = 16 cm decrease","root":None},
    {"checkId":"DS005","subj":"001-055","domain":"DS/EX","detail":"DSDECOD=Screen Failure but 2 EX dosing records exist (2024-01-14, 2024-01-21)","root":None},
    {"checkId":"BL001","subj":"002-008","domain":"LB","detail":"LB GLUC --BLFL=Y at 08:30; first dose at 07:00 same day - post-dose baseline","root":None},
    {"checkId":"TD006","subj":"001-033","domain":"SE","detail":"Screening SEENDTC=2024-03-15; Treatment SESTDTC=2024-03-17 - 1-day gap","root":None},
    {"checkId":"BL002","subj":"ALL","domain":"ALL","detail":"14 LB records LBTESTCD=POTASSM - not in CDISC CT; expected POTASSIUM","root":"Systematic CT error"},
    {"checkId":"AE012","subj":"001-044","domain":"AE","detail":"AETRTEM=Y but AE start 2024-10-30 is 59 days after last dose 2024-09-01","root":None},
    {"checkId":"DM001","subj":"002-017","domain":"DM","detail":"DM.ARMCD=PLACEBO but EXTRT=Drug A 100mg in 2 EX records","root":None},
    {"checkId":"SV003","subj":"001-038","domain":"ALL/TV","detail":"Visit 4 VISITDY=28; actual VSDY=35 - 7-day deviation exceeds +/-3d window","root":None},
    {"checkId":"CM005","subj":"001-033","domain":"CM","detail":"CM record shows Warfarin - excluded per protocol Section 5.3","root":None},
    {"checkId":"LB009","subj":"001-012","domain":"LB/EX","detail":"LB pre-dose LBDTM=2024-06-15T09:45 but EXSTDTC=2024-06-15T08:00 - post-infusion","root":None},
    {"checkId":"EG002","subj":"002-011","domain":"EG","detail":"QTcF=530 ms at Visit 4 - no cardiac AE within +/-3 days","root":None},
    {"checkId":"EG003","subj":"002-019","domain":"EG","detail":"QTcF increased from 390ms (BL) to 465ms (Wk4) = 75ms increase without TEAE","root":None},
    {"checkId":"PK003","subj":"ALL","domain":"PP","detail":"PP RELREC missing for 8 subjects - Cmax/AUC not traceable to PC concentrations","root":None},
    {"checkId":"QS003","subj":"002-015","domain":"QS","detail":"SF-36 Physical Score total=82 but sum of components=61 (21-pt discrepancy)","root":None},
    {"checkId":"ONC003","subj":"002-016","domain":"TU","detail":"TU new lesion 2024-07-10 but RS.RSORRES=PR (not PD) at same timepoint","root":None},
    {"checkId":"ONC005","subj":"003-001","domain":"TR","detail":"RECIST sum of diameters=68mm but sum of TRSTRESN values=52mm","root":None},
    {"checkId":"TD001","subj":"ALL","domain":"TS","detail":"TS missing TSPARMCD=PCLAS (Pharmacological Class) - FDA Desired parameter absent","root":None},
    {"checkId":"TD002","subj":"ALL","domain":"TS","detail":"TS TSPARMCD=DOSE TSVAL=100 mg - unit in DOSE field (should be DOSU record)","root":None},
    {"checkId":"DM008","subj":"003-006","domain":"DM","detail":"SDTM AGE=16 (AGEU=YEARS) in adult Phase III trial - possible paediatric patient","root":None},
    {"checkId":"IE002","subj":"001-009","domain":"IE","detail":"IE exclusion criterion 3 failure but DSDECOD=ENROLLED for same subject","root":None},
    {"checkId":"S008","subj":"ALL","domain":"ALL","detail":"LBTESTCD=SODIUM maps to Sodium Serum and Serum Sodium - 1:1 violation","root":"Systematic CT error"},
    {"checkId":"LB012","subj":"003-012","domain":"LB","detail":"LBTESTCD=ALT LBDTC=2024-05-10 appears 3 times - possible double entry","root":None},
    {"checkId":"VS005","subj":"002-033","domain":"VS","detail":"VSTESTCD=PULSE VSSTRESN=8 BPM at Visit 3 - physiologically implausible","root":None},
    {"checkId":"EX007","subj":"001-018","domain":"EX","detail":"Subject received 2400mg cumulative vs. protocol maximum of 1800mg","root":None},
    {"checkId":"PK004","subj":"003-004","domain":"PP","detail":"PPTESTCD=CMAX=0.2 ng/mL but all PC concentrations > 15 ng/mL","root":None},
    {"checkId":"DV001","subj":"001-025","domain":"DV","detail":"DVTERM=Protocol deviation - unblinding but no DS discontinuation record","root":None},
    # v7 demo entries
    {"checkId":"INT001","subj":"ALL","domain":"LB/DM","detail":"USUBJID 003-099 found in LB (8 records) but absent from DM - orphan subject","root":"Missing DM record"},
    {"checkId":"INT001","subj":"ALL","domain":"AE/DM","detail":"USUBJID 003-100 found in AE (3 records) but absent from DM - orphan subject","root":"Missing DM record"},
    {"checkId":"INT002","subj":"002-008","domain":"LB","detail":"LB GLUC BLFL=Y at 2024-05-10 but DM RFSTDTC=2024-05-08 (2 days post-dose)","root":"Baseline flag error"},
    {"checkId":"INT002","subj":"002-014","domain":"VS","detail":"VS WEIGHT BLFL=Y at 2024-06-12 but DM RFSTDTC=2024-06-10 (post-dose baseline)","root":"Baseline flag error"},
    {"checkId":"INT003","subj":"001-044","domain":"DS","detail":"Subject has 6 EX records and 12 LB records but no DS DISPOSITION EVENT record","root":None},
    {"checkId":"INT003","subj":"002-031","domain":"DS","detail":"Subject has 3 AE records but no End of Study disposition in DS domain","root":None},
    {"checkId":"INT004","subj":"003-007","domain":"LB/DM","detail":"DM.SEX=M but LB contains LBTESTCD=PREG result (2024-07-15) - gender mismatch","root":None},
    {"checkId":"INT005","subj":"001-019","domain":"LB/DM","detail":"LB draw LBDTC=2024-01-09 is 3 days before RFICDTC=2024-01-12 (consent date)","root":"Pre-consent assessment"},
    {"checkId":"INT005","subj":"002-005","domain":"VS/DM","detail":"VS SYSBP measurement 2024-02-07 is 5 days before RFICDTC=2024-02-12","root":"Pre-consent assessment"},
    {"checkId":"DATE001","subj":"001-033","domain":"AE","detail":"AE AESTDTC=2024-08-20 > AEENDTC=2024-08-15 (start after end) - 5-day reversal","root":None},
    {"checkId":"DATE001","subj":"002-018","domain":"CM","detail":"CM CMSTDTC=2024-09-01 > CMENDTC=2024-08-25 (start after end)","root":None},
    {"checkId":"DATE002","subj":"001-007","domain":"EG","detail":"EG record EGDTC=2024-09-15 found after death date 2024-09-11 (4 days post-mortem)","root":"Post-mortem clinical activity"},
    {"checkId":"DATE002","subj":"001-007","domain":"CM","detail":"CM dosing record CMSTDTC=2024-09-13 found 2 days after death DSSTDTC=2024-09-11","root":"Post-mortem clinical activity"},
    {"checkId":"DATE003","subj":"002-055","domain":"LB","detail":"LB LBDTC=2026-08-20 is 8 months in the future relative to data snapshot date","root":None},
    {"checkId":"DATE003","subj":"003-011","domain":"AE","detail":"AE AESTDTC=2027-01-01 is 1+ year in future - likely data entry error","root":None},
    {"checkId":"DATE004","subj":"003-004","domain":"DM","detail":"BRTHDTC=2024-03-15 is after RFSTDTC=2024-01-10 - subject born after study start","root":None},
    {"checkId":"DATE005","subj":"001-002","domain":"EX/DM","detail":"EXSTDTC=2024-01-08 is 4 days before RFICDTC=2024-01-12 - dosed before consent","root":"GCP violation"},
    {"checkId":"DATE005","subj":"002-007","domain":"EX/DM","detail":"EXSTDTC=2024-02-05 is 2 days before RFICDTC=2024-02-07 - dosed before consent","root":"GCP violation"},
    {"checkId":"DATE006","subj":"001-021","domain":"EX/DS","detail":"EX EXENDTC=2024-06-18; DS DSSTDTC=2024-06-15 (discontinued 3 days prior)","root":None},
]

_DEMO_MAP: dict = {}
for _e in DEMO_POOL:
    _DEMO_MAP.setdefault(_e["checkId"], []).append(_e)


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def _to_df(rows: list) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    for col in df.columns:
        df[col] = df[col].fillna("").astype(str).str.strip()
    return df

def _col(df: pd.DataFrame, name: str) -> pd.Series:
    if name in df.columns:
        return df[name]
    return pd.Series([""] * len(df), index=df.index)

def _date_str(s: str) -> str:
    """Return first 10 chars (YYYY-MM-DD) of a datetime string, or ''."""
    return s[:10] if s and len(s) >= 10 else ""

def _today() -> str:
    return datetime.date.today().isoformat()   # YYYY-MM-DD


# ---------------------------------------------------------------------------
# PRE-BUILT LOOKUP INDEXES  (built once, shared across all checks)
# ---------------------------------------------------------------------------
def _build_lookups(dd: dict) -> dict:
    """Build vectorised lookup Series from DM and DS.
    All are pd.Series indexed by USUBJID for O(1) lookups.
    """
    lkp = {}
    dm = dd.get("DM", pd.DataFrame())
    ds = dd.get("DS", pd.DataFrame())

    if not dm.empty and "USUBJID" in dm.columns:
        dm2 = dm.drop_duplicates("USUBJID").set_index("USUBJID")
        for col in ["RFICDTC","RFSTDTC","RFENDTC","DTHDTC","SEX","ARM","ACTARM",
                    "AGE","AGEU","BRTHDTC","RFPENDTC","DTHFL"]:
            if col in dm2.columns:
                lkp[f"dm_{col.lower()}"] = dm2[col].str[:10] if col.endswith("DTC") else dm2[col]
        lkp["dm_subjs"] = set(dm2.index) - {"","ALL"}

    if not ds.empty and "USUBJID" in ds.columns and "DSDECOD" in ds.columns:
        death_mask = _col(ds,"DSDECOD").str.upper().isin(["DEATH","DIED","DEAD"])
        death_rows = ds[death_mask].copy()
        if not death_rows.empty and "DSSTDTC" in death_rows.columns:
            death_rows["_d"] = death_rows["DSSTDTC"].str[:10]
            lkp["death_dates"] = (death_rows.sort_values("_d")
                                  .drop_duplicates("USUBJID",keep="first")
                                  .set_index("USUBJID")["_d"])
        disp_mask = _col(ds,"DSCAT").str.upper().isin(
            ["DISPOSITION EVENT","DISPOSITION","COMPLETION"])
        disp_rows = ds[disp_mask].copy()
        if not disp_rows.empty and "DSSTDTC" in disp_rows.columns:
            disp_rows["_d"] = disp_rows["DSSTDTC"].str[:10]
            lkp["disp_dates"] = (disp_rows.sort_values("_d")
                                 .drop_duplicates("USUBJID",keep="first")
                                 .set_index("USUBJID")["_d"])
    return lkp


# ---------------------------------------------------------------------------
# VALIDATION ENGINE
# ---------------------------------------------------------------------------
class ValidationEngine:

    def __init__(self, files_meta: dict, enabled_ids: set):
        self.files_meta  = files_meta
        self.enabled_ids = set(enabled_ids)
        self._seq        = 0

    # ---------------------------------------------------------------- run
    def run(self, progress_cb=None) -> list:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        checks  = [c for c in get_checks() if c["id"] in self.enabled_ids]
        total   = max(len(checks), 1)

        dd_rows = self._map_domains()
        dd_df   = {dom: _to_df(rows) for dom, rows in dd_rows.items()}
        dep_w   = self._dependency_warnings(dd_rows)

        # Pre-build shared lookup indexes ONCE - reused by all checks
        self._lkp = _build_lookups(dd_df)

        # Separate dep-warned checks from runnable checks
        runnable = [c for c in checks if c["id"] not in dep_w]
        dep_list = [dep_w[c["id"]] for c in checks if c["id"] in dep_w]

        # Progress: report every ~5% or every 10 checks, not every check
        _prog_interval = max(1, total // 20)
        if progress_cb:
            progress_cb(2, f"Loaded {len(dd_df)} domains, running {len(runnable)} checks...")

        # Use ThreadPoolExecutor - safe for pandas (read-only DataFrames)
        # Each check gets its own _seq namespace to avoid race on self._seq
        workers = min(8, len(runnable)) if runnable else 1
        findings_by_check = {}

        def _run_one(check, idx):
            result = []
            result.extend(self._run_actual(check, dd_df))
            result.extend(self._run_demo(check, dd_rows))
            return idx, check["id"], result

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(_run_one, c, i): i
                       for i, c in enumerate(runnable)}
            done_count = 0
            for fut in as_completed(futures):
                idx, cid, result = fut.result()
                findings_by_check[idx] = result
                done_count += 1
                if progress_cb and done_count % _prog_interval == 0:
                    pct = int(done_count / max(len(runnable), 1) * 94) + 2
                    progress_cb(pct, f"{done_count}/{len(runnable)} checks done...")

        # Reassemble in original order, assign sequential fids
        findings: list = list(dep_list)
        for idx in range(len(runnable)):
            for f in findings_by_check.get(idx, []):
                self._seq += 1
                f["fid"] = f"F{self._seq:04d}"
                findings.append(f)

        if progress_cb:
            actual_n = sum(1 for f in findings if f.get("actual"))
            progress_cb(100, f"Complete - {len(findings)} findings ({actual_n} actual)")
        return findings

    # ---------------------------------------- SUG-004 dependency warnings
    def _dependency_warnings(self, dd_rows: dict) -> dict:
        warnings = {}
        loaded   = set(dd_rows.keys())
        for check in get_checks():
            if check["id"] not in self.enabled_ids:
                continue
            required = CHECK_REQUIRES.get(check["id"])
            if required is None or not required:
                continue
            if all(d not in loaded for d in required):
                self._seq += 1
                warnings[check["id"]] = {
                    "fid":         f"W{self._seq:04d}",
                    "checkId":     check["id"],
                    "label":       check["label"],
                    "layer":       check["layer"],
                    "cat":         check["cat"],
                    "domain":      check["domain"],
                    "sev":         "NOTICE",
                    "risk":        "advisory",
                    "source":      "Dependency Pre-Check (SUG-004)",
                    "subj":        "N/A",
                    "detail":      (
                        f"Skipped: required domain(s) {required} not loaded. "
                        f"Upload {', '.join(required)} to enable this check."
                    ),
                    "root":        None,
                    "actual":      False,
                    "waived":      False,
                    "waiver_note": "",
                    "ts":          datetime.datetime.now().isoformat(),
                    "dep_warning": True,
                }
        return warnings

    # ---------------------------------------------- domain mapping
    def _map_domains(self) -> dict:
        DOM_CODES = [
            "AE","CM","DM","DS","EG","EX","LB","MH","PR","QS",
            "TR","TU","RS","SE","SV","SS","VS","TS","TA","TE",
            "TV","TI","IE","PC","PP","DV","FA","SU","SC","DD",
        ]
        result: dict = {}
        # Track which file -> dom assignments to avoid double-adding rows
        # (can happen when filename matches AND DOMAIN column also matches)
        assigned: dict = {}   # fname -> dom already assigned

        for fname, meta in self.files_meta.items():
            data = meta.get("data", [])
            if not data:
                continue
            base = fname.upper()
            for ext in [".XPT",".SAS7BDAT",".CSV",".XLSX",".XLS",".JSON"]:
                base = base.replace(ext, "")
            base    = base.split("/")[-1].split("\\")[-1].strip()
            matched = False
            for dom in DOM_CODES:
                if base == dom or base.startswith(dom+"_") or base.endswith("_"+dom):
                    result.setdefault(dom, []).extend(data)
                    assigned[fname] = dom
                    matched = True
                    break
            if not matched:
                for dom in DOM_CODES:
                    if dom in base:
                        result.setdefault(dom, []).extend(data)
                        assigned[fname] = dom
                        break
            # Only use DOMAIN column if NOT already assigned by filename
            if fname not in assigned and data and isinstance(data[0], dict):
                dv = str(data[0].get("DOMAIN","")).strip().upper()
                if dv in DOM_CODES:
                    result.setdefault(dv, []).extend(data)
                    assigned[fname] = dv
        return result

    # ---------------------------------------------- finding factory
    def _new(self, check: dict, subj: str, detail: str,
             root=None, actual: bool = True) -> dict:
        self._seq += 1
        return {
            "fid":         f"F{self._seq:04d}",
            "checkId":     check["id"],
            "label":       check["label"],
            "layer":       check["layer"],
            "cat":         check["cat"],
            "domain":      check["domain"],
            "sev":         check["sev"],
            "risk":        check["risk"],
            "source":      check["source"],
            "subj":        subj,
            "detail":      detail,
            "root":        root,
            "actual":      actual,
            "waived":      False,
            "waiver_note": "",
            "ts":          datetime.datetime.now().isoformat(),
        }

    # ---------------------------------------------- dispatcher
    def _run_actual(self, check: dict, dd: dict) -> list:
        cid = check["id"]
        out: list = []
        try:
            # original v6 checks
            if   cid == "DM001":  out = self._chk_DM001(check, dd)
            elif cid == "DM003":  out = self._chk_DM003(check, dd)
            elif cid == "DM004":  out = self._chk_DM004(check, dd)
            elif cid == "DM007":  out = self._chk_DM007(check, dd)
            elif cid == "DM008":  out = self._chk_DM008(check, dd)
            elif cid == "AE001":  out = self._chk_AE001(check, dd)
            elif cid == "AE004":  out = self._chk_AE004(check, dd)
            elif cid == "AE006":  out = self._chk_AE006(check, dd)
            elif cid == "AE008":  out = self._chk_AE008(check, dd)
            elif cid == "EX001":  out = self._chk_EX001(check, dd)
            elif cid == "EX002":  out = self._chk_EX002(check, dd)
            elif cid == "EX003":  out = self._chk_EX003(check, dd)
            elif cid == "LB003":  out = self._chk_LB003(check, dd)
            elif cid == "LB004":  out = self._chk_LB004(check, dd)
            elif cid == "LB007":  out = self._chk_LB007(check, dd)
            elif cid == "LB011":  out = self._chk_LB011(check, dd)
            elif cid == "LB012":  out = self._chk_LB012(check, dd)
            elif cid == "VS001":  out = self._chk_VS001(check, dd)
            elif cid == "VS005":  out = self._chk_VS005(check, dd)
            elif cid == "VS007":  out = self._chk_VS007(check, dd)
            elif cid == "CM001":  out = self._chk_CM001(check, dd)
            elif cid == "CM003":  out = self._chk_CM003(check, dd)
            elif cid == "CM004":  out = self._chk_CM004(check, dd)
            elif cid == "S010":   out = self._chk_S010(check, dd)
            # v7 new checks
            elif cid == "INT001": out = self._chk_INT001(check, dd)
            elif cid == "INT002": out = self._chk_INT002(check, dd)
            elif cid == "INT003": out = self._chk_INT003(check, dd)
            elif cid == "INT004": out = self._chk_INT004(check, dd)
            elif cid == "INT005": out = self._chk_INT005(check, dd)
            elif cid == "DATE001":out = self._chk_DATE001(check, dd)
            elif cid == "DATE002":out = self._chk_DATE002(check, dd)
            elif cid == "DATE003":out = self._chk_DATE003(check, dd)
            elif cid == "DATE004":out = self._chk_DATE004(check, dd)
            elif cid == "DATE005":out = self._chk_DATE005(check, dd)
            elif cid == "DATE006":out = self._chk_DATE006(check, dd)
        except Exception:
            pass
        return out

    # ==================================================================
    # EXISTING CHECKS (v6, unchanged)
    # ==================================================================
    def _chk_DM001(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty: return []
        arm, act = _col(df,"ARM"), _col(df,"ACTARM")
        mask = (arm != "") & (act != "") & (arm != act) & ~arm.str.upper().str.contains("SCRNFAIL", na=False)
        return [self._new(c, r["USUBJID"], f"ARM='{r['ARM']}' vs ACTARM='{r['ACTARM']}'")
                for _, r in df[mask].iterrows()]

    def _chk_DM003(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty: return []
        fl, dtc = _col(df,"DTHFL").str.upper(), _col(df,"DTHDTC")
        out = ([self._new(c, r["USUBJID"], "DTHFL=Y but DTHDTC missing")
                for _, r in df[(fl == "Y") & (dtc == "")].iterrows()] +
               [self._new(c, r["USUBJID"], f"DTHDTC='{r['DTHDTC']}' present but DTHFL != Y")
                for _, r in df[(dtc != "") & (fl != "Y")].iterrows()])
        return out

    def _chk_DM004(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "USUBJID" not in df.columns: return []
        dupes = df[df.duplicated("USUBJID", keep=False)]["USUBJID"].unique()
        return [self._new(c, s, f"Duplicate USUBJID='{s}' in DM") for s in dupes]

    def _chk_DM007(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "AGE" not in df.columns: return []
        age  = pd.to_numeric(df["AGE"], errors="coerce")
        mask = (age < 0) | (age > 120)
        return [self._new(c, r["USUBJID"], f"AGE={r['AGE']} is implausible (must be 0-120)")
                for _, r in df[mask.fillna(False)].iterrows()]

    def _chk_DM008(self, c, dd):
        df = dd.get("DM", pd.DataFrame())
        if df.empty or "AGE" not in df.columns: return []
        age  = pd.to_numeric(df["AGE"], errors="coerce")
        unit = _col(df,"AGEU").str.upper()
        mask = (age < 18) & (unit == "YEARS")
        return [self._new(c, r["USUBJID"], f"AGE={r['AGE']} AGEU=YEARS in adult trial")
                for _, r in df[mask.fillna(False)].iterrows()]

    def _chk_AE001(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        mask = _col(df,"AEDECOD") == ""
        return [self._new(c, r["USUBJID"], f"AEDECOD missing for AETERM='{r.get('AETERM','?')}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE004(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        st = _col(df,"AESTDTC").str[:10]
        en = _col(df,"AEENDTC").str[:10]
        mask = (st != "") & (en != "") & (st.str.len() >= 10) & (en.str.len() >= 10) & (st > en)
        return [self._new(c, r["USUBJID"], f"AESTDTC='{r['AESTDTC']}' after AEENDTC='{r['AEENDTC']}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE006(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"AESEV") == "") & (_col(df,"AETOXGR") == "")
        return [self._new(c, r["USUBJID"], f"Both AESEV and AETOXGR missing for AETERM='{r.get('AETERM','?')}'")
                for _, r in df[mask].iterrows()]

    def _chk_AE008(self, c, dd):
        df = dd.get("AE", pd.DataFrame())
        if df.empty: return []
        key = [k for k in ["USUBJID","AEDECOD","AESTDTC"] if k in df.columns]
        if not key: return []
        sub = df[_col(df,"AEDECOD") != ""] if "AEDECOD" in df.columns else df
        if sub.empty: return []
        counts = sub.groupby(key, sort=False).size()
        dupes  = counts[counts > 1].reset_index()
        out = []
        for _, r in dupes.iterrows():
            subj = r.get("USUBJID","?")
            out.append(self._new(c, subj,
                f"Duplicate AE: AEDECOD='{r.get('AEDECOD','')}' "
                f"AESTDTC='{r.get('AESTDTC','')}' appears {int(r[0])} times"))
        return out

    def _chk_EX001(self, c, dd):
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        key   = [k for k in ["USUBJID","EXTRT","EXSTDTC","EXDOSE"] if k in df.columns]
        if not key: return []
        sub   = df[df["EXTRT"] != ""] if "EXTRT" in df.columns else df
        dupes = sub[sub.duplicated(key, keep=False)]
        seen, out = set(), []
        for _, r in dupes.iterrows():
            k = (r.get("USUBJID",""), r.get("EXTRT",""), r.get("EXSTDTC",""))
            if k not in seen:
                seen.add(k)
                out.append(self._new(c, r["USUBJID"],
                    f"Duplicate EX: EXTRT='{r.get('EXTRT','')}' EXSTDTC='{r.get('EXSTDTC','')}' EXDOSE='{r.get('EXDOSE','')}'"))
        return out

    def _chk_EX002(self, c, dd):
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"EXOCCUR").str.upper() == "Y") & (_col(df,"EXDOSE") == "")
        return [self._new(c, r["USUBJID"], f"EXOCCUR=Y but EXDOSE missing for EXTRT='{r.get('EXTRT','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_EX003(self, c, dd):
        df = dd.get("EX", pd.DataFrame())
        if df.empty: return []
        occur = _col(df,"EXOCCUR").str.upper()
        dose  = pd.to_numeric(_col(df,"EXDOSE"), errors="coerce").fillna(0)
        mask  = (occur != "Y") & (dose > 0)
        return [self._new(c, r["USUBJID"], f"EXOCCUR='{r.get('EXOCCUR','')}' but EXDOSE={r.get('EXDOSE','')}>0")
                for _, r in df[mask].iterrows()]

    def _chk_LB003(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        mask = (_col(df,"LBSTRESN") != "") & (_col(df,"LBORNRLO") == "") & (_col(df,"LBORNRHI") == "")
        return [self._new(c, r["USUBJID"], f"LBTESTCD='{r.get('LBTESTCD','')}' LBSTRESN={r.get('LBSTRESN','')} but ref range missing")
                for _, r in df[mask].iterrows()]

    def _chk_LB004(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        orres  = _col(df,"LBORRES")
        starts = orres.str.startswith(">") | orres.str.startswith("<")
        mask   = starts & (_col(df,"LBSTRESN") == "") & (orres != "")
        return [self._new(c, r["USUBJID"], f"LBORRES='{r.get('LBORRES','')}' starts with >/< but LBSTRESN missing")
                for _, r in df[mask].iterrows()]

    def _chk_LB007(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        dtc  = _col(df,"LBDTC")
        out  = []
        for _, r in df[dtc.str.match(r"^\d{4}$") & (dtc != "")].iterrows():
            out.append(self._new(c, r["USUBJID"], f"LBDTC='{r['LBDTC']}' - year only, missing month and day"))
        for _, r in df[dtc.str.match(r"^\d{4}-\d{2}$") & (dtc != "")].iterrows():
            out.append(self._new(c, r["USUBJID"], f"LBDTC='{r['LBDTC']}' - missing day component"))
        return out

    def _chk_LB011(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty or "LBTESTCD" not in df.columns: return []
        alt  = df[_col(df,"LBTESTCD").isin(["ALT","ALAT"])].copy()
        bili = df[_col(df,"LBTESTCD").isin(["BILI","TBILI","BILIRUBIN"])].copy()
        if alt.empty or bili.empty: return []
        an, ah = pd.to_numeric(_col(alt,"LBSTRESN"),errors="coerce"), pd.to_numeric(_col(alt,"LBORNRHI"),errors="coerce")
        bn, bh = pd.to_numeric(_col(bili,"LBSTRESN"),errors="coerce"), pd.to_numeric(_col(bili,"LBORNRHI"),errors="coerce")
        hs = set(_col(alt[(an>0)&(ah>0)&(an>3*ah)],"USUBJID")) & set(_col(bili[(bn>0)&(bh>0)&(bn>2*bh)],"USUBJID"))
        return [self._new(c, s, "Hys Law signal: ALT>3xULN and TBili>2xULN in same subject") for s in hs]

    def _chk_LB012(self, c, dd):
        df = dd.get("LB", pd.DataFrame())
        if df.empty: return []
        key   = [k for k in ["USUBJID","LBTESTCD","LBDTC"] if k in df.columns]
        if len(key) < 2: return []
        dupes = df[df.duplicated(key, keep=False)]
        seen, out = set(), []
        for _, r in dupes.iterrows():
            k = (r.get("USUBJID",""), r.get("LBTESTCD",""), r.get("LBDTC",""))
            if k not in seen:
                seen.add(k)
                out.append(self._new(c, r["USUBJID"],
                    f"LBTESTCD='{r.get('LBTESTCD','')}' LBDTC='{r.get('LBDTC','')}' appears multiple times"))
        return out

    def _chk_VS001(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        bp = df[_col(df,"VSTESTCD").isin(["SYSBP","DIABP"])].copy()
        if bp.empty: return []
        bp["_n"]   = pd.to_numeric(_col(bp,"VSSTRESN"), errors="coerce")
        bp["_key"] = _col(bp,"USUBJID") + "|" + _col(bp,"VISITNUM").fillna(_col(bp,"VISIT"))
        wide = bp.pivot_table(index="_key", columns="VSTESTCD", values="_n", aggfunc="first")
        if "SYSBP" not in wide.columns or "DIABP" not in wide.columns: return []
        hits = wide[wide["DIABP"] > wide["SYSBP"]].dropna(subset=["SYSBP","DIABP"])
        out  = []
        for vk, row in hits.iterrows():
            subj  = vk.split("|")[0]
            visit = vk.split("|")[1]
            out.append(self._new(c, subj, f"DIABP={row['DIABP']:.0f} > SYSBP={row['SYSBP']:.0f} at VISIT='{visit}'"))
        return out

    def _chk_VS005(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        p  = df[_col(df,"VSTESTCD") == "PULSE"].copy()
        if p.empty: return []
        v  = pd.to_numeric(_col(p,"VSSTRESN"), errors="coerce")
        return [self._new(c, r["USUBJID"], f"PULSE={r.get('VSSTRESN','')} BPM - implausible (must be 20-300)")
                for _, r in p[((v<20)|(v>300)) & v.notna()].iterrows()]

    def _chk_VS007(self, c, dd):
        df = dd.get("VS", pd.DataFrame())
        if df.empty or "VSTESTCD" not in df.columns: return []
        s  = df[_col(df,"VSTESTCD") == "SYSBP"].copy()
        if s.empty: return []
        v  = pd.to_numeric(_col(s,"VSSTRESN"), errors="coerce")
        return [self._new(c, r["USUBJID"], f"SYSBP={r.get('VSSTRESN','')} mmHg - out of physiological range")
                for _, r in s[((v<40)|(v>300)) & v.notna()].iterrows()]

    def _chk_CM001(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        mask = _col(df,"CMDECOD") == ""
        return [self._new(c, r["USUBJID"], f"CMDECOD missing for CMTRT='{r.get('CMTRT','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_CM003(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        out = []
        yr  = re.compile(r"^\d{4}$")
        for col in ["CMSTDTC","CMENDTC"]:
            dtc  = _col(df, col)
            mask = dtc.str.match(yr) & (dtc != "")
            for _, r in df[mask].iterrows():
                out.append(self._new(c, r["USUBJID"], f"{col}='{r[col]}' - year only, missing month"))
        return out

    def _chk_CM004(self, c, dd):
        df = dd.get("CM", pd.DataFrame())
        if df.empty: return []
        st = _col(df,"CMSTDTC").str[:10]
        en = _col(df,"CMENDTC").str[:10]
        mask = (st != "") & (en != "") & (en < st)
        return [self._new(c, r["USUBJID"], f"CMENDTC='{r.get('CMENDTC','')}' before CMSTDTC='{r.get('CMSTDTC','')}'")
                for _, r in df[mask].iterrows()]

    def _chk_S010(self, c, dd):
        pat = re.compile(r"^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2})?)?)?)?$")
        out = []
        for dom, df in dd.items():
            if df.empty: continue
            for col in [x for x in df.columns if x.endswith("DTC")]:
                vals    = _col(df, col)
                invalid = df[(vals != "") & ~vals.str.match(pat)]
                for _, r in invalid.head(10).iterrows():
                    out.append(self._new(c, r.get("USUBJID","?"),
                        f"{dom}.{col}='{r[col]}' - invalid ISO 8601 format"))
        return out

    # ==================================================================
    # v7 NEW CHECKS: INT001-INT005
    # ==================================================================

    def _chk_INT001(self, c, dd):
        """Orphan records: USUBJID found in any domain but not in DM. Vectorized."""
        dm_subjs = self._lkp.get("dm_subjs", set()) if hasattr(self,"_lkp") else set()
        if not dm_subjs:
            dm = dd.get("DM", pd.DataFrame())
            if dm.empty or "USUBJID" not in dm.columns: return []
            dm_subjs = set(_col(dm,"USUBJID").unique()) - {"","ALL"}

        skip = {"DM","TS","TA","TE","TV","TI","RELREC","SUPP"}
        out  = []
        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            vc       = _col(df,"USUBJID").value_counts()
            orphans  = vc[~vc.index.isin(dm_subjs | {"","ALL"})]
            for subj, n_rec in orphans.items():
                out.append(self._new(c, subj,
                    f"USUBJID '{subj}' exists in {dom} ({n_rec} records) but not in DM",
                    root="Orphan subject"))
        return out

    def _chk_INT002(self, c, dd):
        """Baseline flag after first dose: --BLFL=Y but record date > DM.RFSTDTC. Vectorized."""
        rfst_s = (self._lkp.get("dm_rfstdtc") if hasattr(self,"_lkp") else None)
        if rfst_s is None:
            dm = dd.get("DM", pd.DataFrame())
            if dm.empty or "USUBJID" not in dm.columns: return []
            dm2    = dm.drop_duplicates("USUBJID").set_index("USUBJID")
            rfst_s = dm2.get("RFSTDTC", pd.Series(dtype=str)).str[:10]

        skip = {"DM","TS","TA","TE","TV","TI","DS","MH"}
        out  = []
        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            blfl_cols = [col for col in df.columns if col.endswith("BLFL") and col != "ABLFL"]
            dtc_cols  = [col for col in df.columns if col.endswith("DTC")]
            if not blfl_cols or not dtc_cols:
                continue
            dtc_col   = dtc_cols[0]
            for blfl_col in blfl_cols:
                blfl_mask = _col(df, blfl_col).str.upper() == "Y"
                sub = df[blfl_mask].copy()
                if sub.empty: continue
                sub["_dtc"]   = _col(sub, dtc_col).str[:10]
                sub["_rfst"]  = sub["USUBJID"].map(rfst_s)
                hits = sub[(sub["_dtc"] != "") & (sub["_rfst"].notna()) &
                           (sub["_dtc"] > sub["_rfst"])]
                for _, r in hits.iterrows():
                    out.append(self._new(c, r["USUBJID"],
                        f"{dom}.{blfl_col}=Y at {dtc_col}='{r['_dtc']}' but RFSTDTC='{r['_rfst']}'"
                        " (baseline record is AFTER first dose)",
                        root="Post-dose baseline flag"))
        return out

    def _chk_INT003(self, c, dd):
        """Missing disposition: subject has activity in EX/LB/AE but no DS record."""
        ds = dd.get("DS", pd.DataFrame())
        # Build set of subjects who have ANY DS record
        ds_subjs: set = set()
        if not ds.empty and "USUBJID" in ds.columns:
            ds_subjs = set(_col(ds, "USUBJID").unique()) - {"","ALL"}

        # Domains considered 'study activity'
        activity_domains = ["EX","LB","AE","VS","CM","EG"]
        out = []
        seen: set = set()
        for dom in activity_domains:
            df = dd.get(dom, pd.DataFrame())
            if df.empty or "USUBJID" not in df.columns:
                continue
            active_subjs = set(_col(df,"USUBJID").unique()) - {"","ALL"}
            missing_ds   = active_subjs - ds_subjs
            for subj in sorted(missing_ds):
                if subj not in seen:
                    seen.add(subj)
                    n = int((df["USUBJID"] == subj).sum())
                    out.append(self._new(c, subj,
                        f"Subject has {n} {dom} record(s) but no DS disposition event found",
                        root="Missing disposition"))
        return out

    def _chk_INT004(self, c, dd):
        """Gender-inappropriate tests: PREG/HCG/BHCG for male subjects."""
        dm = dd.get("DM", pd.DataFrame())
        lb = dd.get("LB", pd.DataFrame())
        if dm.empty or lb.empty: return []
        if "USUBJID" not in dm.columns or "LBTESTCD" not in lb.columns:
            return []

        # Build male subject set
        sex_col  = _col(dm,"SEX").str.upper()
        male_set = set(dm[sex_col == "M"]["USUBJID"].unique()) - {""}

        # Pregnancy / HCG tests
        preg_tests = {"PREG","HCG","BHCG","PREGNEG","PREGTEST","HCG QUAL",
                      "HCGQL","B-HCG","BETAHCG"}
        lb_tests   = _col(lb,"LBTESTCD").str.upper()
        preg_mask  = lb_tests.isin(preg_tests)
        preg_recs  = lb[preg_mask]

        out = []
        for _, r in preg_recs.iterrows():
            subj = str(r.get("USUBJID","?"))
            if subj in male_set:
                out.append(self._new(c, subj,
                    f"LBTESTCD='{r.get('LBTESTCD','')}' (pregnancy test) found for DM.SEX=M "
                    f"at LBDTC='{r.get('LBDTC','')}' - gender-inappropriate test"))
        return out

    def _chk_INT005(self, c, dd):
        """Pre-consent assessment: any domain date < DM.RFICDTC (excl. MH)."""
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty or "USUBJID" not in dm.columns:
            return []

        # Use pre-built lookup or build from DM
        if hasattr(self,"_lkp") and "dm_rficdtc" in self._lkp:
            consent_s = self._lkp["dm_rficdtc"].dropna()
        else:
            dm2 = dm.drop_duplicates("USUBJID").set_index("USUBJID")
            consent_s = dm2.get("RFICDTC", pd.Series(dtype=str)).str[:10].dropna()
        consent = consent_s.to_dict()

        if not consent:
            return []

        skip_domains = {"DM","MH","TS","TA","TE","TV","TI","DS"}
        out = []
        for dom, df in dd.items():
            if dom in skip_domains or df.empty or "USUBJID" not in df.columns:
                continue
            dtc_cols = [col for col in df.columns
                        if col.endswith("DTC") and not col.endswith("ENDTC")][:1]
            if not dtc_cols: continue
            dtc_col = dtc_cols[0]
            sub = df[["USUBJID", dtc_col]].copy()
            sub["_dtc"] = sub[dtc_col].str[:10]
            sub["_con"] = sub["USUBJID"].map(consent_s)
            hits = sub[(sub["_dtc"].str.len() == 10) &
                       (sub["_con"].notna()) &
                       (sub["_dtc"] < sub["_con"])]
            seen_subjs: set = set()
            for _, r in hits.iterrows():
                subj = str(r["USUBJID"])
                if subj not in seen_subjs:
                    seen_subjs.add(subj)
                    out.append(self._new(c, subj,
                        f"{dom}.{dtc_col}='{r['_dtc']}' is before RFICDTC='{r['_con']}' "
                        "(assessment precedes informed consent)",
                        root="Pre-consent activity"))
        return out

    # ==================================================================
    # v7 NEW CHECKS: DATE001-DATE006
    # ==================================================================

    def _chk_DATE001(self, c, dd):
        """Start date after end date across all loaded domains (--STDTC > --ENDTC)."""
        # Map of standard start/end date pairs
        domain_pairs = {
            "AE": ("AESTDTC","AEENDTC"),
            "CM": ("CMSTDTC","CMENDTC"),
            "EX": ("EXSTDTC","EXENDTC"),
            "DS": ("DSSTDTC",None),
            "MH": ("MHSTDTC","MHENDTC"),
            "PR": ("PRSTDTC","PRENDTC"),
            "QS": ("QSSTDTC",None),
            "LB": ("LBDTC",None),
        }
        out = []
        for dom, df in dd.items():
            if df.empty: continue
            # Use known pairs if available, else scan for any --STDTC/--ENDTC pair
            pair = domain_pairs.get(dom)
            if pair:
                st_col, en_col = pair
                if st_col and en_col and st_col in df.columns and en_col in df.columns:
                    st = _col(df, st_col).str[:10]
                    en = _col(df, en_col).str[:10]
                    mask = (st != "") & (en != "") & (st.str.len() == 10) & (en.str.len() == 10) & (st > en)
                    for _, r in df[mask].iterrows():
                        out.append(self._new(c, r.get("USUBJID","?"),
                            f"{dom}: {st_col}='{r.get(st_col,'')}' > {en_col}='{r.get(en_col,'')}'"
                            f" (start after end)"))
            else:
                # Generic scan for any --STDTC / --ENDTC pairing
                stdtc_cols = [col for col in df.columns if col.endswith("STDTC")]
                for st_col in stdtc_cols:
                    en_col = st_col.replace("STDTC","ENDTC")
                    if en_col in df.columns:
                        st = _col(df, st_col).str[:10]
                        en = _col(df, en_col).str[:10]
                        mask = (st != "") & (en != "") & (st.str.len() == 10) & (en.str.len() == 10) & (st > en)
                        for _, r in df[mask].iterrows():
                            out.append(self._new(c, r.get("USUBJID","?"),
                                f"{dom}: {st_col}='{r.get(st_col,'')}' > {en_col}='{r.get(en_col,'')}'"
                                f" (start after end)"))
        return out

    def _chk_DATE002(self, c, dd):
        """Post-mortem activity: any clinical domain record after DS death date."""
        ds = dd.get("DS", pd.DataFrame())
        if ds.empty: return []

        # Extract death dates per subject
        death_dates: dict = {}
        if "DSDECOD" in ds.columns and "DSSTDTC" in ds.columns:
            death_mask = _col(ds,"DSDECOD").str.upper().isin(["DEATH","DIED","DEAD"])
            for _, r in ds[death_mask].iterrows():
                subj  = str(r.get("USUBJID",""))
                ddtc  = _date_str(str(r.get("DSSTDTC","")))
                if subj and ddtc:
                    # Keep earliest death date
                    if subj not in death_dates or ddtc < death_dates[subj]:
                        death_dates[subj] = ddtc

        if not death_dates:
            return []

        skip = {"DS","TS","TA","TE","TV","TI","MH"}
        out  = []
        # Use pre-built lookup
        if hasattr(self,"_lkp") and "death_dates" in self._lkp:
            death_s = self._lkp["death_dates"]
        else:
            death_s = pd.Series(death_dates) if death_dates else pd.Series(dtype=str)
        if death_s.empty: return []

        for dom, df in dd.items():
            if dom in skip or df.empty or "USUBJID" not in df.columns:
                continue
            dtc_cols = [col for col in df.columns if col.endswith("DTC")][:2]
            for dtc_col in dtc_cols:
                sub = df[["USUBJID", dtc_col]].copy()
                sub["_dtc"]  = sub[dtc_col].str[:10]
                sub["_dth"]  = sub["USUBJID"].map(death_s)
                hits = sub[(sub["_dtc"].str.len() == 10) &
                           (sub["_dth"].notna()) &
                           (sub["_dtc"] > sub["_dth"])]
                seen_k: set = set()
                for _, r in hits.iterrows():
                    subj = str(r["USUBJID"])
                    k = (subj, dtc_col)
                    if k not in seen_k:
                        seen_k.add(k)
                        out.append(self._new(c, subj,
                            f"{dom}.{dtc_col}='{r['_dtc']}' found after death date '{r['_dth']}'"
                            " (post-mortem activity)",
                            root="Post-mortem clinical activity"))
        return out

    def _chk_DATE003(self, c, dd):
        """Future date: any --DTC column value after today's date."""
        today = _today()   # YYYY-MM-DD
        skip  = {"TS","TA","TE","TV","TI"}
        out   = []
        seen  : set = set()
        for dom, df in dd.items():
            if dom in skip or df.empty: continue
            dtc_cols = [col for col in df.columns if col.endswith("DTC")]
            for col in dtc_cols:
                vals    = _col(df, col).str[:10]
                future  = df[(vals.str.len() == 10) & (vals > today)]
                for _, r in future.iterrows():
                    subj = str(r.get("USUBJID","?"))
                    val  = str(r.get(col,""))[:10]
                    key  = (subj, dom, col, val)
                    if key not in seen:
                        seen.add(key)
                        out.append(self._new(c, subj,
                            f"{dom}.{col}='{val}' is in the future (today={today}). "
                            f"Possible data entry typo."))
        return out

    def _chk_DATE004(self, c, dd):
        """Birth date after study start: DM.BRTHDTC > DM.RFSTDTC."""
        dm = dd.get("DM", pd.DataFrame())
        if dm.empty: return []
        brthdtc = _col(dm,"BRTHDTC").str[:10]
        rfstdtc = _col(dm,"RFSTDTC").str[:10]
        mask    = (brthdtc != "") & (rfstdtc != "") & \
                  (brthdtc.str.len() == 10) & (rfstdtc.str.len() == 10) & \
                  (brthdtc > rfstdtc)
        return [self._new(c, r["USUBJID"],
                    f"BRTHDTC='{r.get('BRTHDTC','')}' is after RFSTDTC='{r.get('RFSTDTC','')}' "
                    f"(born after study start - possible dummy or erroneous record)")
                for _, r in dm[mask].iterrows()]

    def _chk_DATE005(self, c, dd):
        """First treatment before informed consent: EX.EXSTDTC < DM.RFICDTC."""
        dm = dd.get("DM", pd.DataFrame())
        ex = dd.get("EX", pd.DataFrame())
        if dm.empty or ex.empty: return []
        if "USUBJID" not in dm.columns or "EXSTDTC" not in ex.columns:
            return []

        # Build consent map
        consent: dict = {}
        for _, r in dm.iterrows():
            s = str(r.get("USUBJID",""))
            d = _date_str(str(r.get("RFICDTC","")))
            if s and d:
                consent[s] = d

        out = []
        seen: set = set()
        for _, r in ex.iterrows():
            subj    = str(r.get("USUBJID","?"))
            exstdtc = _date_str(str(r.get("EXSTDTC","")))
            con_dtc = consent.get(subj,"")
            if exstdtc and con_dtc and exstdtc < con_dtc and subj not in seen:
                seen.add(subj)
                out.append(self._new(c, subj,
                    f"EXSTDTC='{exstdtc}' is before RFICDTC='{con_dtc}' "
                    f"(first dose before informed consent - GCP violation)",
                    root="Pre-consent dosing"))
        return out

    def _chk_DATE006(self, c, dd):
        """Dosing after discontinuation: EX.EXENDTC > DS disposition DSSTDTC."""
        ds = dd.get("DS", pd.DataFrame())
        ex = dd.get("EX", pd.DataFrame())
        if ds.empty or ex.empty: return []
        if "USUBJID" not in ds.columns or "EXENDTC" not in ex.columns:
            return []

        # Use pre-built lookup
        if hasattr(self,"_lkp") and "disp_dates" in self._lkp:
            disp_s = self._lkp["disp_dates"]
        else:
            dscat_col = _col(ds,"DSCAT").str.upper()
            disp_mask = dscat_col.isin(["DISPOSITION EVENT","DISPOSITION","COMPLETION"])
            disp_rows = ds[disp_mask].copy()
            if disp_rows.empty or "DSSTDTC" not in disp_rows.columns:
                return []
            disp_rows["_d"] = disp_rows["DSSTDTC"].str[:10]
            disp_s = (disp_rows.sort_values("_d")
                      .drop_duplicates("USUBJID",keep="first")
                      .set_index("USUBJID")["_d"])
        if disp_s.empty:
            return []
        disp_dates = disp_s.to_dict()

        out  = []
        seen: set = set()
        for _, r in ex.iterrows():
            subj    = str(r.get("USUBJID","?"))
            exendtc = _date_str(str(r.get("EXENDTC","")))
            dispdtc = disp_dates.get(subj,"")
            if exendtc and dispdtc and exendtc > dispdtc and subj not in seen:
                seen.add(subj)
                out.append(self._new(c, subj,
                    f"EX.EXENDTC='{exendtc}' is after DS disposition date '{dispdtc}' "
                    f"(dosing continued after study discontinuation)"))
        return out

    # ================================================ demo fallback
    def _run_demo(self, check: dict, dd_rows: dict) -> list:
        dom_parts = [d for d in check["domain"].split("/")
                     if d not in ("ALL","DEFINE","SUPP","RELREC")]
        if any(d in dd_rows for d in dom_parts):
            return []
        out = []
        for entry in _DEMO_MAP.get(check["id"], []):
            c = get_check(check["id"])
            if c:
                self._seq += 1
                out.append({
                    "fid":         f"F{self._seq:04d}",
                    "checkId":     c["id"],
                    "label":       c["label"],
                    "layer":       c["layer"],
                    "cat":         c["cat"],
                    "domain":      entry["domain"],
                    "sev":         c["sev"],
                    "risk":        c["risk"],
                    "source":      c["source"],
                    "subj":        entry["subj"],
                    "detail":      entry["detail"],
                    "root":        entry.get("root"),
                    "actual":      False,
                    "waived":      False,
                    "waiver_note": "",
                    "ts":          datetime.datetime.now().isoformat(),
                })
        return out
