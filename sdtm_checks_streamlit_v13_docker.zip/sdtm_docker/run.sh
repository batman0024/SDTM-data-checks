#!/usr/bin/env bash
# ── SDTM CIS v13 — Mac / Linux Launcher ──────────────────────────────────────
set -e

echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║   SDTM Clinical Integrity Suite v13                 ║"
echo "  ║   Internal Review Build                             ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""

# Check Docker
if ! command -v docker &>/dev/null; then
    echo "  [ERROR] Docker not found."
    echo "          Install Docker Desktop: https://docker.com"
    exit 1
fi

# Check daemon
if ! docker info &>/dev/null; then
    echo "  [ERROR] Docker is not running. Start Docker Desktop first."
    exit 1
fi

echo "  Starting CIS..."
echo "  (First run builds the image — ~2 minutes)"
echo "  (Subsequent runs start in <5 seconds)"
echo ""

mkdir -p data

docker compose up --build -d

echo ""
echo "  ✓ CIS is running at:  http://localhost:8501"
echo ""

# Open browser (works on Mac and most Linux desktops)
if command -v open &>/dev/null; then
    sleep 3 && open http://localhost:8501
elif command -v xdg-open &>/dev/null; then
    sleep 3 && xdg-open http://localhost:8501
fi

echo "  To stop:  ./stop.sh   or   docker compose down"
echo ""
