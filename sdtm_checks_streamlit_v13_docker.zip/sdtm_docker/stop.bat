@echo off
echo Stopping SDTM CIS...
docker compose down
echo Done.
pause
