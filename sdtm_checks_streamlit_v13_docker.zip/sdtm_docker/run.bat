@echo off
:: ── SDTM CIS v13 — Windows Launcher ─────────────────────────────────────────
title SDTM Clinical Integrity Suite v13

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   SDTM Clinical Integrity Suite v13                 ║
echo  ║   Internal Review Build                             ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: Check Docker is available
where docker >nul 2>&1
if %ERRORLEVEL% NEq 0 (
    echo  [ERROR] Docker not found. Install Docker Desktop from https://docker.com
    echo          then re-run this script.
    pause
    exit /b 1
)

:: Check Docker daemon is running
docker info >nul 2>&1
if %ERRORLEVEL% NEq 0 (
    echo  [ERROR] Docker Desktop is not running. Please start it first.
    pause
    exit /b 1
)

echo  Starting CIS...
echo  (First run will build the image — this takes ~2 minutes)
echo  (Subsequent runs start in under 5 seconds)
echo.

:: Create data folder if it doesn't exist
if not exist "data" mkdir data

:: Build and start
docker compose up --build -d

if %ERRORLEVEL% NEq 0 (
    echo.
    echo  [ERROR] Failed to start. Check output above.
    pause
    exit /b 1
)

echo.
echo  ✓ CIS is running at:  http://localhost:8501
echo.
echo  Opening browser...
timeout /t 3 /nobreak >nul
start http://localhost:8501

echo.
echo  To stop:  run stop.bat   or   docker compose down
echo.
pause
