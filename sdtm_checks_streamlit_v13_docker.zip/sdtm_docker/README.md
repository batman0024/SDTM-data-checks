# SDTM Clinical Integrity Suite v13
## Internal Review Guide — Zero Install

---

## Prerequisites (one-time, IT can push this)

| Platform | Install |
|----------|---------|
| Windows  | [Docker Desktop for Windows](https://www.docker.com/products/docker-desktop/) |
| Mac      | [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop/) |
| Linux    | `sudo apt install docker.io docker-compose-plugin` |

That is the **only** thing your team needs to install.

---

## Starting the App

### Windows
1. Unzip `sdtm_checks_streamlit_v13.zip` to any folder
2. Double-click **`run.bat`**
3. Browser opens automatically at **http://localhost:8501**

### Mac / Linux
```bash
unzip sdtm_checks_streamlit_v13.zip
cd sdtm_checks_streamlit_v13
chmod +x run.sh stop.sh
./run.sh
```

> **First run** downloads the Python base image and installs packages (~2 minutes, one time only).
> **All subsequent runs** start in under 5 seconds.

---

## Stopping the App

- **Windows:** double-click `stop.bat`
- **Mac/Linux:** `./stop.sh`
- Or from any terminal: `docker compose down`

---

## Data Privacy — Important

- **No data leaves your machine.** The app runs entirely locally inside Docker.
- Upload your SDTM files via the sidebar — they live only in memory during the session.
- Nothing is written to disk inside the container by default.
- The `./data/` folder next to `run.bat` is a local mount you can use if you want to persist uploads across sessions — it stays on your filesystem, never inside the image.

---

## Supported File Types

| Format | Row Data | Notes |
|--------|----------|-------|
| `.xpt` | ✅ Full | Native parser, no extra install |
| `.sas7bdat` | ✅ Full | pyreadstat included in this build |
| `.csv` | ✅ Full | Up to 5 000 rows |
| `.xlsx` | ✅ Full | Up to 5 000 rows |
| `.json` | ✅ Full | SDTM-JSON format |

---

## Sharing with the Team (internal network only)

If you want **one person to run the server** and the rest of the team to access it via browser on the same internal network:

1. Start the app on one machine with `run.bat` / `run.sh`
2. Find that machine's IP address (e.g. `192.168.1.42`)
3. Team members open **`http://192.168.1.42:8501`** in their browser — no install needed on their side

> Ensure your firewall allows inbound TCP on port 8501 from your internal network.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `Docker not found` | Install Docker Desktop and restart your terminal |
| `Docker is not running` | Open Docker Desktop from the system tray and wait for it to start |
| Port 8501 already in use | Edit `docker-compose.yml`, change `"8501:8501"` to `"8502:8501"`, then access `http://localhost:8502` |
| SAS7BDAT loads 0 rows | This build includes `pyreadstat` — should not happen. Check the Files tab for error details |
| App won't start on Linux | Run `sudo usermod -aG docker $USER` then log out and back in |

---

## What the App Does

SDTM Clinical Integrity Suite runs **135+ validation checks** across your SDTM datasets, beyond standard Pinnacle 21 checks:

- **Submission Blockers** — will cause FDA rejection
- **Medical Concerns** — patient safety flags (Hys Law, post-mortem activity, GCP violations)
- **Structural Errors** — SDTMIG conformance issues
- **Advisory Notices** — best-practice recommendations

Each finding has a stable fingerprint ID — waivers you apply persist across re-runs of the same data.

Reports can be downloaded as **HTML** (shareable) or **Excel** (annotatable), both containing full audit trail metadata (Run ID, YAML hash, dataset list, timestamp).
