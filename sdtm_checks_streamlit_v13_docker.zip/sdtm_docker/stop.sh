#!/usr/bin/env bash
echo "Stopping SDTM CIS..."
docker compose down
echo "Done."
