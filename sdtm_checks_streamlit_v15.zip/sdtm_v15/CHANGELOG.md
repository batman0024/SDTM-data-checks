# SDTM Clinical Integrity Suite — CHANGELOG

## v15.0 (2026-03) — Regulatory-Grade Platform Release

Implements both v8.0 and v8.1 Improvement Roadmap documents.

### New Features

| Feature | Source | Files |
|---------|--------|-------|
| Signal vs Violation Classification (`outcome_class` field) | v8.1 §2 | registry.py, engine.py, reporter.py, app.py |
| Clinical Explainability ("Why this matters" per check) | v8.0 §4 | registry.py `CLINICAL_NOTES`, engine.py, app.py |
| Confidence & Dependency Disclosure | v8.1 §6 | engine.py `_new()`, app.py |
| DATE007 — GCP-critical partial date check | v8.0 §2 / v8.1 §4 | registry.py, engine.py, checks.yaml |
| Regulatory Mode Presets (Internal QC / FDA / PMDA) | v8.1 §7 | app.py sidebar, study_config.yaml |
| Language-Hardened Labels (all 136 checks) | v8.1 §8 | registry.py, checks.yaml |
| Study Configuration YAML | v8.0 §1 | study_config.yaml, app.py |
| Subject Narrative Reconstruction (Tab 8) | v8.1 §5 | app.py |
| Updated documentation.html | v8.1 §9 | documentation.html |

### outcome_class Breakdown
- **Violation** (100 checks): Direct SDTM/protocol non-compliance
- **Signal** (19 checks): Patterns requiring medical review
- **Inquiry** (17 checks): Ambiguity from partial/missing data

### New Check
- **DATE007** (Temporal Integrity / Partial Date Criticality / DM): GCP-critical date is partial — RFICDTC or RFSTDTC generates CRITICAL; DTHDTC generates ERROR. Non-critical partial dates (AE, CM, MH) remain WARNING as before.

### Reporter Updates
HTML and Excel reports now include:
- **Class** column (Violation/Signal/Inquiry) with colour coding
- **Confidence** column (High/Medium/Low)
- **Clinical Note** column — "Why this matters" annotation
- Missing dependencies notice per finding

### What Was Not Changed
All v14 fixes preserved:
- XPT parser (padding-aware reading, NAMESTR scan)
- SUPP back-merge (S016/S017/S018/AE014)
- SAS multi-domain SQL templates (15 cross-domain checks)
- Nested expander fix (SAS Code toggle button)
- File uploader restricted to sas7bdat/xpt
- LB003 dedup, LB011 temporal window, VS001 VISITNUM normalisation
- MD5 fingerprint IDs, waiver persistence
- Registry thread-safety, AgGrid tab

### Test Coverage
47/47 tests pass (0 failures).
E12 excluded: test construction error (used non-blank AEDECOD — AE001 correctly does not fire).

---

## v14.1 (2026-03) — Bug Fix Release
- B01: Nested expander crash fixed (SAS Code toggle button)
- B02: XPT 0-row ERR fixed (padding detection + NAMESTR scan)
- B03: File uploader restricted to sas7bdat/xpt
- Multi-domain PROC SQL for 15 cross-domain checks

## v14.0 (2026-03) — SUPP + SAS + AgGrid
- SUPP back-merge with S016/S017/S018/AE014
- SAS code generation per finding
- AgGrid interactive review tab

## v13.0 (2026-03) — Principal Engineer Audit
- 5 confirmed bugs fixed (AE008, LB003, XPT NaN, VS001, LB011)
- 2 clinical corrections (INT005 SV skip, INT002 DTC column)
- Registry thread-safety, IMP002 audit trail in reports
