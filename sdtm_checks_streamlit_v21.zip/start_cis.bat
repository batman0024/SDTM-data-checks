@echo off
chcp 65001 >nul 2>&1
:: ============================================================
::  CIS Launcher  --  Streamlit + FastAPI Gateway
::  Clinical Integrity Suite v15  |  Internal Use Only
:: ============================================================
::
::  EXPECTED FOLDER LAYOUT (unzip preserves this):
::
::  sdtm_checks_streamlit_v20\          <-- root (where this bat lives)
::    cis_v20\                          <-- Streamlit app
::      app.py
::      ui\
::      modules\
::    gateway.py                        <-- FastAPI gateway
::    start_cis.bat                     <-- this file
::    requirements_gateway.txt
::
::  USAGE:
::    Double-click  start_cis.bat
::    start_cis.bat --admin you@company.com
::    start_cis.bat --domains company.com
::    start_cis.bat --hours 12
::    start_cis.bat --port 9000
:: ============================================================

title CIS Clinical Integrity Suite v15

:: ---- Editable config -----------------------------------------------
set STREAMLIT_PORT=8501
set GATEWAY_PORT=8000
set SESSION_HOURS=8

:: This bat lives in the root. APP_DIR is the cis_v20 subfolder.
set SCRIPT_DIR=%~dp0
set APP_DIR=%SCRIPT_DIR%cis_v20
set GATEWAY_FILE=%SCRIPT_DIR%gateway.py

:: Optional: admin email to view /admin activity log (blank = disabled)
set ADMIN_EMAILS=

:: Optional: restrict login to email domain(s), e.g. company.com
set ALLOWED_DOMAINS=

:: Python command (change if using conda or a venv)
set PYTHON_CMD=python
:: conda example:
::   set PYTHON_CMD=C:\ProgramData\Miniconda3\envs\cis\python.exe
:: venv example:
::   set PYTHON_CMD=%SCRIPT_DIR%.venv\Scripts\python.exe
:: --------------------------------------------------------------------

:parse_args
if "%1"=="--admin"   (set ADMIN_EMAILS=%2   & shift & shift & goto parse_args)
if "%1"=="--domains" (set ALLOWED_DOMAINS=%2& shift & shift & goto parse_args)
if "%1"=="--hours"   (set SESSION_HOURS=%2  & shift & shift & goto parse_args)
if "%1"=="--port"    (set GATEWAY_PORT=%2   & shift & shift & goto parse_args)
if "%1"=="--appdir"  (set APP_DIR=%2        & shift & shift & goto parse_args)

echo.
echo  =====================================================
echo   CIS Clinical Integrity Suite v15  --  Launcher
echo   SDTM Beyond-P21  ^|  Internal Use Only
echo  =====================================================
echo.
echo  [CONFIG]
echo    App dir   : %APP_DIR%
echo    Streamlit : http://127.0.0.1:%STREAMLIT_PORT%  (internal only)
echo    Gateway   : http://0.0.0.0:%GATEWAY_PORT%      (open in browser)
echo    Session   : %SESSION_HOURS% hours
if not "%ADMIN_EMAILS%"==""    echo    Admin     : %ADMIN_EMAILS%
if not "%ALLOWED_DOMAINS%"=="" echo    Domains   : %ALLOWED_DOMAINS%
echo.

:: Verify app dir exists
if not exist "%APP_DIR%\app.py" (
    echo  [ERROR] Cannot find app.py in: %APP_DIR%
    echo  Check that cis_v20 folder is next to this bat file.
    echo.
    pause
    exit /b 1
)

:: Verify gateway.py exists
if not exist "%GATEWAY_FILE%" (
    echo  [ERROR] Cannot find gateway.py in: %SCRIPT_DIR%
    echo  Check that gateway.py is in the same folder as start_cis.bat.
    echo.
    pause
    exit /b 1
)

:: Check Python
%PYTHON_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Edit PYTHON_CMD at the top of this script.
    echo.
    pause
    exit /b 1
)

:: Check and install required packages
echo  [CHECK] Verifying required packages...
%PYTHON_CMD% -c "import streamlit,fastapi,uvicorn,httpx,altair,pandas" 2>nul
if errorlevel 1 (
    echo  [INSTALL] Installing missing packages (first-time setup, please wait)...
    %PYTHON_CMD% -m pip install streamlit fastapi "uvicorn[standard]" httpx altair pandas openpyxl --quiet
    if errorlevel 1 (
        echo  [ERROR] pip install failed. Try running manually:
        echo    %PYTHON_CMD% -m pip install streamlit fastapi uvicorn httpx altair pandas openpyxl
        pause
        exit /b 1
    )
    echo  [INSTALL] Done.
    echo.
)

:: Set env vars for gateway.py
set STREAMLIT_URL=http://127.0.0.1:%STREAMLIT_PORT%

:: Start Streamlit in a minimised background window
echo  [START] Launching Streamlit on port %STREAMLIT_PORT%...
start "CIS Streamlit" /min cmd /c "cd /d ""%APP_DIR%"" && %PYTHON_CMD% -m streamlit run app.py --server.port %STREAMLIT_PORT% --server.headless true --server.address 127.0.0.1 --browser.gatherUsageStats false 2>&1"

echo  [WAIT]  Giving Streamlit 6s to start...
timeout /t 6 /nobreak >nul

:: Start FastAPI gateway in this window (foreground so Ctrl+C stops it)
echo  [START] Launching CIS Gateway on port %GATEWAY_PORT%...
echo.
echo  ---------------------------------------------------------
echo   Open in browser : http://localhost:%GATEWAY_PORT%
echo   Activity log    : http://localhost:%GATEWAY_PORT%/admin
echo   Press Ctrl+C to stop all services
echo  ---------------------------------------------------------
echo.

cd /d "%SCRIPT_DIR%"
%PYTHON_CMD% -m uvicorn gateway:app --host 0.0.0.0 --port %GATEWAY_PORT% --log-level info

:: Cleanup
echo.
echo  [STOP] Closing Streamlit background window...
taskkill /fi "WINDOWTITLE eq CIS Streamlit" /f >nul 2>&1
echo  [DONE] All services stopped.
echo.
pause
