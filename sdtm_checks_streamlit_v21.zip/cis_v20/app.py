"""
SDTM Clinical Integrity Suite v8.0
Streamlit Edition - Redesigned Dashboard
"""
import hashlib
import uuid
import yaml
import streamlit as st
import pandas as pd
import os, datetime

from modules.registry import CHECKS, get_check, get_checks, LAYERS, CATEGORIES
from modules.engine   import ValidationEngine, DEMO_POOL
from modules.parser   import FileParser
from modules.reporter import make_html_report, make_excel_report

# __ PAGE CONFIG ______________________________________________________________
st.set_page_config(
    page_title="SDTM Clinical Integrity Suite v8.0",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={"About": "SDTM CIS v8.0 | Beyond-P21 | 135 Checks"},
)

# __ SESSION STATE (must be before theme injection) ___________________________
def _init():
    defs = {
        "uploaded_files_meta": {}, "findings": [],
        "enabled_ids": set(c["id"] for c in get_checks()),
        "is_running": False, "run_count": 0, "last_run_ts": "",
        "waived_notes": {}, "clear_trigger": 0,
        "run_id": "",
        "checks_yaml_hash": "",
        "run_dataset_list": [],
        "cis_version": "8.0",
        "supp_merge_log": [],
        "theme": "dark",  # dark | light
        "study_config": {},
        "regulatory_mode": "internal_qc",
    }
    for k, v in defs.items():
        if k not in st.session_state:
            st.session_state[k] = v
_init()

# __ THEME (loaded from ui/ folder — after session state so theme key exists) __
from ui import inject_theme, inject_scroll_fab
_theme_now = st.session_state.get("theme", "dark")
inject_theme(_theme_now)
inject_scroll_fab()

# __ CONSTANTS _________________________________________________________________
# Design tokens loaded from ui/tokens.py
from ui.tokens import RISK_COLORS, RISK_LABELS, SEV_COLORS, SEV_BADGE, RISK_BADGE

CARD_LIMIT = 50   # render interactive cards only for groups <= this size; larger groups use dataframe view

# SDTM domains grouped for display
DOMAIN_GROUPS = {
    "Demographics & Disposition": ["DM","DS","SS"],
    "Safety & Adverse Events":    ["AE","MH","CM","PR","DV"],
    "Exposure & PK":              ["EX","PC","PP"],
    "Lab & Vitals":               ["LB","VS","EG"],
    "Oncology & Tumor":           ["TR","TU","RS"],
    "Questionnaires & Other":     ["QS","IE","SV","SE","FA","EC","HO"],
    "Trial Design":               ["TS","TA","TE","TV","TI"],
    "Structural":                 ["ALL","DEFINE","SUPP","RELREC"],
}

# __ HELPERS ___________________________________________________________________
def _active():
    return [f for f in st.session_state.findings
            if not f.get("waived") and not f.get("dep_warning")]

def _dep_warns():
    return [f for f in st.session_state.findings if f.get("dep_warning")]

def _count_by(lst, key):
    out = {}
    for f in lst:
        v = f.get(key,"?")
        out[v] = out.get(v,0) + 1
    return out

def _worst_risk(risks):
    for r in ["submission-blocker","medical-concern","structural","advisory"]:
        if r in risks: return r
    return "advisory"

def _badge(text, kind):
    cls = SEV_BADGE.get(text) or RISK_BADGE.get(kind) or "badge-struct"
    return f'<span class="badge {cls}">{text}</span>'

def _sev_icon(sev):
    return {"REJECT":"[!]","CRITICAL":"[X]","ERROR":"[^]","WARNING":"[~]","NOTICE":"[i]"}.get(sev,"[-]")

def _domain_of(f):
    return f.get("domain","ALL").split("/")[0]

def _findings_df(findings, risk_filter="All"):
    rows = []
    for f in findings:
        if risk_filter != "All" and f.get("risk") != risk_filter:
            continue
        rows.append({
            "ID": f["fid"], "Sev": f["sev"],
            "Risk": RISK_LABELS.get(f["risk"], f["risk"]),
            "Subject": "GLOBAL" if f["subj"]=="ALL" else f["subj"],
            "Domain":  _domain_of(f),
            "Check":   f["label"],
            "Detail":  f["detail"],
            "Source":  f["source"], "Layer": f["layer"],
            "Waived":  "YES" if f.get("waived") else "",
        })
    if not rows:
        return pd.DataFrame(columns=["ID","Sev","Risk","Subject","Domain","Check","Detail","Source","Layer","Waived"])
    return pd.DataFrame(rows)

# __ FINDING CARD ______________________________________________________________
def _render_card(f, compact=False, tab_ctx="t"):
    risk      = f.get("risk","structural")
    sev       = f.get("sev","")
    is_waived = f.get("waived",False)
    fid       = f["fid"]
    subj      = "GLOBAL" if f["subj"]=="ALL" else f["subj"]
    css_cls   = {"submission-blocker":"blocker","medical-concern":"medical",
                 "structural":"structural","advisory":"advisory"}.get(risk,"structural")
    wb_badge  = '<span class="waived-badge">WAIVED</span>' if is_waived else ""
    ab        = ('<span class="badge-actual">ACTUAL</span>' if f.get("actual")
                 else '<span class="badge-demo">DEMO</span>')
    root_html = (f'<div class="finding-root">Root: {f["root"]}</div>'
                 if f.get("root") else "")
    supp_tag  = ('<span style="font-size:.58rem;color:#90d0b0;border:1px solid rgba(80,200,140,.3);'
                 'padding:1px 5px;border-radius:2px;background:rgba(80,200,140,.06)">SUPP-MERGED</span> '
                 if f.get("supp_enriched") else "")

    # outcome_class badge
    oc = f.get("outcome_class", "")
    oc_colors = {"Violation": "#ff6870", "Signal": "#f0c040", "Inquiry": "#70a8ff"}
    oc_html = (f'<span style="font-size:.58rem;font-weight:700;padding:1px 5px;border-radius:2px;'
               f'color:{oc_colors.get(oc,"#9098b8")};border:1px solid {oc_colors.get(oc,"#9098b8")}44;'
               f'background:{oc_colors.get(oc,"#9098b8")}11">{oc}</span>' if oc else "")
    # confidence badge
    conf = f.get("confidence", "")
    conf_colors = {"High": "#58c890", "Medium": "#f0c040", "Low": "#ff8060"}
    conf_html = (f'<span style="font-size:.55rem;color:{conf_colors.get(conf,"#7880a8")};'
                 f'padding:1px 4px;border-radius:2px;'
                 f'border:1px solid {conf_colors.get(conf,"#7880a8")}33">{conf} conf</span>' if conf else "")
    # clinical note
    note_text = f.get("clinical_note", "")
    clinical_note_html = (
        f'<div style="margin-top:5px;padding:5px 8px;background:rgba(104,152,255,.05);'
        f'border-left:2px solid #4870c855;border-radius:2px;font-size:.68rem;'
        f'color:#7888a8;line-height:1.55">'
        f'<span style="color:#5878a0;font-size:.6rem;text-transform:uppercase;'
        f'letter-spacing:.06em">Why this matters</span><br>{note_text}</div>'
        if note_text else ""
    )
    # missing deps notice
    missing_deps = f.get("missing_deps", [])
    deps_html = (
        f'<div style="font-size:.62rem;color:#806040;margin-top:3px">'
        f'⚠ Missing domains: {", ".join(missing_deps)} — confidence limited</div>'
        if missing_deps else ""
    )

    st.markdown(f"""
    <div class="finding-card {css_cls}" style="opacity:{'0.4' if is_waived else '1'}">
      <div style="display:flex;align-items:center;gap:7px;margin-bottom:4px;flex-wrap:wrap">
        <code style="font-size:.67rem;color:#505878;background:none;border:none;padding:0">{_sev_icon(sev)}</code>
        {_badge(sev,sev)}&nbsp;{_badge(RISK_LABELS.get(risk,risk),risk)}
        <span class="finding-subject">{subj}</span>
        <span class="finding-domain">[{_domain_of(f)}]</span>
        {ab} {supp_tag}{wb_badge}
      </div>
      <div class="finding-label">{f.get("label","")}</div>
      <div class="finding-detail">{f.get("detail","")}</div>
      {root_html}
      <div class="finding-meta">
        {fid} &bull; {f.get("cat","")} &bull; {f.get("source","")}
        {oc_html} {conf_html}
      </div>
      {deps_html}
      {clinical_note_html}
    </div>""", unsafe_allow_html=True)

    if not compact:
        # SAS code display — use a toggle button (not expander) to avoid nested-expander crash
        sas = f.get("sas_code","")
        if sas:
            toggle_key = f"sas_toggle_{fid}_{tab_ctx}"
            if toggle_key not in st.session_state:
                st.session_state[toggle_key] = False
            btn_label = "▲ Hide SAS" if st.session_state[toggle_key] else "▶ SAS Code"
            if st.button(btn_label, key=f"sas_btn_{fid}_{tab_ctx}",
                         use_container_width=False):
                st.session_state[toggle_key] = not st.session_state[toggle_key]
                st.rerun()
            if st.session_state[toggle_key]:
                st.code(sas, language="sas")

        c1, c2 = st.columns([5, 1])
        with c1:
            note = st.text_input("Note", value=f.get("waiver_note",""),
                                 placeholder="cSDRG Section 4 justification...",
                                 key=f"note_{fid}_{tab_ctx}", label_visibility="collapsed")
        with c2:
            if st.button("Unwaive" if is_waived else "Waive", key=f"waive_{fid}_{tab_ctx}",
                         use_container_width=True):
                f["waived"] = not is_waived
                f["waiver_note"] = note
                if f["waived"]:
                    st.session_state.waived_notes[fid] = note
                else:
                    st.session_state.waived_notes.pop(fid, None)
                st.rerun()

# __ VALIDATION RUNNER _________________________________________________________
def _compute_yaml_hash() -> str:
    """Compute MD5 of checks.yaml for audit traceability (IMP002)."""
    try:
        yaml_path = os.path.join(os.path.dirname(__file__), "checks.yaml")
        with open(yaml_path, "rb") as fh:
            return hashlib.md5(fh.read()).hexdigest()[:12].upper()
    except Exception:
        return "N/A"

def _load_study_config() -> dict:
    """Load study_config.yaml for protocol-aware parameterization (v8.0 §1)."""
    try:
        cfg_path = os.path.join(os.path.dirname(__file__), "study_config.yaml")
        if os.path.exists(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as fh:
                return yaml.safe_load(fh) or {}
    except Exception:
        pass
    return {}


def run_validation():
    st.session_state.is_running   = True
    st.session_state.findings     = []
    files_meta  = dict(st.session_state.uploaded_files_meta)
    enabled_ids = set(st.session_state.enabled_ids)
    engine      = ValidationEngine(files_meta, enabled_ids)
    prog_ph     = st.empty()
    bar         = prog_ph.progress(0, text="Initializing...")

    def cb(pct, label=""):
        bar.progress(min(pct,100)/100, text=label[:75] if label else "Running...")

    findings = engine.run(cb)

    # Restore waivers using stable fingerprint fids (IMP005 fix)
    for f in findings:
        fid = f.get("fid","")
        if fid and fid in st.session_state.waived_notes:
            f["waived"] = True
            f["waiver_note"] = st.session_state.waived_notes[fid]

    # A10: TD007 promoted to ERROR in FDA safety review mode
    _reg_mode = st.session_state.get('regulatory_mode','internal_qc')
    if _reg_mode == 'fda_safety_review':
        for _f in findings:
            if _f.get('checkId') == 'TD007' and _f.get('sev') == 'WARNING':
                _f['sev'] = 'ERROR'
    st.session_state.findings     = findings
    st.session_state.is_running   = False
    st.session_state.run_count   += 1
    st.session_state.last_run_ts  = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # IMP002 – capture run metadata
    st.session_state.run_id           = str(uuid.uuid4())
    st.session_state.checks_yaml_hash = _compute_yaml_hash()
    st.session_state.run_dataset_list = sorted(files_meta.keys())
    st.session_state.supp_merge_log   = getattr(engine, "supp_merge_log", [])
    st.session_state.study_config     = _load_study_config()
    _mode = st.session_state.study_config.get("study_metadata",{}).get("regulatory_mode","internal_qc")
    st.session_state.regulatory_mode  = _mode

    prog_ph.empty()

# __ SIDEBAR ___________________________________________________________________
with st.sidebar:
    st.markdown("""
    <div style="text-align:center;padding:.4rem 0 .8rem;border-bottom:1px solid #1a1d2e;margin-bottom:.6rem">
      <div class="sidebar-title">CIS v15.0</div>
      <div class="sidebar-sub">SDTM Beyond-P21</div>
    </div>""", unsafe_allow_html=True)

    # ── Theme toggle ─────────────────────────────────────────────────
    _is_light = st.session_state.get("theme","dark") == "light"
    _theme_label = "☀ Light Theme" if not _is_light else "🌙 Dark Theme"
    if st.button(_theme_label, key="theme_btn", use_container_width=True):
        st.session_state["theme"] = "light" if not _is_light else "dark"
        st.rerun()

    # -- File Upload --
    st.markdown('<div style="font-size:.7rem;font-weight:700;color:#8ab0e8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Upload Datasets</div>',
                unsafe_allow_html=True)

    # key includes clear_trigger so the widget fully resets when Clear is pressed
    uploaded = st.file_uploader(
        "files", type=["sas7bdat","xpt"],
        accept_multiple_files=True, label_visibility="collapsed",
        key=f"uploader_{st.session_state.clear_trigger}",
        help="SAS7BDAT (full rows via pyreadstat) and XPT (full rows built-in)")

    if uploaded:
        for uf in uploaded:
            fname = uf.name
            if fname not in st.session_state.uploaded_files_meta:
                ext  = os.path.splitext(fname)[1].lower()
                raw  = uf.read()
                meta = FileParser.analyze(raw, fname, ext)
                st.session_state.uploaded_files_meta[fname] = meta

    n_files = len(st.session_state.uploaded_files_meta)
    if n_files > 0:
        # Show pyreadstat notice if SAS7BDAT with 0 rows
        has_sas_no_rows = any(
            m.get("ext","")==".sas7bdat" and m.get("rows",0)==0
            for m in st.session_state.uploaded_files_meta.values()
        )
        if has_sas_no_rows:
            st.markdown(
                '<div class="install-notice">SAS7BDAT shows 0 rows. '
                'Run: <b>pip install pyreadstat</b> for full data.</div>',
                unsafe_allow_html=True)

        st.markdown(f'<div style="font-size:.7rem;color:#6898ff;font-weight:600;margin:.3rem 0">'
                    f'{n_files} file(s) loaded</div>', unsafe_allow_html=True)
        # A3: memory/performance warning for large studies
        _total_rows = sum(m.get('rows',0) for m in st.session_state.uploaded_files_meta.values())
        if _total_rows > 500_000:
            st.markdown(
                f'<div style="background:rgba(255,160,60,.08);border:1px solid rgba(255,160,60,.3);'
                f'border-left:3px solid #ffa03c;border-radius:4px;padding:.4rem .7rem;'
                f'font-size:.66rem;color:#c09060;margin:.3rem 0">'
                f'⚠ {_total_rows:,} total rows. Large studies may cause slow runs or OOM errors. '
                f'Consider pre-filtering LB/AE/CM by subject/visit before upload.</div>',
                unsafe_allow_html=True)
        for fname, m in st.session_state.uploaded_files_meta.items():
            err   = m.get("parse_error","")
            ok    = '<span style="color:#58c890">OK</span>' if not err else '<span style="color:#ff7070">ERR</span>'
            short = fname[:24] + "..." if len(fname) > 24 else fname
            r, c  = m.get("rows",0), m.get("cols",0)
            st.markdown(f'<div style="font-size:.66rem;color:#7888b0;padding:2px 0">'
                        f'{ok} <span style="color:#a8b4cc">{short}</span> '
                        f'<span style="color:#505878">({r}r,{c}c)</span></div>',
                        unsafe_allow_html=True)

        st.markdown("<div style='height:3px'></div>", unsafe_allow_html=True)
        # FIX: Use a unique key based on trigger counter to force rerun
        if st.button("Clear All Files", key="clear_btn",
                     use_container_width=True):
            # Increment clear_trigger FIRST   this changes the file_uploader key,
            # which forces Streamlit to create a fresh empty uploader widget.
            st.session_state.clear_trigger += 1
            st.session_state.uploaded_files_meta = {}
            st.session_state.findings      = []
            st.session_state.waived_notes  = {}
            st.rerun()
    else:
        st.markdown('<div class="info-box">No files loaded. Runs with 59 demo findings.</div>',
                    unsafe_allow_html=True)

    st.divider()

    # -- Check Config --
    _live = get_checks()
    n_en  = len(st.session_state.enabled_ids)
    st.markdown('<div style="font-size:.7rem;font-weight:700;color:#8ab0e8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Check Configuration</div>',
                unsafe_allow_html=True)
    st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">'
                f'<span style="color:#8ab0e8;font-weight:700">{n_en}</span> / {len(_live)} active'
                f' <span style="font-size:.6rem;color:#404868">(checks.yaml auto-reloads)</span></div>',
                unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Enable All", key="ena", use_container_width=True):
            st.session_state.enabled_ids = set(c["id"] for c in _live); st.rerun()
    with c2:
        if st.button("Disable All", key="dis", use_container_width=True):
            st.session_state.enabled_ids = set(); st.rerun()

    sel_layer = st.selectbox("Layer", ["All"] + sorted(LAYERS), key="lay")
    sel_cat   = st.selectbox("Category", ["All"] + sorted(CATEGORIES), key="cat")
    srch_chk  = st.text_input("Search", placeholder="Check ID or keyword...", key="csr")

    filtered = [c for c in _live
                if (sel_layer=="All" or c["layer"]==sel_layer)
                and (sel_cat=="All" or c["cat"]==sel_cat)
                and (not srch_chk or srch_chk.lower() in c["label"].lower()
                     or srch_chk.lower() in c["id"].lower())]

    with st.expander(f"Toggle Checks  ({len(filtered)} shown)", expanded=False):
        for c in filtered:
            is_on   = c["id"] in st.session_state.enabled_ids
            new_val = st.checkbox(
                f"**{c['id']}**  {c['label'][:44]}{'...' if len(c['label'])>44 else ''}",
                value=is_on, key=f"chk_{c['id']}",
                help=f"Layer:{c['layer']} | Sev:{c['sev']} | Domain:{c['domain']}")
            if new_val != is_on:
                if new_val: st.session_state.enabled_ids.add(c["id"])
                else:       st.session_state.enabled_ids.discard(c["id"])

    st.divider()

    # -- Run + Download --
    if st.session_state.last_run_ts:
        st.markdown(f'<div style="font-size:.66rem;color:#505878;margin-bottom:.3rem">'
                    f'Last run: <span style="color:#7880a8">{st.session_state.last_run_ts}</span>'
                    f' (#{st.session_state.run_count})</div>', unsafe_allow_html=True)

    # ── Regulatory Mode (v8.1 §7) ────────────────────────────────────────────
    st.divider()
    st.markdown(
        '<div style="font-size:.7rem;font-weight:700;color:#8ab0e8;text-transform:uppercase;'
        'letter-spacing:.08em;margin-bottom:.3rem">Review Mode</div>',
        unsafe_allow_html=True)
    _mode_opts = {
        "internal_qc":      "🔬 Internal QC",
        "fda_safety_review":"🇺🇸 FDA Safety Review",
        "pmda_compliance":  "🇯🇵 PMDA Compliance",
    }
    _sel_mode = st.selectbox(
        "mode", list(_mode_opts.values()),
        index=list(_mode_opts.keys()).index(
            st.session_state.get("regulatory_mode","internal_qc")),
        key="reg_mode_sel", label_visibility="collapsed")
    # Store back as key
    for k, v in _mode_opts.items():
        if v == _sel_mode:
            st.session_state.regulatory_mode = k
            break

    # A1: Demo Mode Toggle
    import os as _os_app
    _demo_env_set = _os_app.environ.get('DEMO_MODE','')
    _demo_opts = {'auto':'Auto (demo when no data)','disabled':'Disabled (production)','always':'Always (dev only)'}
    _cur_demo = st.session_state.get('demo_mode_ui','auto')
    _sel_demo = st.selectbox('Demo Mode', list(_demo_opts.values()),
        index=list(_demo_opts.keys()).index(_cur_demo) if _cur_demo in _demo_opts else 0,
        key='demo_mode_sel',
        help='Disabled=never show synthetic findings (CDM production). Auto=show only when no files loaded. Always=show alongside real data (dev only).',
        disabled=bool(_demo_env_set))
    for _dk, _dv in _demo_opts.items():
        if _dv == _sel_demo:
            st.session_state['demo_mode_ui'] = _dk
            if not _demo_env_set:
                _os_app.environ['DEMO_MODE'] = _dk
            break
    if _demo_env_set:
        st.markdown(f'<div style="font-size:.6rem;color:#404868">DEMO_MODE env={_demo_env_set!r}</div>', unsafe_allow_html=True)

    st.divider()
    if st.button("Run Validation", type="primary", use_container_width=True,
                 disabled=st.session_state.is_running, key="run_btn"):
        run_validation(); st.rerun()

    if st.session_state.findings:
        st.divider()
        _run_meta = {
            "run_id":           st.session_state.run_id,
            "checks_yaml_hash": st.session_state.checks_yaml_hash,
            "cis_version":      st.session_state.cis_version,
            "run_dataset_list": st.session_state.run_dataset_list,
        }
        rh = make_html_report(findings=st.session_state.findings,
                              files_meta=st.session_state.uploaded_files_meta,
                              enabled_ids=st.session_state.enabled_ids,
                              run_meta=_run_meta)
        st.download_button("Download HTML Report", data=rh.encode("utf-8"),
            file_name=f"cis_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
            mime="text/html", use_container_width=True, key="dl_html")
        try:
            xl = make_excel_report(findings=st.session_state.findings,
                                   files_meta=st.session_state.uploaded_files_meta,
                                   enabled_ids=st.session_state.enabled_ids,
                                   run_meta=_run_meta)
            st.download_button("Download Excel Report", data=xl,
                file_name=f"cis_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True, key="dl_xl")
        except Exception as _xe:
            st.caption(f"Excel unavailable: {_xe}")

# __ MAIN HEADER _______________________________________________________________
_run_meta_html = ""
if st.session_state.run_id:
    _ds_count = len(st.session_state.run_dataset_list)
    _run_meta_html = (
        f'<div style="font-size:.62rem;color:#4a5475;margin-top:.35rem;font-family:JetBrains Mono,monospace;'
        f'border-top:1px solid #131624;padding-top:.3rem;display:flex;gap:1.2rem;flex-wrap:wrap">'
        f'<span>RUN&nbsp;<span style="color:#6878a8">{st.session_state.run_id[:8].upper()}</span></span>'
        f'<span>CIS&nbsp;<span style="color:#6878a8">v{st.session_state.cis_version}</span></span>'
        f'<span>YAML&nbsp;<span style="color:#6878a8">{st.session_state.checks_yaml_hash}</span></span>'
        f'<span>DATASETS&nbsp;<span style="color:#6878a8">{_ds_count}</span></span>'
        f'<span>TS&nbsp;<span style="color:#6878a8">{st.session_state.last_run_ts}</span></span>'
        f'</div>'
    )

_mode_display = {
    "internal_qc":       "Internal QC",
    "fda_safety_review": "FDA Safety Review",
    "pmda_compliance":   "PMDA Compliance",
}.get(st.session_state.get("regulatory_mode","internal_qc"), "Internal QC")

st.markdown(
    f'<div class="header-glow">'
    f'<div class="suite-title">Clinical Integrity Suite</div>'
    f'<div class="suite-sub">SDTM Beyond-P21 &nbsp;|&nbsp; v15.0 &nbsp;|&nbsp; '
    f'{len(_live)} Checks &nbsp;|&nbsp; 35+ Domains &nbsp;|&nbsp; FDA JumpStart &nbsp;|&nbsp; '
    f'Mode: <span style="color:#90c8ff">{_mode_display}</span></div>'
    f'{_run_meta_html}'
    f'</div>', unsafe_allow_html=True)

# __ SCORECARD ROW _____________________________________________________________
findings_all = st.session_state.findings
active       = _active()
by_risk      = _count_by(active,"risk")
waived_n     = len([f for f in findings_all if f.get("waived")])
dep_n        = len(_dep_warns())

m1,m2,m3,m4,m5,m6 = st.columns(6)
m1.metric("Active",    len(active))
m2.metric("Blockers",  by_risk.get("submission-blocker",0))
m3.metric("Medical",   by_risk.get("medical-concern",0))
m4.metric("Structural",by_risk.get("structural",0))
m5.metric("Waived",    waived_n)
m6.metric("Advisory",  by_risk.get("advisory",0))

st.divider()

# __ MAIN TABS _________________________________________________________________
t_summ, t_domain, t_issue, t_subj, t_reg, t_files, t_aggrid, t_narrative = st.tabs([
    "Summary Dashboard",
    "By Domain",
    "By Issue Type",
    "By Subject",
    "Check Registry",
    "Files",
    "📊 Findings Table",
    "📋 Subject Narrative",
])

# ____________________________________________________________________
# TAB 1: SUMMARY DASHBOARD
# ____________________________________________________________________
with t_summ:
    if not active:
        st.markdown("""
        <div style="text-align:center;padding:4rem 2rem">
          <div style="font-size:2.5rem;opacity:.1;font-family:Orbitron,monospace">CIS</div>
          <div style="font-family:Orbitron,monospace;font-size:1rem;color:#404868;margin:.5rem 0">
            SDTM Clinical Integrity Suite v8.0</div>
          <div style="color:#363858;font-size:.76rem;line-height:1.8">
            Upload SDTM datasets in the sidebar and click <b style="color:#506090">Run Validation</b>.<br>
            Accepts SAS7BDAT (XPT native row reader), CSV, XLSX, JSON.<br>
            Or click Run Validation now to see demo findings.
          </div>
        </div>""", unsafe_allow_html=True)
    else:
        by_sev   = _count_by(active,"sev")
        by_dom   = _count_by(active, "domain")
        by_cat   = _count_by(active,"cat")
        by_layer = _count_by(active,"layer")

        # ---- Run Info Panel (IMP002) ----
        if st.session_state.run_id:
            _actual_n = sum(1 for f in active if f.get("actual"))
            _demo_n   = sum(1 for f in active if not f.get("actual"))
            _ds_n     = len(st.session_state.run_dataset_list)
            _waived_n = len([f for f in findings_all if f.get("waived")])
            st.markdown(
                f'<div style="background:#090a14;border:1px solid #1a1e30;border-left:3px solid #3050a0;'
                f'border-radius:4px;padding:.5rem .9rem;font-size:.68rem;color:#4a5070;'
                f'display:flex;flex-wrap:wrap;gap:1.4rem;margin-bottom:.6rem">'
                f'<span>RUN&nbsp;<b style="color:#6878a8">{st.session_state.run_id[:8].upper()}</b></span>'
                f'<span>YAML&nbsp;<b style="color:#6878a8">{st.session_state.checks_yaml_hash}</b></span>'
                f'<span>DATASETS&nbsp;<b style="color:#6878a8">{_ds_n}</b></span>'
                f'<span>ACTUAL&nbsp;<b style="color:#58c890">{_actual_n}</b></span>'
                f'<span>DEMO&nbsp;<b style="color:#6898ff">{_demo_n}</b></span>'
                f'<span>WAIVED&nbsp;<b style="color:#c0c890">{_waived_n}</b></span>'
                f'<span>TS&nbsp;<b style="color:#6878a8">{st.session_state.last_run_ts}</b></span>'
                f'</div>', unsafe_allow_html=True)

        from ui import render_dashboard_charts
        render_dashboard_charts(
            active=active,
            by_risk=by_risk,
            by_sev=by_sev,
            by_cat=by_cat,
            by_layer=by_layer,
            domain_of_fn=_domain_of,
        )

        # ---- Dep warnings summary (compact) ----
        if dep_n > 0:
            st.divider()
            st.markdown(
                f'<div class="info-box">'
                f'<b style="color:#6898ff">{dep_n} dependency notices</b> _ checks skipped '
                f'because required domains are not loaded. '
                f'Upload the missing domain files to enable them.</div>',
                unsafe_allow_html=True)
            with st.expander(f"Show {dep_n} dependency notices", expanded=False):
                for w in _dep_warns():
                    st.markdown(
                        f'<div class="dep-notice"><b style="color:#78a8ff">{w["checkId"]}</b> '
                        f'{w["detail"]}</div>', unsafe_allow_html=True)

# ____________________________________________________________________
# TAB 2: BY DOMAIN
# ____________________________________________________________________
with t_domain:
    if not active:
        st.info("Run validation to see domain findings.")
    else:
        # Risk filter
        rf = st.selectbox("Filter by Risk", ["All","submission-blocker","medical-concern","structural","advisory"],
                          format_func=lambda x: "All Findings" if x=="All" else RISK_LABELS.get(x,x),
                          key="dom_risk")
        hide_w = st.checkbox("Hide waived", key="dom_hw")

        filtered_active = [f for f in findings_all
                           if not f.get("dep_warning")
                           and not (hide_w and f.get("waived"))
                           and (rf=="All" or f.get("risk")==rf)]

        # Group by domain group
        for group_name, dom_list in DOMAIN_GROUPS.items():
            group_findings = [f for f in filtered_active if _domain_of(f) in dom_list]
            if not group_findings:
                continue
            n = len(group_findings)
            worst = _worst_risk([f["risk"] for f in group_findings])
            wc    = RISK_COLORS.get(worst,"#6898ff")
            with st.expander(f"{group_name}  [{n} finding{'s' if n!=1 else ''}]", expanded=False):
                # Sub-group by individual domain
                sub_doms = {}
                for f in group_findings:
                    sub_doms.setdefault(_domain_of(f),[]).append(f)
                for dom, dfinds in sorted(sub_doms.items()):
                    st.markdown(
                        f'<div class="domain-group-hdr">'
                        f'{dom} <span class="domain-count-pill">{len(dfinds)}</span></div>',
                        unsafe_allow_html=True)
                    for f in dfinds:
                        _render_card(f)

        # Any domain not in DOMAIN_GROUPS
        all_grouped_doms = {d for dl in DOMAIN_GROUPS.values() for d in dl}
        ungrouped = [f for f in filtered_active if _domain_of(f) not in all_grouped_doms]
        if ungrouped:
            with st.expander(f"Other Domains  [{len(ungrouped)} findings]", expanded=False):
                for f in ungrouped:
                    _render_card(f)

# ____________________________________________________________________
# TAB 3: BY ISSUE TYPE
# ____________________________________________________________________
with t_issue:
    if not active:
        st.info("Run validation to see findings by issue type.")
    else:
        hide_w2 = st.checkbox("Hide waived", key="iss_hw")
        filtered2 = [f for f in findings_all
                     if not f.get("dep_warning")
                     and not (hide_w2 and f.get("waived"))]

        # Show Medical + Blockers first (highest priority)
        critical_f = [f for f in filtered2 if f.get("risk") in ("submission-blocker","medical-concern")]
        if critical_f:
            # Root-cause clusters
            root_groups = {}
            standalone  = []
            for f in critical_f:
                if f.get("root"):
                    root_groups.setdefault(f["root"],[]).append(f)
                else:
                    standalone.append(f)

            st.markdown('<div class="section-lbl">Submission Blockers and Medical Concerns</div>',
                        unsafe_allow_html=True)

            if root_groups:
                st.markdown('<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">Root-Cause Clusters</div>',
                            unsafe_allow_html=True)
                for root, rf_list in root_groups.items():
                    worst = _worst_risk([f["risk"] for f in rf_list])
                    with st.expander(f"Root: {root}  [{len(rf_list)} findings]  {RISK_LABELS.get(worst,worst)}", expanded=False):
                        if len(rf_list) <= CARD_LIMIT:
                            for fi in rf_list: _render_card(fi, tab_ctx=f"iss_root")
                        else:
                            st.dataframe(_findings_df(rf_list), use_container_width=True, hide_index=True, height=400)

            if standalone:
                st.markdown('<div style="font-size:.7rem;color:#7880a8;margin:.4rem 0">Individual Findings</div>',
                            unsafe_allow_html=True)
                if len(standalone) <= CARD_LIMIT:
                    for fi in standalone: _render_card(fi, tab_ctx='iss_crit')
                else:
                    st.info(f"{len(standalone)} findings   table view (> {CARD_LIMIT} cards would freeze the browser)")
                    st.dataframe(_findings_df(standalone), use_container_width=True, hide_index=True, height=400)

        struct_f = [f for f in filtered2 if f.get("risk")=="structural"]
        if struct_f:
            st.divider()
            st.markdown('<div class="section-lbl">Structural Errors</div>', unsafe_allow_html=True)
            # Group by category
            cats = {}
            for f in struct_f:
                cats.setdefault(f.get("cat","Other"),[]).append(f)
            for cat, cf in sorted(cats.items(), key=lambda x:-len(x[1])):
                with st.expander(f"{cat}  [{len(cf)}]", expanded=False):
                    if len(cf) <= CARD_LIMIT:
                        for fi in cf: _render_card(fi, tab_ctx=f"iss_struct")
                    else:
                        st.dataframe(_findings_df(cf), use_container_width=True, hide_index=True, height=400)

        adv_f = [f for f in filtered2 if f.get("risk")=="advisory"]
        if adv_f:
            st.divider()
            st.markdown('<div class="section-lbl">Advisory Notices</div>', unsafe_allow_html=True)
            if len(adv_f) <= CARD_LIMIT:
                for fi in adv_f: _render_card(fi, compact=True, tab_ctx="iss_adv")
            else:
                st.dataframe(_findings_df(adv_f), use_container_width=True, hide_index=True, height=300)

        if not filtered2:
            st.info("No findings match the current filter.")

        # Full table at bottom
        st.divider()
        st.markdown('<div class="section-lbl">Complete Findings Table</div>', unsafe_allow_html=True)
        df_all = _findings_df(filtered2)
        st.dataframe(df_all, use_container_width=True, hide_index=True, height=360)

# ____________________________________________________________________
# TAB 4: BY SUBJECT
# ____________________________________________________________________
with t_subj:
    if not active:
        st.info("Run validation to see subject data.")
    else:
        srch_s = st.text_input("Filter by Subject ID", placeholder="e.g. 001-007",
                               key="subj_s")
        sm = {}
        for f in [x for x in findings_all if not x.get("dep_warning") and not x.get("waived")]:
            k = "GLOBAL" if f["subj"]=="ALL" else f["subj"]
            sm.setdefault(k,[]).append(f)

        # Summary table
        rows = []
        for subj, sf in sorted(sm.items(),
                key=lambda x:(0 if _worst_risk([f["risk"] for f in x[1]])=="medical-concern" else 1, x[0])):
            if srch_s and srch_s.lower() not in subj.lower():
                continue
            doms = list(dict.fromkeys(_domain_of(f) for f in sf))
            rows.append({"Subject":subj,"Findings":len(sf),
                         "Worst Risk":RISK_LABELS.get(_worst_risk([f["risk"] for f in sf]),""),
                         "Domains":", ".join(doms[:6]),
                         "Categories":", ".join(list(dict.fromkeys(f["cat"] for f in sf))[:4])})

        if rows:
            st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.4rem">'
                        f'<span style="color:#8ab0e8;font-weight:700">{len(rows)}</span>'
                        f' subjects with active findings</div>', unsafe_allow_html=True)
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True, height=400)

        # Expandable detail for searched subject
        if srch_s:
            matches = [f for f in active if srch_s.lower() in (f["subj"] or "").lower()]
            if matches:
                st.divider()
                st.markdown(f'<div class="section-lbl">Detail: "{srch_s}"</div>', unsafe_allow_html=True)
                for fi in matches: _render_card(fi, tab_ctx="subj_detail")

# ____________________________________________________________________
# TAB 5: CHECK REGISTRY
# ____________________________________________________________________
with t_reg:
    st.markdown('<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;color:#a0b8e0;margin-bottom:.5rem">Full Check Registry</div>', unsafe_allow_html=True)
    rc1, rc2, rc3 = st.columns([2,1,1])
    with rc1: srch_r = st.text_input("Search", placeholder="ID or keyword...", key="reg_s")
    with rc2: lr = st.selectbox("Layer", ["All"]+sorted(LAYERS), key="reg_l")
    with rc3: cr = st.selectbox("Category", ["All"]+sorted(CATEGORIES), key="reg_c")

    reg_ch = [c for c in _live
              if (not srch_r or srch_r.lower() in c["label"].lower() or srch_r.lower() in c["id"].lower())
              and (lr=="All" or c["layer"]==lr)
              and (cr=="All" or c["cat"]==cr)]

    df_reg = pd.DataFrame([{
        "ID":c["id"],"Layer":c["layer"],"Category":c["cat"],"Domain":c["domain"],
        "Severity":c["sev"],"Risk":RISK_LABELS.get(c["risk"],c["risk"]),
        "Description":c["label"],"Source":c["source"],
        "Enabled":"ON" if c["id"] in st.session_state.enabled_ids else "OFF",
    } for c in reg_ch])

    st.markdown(f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.3rem">'
                f'<span style="color:#8ab0e8;font-weight:700">{len(df_reg)}</span>'
                f' of {len(_live)} checks shown</div>', unsafe_allow_html=True)
    st.dataframe(df_reg, use_container_width=True, hide_index=True, height=500)

# ____________________________________________________________________
# TAB 6: FILES
# ____________________________________________________________________
with t_files:
    st.markdown('<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;color:#a0b8e0;margin-bottom:.5rem">Loaded Files</div>', unsafe_allow_html=True)

    fm = st.session_state.uploaded_files_meta
    if not fm:
        st.markdown('<div class="info-box">No files loaded. Upload via the sidebar.</div>', unsafe_allow_html=True)
    else:
        file_rows = []
        for fname, m in fm.items():
            note = m.get("parse_note","")
            err  = m.get("parse_error","")
            status = ("WARN: " + note[:40]) if note else ("ERR: " + err[:40]) if err else "OK"
            file_rows.append({
                "Filename":fname,"Type":m.get("type",""),"Rows":m.get("rows",0),
                "Cols":m.get("cols",0),"Size":f"{m.get('size',0):,} B",
                "Variables":", ".join((m.get("variables") or [])[:5]),
                "Status":status,
            })
        st.dataframe(pd.DataFrame(file_rows), use_container_width=True, hide_index=True)

        # If any SAS7BDAT with 0 rows, show install hint prominently
        sas_no_rows = [(fn, m) for fn, m in fm.items()
                       if m.get("ext","")==".sas7bdat" and m.get("rows",0)==0]
        if sas_no_rows:
            st.markdown("""
            <div class="install-notice" style="margin-top:.6rem;font-size:.75rem;padding:.7rem 1rem">
              <b>SAS7BDAT files loaded as header-only (0 rows)</b><br>
              To read full row data, install pyreadstat in your conda environment:<br>
              <code style="background:rgba(255,176,96,.1);border:1px solid rgba(255,176,96,.3);
              padding:2px 8px;border-radius:2px;color:#e0b070">
              pip install pyreadstat</code><br>
              Then re-upload the files. XPT files are read with full rows using the built-in parser.
            </div>""", unsafe_allow_html=True)

        # SUPP merge summary
        supp_log = st.session_state.supp_merge_log
        if supp_log:
            st.divider()
            st.markdown('<div class="section-lbl">SUPP Back-Merge Log</div>', unsafe_allow_html=True)
            supp_issues = [e for e in supp_log if e.get("check")]
            supp_info   = [e for e in supp_log if not e.get("check")]
            if supp_issues:
                st.markdown(
                    f'<div class="info-box" style="border-left-color:#ffb060">'
                    f'<b style="color:#ffb060">{len(supp_issues)} SUPP structural issue(s) detected</b> '
                    f'(S016/S017/S018) — see Issues tab for details.</div>',
                    unsafe_allow_html=True)
            for entry in supp_log:
                color = "#ffb060" if entry.get("check") else "#58c890"
                st.markdown(
                    f'<div class="dep-notice" style="border-left-color:{color}">'
                    f'<b style="color:#90b8ff">SUPP{entry.get("domain","")}</b> '
                    f'{entry.get("issue","")}</div>',
                    unsafe_allow_html=True)
        elif st.session_state.run_id:
            st.markdown(
                '<div class="info-box">No SUPP datasets loaded — back-merge not applicable.</div>',
                unsafe_allow_html=True)

        # Variable preview
        st.divider()
        st.markdown('<div class="section-lbl">Variable Preview</div>', unsafe_allow_html=True)
        sel_f = st.selectbox("Select file", list(fm.keys()), key="fp_sel")
        if sel_f:
            m  = fm[sel_f]
            dt = m.get("data",[])
            if dt:
                st.dataframe(pd.DataFrame(dt[:50]), use_container_width=True,
                             hide_index=True, height=280)
            else:
                st.markdown('<div class="info-box">No row data. SAS7BDAT: install pyreadstat. XPT: already has native row reader.</div>', unsafe_allow_html=True)

# ____________________________________________________________________
# TAB 7: INTERACTIVE FINDINGS REVIEW  (native — AgGrid removed)
# ____________________________________________________________________
with t_aggrid:
    st.markdown(
        '<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;'
        'color:#a0b8e0;margin-bottom:.5rem">&#128202; Interactive Findings Review</div>',
        unsafe_allow_html=True)

    if not active:
        st.info("Run validation first to populate the findings table.")
    else:
        ag_rows = []
        for f in [x for x in findings_all if not x.get("dep_warning")]:
            ag_rows.append({
                "ID":          f.get("fid",""),
                "Severity":    f.get("sev",""),
                "Risk":        RISK_LABELS.get(f.get("risk",""), f.get("risk","")),
                "Subject":     "GLOBAL" if f.get("subj","")=="ALL" else f.get("subj",""),
                "Domain":      _domain_of(f),
                "Layer":       f.get("layer",""),
                "Category":    f.get("cat",""),
                "Check":       f.get("label",""),
                "Detail":      f.get("detail",""),
                "Source":      f.get("source",""),
                "Data":        "ACTUAL" if f.get("actual") else "DEMO",
                "Waived":      "YES" if f.get("waived") else "",
                "Waiver Note": f.get("waiver_note",""),
                "SAS Code":    f.get("sas_code",""),
            })
        ag_df = pd.DataFrame(ag_rows) if ag_rows else pd.DataFrame(
            columns=["ID","Severity","Risk","Subject","Domain","Layer",
                     "Category","Check","Detail","Source","Data","Waived","Waiver Note","SAS Code"])

        ctrl1, ctrl2, ctrl3, ctrl4 = st.columns([2, 2, 2, 1])
        with ctrl1:
            risk_opts = ["All"] + list(RISK_LABELS.values())
            sel_risk = st.selectbox("Filter by Risk", risk_opts, key="ift_risk",
                                    label_visibility="collapsed")
        with ctrl2:
            sev_opts = ["All", "REJECT", "CRITICAL", "ERROR", "WARNING", "INFO"]
            sel_sev  = st.selectbox("Filter by Severity", sev_opts, key="ift_sev",
                                    label_visibility="collapsed")
        with ctrl3:
            dom_txt = st.text_input("Domain filter (comma-sep)", placeholder="AE, LB, DM…",
                                    key="ift_dom", label_visibility="collapsed")
        with ctrl4:
            hw = st.checkbox("Hide waived", value=True, key="ift_hw")

        disp = ag_df.copy()
        if sel_risk != "All":
            disp = disp[disp["Risk"] == sel_risk]
        if sel_sev != "All":
            disp = disp[disp["Severity"] == sel_sev]
        if dom_txt:
            doms = [d.strip().upper() for d in dom_txt.split(",") if d.strip()]
            disp = disp[disp["Domain"].isin(doms)]
        if hw:
            disp = disp[disp["Waived"] != "YES"]

        st.markdown(
            f'<div style="font-size:.7rem;color:#7880a8;margin-bottom:.3rem">' +
            f'<span style="color:#8ab0e8;font-weight:700">{len(disp)}</span>' +
            f' findings shown of {len(ag_df)} total</div>', unsafe_allow_html=True)

        st.dataframe(
            disp.drop(columns=["SAS Code"], errors="ignore"),
            use_container_width=True,
            hide_index=True,
            height=480,
            column_config={
                "ID":          st.column_config.TextColumn("ID",       width=90),
                "Severity":    st.column_config.TextColumn("Severity", width=90),
                "Risk":        st.column_config.TextColumn("Risk",     width=180),
                "Subject":     st.column_config.TextColumn("Subject",  width=130),
                "Domain":      st.column_config.TextColumn("Domain",   width=70),
                "Layer":       st.column_config.TextColumn("Layer",    width=130),
                "Category":    st.column_config.TextColumn("Category", width=150),
                "Check":       st.column_config.TextColumn("Check",    width=280),
                "Detail":      st.column_config.TextColumn("Detail",   width=380),
                "Source":      st.column_config.TextColumn("Source",   width=110),
                "Data":        st.column_config.TextColumn("Data",     width=65),
                "Waived":      st.column_config.TextColumn("Waived",   width=60),
                "Waiver Note": st.column_config.TextColumn("Waiver Note", width=200),
            }
        )

        st.divider()
        st.markdown('<div class="section-lbl">SAS Code Browser</div>', unsafe_allow_html=True)
        if not disp.empty:
            sel_id = st.selectbox("Select Finding ID to view SAS code",
                                  disp["ID"].tolist(), key="ift_sel_id")
            match  = next((f for f in findings_all if f.get("fid") == sel_id), None)
            if match and match.get("sas_code"):
                st.code(match["sas_code"], language="sas")

        csv_bytes = disp.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download Filtered CSV",
            data=csv_bytes,
            file_name=f"cis_findings_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            key="ift_csv_dl",
        )
# ____________________________________________________________________
# TAB 8: SUBJECT NARRATIVE + GANTT TIMELINE  (v8.0 §3 / v8.1 §5)
# ____________________________________________________________________
with t_narrative:
    _is_light_narr = st.session_state.get("theme","dark") == "light"
    _txt_col  = "#1a1e2e" if _is_light_narr else "#c0c8e0"
    _bg_col   = "#ffffff" if _is_light_narr else "#0b0c15"
    _border   = "#d0d4e8" if _is_light_narr else "#1a1d2e"
    _sub_col  = "#4050a0" if _is_light_narr else "#7880a8"

    st.markdown(
        '<div style="font-family:Orbitron,monospace;font-size:.9rem;font-weight:700;'
        'color:#a0b8e0;margin-bottom:.5rem">📋 Subject Narrative & Timeline</div>',
        unsafe_allow_html=True)

    if not active:
        st.info("Run validation first to generate narratives.")
    else:
        all_subjs = sorted({
            f["subj"] for f in findings_all
            if f.get("subj") and f["subj"] not in ("ALL","N/A","?","GLOBAL")
            and not f.get("dep_warning")
        })

        if not all_subjs:
            st.info("No subject-level findings available.")
        else:
            nc1, nc2, nc3 = st.columns([2, 1, 1])
            with nc1:
                srch_n = st.text_input("🔍 Filter subject", placeholder="Search USUBJID...",
                                       key="narr_srch", label_visibility="collapsed")
                filtered_subjs = [s for s in all_subjs if not srch_n or srch_n.lower() in s.lower()]
                sel_subj = st.selectbox("Subject", filtered_subjs,
                                        key="narr_subj", label_visibility="collapsed") if filtered_subjs else None
            with nc2:
                show_gantt   = st.checkbox("Gantt Timeline",  value=True,  key="narr_gantt")
            with nc3:
                show_waived  = st.checkbox("Show waived",     value=False, key="narr_waived")

            if sel_subj:
                subj_finds = [f for f in findings_all
                              if f.get("subj") == sel_subj and not f.get("dep_warning")
                              and (show_waived or not f.get("waived"))]
                n_active  = sum(1 for f in subj_finds if not f.get("waived"))
                n_waived  = sum(1 for f in subj_finds if f.get("waived"))
                worst_r   = _worst_risk([f["risk"] for f in subj_finds if not f.get("waived")])
                worst_col = RISK_COLORS.get(worst_r, "#6898ff")

                # ── Status bar ───────────────────────────────────────────
                st.markdown(
                    f'<div style="display:flex;gap:1.5rem;font-size:.72rem;padding:.4rem 0;'
                    f'border-bottom:1px solid {_border};margin-bottom:.7rem">'
                    f'<span style="color:{_sub_col}">Subject: <b style="color:{_txt_col}">{sel_subj}</b></span>'
                    f'<span style="color:{_sub_col}">Active: <b style="color:{worst_col}">{n_active}</b></span>'
                    f'<span style="color:{_sub_col}">Waived: <b style="color:#c0c890">{n_waived}</b></span>'
                    f'<span style="color:{_sub_col}">Worst: <b style="color:{worst_col}">{RISK_LABELS.get(worst_r,worst_r)}</b></span>'
                    f'</div>', unsafe_allow_html=True)

                # ── Get DM row for this subject ───────────────────────────
                fm_narr = st.session_state.uploaded_files_meta
                dm_row  = {}
                for _fn, _meta in fm_narr.items():
                    _base = _fn.upper().replace(".SAS7BDAT","").replace(".XPT","").split("\\")[-1].split("/")[-1]
                    if _base == "DM" or any(r.get("DOMAIN","").upper()=="DM" for r in (_meta.get("data") or [])[:1]):
                        for _r in (_meta.get("data") or []):
                            if str(_r.get("USUBJID","")).strip() == sel_subj:
                                dm_row = _r; break
                    if dm_row: break

                # ── Protocol anchors from DM ──────────────────────────────
                anchors = [
                    ("RFICDTC", "Informed Consent",  "#58c890", "✅"),
                    ("RFSTDTC", "First Dose",         "#70a8ff", "💊"),
                    ("RFENDTC", "Last Dose",          "#90c8ff", "🏁"),
                    ("RFPENDTC","Last Contact",        "#7880a8", "📞"),
                    ("DTHDTC",  "Death",              "#ff6060", "☠"),
                ]
                anchor_events = []
                for col, lbl, col_hex, icon in anchors:
                    v = dm_row.get(col,"").strip()[:10]
                    if v and len(v) >= 7:
                        anchor_events.append({"date":v,"label":f"{icon} {lbl}","color":col_hex,"type":"anchor","detail":f"{col}={v}"})

                # ── Finding events — with lab/similar collapse ─────────────
                import re as _re
                from collections import defaultdict as _dd

                # 1) Build raw list
                _raw_finds = []
                for f in subj_finds:
                    dm2  = _re.search(r"(\d{4}-\d{2}-\d{2})", f.get("detail",""))
                    edt  = dm2.group(1) if dm2 else ""
                    risk = f.get("risk","structural")
                    fcol = RISK_COLORS.get(risk,"#6898ff")
                    oc   = f.get("outcome_class","")
                    _raw_finds.append({
                        "date":   edt, "label": f.get("cat",""),
                        "color":  fcol, "type": "finding",
                        "risk":   risk, "detail": f"{oc+' — ' if oc else ''}{f.get('label','')[:60]}",
                        "fid":    f.get("fid",""), "waived": f.get("waived",False),
                        "confidence": f.get("confidence",""),
                        "checkId": f.get("checkId",""),
                        "layer":   f.get("layer",""),
                    })

                # 2) Collapse groups: same cat + same date → one collapsed row
                #    Lab-heavy cats that often flood: "Under-reporting","Lab Logic","Lab Units"
                COLLAPSE_CATS = {
                    "Under-reporting", "Lab Logic", "Lab Units", "Temporal",
                    "Questionnaire", "Cross-Domain", "Partial Date",
                }
                _grp: dict = _dd(list)
                _single = []
                for ev in _raw_finds:
                    cat  = ev["label"]
                    date = ev["date"]
                    if cat in COLLAPSE_CATS:
                        _grp[(cat, date or "?")].append(ev)
                    else:
                        _single.append(ev)

                finding_events = list(_single)
                for (cat, date), evs in sorted(_grp.items()):
                    if len(evs) == 1:
                        finding_events.append(evs[0])
                    else:
                        # Merge into one row — pick worst risk
                        risk_order = ["submission-blocker","medical-concern","structural","advisory"]
                        risks = [e["risk"] for e in evs]
                        worst = next((r for r in risk_order if r in risks), evs[0]["risk"])
                        fcol  = RISK_COLORS.get(worst,"#6898ff")
                        checks_list = list({e["checkId"] for e in evs if e["checkId"]})[:3]
                        checks_str  = "/".join(checks_list) + (f"+{len(checks_list)}" if len(checks_list)>3 else "")
                        n_waived = sum(1 for e in evs if e.get("waived"))
                        finding_events.append({
                            "date": date if date != "?" else "",
                            "label": f"{cat} ×{len(evs)}",
                            "color": fcol, "type": "finding", "risk": worst,
                            "detail": f"{len(evs)} {cat} findings ({checks_str})"
                                      + (f" [{n_waived} waived]" if n_waived else ""),
                            "fid": evs[0]["fid"], "waived": n_waived == len(evs),
                            "confidence": "High",
                            "checkId": checks_list[0] if checks_list else "",
                            "_collapsed": True, "_count": len(evs),
                        })

                all_events = anchor_events + finding_events
                all_events.sort(key=lambda x: (x["date"]=="", x["date"]))

                # ════════════════════════════════════════════════════════════
                # GANTT-STYLE SVG TIMELINE
                # ════════════════════════════════════════════════════════════
                if show_gantt and all_events:
                    st.markdown('<div class="section-lbl">Gantt Timeline</div>', unsafe_allow_html=True)

                    # Date range
                    dated = [e for e in all_events if e["date"]]
                    if dated:
                        from datetime import datetime, timedelta
                        def _pd(d):
                            try: return datetime.strptime(d[:10],"%Y-%m-%d")
                            except: return None
                        dts = [_pd(e["date"]) for e in dated if _pd(e["date"])]
                        if dts:
                            d_min = min(dts) - timedelta(days=10)
                            d_max = max(dts) + timedelta(days=10)
                            span  = max((d_max - d_min).days, 1)

                            SVG_W    = 860
                            LBL_W    = 140
                            BAR_W    = SVG_W - LBL_W - 20
                            ROW_H    = 28
                            HDR_H    = 36
                            n_rows   = len(all_events)
                            SVG_H    = HDR_H + n_rows * ROW_H + 16

                            bg  = "#0c0d16" if not _is_light_narr else "#f8faff"
                            fg  = "#7880a8" if not _is_light_narr else "#6070a8"
                            grid= "#1a1d2e" if not _is_light_narr else "#d0d4e8"
                            txt = "#c0c8e0" if not _is_light_narr else "#1a1e2e"

                            svg = [f'<svg width="{SVG_W}" height="{SVG_H}" xmlns="http://www.w3.org/2000/svg" '
                                   f'style="display:block;background:{bg};border-radius:6px;border:1px solid {grid}">']

                            # Month grid lines + labels
                            cur = d_min.replace(day=1)
                            while cur < d_max:
                                x = LBL_W + int((cur - d_min).days / span * BAR_W)
                                svg.append(f'<line x1="{x}" y1="{HDR_H}" x2="{x}" y2="{SVG_H-8}" stroke="{grid}" stroke-width="1" stroke-dasharray="3,3"/>')
                                svg.append(f'<text x="{x+3}" y="{HDR_H-8}" font-family="Courier New" font-size="9" fill="{fg}">{cur.strftime("%b %Y")}</text>')
                                # Advance one month
                                m = cur.month + 1
                                y = cur.year + (1 if m > 12 else 0)
                                m = m if m <= 12 else 1
                                try:
                                    cur = cur.replace(year=y, month=m, day=1)
                                except:
                                    break

                            # Today line
                            from datetime import date as _date
                            today_dt = datetime.combine(_date.today(), datetime.min.time())
                            if d_min <= today_dt <= d_max:
                                tx = LBL_W + int((today_dt - d_min).days / span * BAR_W)
                                svg.append(f'<line x1="{tx}" y1="{HDR_H}" x2="{tx}" y2="{SVG_H-8}" stroke="#60a860" stroke-width="1.5" stroke-dasharray="4,2"/>')
                                svg.append(f'<text x="{tx+2}" y="{HDR_H+10}" font-family="Courier New" font-size="8" fill="#60a860">Today</text>')

                            # Event rows
                            for i, evt in enumerate(all_events):
                                y0   = HDR_H + i * ROW_H
                                yc   = y0 + ROW_H // 2
                                col  = evt["color"]
                                lbl  = evt["label"][:20]
                                is_a = evt["type"] == "anchor"

                                # Row background (alternating)
                                if i % 2 == 0:
                                    rb = "#0e0f18" if not _is_light_narr else "#f0f2fa"
                                    svg.append(f'<rect x="0" y="{y0}" width="{SVG_W}" height="{ROW_H}" fill="{rb}"/>')

                                # Label
                                fw = "700" if is_a else "400"
                                svg.append(f'<text x="{LBL_W-6}" y="{yc+4}" text-anchor="end" font-family="Courier New" font-size="10" font-weight="{fw}" fill="{col}">{lbl}</text>')

                                # Event dot / bar
                                edt = _pd(evt["date"])
                                if edt:
                                    ex = LBL_W + int((edt - d_min).days / span * BAR_W)
                                    if is_a:
                                        # Diamond for anchors
                                        svg.append(f'<polygon points="{ex},{yc-7} {ex+7},{yc} {ex},{yc+7} {ex-7},{yc}" fill="{col}" opacity=".9"/>')
                                    else:
                                        # Circle for findings
                                        _is_coll = evt.get("_collapsed", False)
                                        r = 9 if _is_coll else 5
                                        opacity = ".35" if evt.get("waived") else ".85"
                                        svg.append(f'<circle cx="{ex}" cy="{yc}" r="{r}" fill="{col}" opacity="{opacity}"/>')
                                        if _is_coll:
                                            _cnt = evt.get("_count", "")
                                            svg.append(f'<text x="{ex}" y="{yc+3}" text-anchor="middle" font-family="Courier New" font-size="7" fill="#ffffff" font-weight="700">{_cnt}</text>')
                                        # Confidence ring
                                        cf = evt.get("confidence","")
                                        if cf == "Low":
                                            svg.append(f'<circle cx="{ex}" cy="{yc}" r="{r+3}" fill="none" stroke="#ff8060" stroke-width="1.5" opacity=".6"/>')
                                    # Tooltip-style label on right
                                    detail = evt.get("detail","")[:80]
                                    svg.append(f'<text x="{ex+10}" y="{yc+4}" font-family="Courier New" font-size="9" fill="{fg}">{detail}</text>')
                                else:
                                    # No date — show at far left
                                    svg.append(f'<text x="{LBL_W+4}" y="{yc+4}" font-family="Courier New" font-size="9" fill="{fg}" opacity=".5">[no date] {evt.get("detail","")[:80]}</text>')

                            # Legend
                            ly = SVG_H - 6
                            svg.append(f'<text x="8" y="{ly}" font-family="Courier New" font-size="8" fill="{fg}">◆ Anchor  ● Finding  ⬤ Collapsed group  ● Waived  ◎ Low confidence</text>')
                            svg.append("</svg>")

                            st.markdown("".join(svg), unsafe_allow_html=True)
                    else:
                        st.info("No dated events available for timeline. Upload DM domain for protocol anchors.")

                # ════════════════════════════════════════════════════════════
                # VERTICAL EVENT SEQUENCE (always shown)
                # ════════════════════════════════════════════════════════════
                st.markdown('<div class="section-lbl" style="margin-top:.8rem">Event Sequence</div>', unsafe_allow_html=True)
                if all_events:
                    seq_html = f'<div style="position:relative;padding-left:28px;margin:.4rem 0">' 
                    seq_html += f'<div style="position:absolute;left:10px;top:0;bottom:0;width:2px;background:{_border}"></div>'
                    for evt in all_events:
                        is_a = evt["type"] == "anchor"
                        dc   = evt["color"]
                        ds   = "12px" if is_a else "9px"
                        cf   = evt.get("confidence","")
                        cf_c = {"High":"#58c890","Medium":"#f0c040","Low":"#ff8060"}.get(cf,_sub_col)
                        conf_span = f'<span style="font-size:.55rem;color:{cf_c};border:1px solid {cf_c}33;padding:0 3px;border-radius:2px;margin-left:4px">{cf}</span>' if cf and not is_a else ""
                        waived_span = '<span style="font-size:.55rem;color:#c0c890;margin-left:4px">[waived]</span>' if evt.get("waived") else ""
                        date_str = f'<b style="color:{_sub_col};font-size:.63rem;margin-right:5px">{evt["date"] or "?"}</b>'
                        bg_card  = (f"background:{_bg_col};border:1px solid {_border}" if not is_a else "")
                        pad_card = "padding:.45rem .7rem;border-radius:4px;" if not is_a else ""
                        bc_left  = f"border-left:3px solid {dc};" if not is_a else ""
                        seq_html += (
                            f'<div style="position:relative;margin-bottom:.45rem;{pad_card}{bg_card}{bc_left}">'
                            f'<div style="position:absolute;left:-22px;top:5px;width:{ds};height:{ds};background:{dc};border-radius:50%;border:2px solid {_bg_col}"></div>'
                            f'<div style="font-size:.72rem;font-weight:{"700" if is_a else "500"};color:{dc}">{date_str}{evt["label"]}{conf_span}{waived_span}</div>'
                            f'<div style="font-size:.66rem;color:{_sub_col};margin-top:2px;line-height:1.5">' +
                        (f'<span style="background:#1a1d2e;border:1px solid #2a2d3e;border-radius:3px;'
                         f'padding:0 5px;font-size:.6rem;color:#8898c8;margin-right:4px">×{evt["_count"]} collapsed</span>'
                         if evt.get("_collapsed") else '') +
                        f'{evt["detail"]}</div>'
                            f'</div>'
                        )
                    seq_html += "</div>"
                    st.markdown(seq_html, unsafe_allow_html=True)
                else:
                    st.info("No events found. Upload DM and AE/LB/DS domains for a full timeline.")

                # ════════════════════════════════════════════════════════════
                # NARRATIVE SUMMARY TEXT
                # ════════════════════════════════════════════════════════════
                st.divider()
                st.markdown('<div class="section-lbl">Narrative Summary</div>', unsafe_allow_html=True)

                consent   = dm_row.get("RFICDTC","unknown")[:10]
                first_d   = dm_row.get("RFSTDTC","unknown")[:10]
                last_d    = dm_row.get("RFENDTC","unknown")[:10]
                arm       = dm_row.get("ARM", dm_row.get("ACTARM","unknown"))
                age       = dm_row.get("AGE","")
                sex       = dm_row.get("SEX","")
                death_dt  = dm_row.get("DTHDTC","")[:10]

                demo_str  = f" ({age}yr {sex})".strip() if age or sex else ""
                parts = [
                    f"**{sel_subj}**{demo_str} provided informed consent on **{consent}** "
                    f"and was randomised to **{arm}**. "
                    f"First dose: **{first_d}**, last dose: **{last_d}**."
                ]
                if death_dt:
                    parts.append(f"Subject death recorded on **{death_dt}**.")

                crit_f = [f for f in subj_finds if f.get("risk") in ("submission-blocker","medical-concern") and not f.get("waived")]
                if crit_f:
                    parts.append(f"\n\n**{len(crit_f)} critical finding(s)** requiring review:")
                    for cf in crit_f[:5]:
                        oc = cf.get("outcome_class","")
                        parts.append(f"- [{oc}] {cf.get('label','')}: _{cf.get('detail','')}_")
                    if len(crit_f) > 5:
                        parts.append(f"- _...and {len(crit_f)-5} more_")

                sig_f = [f for f in subj_finds if f.get("outcome_class")=="Signal" and not f.get("waived")]
                if sig_f:
                    parts.append(f"\n**{len(sig_f)} safety signal(s)** flagged for medical review.")

                parts.append("\n\n_This narrative is auto-generated by CIS v15. Human review required before inclusion in clinical study reports._")
                st.markdown("\n".join(parts))

                # ── All findings table ────────────────────────────────────
                st.divider()
                st.markdown('<div class="section-lbl">All Findings for Subject</div>', unsafe_allow_html=True)
                df_subj_narr = pd.DataFrame([{
                    "ID":     f.get("fid",""),
                    "Sev":    f.get("sev",""),
                    "Risk":   RISK_LABELS.get(f.get("risk",""),f.get("risk","")),
                    "Class":  f.get("outcome_class",""),
                    "Conf":   f.get("confidence",""),
                    "Domain": _domain_of(f),
                    "Check":  f.get("label",""),
                    "Detail": f.get("detail",""),
                    "Waived": "YES" if f.get("waived") else "",
                } for f in subj_finds])
                st.dataframe(df_subj_narr, use_container_width=True, hide_index=True,
                             height=400,
                             column_config={
                                 "Check":  st.column_config.TextColumn("Check",  width="large"),
                                 "Detail": st.column_config.TextColumn("Detail", width="large"),
                             })
