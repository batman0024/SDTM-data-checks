"""
modules/registry.py
SUG-001: YAML-backed hot-reloadable check registry.
v7.0: Added 11 Hidden Integrity + Temporal Integrity checks
      INT001-INT005 and DATE001-DATE006.
"""

import os
import logging
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# SUG-004: Required domains per check
# ---------------------------------------------------------------------------
CHECK_REQUIRES = {
    "DM001":["DM","EX"],  "DM003":["DM"],    "DM004":["DM"],
    "AE001":["AE"],        "AE004":["AE"],    "AE005":["AE","DM"],
    "AE006":["AE"],        "AE008":["AE"],
    "EX001":["EX"],        "EX002":["EX"],
    "LB001":["LB","DM"],   "LB003":["LB"],    "LB004":["LB"],
    "LB007":["LB"],        "LB011":["LB"],
    "VS001":["VS"],
    "CM001":["CM"],        "CM003":["CM"],
    "DS005":["DS","EX"],   "DS006":["DS","AE"],  "DS008":["DS","LB"],
    "AE015":["LB","AE"],   "AE016":["AE","CM"],  "LB009":["LB","EX"],
    "S010": [],
    # New v7 checks
    "INT001":["DM"],                  # needs DM as reference for all domains
    "INT002":["DM"],                  # DM.RFSTDTC + any BLFL-flagged domain
    "INT003":["EX","DS"],             # needs EX or LB/AE plus DS
    "INT004":["DM","LB"],             # DM.SEX cross-checked with LB.LBTESTCD
    "INT005":["DM"],                  # DM.RFICDTC + any observation domain
    "DATE001":[],                     # scans all loaded domains
    "DATE002":["DS"],                 # DS death date + all observation domains
    "DATE003":[],                     # scans all loaded domains, compares to today
    "DATE004":["DM"],                 # DM.BRTHDTC vs RFSTDTC
    "DATE005":["EX","DM"],            # EX.EXSTDTC vs DM.RFICDTC
    "DATE006":["EX","DS"],            # EX.EXENDTC vs DS disposition date
}

DEFAULT_CHECKS = [
    # __ STRUCTURAL __________________________________________________________
    {"id":"S001","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT","label":"Dataset file missing for domain declared in Define-XML","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"S002","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT","label":"XPT variable name exceeds 8 characters","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S003","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"REJECT","label":"Variable label exceeds 40 characters (SAS v5 transport limit)","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S004","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"ERROR","label":"DOMAIN value does not match 2-char dataset name","risk":"structural","source":"SDTMIG"},
    {"id":"S005","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"ERROR","label":"--SEQ not unique within USUBJID","risk":"structural","source":"SDTMIG"},
    {"id":"S006","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"ERROR","label":"Required variable null for one or more records","risk":"submission-blocker","source":"SDTMIG"},
    {"id":"S007","layer":"Structure","cat":"Dataset Integrity","domain":"ALL","sev":"WARNING","label":"Permissible variable entirely null (should be dropped per SDTMIG)","risk":"structural","source":"SDTMIG"},
    {"id":"S008","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR","label":"--TESTCD/--TEST not 1:1 - same TESTCD maps to different TEST values","risk":"structural","source":"PharmaSUG-2018"},
    {"id":"S009","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR","label":"VISITNUM/VISIT not 1:1 across domains","risk":"structural","source":"SDTMIG"},
    {"id":"S010","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR","label":"ISO 8601 date format violation in --DTC variable","risk":"structural","source":"SDTMIG"},
    {"id":"S011","layer":"Structure","cat":"Controlled Terms","domain":"ALL","sev":"ERROR","label":"--DY calculated with Day 0 (No-Day-0 rule violated)","risk":"structural","source":"SDTMIG"},
    {"id":"S012","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"REJECT","label":"Define-XML v2.0/2.1 not present in submission package","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"S013","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"ERROR","label":"Variable in dataset not described in Define-XML ItemDef","risk":"structural","source":"FDA TCG"},
    {"id":"S014","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"ERROR","label":"Origin=CRF variable absent from annotated CRF page list","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"S015","layer":"Structure","cat":"Define-XML","domain":"DEFINE","sev":"WARNING","label":"Origin=Derived with Method column blank in Define-XML","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"S016","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"WARNING","label":"QNAM in SUPP-- uses reserved standard variable name","risk":"structural","source":"SDTMIG"},
    {"id":"S017","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"ERROR","label":"SUPP-- RDOMAIN does not match parent domain code","risk":"structural","source":"SDTMIG"},
    {"id":"S018","layer":"Structure","cat":"SUPPQUAL","domain":"SUPP","sev":"ERROR","label":"SUPP-- IDVAR/IDVARVAL does not resolve to existing parent record","risk":"structural","source":"SDTMIG"},
    # __ TRIAL DESIGN ________________________________________________________
    {"id":"TD001","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR","label":"FDA Desired TS parameter missing (TTYPE, INTMODEL, PCLAS)","risk":"submission-blocker","source":"FDA TCG"},
    {"id":"TD002","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR","label":"TSPARMCD=DOSE contains unit in TSVAL (should use DOSU record)","risk":"structural","source":"PharmaSUG-2020"},
    {"id":"TD003","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"ERROR","label":"TSPARMCD=ACTSUBJ missing or 0 at study end","risk":"structural","source":"FDA TCG"},
    {"id":"TD004","layer":"Trial Design","cat":"TS Domain","domain":"TS","sev":"WARNING","label":"TS study start (SSTDTC) is after first subject RFSTDTC in DM","risk":"structural","source":"PharmaSUG-2016"},
    {"id":"TD005","layer":"Trial Design","cat":"TA/TE/SE","domain":"TA","sev":"ERROR","label":"ARMCD/ARM in DM not found in TA domain","risk":"structural","source":"SDTMIG"},
    {"id":"TD006","layer":"Trial Design","cat":"TA/TE/SE","domain":"SE","sev":"ERROR","label":"SE gap - SESTDTC does not immediately follow preceding SEENDTC","risk":"structural","source":"PharmaSUG-2015"},
    {"id":"TD007","layer":"Trial Design","cat":"Trial Visits","domain":"TV","sev":"ERROR","label":"VISITNUM in observation domain not found in TV domain","risk":"structural","source":"SDTMIG"},
    {"id":"TD008","layer":"Trial Design","cat":"TI/IE","domain":"TI","sev":"ERROR","label":"IE.IETESTCD not derived from TI domain criteria list","risk":"structural","source":"PharmaSUG-2024"},
    # __ DEMOGRAPHICS ________________________________________________________
    {"id":"DM001","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR","label":"ARM != ACTARM - planned vs. actual arm mismatch","risk":"medical-concern","source":"SDTMIG/P21"},
    {"id":"DM002","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR","label":"ARMNRS required when ARMCD = SCRNFAIL","risk":"structural","source":"P21"},
    {"id":"DM003","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR","label":"DTHFL=Y but DTHDTC missing or DTHDTC present without DTHFL=Y","risk":"medical-concern","source":"P21"},
    {"id":"DM004","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"REJECT","label":"Duplicate USUBJID in DM","risk":"submission-blocker","source":"P21"},
    {"id":"DM005","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"ERROR","label":"USUBJID inconsistency across DM, AE, DS, EX (orphan subjects)","risk":"submission-blocker","source":"P21"},
    {"id":"DM006","layer":"P21-Base","cat":"Demographics","domain":"DM","sev":"WARNING","label":"RFICDTC (informed consent date) missing in DM","risk":"medical-concern","source":"P21"},
    {"id":"DM007","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING","label":"AGE < 0 or AGE > 120 - implausible age value","risk":"medical-concern","source":"Physiology"},
    {"id":"DM008","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING","label":"AGE < 18 years in adult Phase II/III trial","risk":"medical-concern","source":"ICH E6"},
    {"id":"DM009","layer":"Beyond-P21","cat":"Demographics","domain":"DM","sev":"WARNING","label":"RFSTDTC after RFENDTC - reference start date after reference end date","risk":"structural","source":"SDTMIG"},
    # __ ADVERSE EVENTS ______________________________________________________
    {"id":"AE001","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"REJECT","label":"Missing AEDECOD (MedDRA preferred term required)","risk":"submission-blocker","source":"P21"},
    {"id":"AE002","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AE death date present but AESDTH != Y","risk":"medical-concern","source":"P21"},
    {"id":"AE003","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AEOUT=FATAL with inconsistent AESTDTC or AEENDTC","risk":"medical-concern","source":"P21"},
    {"id":"AE004","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AESTDTC after AEENDTC (start date after end date)","risk":"structural","source":"P21"},
    {"id":"AE005","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AE record exists after subject death date","risk":"medical-concern","source":"P21"},
    {"id":"AE006","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"Both AESEV and AETOXGR are missing","risk":"structural","source":"P21"},
    {"id":"AE007","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"Grade 5 AE with inconsistent death variables (AESDTH/AEOUT)","risk":"medical-concern","source":"P21"},
    {"id":"AE008","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"Duplicated AE entries (same USUBJID/AEDECOD/AESTDTC)","risk":"structural","source":"P21"},
    {"id":"AE009","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"Missing or unexpected AEREL values (ICH E2A causality required)","risk":"structural","source":"P21/ICH-E2A"},
    {"id":"AE010","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AE leading to study discontinuation with no DS record","risk":"medical-concern","source":"P21"},
    {"id":"AE011","layer":"P21-Base","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"AE death dates not reflected in DS disposition record","risk":"medical-concern","source":"P21"},
    {"id":"AE012","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"ERROR","label":"AETRTEM=Y but AE start > 30 days after last dose","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"AE013","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"AESOC inconsistent with AEDECOD per MedDRA hierarchy","risk":"structural","source":"MedDRA/SDTMIG"},
    {"id":"AE014","layer":"Beyond-P21","cat":"AE Integrity","domain":"AE","sev":"WARNING","label":"AESER=Y but SAE narrative (SUPPAE.SAENARR) missing","risk":"advisory","source":"ICH-E3"},
    {"id":"AE015","layer":"Beyond-P21","cat":"Cross-Domain","domain":"LB/AE","sev":"CRITICAL","label":"Silent AE - CTCAE Grade 3/4 lab toxicity with no AE in +/-7 days","risk":"medical-concern","source":"CTCAE/Beyond-P21"},
    {"id":"AE016","layer":"Beyond-P21","cat":"Cross-Domain","domain":"AE/CM","sev":"ERROR","label":"Severe AE (AESEV=SEVERE) without matching concomitant medication","risk":"medical-concern","source":"Beyond-P21"},
    # __ DISPOSITION _________________________________________________________
    {"id":"DS001","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR","label":"DSDECOD=DEATH without DSSCAT=STUDY PARTICIPATION","risk":"medical-concern","source":"P21"},
    {"id":"DS002","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR","label":"DSDECOD=DEATH with missing DSSTDTC","risk":"medical-concern","source":"P21"},
    {"id":"DS003","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"WARNING","label":"Multiple non-matching death dates in DS for same subject","risk":"medical-concern","source":"P21"},
    {"id":"DS004","layer":"P21-Base","cat":"DS Logic","domain":"DS","sev":"ERROR","label":"Exposure after study discontinuation per DS record","risk":"medical-concern","source":"P21"},
    {"id":"DS005","layer":"Beyond-P21","cat":"DS Logic","domain":"DS/EX","sev":"CRITICAL","label":"Screen Failure (DSDECOD=Screen Failure) with EX dosing records present","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS006","layer":"Beyond-P21","cat":"Temporal","domain":"DS/ALL","sev":"CRITICAL","label":"Dead Man Walking - any domain record exists after DSDECOD=DEATH date","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS007","layer":"Beyond-P21","cat":"Temporal","domain":"DM/ALL","sev":"ERROR","label":"Narrative Continuity - record after RFPENDTC (Last Contact date)","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"DS008","layer":"Beyond-P21","cat":"Temporal","domain":"DS/PR","sev":"CRITICAL","label":"Informed Consent Violation - procedure before RFICDTC","risk":"medical-concern","source":"ICH-E6/Beyond-P21"},
    # __ EXPOSURE ____________________________________________________________
    {"id":"EX001","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR","label":"Duplicate dosing records (same USUBJID/EXTRT/EXSTDTC/EXDOSE)","risk":"structural","source":"P21"},
    {"id":"EX002","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR","label":"Missing EXDOSE when EXOCCUR=Y","risk":"structural","source":"P21"},
    {"id":"EX003","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"WARNING","label":"EXOCCUR != Y but EXDOSE > 0","risk":"structural","source":"P21"},
    {"id":"EX004","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"WARNING","label":"Missing EXDOSU (dose units)","risk":"structural","source":"P21"},
    {"id":"EX005","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR","label":"EXSTDTC after subject death date in DS","risk":"medical-concern","source":"P21"},
    {"id":"EX006","layer":"P21-Base","cat":"Exposure","domain":"EX","sev":"ERROR","label":"EXSTDTC > EXENDTC for same infusion record","risk":"structural","source":"P21"},
    {"id":"EX007","layer":"Beyond-P21","cat":"Exposure","domain":"EX","sev":"ERROR","label":"Cumulative dose per subject exceeds protocol-defined maximum","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"EX008","layer":"Beyond-P21","cat":"Exposure","domain":"EX","sev":"ERROR","label":"Treatment-epoch subject with no EX records (no dosing evidence)","risk":"medical-concern","source":"Beyond-P21"},
    # __ LABORATORY __________________________________________________________
    {"id":"LB001","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"ERROR","label":"LB record after subject death date","risk":"medical-concern","source":"P21"},
    {"id":"LB002","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"ERROR","label":"LBDTC visit ordinal error","risk":"structural","source":"P21"},
    {"id":"LB003","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"Missing reference range when numeric result present","risk":"structural","source":"P21"},
    {"id":"LB004","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"LBSTRESN missing; LBORRES starts with > or < (use LBSTRESC)","risk":"structural","source":"P21"},
    {"id":"LB005","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"LBORRES populated but LBSTRESN and LBSTRESC both missing","risk":"structural","source":"P21"},
    {"id":"LB006","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"Missing LBSTRESU with non-missing numeric lab result","risk":"structural","source":"P21"},
    {"id":"LB007","layer":"P21-Base","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"Missing month in LBDTC (partial date)","risk":"structural","source":"P21"},
    {"id":"LB008","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"ERROR","label":"LBORRES contains range (10-20) but LBSTRESN is single value without LBMETHOD","risk":"structural","source":"Beyond-P21"},
    {"id":"LB009","layer":"Beyond-P21","cat":"Cross-Domain","domain":"LB/EX","sev":"ERROR","label":"Pre-dose lab draw violation - LBDTM after EXSTDTC (infusion started)","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"LB010","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"LBNRIND value inconsistent with LBSTRESN vs. reference range","risk":"structural","source":"SDTMIG"},
    {"id":"LB011","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"ERROR","label":"Hy's Law Signal - ALT > 3xULN and Total Bilirubin > 2xULN same timepoint","risk":"medical-concern","source":"FDA DILI Guidance"},
    {"id":"LB012","layer":"Beyond-P21","cat":"Lab Logic","domain":"LB","sev":"WARNING","label":"Duplicate LBDTC/LBTESTCD for same subject (possible double entry)","risk":"structural","source":"Beyond-P21"},
    # __ VITAL SIGNS _________________________________________________________
    {"id":"VS001","layer":"P21-Base","cat":"Vital Signs","domain":"VS","sev":"CRITICAL","label":"Diastolic BP > Systolic BP (physiologically impossible)","risk":"medical-concern","source":"P21/Physiology"},
    {"id":"VS002","layer":"P21-Base","cat":"Vital Signs","domain":"VS","sev":"ERROR","label":"VS record after subject death date","risk":"medical-concern","source":"P21"},
    {"id":"VS003","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"ERROR","label":"Weight change > 20 percent between consecutive weekly visits","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"VS004","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING","label":"Height decreasing significantly over time (> 5 cm from baseline)","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"VS005","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING","label":"VSTESTCD=PULSE with value < 20 or > 300 BPM (implausible)","risk":"medical-concern","source":"Physiology"},
    {"id":"VS006","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING","label":"VSTESTCD=TEMP value in Fahrenheit range but VSSTRESU=C (unit swap)","risk":"medical-concern","source":"Physiology"},
    {"id":"VS007","layer":"Beyond-P21","cat":"Vital Signs","domain":"VS","sev":"WARNING","label":"VSTESTCD=SYSBP < 40 or > 300 mmHg (out of physiological range)","risk":"medical-concern","source":"Physiology"},
    # __ ECG / CM / PK / QS / IE / SS / ONCOLOGY / DV / MH / OTHER __________
    {"id":"EG001","layer":"P21-Base","cat":"ECG","domain":"EG","sev":"ERROR","label":"EGDTC and VISITNUM ordinal error","risk":"structural","source":"P21"},
    {"id":"EG002","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"WARNING","label":"QTcF > 500 ms without corresponding cardiac AE record","risk":"medical-concern","source":"ICH-E14"},
    {"id":"EG003","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"WARNING","label":"QTcF increase > 60 ms from baseline without TEAE record","risk":"medical-concern","source":"ICH-E14"},
    {"id":"EG004","layer":"Beyond-P21","cat":"ECG","domain":"EG","sev":"ERROR","label":"EG record after subject death date","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"CM001","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"ERROR","label":"Missing CMDECOD (WHO Drug dictionary term required)","risk":"structural","source":"P21"},
    {"id":"CM002","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"WARNING","label":"Missing or inconsistent CMLAT when CMCAT indicates laterality","risk":"structural","source":"P21"},
    {"id":"CM003","layer":"P21-Base","cat":"CM Logic","domain":"CM","sev":"WARNING","label":"Missing month in CMSTDTC or CMENDTC (partial date)","risk":"structural","source":"P21"},
    {"id":"CM004","layer":"Beyond-P21","cat":"CM Logic","domain":"CM","sev":"WARNING","label":"CMENDTC before CMSTDTC (end date before start date)","risk":"structural","source":"SDTMIG"},
    {"id":"CM005","layer":"Beyond-P21","cat":"CM Logic","domain":"CM","sev":"WARNING","label":"Prohibited concomitant medication per protocol exclusion list","risk":"medical-concern","source":"Protocol"},
    {"id":"PK001","layer":"Beyond-P21","cat":"PK Concentrations","domain":"PC","sev":"ERROR","label":"PC record without corresponding EX record on same day","risk":"medical-concern","source":"CDISC-PK"},
    {"id":"PK002","layer":"Beyond-P21","cat":"PK Concentrations","domain":"PC","sev":"ERROR","label":"PCRFTDTC (reference time) after PCDTC (sample time)","risk":"structural","source":"SDTMIG"},
    {"id":"PK003","layer":"Beyond-P21","cat":"PK Parameters","domain":"PP","sev":"ERROR","label":"PP record not linked to PC via RELREC (traceability missing)","risk":"structural","source":"CDISC-PK"},
    {"id":"PK004","layer":"Beyond-P21","cat":"PK Parameters","domain":"PP","sev":"WARNING","label":"PPTESTCD=CMAX value lower than all PC concentrations (impossible)","risk":"medical-concern","source":"PK Logic"},
    {"id":"QS001","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"WARNING","label":"Non-validated questionnaire mapped to QS domain","risk":"structural","source":"SDTMIG"},
    {"id":"QS002","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"WARNING","label":"Logically skipped QS items not flagged (QSSTAT/QSREASND missing)","risk":"structural","source":"FDA TCG"},
    {"id":"QS003","layer":"Beyond-P21","cat":"Questionnaires","domain":"QS","sev":"ERROR","label":"Total score inconsistent with sum of component item scores","risk":"medical-concern","source":"QRS Logic"},
    {"id":"IE001","layer":"Beyond-P21","cat":"IE Criteria","domain":"IE/TI","sev":"ERROR","label":"IE.IETESTCD not found in TI domain criteria list","risk":"structural","source":"PharmaSUG-2024"},
    {"id":"IE002","layer":"Beyond-P21","cat":"IE Criteria","domain":"IE","sev":"WARNING","label":"IE exclusion criterion failure while subject DSDECOD=ENROLLED","risk":"medical-concern","source":"Beyond-P21"},
    {"id":"SS001","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"ERROR","label":"SS ALIVE status date later than DM death date (DTHDTC)","risk":"medical-concern","source":"P21"},
    {"id":"SS002","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"ERROR","label":"SS DEAD status date before DM death date","risk":"medical-concern","source":"P21"},
    {"id":"SS003","layer":"P21-Base","cat":"SS Logic","domain":"SS","sev":"WARNING","label":"SSSTAT=NOT DONE but non-missing SSORRES","risk":"structural","source":"P21"},
    {"id":"ONC001","layer":"P21-Base","cat":"Oncology","domain":"TR","sev":"WARNING","label":"Duplicate TR records (same USUBJID/TRTESTCD/TRDTC/TULNKID)","risk":"structural","source":"P21"},
    {"id":"ONC002","layer":"P21-Base","cat":"Oncology","domain":"TR","sev":"ERROR","label":"TR TRDTC visit ordinal error","risk":"structural","source":"P21"},
    {"id":"ONC003","layer":"P21-Base","cat":"Oncology","domain":"TU","sev":"ERROR","label":"New lesion in TU without RS RSORRES=PD at same timepoint","risk":"medical-concern","source":"P21/RECIST 1.1"},
    {"id":"ONC004","layer":"Beyond-P21","cat":"Oncology","domain":"TR/TU","sev":"ERROR","label":"TR lesion TULNKID not found in TU (broken parent-child link)","risk":"structural","source":"SDTMIG"},
    {"id":"ONC005","layer":"Beyond-P21","cat":"Oncology","domain":"TR","sev":"ERROR","label":"RECIST sum of target diameters mismatch vs. individual LDIAM records","risk":"medical-concern","source":"RECIST 1.1"},
    {"id":"DV001","layer":"Beyond-P21","cat":"Protocol Dev.","domain":"DV","sev":"WARNING","label":"Major protocol deviation with no DS discontinuation record","risk":"medical-concern","source":"ICH-E6"},
    {"id":"DV002","layer":"Beyond-P21","cat":"Protocol Dev.","domain":"DV","sev":"WARNING","label":"DVTERM not categorised (DVCAT missing)","risk":"structural","source":"SDTMIG"},
    {"id":"MH001","layer":"P21-Base","cat":"Medical History","domain":"MH","sev":"WARNING","label":"Missing month in MHSTDTC (partial date)","risk":"structural","source":"P21"},
    {"id":"MH002","layer":"Beyond-P21","cat":"Medical History","domain":"MH/AE","sev":"WARNING","label":"MH ongoing condition also recorded as new AE (possible duplicate)","risk":"advisory","source":"Beyond-P21"},
    {"id":"PR001","layer":"Beyond-P21","cat":"Procedures","domain":"PR/DS","sev":"CRITICAL","label":"Procedure date before informed consent date (RFICDTC)","risk":"medical-concern","source":"Beyond-P21/ICH-E6"},
    {"id":"REL001","layer":"Beyond-P21","cat":"RELREC","domain":"RELREC","sev":"ERROR","label":"RELREC IDVAR value not a valid key variable in referenced domain","risk":"structural","source":"SDTMIG"},
    {"id":"REL002","layer":"Beyond-P21","cat":"RELREC","domain":"RELREC","sev":"WARNING","label":"PC/PP RELREC missing - PK parameter not traceable to concentrations","risk":"structural","source":"CDISC-PK"},
    {"id":"SV001","layer":"P21-Base","cat":"Visit Logic","domain":"SV","sev":"ERROR","label":"SV SVSTDTC visit ordinal error","risk":"structural","source":"P21"},
    {"id":"SV002","layer":"P21-Base","cat":"Visit Logic","domain":"SV","sev":"WARNING","label":"Duplicate records in SV","risk":"structural","source":"P21"},
    {"id":"SV003","layer":"Beyond-P21","cat":"Visit Logic","domain":"ALL/TV","sev":"ERROR","label":"Visit Windowing - actual --DY deviates > +/-3 days from VISITDY","risk":"structural","source":"Beyond-P21"},
    {"id":"BL001","layer":"Beyond-P21","cat":"Metadata","domain":"ALL/EX","sev":"ERROR","label":"Time-Level Baseline - --BLFL=Y set on record after first dose datetime","risk":"structural","source":"Beyond-P21"},
    {"id":"BL002","layer":"Beyond-P21","cat":"Metadata","domain":"ALL","sev":"ERROR","label":"VLM/Codelist Leakage - raw value not in CDISC controlled terminology","risk":"structural","source":"PharmaSUG-2020"},

    # __ HIDDEN INTEGRITY ESSENTIALS (v7) ____________________________________
    {"id":"INT001","layer":"Hidden Integrity","cat":"Subject Integrity","domain":"ALL/DM","sev":"REJECT",
     "label":"Orphan Record - USUBJID in observation domain not found in DM",
     "risk":"submission-blocker","source":"INT001"},
    {"id":"INT002","layer":"Hidden Integrity","cat":"Baseline Logic","domain":"ALL/DM","sev":"ERROR",
     "label":"Baseline flag (--BLFL=Y) set on record occurring after First Dose (RFSTDTC)",
     "risk":"medical-concern","source":"INT002"},
    {"id":"INT003","layer":"Hidden Integrity","cat":"Disposition Gap","domain":"DS/EX","sev":"ERROR",
     "label":"Subject has study activity (EX/LB/AE) but no End of Study disposition in DS",
     "risk":"structural","source":"INT003"},
    {"id":"INT004","layer":"Hidden Integrity","cat":"Physiological Logic","domain":"LB/DM","sev":"WARNING",
     "label":"Gender-inappropriate lab test - pregnancy/HCG test result for male subject",
     "risk":"advisory","source":"INT004"},
    {"id":"INT005","layer":"Hidden Integrity","cat":"GCP Compliance","domain":"ALL/DM","sev":"CRITICAL",
     "label":"Study assessment performed before Informed Consent date (RFICDTC)",
     "risk":"medical-concern","source":"ICH-E6/INT005"},

    # __ TEMPORAL INTEGRITY & LOGIC (v7) _____________________________________
    {"id":"DATE001","layer":"Temporal Integrity","cat":"Date Logic","domain":"ALL","sev":"ERROR",
     "label":"Start Date after End Date within same record (--STDTC > --ENDTC)",
     "risk":"structural","source":"DATE001"},
    {"id":"DATE002","layer":"Temporal Integrity","cat":"Post-Mortem Activity","domain":"ALL/DS","sev":"CRITICAL",
     "label":"Post-Mortem Activity - clinical record exists after subject Death Date",
     "risk":"submission-blocker","source":"DATE002"},
    {"id":"DATE003","layer":"Temporal Integrity","cat":"Date Logic","domain":"ALL","sev":"WARNING",
     "label":"Future Date - assessment date is after today's data snapshot date",
     "risk":"advisory","source":"DATE003"},
    {"id":"DATE004","layer":"Temporal Integrity","cat":"Date Logic","domain":"DM","sev":"ERROR",
     "label":"Birth Date (BRTHDTC) is after Study Start Date (RFSTDTC)",
     "risk":"medical-concern","source":"DATE004"},
    {"id":"DATE005","layer":"Temporal Integrity","cat":"GCP Compliance","domain":"EX/DM","sev":"CRITICAL",
     "label":"First Treatment (EXSTDTC) before Informed Consent date (RFICDTC)",
     "risk":"medical-concern","source":"ICH-E6/DATE005"},
    {"id":"DATE006","layer":"Temporal Integrity","cat":"Disposition Gap","domain":"EX/DS","sev":"ERROR",
     "label":"Dosing after Study Discontinuation - EXENDTC after DS disposition date",
     "risk":"structural","source":"DATE006"},
]

# ---------------------------------------------------------------------------
# YAML loader and hot-reload machinery (unchanged from v6)
# ---------------------------------------------------------------------------
_cache_mtime: float = 0.0
_cache_checks: list = []
YAML_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "checks.yaml")

def _load_yaml() -> list:
    try:
        import yaml
        with open(YAML_PATH, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        raw   = data.get("checks", []) if isinstance(data, dict) else []
        req   = {"id","layer","cat","domain","sev","label","risk","source"}
        valid = [c for c in raw if isinstance(c, dict) and req.issubset(c.keys())]
        if len(valid) != len(raw):
            log.warning("checks.yaml: %d checks skipped (missing fields)", len(raw)-len(valid))
        return valid
    except ImportError:
        return []
    except FileNotFoundError:
        return []
    except Exception as exc:
        log.error("checks.yaml load error: %s", exc)
        return []

def _get_checks() -> list:
    global _cache_mtime, _cache_checks
    try:
        mtime = os.path.getmtime(YAML_PATH) if os.path.exists(YAML_PATH) else 0.0
    except OSError:
        mtime = 0.0
    if mtime != _cache_mtime:
        yaml_checks   = _load_yaml()
        _cache_checks = yaml_checks if yaml_checks else list(DEFAULT_CHECKS)
        _cache_mtime  = mtime
    return _cache_checks

def get_checks() -> list:  return _get_checks()
def get_check(cid: str):   return next((c for c in _get_checks() if c["id"] == cid), None)

class _ChecksProxy:
    def __iter__(self):       return iter(_get_checks())
    def __len__(self):        return len(_get_checks())
    def __getitem__(self, i): return _get_checks()[i]
    def __contains__(self, x): return x in _get_checks()

CHECKS     = _ChecksProxy()
LAYERS     = sorted({c["layer"] for c in DEFAULT_CHECKS})
CATEGORIES = sorted({c["cat"]   for c in DEFAULT_CHECKS})

_get_checks()  # warm cache
