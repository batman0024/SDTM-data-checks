"""
SDTM Clinical Integrity Suite - Streamlit Edition v5.1
Beyond-P21 Validation Dashboard

HOW TO RUN:
    pip install streamlit pandas openpyxl
    streamlit run app.py

Then open: http://localhost:8501
"""

import streamlit as st
import pandas as pd
import os
import time
import datetime

from modules.registry import CHECKS, get_check, get_checks, LAYERS, CATEGORIES
from modules.engine import ValidationEngine, DEMO_POOL
from modules.parser import FileParser
from modules.reporter import make_html_report, make_excel_report

# ---------------------------------------------------------------------------
# PAGE CONFIG  (must be FIRST Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SDTM Clinical Integrity Suite v7.0",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": None,
        "Report a bug": None,
        "About": "SDTM Clinical Integrity Suite v7.0 | Beyond-P21 + SUG Upgrades",
    },
)

# ---------------------------------------------------------------------------
# CUSTOM CSS
# All colors verified for readability on dark #05060a background.
# Every previously invisible color (eg #252840, #454870) has been fixed.
# ---------------------------------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Orbitron:wght@400;600;700;900&display=swap');

/* ---- ROOT ---- */
html, body, [class*="css"] {
    font-family: 'JetBrains Mono', 'Courier New', monospace !important;
}

/* ---- BACKGROUNDS ---- */
.stApp { background: #05060a !important; }
.block-container {
    padding-top: 1rem !important;
    padding-bottom: 2rem !important;
    max-width: 100% !important;
}

/* ---- SIDEBAR ---- */
[data-testid="stSidebar"] {
    background: #08090e !important;
    border-right: 1px solid #1a1d2e !important;
    box-shadow: 2px 0 20px rgba(0,0,0,0.6) !important;
}
[data-testid="stSidebar"] .block-container {
    padding: 0.8rem 0.7rem !important;
}

/* ---- SIDEBAR TEXT -- all must be readable on #08090e ---- */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color: #b0b8d0 !important; }
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] { color: #6870a0 !important; }

/* ---- GLOBAL BODY TEXT ---- */
p, div { color: #b0b8d0; }
.stMarkdown p { color: #b8bdd0 !important; }
.stMarkdown strong { color: #d8ddf0 !important; }

/* ---- SUITE TITLE / HEADER ---- */
.suite-title {
    font-family: 'Orbitron', monospace !important;
    font-size: 1.55rem !important;
    font-weight: 900 !important;
    background: linear-gradient(135deg, #5898ff, #70b8ff, #90d4ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 0.04em;
    line-height: 1.2;
}
/* FIX: was #454870 - near-invisible. Now #8090b8 - clearly readable subtitle */
.suite-subtitle {
    font-size: 0.68rem;
    color: #8090b8 !important;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-top: 0.15rem;
}

/* ---- METRIC CARDS ---- */
[data-testid="metric-container"] {
    background: #0c0d16 !important;
    border: 1px solid #1a1d2e !important;
    border-radius: 6px !important;
    padding: 0.8rem 1rem !important;
    transition: transform 0.2s, border-color 0.2s !important;
}
[data-testid="metric-container"]:hover {
    transform: translateY(-2px) !important;
    border-color: #2a2f4e !important;
}
/* FIX: ensure metric value text is bright */
[data-testid="stMetricValue"] {
    font-family: 'Orbitron', monospace !important;
    font-size: 1.9rem !important;
    font-weight: 700 !important;
    color: #dce0f8 !important;
}
/* FIX: was #454870 (very dark) - now #7880a8 clearly readable muted label */
[data-testid="stMetricLabel"] {
    font-size: 0.62rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.09em !important;
    color: #7880a8 !important;
}
[data-testid="stMetricDelta"] { display: none !important; }

/* ---- BUTTONS ---- */
.stButton > button {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.74rem !important;
    font-weight: 700 !important;
    letter-spacing: 0.05em !important;
    text-transform: uppercase !important;
    border-radius: 4px !important;
    transition: all 0.2s !important;
}
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #0a2060, #183ebf) !important;
    border: 1px solid #4880ff !important;
    /* FIX: bright enough text on dark bg */
    color: #a0c8ff !important;
    box-shadow: 0 0 14px rgba(40,100,220,0.28) !important;
}
.stButton > button[kind="primary"]:hover {
    box-shadow: 0 0 24px rgba(64,128,255,0.55) !important;
    transform: translateY(-1px) !important;
    color: #c0dcff !important;
}
.stButton > button[kind="secondary"] {
    background: #0c0d16 !important;
    border: 1px solid #252840 !important;
    /* FIX: was #8890b0 - fine but brightened slightly */
    color: #9098b8 !important;
}
.stButton > button[kind="secondary"]:hover {
    border-color: #4080ff !important;
    color: #90b8ff !important;
    background: rgba(64,128,255,0.05) !important;
}

/* ---- TABS ---- */
[data-testid="stTabs"] button {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.72rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.07em !important;
    /* FIX: was #454870 (near-invisible on dark). Now #7880a8 - clearly readable */
    color: #7880a8 !important;
    border-radius: 0 !important;
    padding: 0.55rem 1.1rem !important;
    transition: color 0.15s !important;
}
[data-testid="stTabs"] button[aria-selected="true"] {
    color: #70a8ff !important;
    border-bottom: 2px solid #4880ff !important;
    background: transparent !important;
}
[data-testid="stTabs"] button:hover {
    color: #a0c8ff !important;
    background: rgba(64,128,255,0.04) !important;
}

/* ---- EXPANDERS ---- */
[data-testid="stExpander"] {
    background: #0b0c15 !important;
    border: 1px solid #1a1d2e !important;
    border-radius: 5px !important;
    overflow: hidden !important;
}
/* FIX: expander summary text - bright and readable */
[data-testid="stExpander"] summary {
    font-size: 0.74rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.07em !important;
    color: #8ab0e8 !important;
    font-weight: 700 !important;
    padding: 0.55rem 0.8rem !important;
}
[data-testid="stExpander"] summary:hover {
    color: #b0d0ff !important;
}

/* ---- PROGRESS ---- */
[data-testid="stProgress"] > div > div {
    background: linear-gradient(90deg, #2060e0, #4890ff, #70b8ff) !important;
    box-shadow: 0 0 8px rgba(72,144,255,0.5) !important;
}

/* ---- INPUTS / SELECTS ---- */
.stTextInput > div > div > input,
.stTextArea textarea {
    background: #0c0d16 !important;
    border: 1px solid #1a1d2e !important;
    color: #d0d8f0 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.76rem !important;
    border-radius: 3px !important;
}
.stTextInput > div > div > input::placeholder { color: #404870 !important; }
.stTextInput > div > div > input:focus {
    border-color: #4880ff !important;
    box-shadow: 0 0 0 1px rgba(72,128,255,0.4) !important;
}
/* Selectbox text */
[data-testid="stSelectbox"] span { color: #c0c8e0 !important; }
[data-testid="stSelectbox"] div  { color: #c0c8e0 !important; }

/* ---- FILE UPLOADER ---- */
[data-testid="stFileUploader"] {
    background: #0c0d16 !important;
    border: 2px dashed #252840 !important;
    border-radius: 6px !important;
}
[data-testid="stFileUploader"]:hover { border-color: #4080ff !important; }
/* FIX: upload area text was invisible */
[data-testid="stFileUploaderDropzone"] label,
[data-testid="stFileUploaderDropzone"] div,
[data-testid="stFileUploaderDropzone"] span { color: #6870a0 !important; }
[data-testid="stFileUploaderDropzone"] small { color: #505878 !important; }

/* ---- CHECKBOXES ---- */
[data-testid="stCheckbox"] label { color: #a8b0c8 !important; font-size: 0.76rem !important; }

/* ---- CAPTIONS ---- */
/* FIX: captions were barely visible - now clearly muted but readable */
[data-testid="stCaptionContainer"],
.stCaption { color: #6068908 !important; color: #606890 !important; }

/* ---- MARKDOWN HEADINGS in main area ---- */
.stMarkdown h5 {
    color: #90b8ff !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.78rem !important;
    text-transform: uppercase !important;
    letter-spacing: 0.09em !important;
}
.stMarkdown h4 {
    color: #a0c0ff !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 0.88rem !important;
}
.stMarkdown hr { border-color: #1a1d2e !important; }

/* ---- SEVERITY / RISK BADGES ---- */
.badge {
    display: inline-block;
    font-size: 0.64rem;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 3px;
    border: 1px solid currentColor;
    letter-spacing: 0.05em;
    white-space: nowrap;
}
/* FIX: all badge colors brightened to be readable on dark card bg */
.badge-reject   { color: #ff6060; background: rgba(255,96,96,0.12); }
.badge-critical { color: #ff8080; background: rgba(255,128,128,0.12); }
.badge-error    { color: #ffb060; background: rgba(255,176,96,0.12); }
.badge-warning  { color: #f0d840; background: rgba(240,216,64,0.1); }
.badge-blocker  { color: #ff6060; background: rgba(255,96,96,0.1); }
.badge-medical  { color: #ff8080; background: rgba(255,128,128,0.1); }
.badge-struct   { color: #ffb060; background: rgba(255,176,96,0.1); }
.badge-advisory { color: #6898ff; background: rgba(104,152,255,0.1); }

/* ---- FINDING CARDS ---- */
.finding-card {
    background: #0b0c15;
    border: 1px solid #1a1d2e;
    border-radius: 5px;
    padding: 0.8rem 1rem;
    margin-bottom: 0.45rem;
    transition: background 0.15s, border-color 0.15s;
    border-left: 3px solid #252840;
}
.finding-card:hover { background: #0d0e18; border-color: #2a2f4e; }
.finding-card.medical    { border-left-color: #ff8080; }
.finding-card.blocker    { border-left-color: #ff6060; }
.finding-card.structural { border-left-color: #ffb060; }
.finding-card.advisory   { border-left-color: #6898ff; }

/* FIX: subject ID - bright blue, highly visible */
.finding-subject { color: #78a8ff; font-weight: 700; font-size: 0.82rem; }

/* FIX: domain was #454870 invisible. Now #7888b0 - readable muted */
.finding-domain { color: #7888b0; font-size: 0.7rem; font-weight: 500; }

/* FIX: check label text - bright enough to read comfortably */
.finding-label  { color: #a8b4cc; font-size: 0.77rem; font-weight: 500; margin-top: 3px; line-height: 1.5; }

/* FIX: detail is primary info - should be clearly bright */
.finding-detail { color: #c8d2e8; font-size: 0.74rem; margin-top: 5px; line-height: 1.6; }

/* FIX: meta was #252840 - completely invisible. Now #5a6484 - visible but dim */
.finding-meta   { color: #5a6484; font-size: 0.64rem; margin-top: 5px; }

/* FIX: root line was #252840 - invisible. Now #607090 - readable */
.finding-root   { color: #607090; font-size: 0.67rem; margin-top: 4px; }

/* ---- ACTUAL / DEMO BADGES ---- */
.badge-actual {
    font-size: 0.62rem; color: #58c890;
    border: 1px solid rgba(88,200,144,0.4);
    padding: 1px 5px; border-radius: 2px;
    background: rgba(88,200,144,0.08);
}
.badge-demo {
    font-size: 0.62rem; color: #6898ff;
    border: 1px solid rgba(104,152,255,0.35);
    padding: 1px 5px; border-radius: 2px;
    background: rgba(104,152,255,0.08);
}

/* ---- WAIVED BADGE ---- */
.waived-badge {
    display: inline-block; font-size: 0.62rem; font-weight: 700;
    padding: 2px 6px; border-radius: 2px;
    color: #58c890; background: rgba(88,200,144,0.1);
    border: 1px solid rgba(88,200,144,0.35); letter-spacing: 0.05em;
}

/* ---- INFO BOX ---- */
.info-box {
    background: rgba(72,128,255,0.07);
    border: 1px solid rgba(72,128,255,0.22);
    border-radius: 4px;
    padding: 0.65rem 0.9rem;
    font-size: 0.74rem;
    /* FIX: was #8890b0 - bumped to #9aa2c0 */
    color: #9aa2c0;
    margin-bottom: 0.7rem;
    line-height: 1.55;
}

/* ---- HEADER GLOW LINE ---- */
.header-glow {
    background: linear-gradient(135deg, #0a1840 0%, #040508 65%);
    border-bottom: 1px solid #1a1d2e;
    padding: 0.9rem 0 0.75rem;
    margin-bottom: 0.8rem;
    position: relative;
}
.header-glow::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent, #4880ff, #78b8ff, #4880ff, transparent);
    opacity: 0.55;
}

/* ---- SIDEBAR LOGO ---- */
.sidebar-logo-title {
    font-family: 'Orbitron', monospace;
    font-size: 1.1rem; font-weight: 900;
    background: linear-gradient(135deg, #5898ff, #90c8ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text; letter-spacing: 0.04em;
}
/* FIX: was #252840 - completely invisible. Now #586080 - readable dim */
.sidebar-logo-sub {
    font-size: 0.6rem; color: #586080 !important;
    text-transform: uppercase; letter-spacing: 0.12em; margin-top: 3px;
}

/* ---- SECTION DIVIDERS ---- */
hr { border-color: #1a1d2e !important; margin: 0.6rem 0 !important; }

/* ---- EMPTY STATE ---- */
/* FIX: was #252840 - invisible. Now #404868 and #363858 - dimmed but readable */
.empty-state-title {
    font-family: 'Orbitron', monospace; font-size: 1.05rem;
    color: #404868 !important; margin-bottom: 0.4rem;
}
.empty-state-sub { color: #343658 !important; font-size: 0.75rem; }

/* ---- SECTION LABEL ---- */
.section-label {
    font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.1em;
    color: #5a6888;
    display: flex; align-items: center; gap: 0.6rem; margin-bottom: 0.5rem;
}
.section-label::after {
    content: ''; flex: 1; height: 1px; background: #1a1d2e;
}

/* ---- SCROLLBAR ---- */
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: #05060a; }
::-webkit-scrollbar-thumb { background: #252840; border-radius: 2px; }
::-webkit-scrollbar-thumb:hover { background: #4880ff; }

/* ---- ALTAIR CHART TEXT ---- */
.vega-embed text { fill: #7880a8 !important; font-size: 11px !important; }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# SESSION STATE INITIALISATION
# ---------------------------------------------------------------------------
def _init_state():
    defaults = {
        "uploaded_files_meta": {},
        "findings":            [],
        "enabled_ids":         set(c["id"] for c in CHECKS),
        "is_running":          False,
        "run_progress":        0,
        "run_label":           "",
        "run_count":           0,
        "last_run_ts":         "",
        "waived_notes":        {},
        "risk_filter":         "All",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ---------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------
RISK_COLORS = {
    "submission-blocker": "#ff6060",
    "medical-concern":    "#ff8080",
    "structural":         "#ffb060",
    "advisory":           "#6898ff",
}
RISK_LABELS = {
    "submission-blocker": "Submission Blocker",
    "medical-concern":    "Medical Concern",
    "structural":         "Structural Error",
    "advisory":           "Advisory",
}
SEV_COLORS = {
    "REJECT":   "#ff6060",
    "CRITICAL": "#ff8080",
    "ERROR":    "#ffb060",
    "WARNING":  "#f0d840",
    "NOTICE":   "#6898ff",
}

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def _active_findings():
    return [f for f in st.session_state.findings if not f.get("waived")]

def _count_by(findings, key):
    out = {}
    for f in findings:
        v = f.get(key, "?")
        out[v] = out.get(v, 0) + 1
    return out

def _count_dom(findings):
    out = {}
    for f in findings:
        d = f.get("domain", "?").split("/")[0]
        out[d] = out.get(d, 0) + 1
    return out

def _worst_risk(risk_list):
    for r in ["submission-blocker","medical-concern","structural","advisory"]:
        if r in risk_list:
            return r
    return "advisory"

def _badge_html(text, kind):
    cls_map = {
        "REJECT":             "badge-reject",
        "CRITICAL":           "badge-critical",
        "ERROR":              "badge-error",
        "WARNING":            "badge-warning",
        "submission-blocker": "badge-blocker",
        "medical-concern":    "badge-medical",
        "structural":         "badge-struct",
        "advisory":           "badge-advisory",
    }
    cls = cls_map.get(text, cls_map.get(kind, "badge-struct"))
    return f'<span class="badge {cls}">{text}</span>'

def _sev_icon(sev):
    return {"REJECT":"[!]","CRITICAL":"[X]","ERROR":"[^]",
            "WARNING":"[~]","NOTICE":"[i]"}.get(sev,"[-]")

def _findings_to_df(findings, risk_filter="All"):
    rows = []
    for f in findings:
        if risk_filter != "All" and f.get("risk") != risk_filter:
            continue
        rows.append({
            "ID":      f["fid"],
            "Sev":     f["sev"],
            "Risk":    RISK_LABELS.get(f["risk"], f["risk"]),
            "Subject": "GLOBAL" if f["subj"] == "ALL" else f["subj"],
            "Domain":  f["domain"].split("/")[0],
            "Check":   f["label"][:55] + ("..." if len(f["label"]) > 55 else ""),
            "Detail":  f["detail"][:75] + ("..." if len(f["detail"]) > 75 else ""),
            "Source":  f["source"],
            "Layer":   f["layer"],
            "Waived":  "YES" if f.get("waived") else "",
        })
    if not rows:
        return pd.DataFrame(columns=["ID","Sev","Risk","Subject","Domain",
                                      "Check","Detail","Source","Layer","Waived"])
    return pd.DataFrame(rows)

def _files_to_df(meta_dict):
    rows = []
    for fname, m in meta_dict.items():
        rows.append({
            "Filename":  fname,
            "Type":      m.get("type",""),
            "Rows":      m.get("rows",0),
            "Cols":      m.get("cols",0),
            "Size":      f"{m.get('size',0):,} B",
            "Variables": ", ".join((m.get("variables") or [])[:5]),
            "Status":    "ERROR: " + m["parse_error"] if m.get("parse_error") else "OK",
        })
    if not rows:
        return pd.DataFrame(columns=["Filename","Type","Rows","Cols",
                                      "Size","Variables","Status"])
    return pd.DataFrame(rows)

def _subject_summary(findings):
    sm = {}
    for f in [x for x in findings if not x.get("waived")]:
        k = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
        sm.setdefault(k, []).append(f)
    rows = []
    for subj, sf in sorted(
            sm.items(),
            key=lambda x: (
                0 if _worst_risk([f["risk"] for f in x[1]]) == "medical-concern" else 1,
                x[0],
            )):
        doms = list(dict.fromkeys(f["domain"].split("/")[0] for f in sf))
        rows.append({
            "Subject":    subj,
            "Findings":   len(sf),
            "Worst Risk": RISK_LABELS.get(_worst_risk([f["risk"] for f in sf]),""),
            "Domains":    ", ".join(doms[:6]),
            "Categories": ", ".join(list(dict.fromkeys(f["cat"] for f in sf))[:4]),
        })
    if not rows:
        return pd.DataFrame(columns=["Subject","Findings","Worst Risk","Domains","Categories"])
    return pd.DataFrame(rows)

def _domain_map_df(findings):
    active     = [f for f in findings if not f.get("waived")]
    dom_counts = _count_dom(active)
    all_doms   = sorted(set(
        d for c in CHECKS for d in c["domain"].split("/")
        if d not in ("ALL","DEFINE","SUPP","RELREC")
    ))
    rows = []
    for dom in all_doms:
        dc = [c for c in CHECKS if dom in c["domain"].split("/")]
        en = len([c for c in dc if c["id"] in st.session_state.enabled_ids])
        has_crit = any(c["sev"] in ("CRITICAL","REJECT") for c in dc)
        rows.append({
            "Domain":          dom,
            "Total Checks":    len(dc),
            "Enabled":         en,
            "Critical Rules":  "YES" if has_crit else "",
            "Active Findings": dom_counts.get(dom, 0),
        })
    if not rows:
        return pd.DataFrame(columns=["Domain","Total Checks","Enabled",
                                      "Critical Rules","Active Findings"])
    return pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# FINDING CARD RENDERER
# ---------------------------------------------------------------------------
def _render_finding_card(f):
    risk      = f.get("risk","structural")
    sev       = f.get("sev","")
    is_waived = f.get("waived", False)
    fid       = f["fid"]
    subj      = "GLOBAL" if f["subj"] == "ALL" else f["subj"]
    css_cls   = {"submission-blocker":"blocker","medical-concern":"medical",
                 "structural":"structural","advisory":"advisory"}.get(risk,"structural")

    waived_badge = '<span class="waived-badge">WAIVED</span>' if is_waived else ""
    actual_badge = ('<span class="badge-actual">ACTUAL</span>'
                   if f.get("actual") else '<span class="badge-demo">DEMO</span>')
    # FIX: root was #252840 invisible - now .finding-root = #607090 readable
    root_line = (f'<div class="finding-root">Root cause: {f["root"]}</div>'
                 if f.get("root") else "")

    st.markdown(f"""
    <div class="finding-card {css_cls}" style="opacity:{'0.42' if is_waived else '1'}">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;flex-wrap:wrap">
        <code style="font-size:0.68rem;color:#505878;background:none;border:none;padding:0">{_sev_icon(sev)}</code>
        {_badge_html(sev, sev)}
        {_badge_html(RISK_LABELS.get(risk,risk), risk)}
        <span class="finding-subject">{subj}</span>
        <span class="finding-domain">[{f.get("domain","").split("/")[0]}]</span>
        {actual_badge}
        {waived_badge}
      </div>
      <div class="finding-label">{f.get("label","")}</div>
      <div class="finding-detail">{f.get("detail","")}</div>
      {root_line}
      <div class="finding-meta">{fid} &bull; {f.get("cat","")} &bull; {f.get("source","")}</div>
    </div>
    """, unsafe_allow_html=True)

    # Waiver controls
    with st.container():
        wc1, wc2, wc3 = st.columns([4,1,1])
        with wc1:
            note = st.text_input(
                "waiver note",
                value=f.get("waiver_note",""),
                placeholder="Enter cSDRG Section 4 justification...",
                key=f"note_{fid}",
                label_visibility="collapsed",
            )
        with wc2:
            if st.button("Unwaive" if is_waived else "Waive",
                         key=f"waive_{fid}", use_container_width=True):
                f["waived"]      = not is_waived
                f["waiver_note"] = note
                if f["waived"]:
                    st.session_state.waived_notes[fid] = note
                else:
                    st.session_state.waived_notes.pop(fid, None)
                st.rerun()
        with wc3:
            if is_waived:
                st.markdown(
                    '<span style="font-size:0.7rem;color:#58c890">Waived</span>',
                    unsafe_allow_html=True,
                )

# ---------------------------------------------------------------------------
# VALIDATION RUNNER
# ---------------------------------------------------------------------------
def run_validation():
    st.session_state.is_running    = True
    st.session_state.findings      = []
    st.session_state.run_progress  = 0

    files_meta  = dict(st.session_state.uploaded_files_meta)
    enabled_ids = set(st.session_state.enabled_ids)
    engine      = ValidationEngine(files_meta, enabled_ids)

    prog_ph = st.empty()
    bar     = prog_ph.progress(0, text="Initializing validation engine...")

    def progress_cb(pct, label=""):
        st.session_state.run_progress = pct
        st.session_state.run_label    = label
        bar.progress(min(pct,100)/100,
                     text=label[:75] if label else "Running checks...")

    findings = engine.run(progress_cb)

    for f in findings:
        if f["fid"] in st.session_state.waived_notes:
            f["waived"]      = True
            f["waiver_note"] = st.session_state.waived_notes[f["fid"]]

    st.session_state.findings     = findings
    st.session_state.is_running   = False
    st.session_state.run_progress = 100
    st.session_state.run_count   += 1
    st.session_state.last_run_ts  = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    prog_ph.empty()

# ---------------------------------------------------------------------------
# SIDEBAR
# ---------------------------------------------------------------------------
with st.sidebar:

    st.markdown("""
    <div style="text-align:center;padding:0.5rem 0 0.9rem;
                border-bottom:1px solid #1a1d2e;margin-bottom:0.7rem">
      <div class="sidebar-logo-title">CIS v7.0</div>
      <div class="sidebar-logo-sub">SDTM Beyond-P21 Validation</div>
    </div>
    """, unsafe_allow_html=True)

    # -- File Upload ---
    st.markdown(
        '<div style="font-size:0.7rem;font-weight:700;color:#8ab0e8;'
        'text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.35rem">'
        'Upload Datasets</div>', unsafe_allow_html=True,
    )

    uploaded = st.file_uploader(
        "Drop files",
        type=["sas7bdat","xpt","csv","xlsx","xls","json","xml","txt","pdf"],
        accept_multiple_files=True,
        help="SAS7BDAT, XPT, CSV, XLSX, JSON, Define-XML, PDF",
        label_visibility="collapsed",
    )

    if uploaded:
        for uf in uploaded:
            fname = uf.name
            if fname not in st.session_state.uploaded_files_meta:
                ext  = os.path.splitext(fname)[1].lower()
                raw  = uf.read()
                meta = FileParser.analyze(raw, fname, ext)
                st.session_state.uploaded_files_meta[fname] = meta

    n_files = len(st.session_state.uploaded_files_meta)
    if n_files > 0:
        st.markdown(
            f'<div style="font-size:0.7rem;color:#6898ff;font-weight:600;'
            f'margin-bottom:0.25rem">{n_files} file(s) loaded</div>',
            unsafe_allow_html=True,
        )
        for fname, m in st.session_state.uploaded_files_meta.items():
            err   = m.get("parse_error","")
            # FIX: status text colors visible on dark sidebar
            ok_span = ('<span style="color:#58c890">OK</span>' if not err
                       else '<span style="color:#ff7070">ERR</span>')
            short = fname[:22] + "..." if len(fname) > 22 else fname
            st.markdown(
                f'<div style="font-size:0.67rem;color:#7888b0;padding:2px 0">'
                f'{ok_span} <span style="color:#a8b4cc">{short}</span>'
                f' <span style="color:#505878">'
                f'({m.get("rows",0)}r, {m.get("cols",0)}c)</span></div>',
                unsafe_allow_html=True,
            )
        st.markdown("<div style='height:3px'></div>", unsafe_allow_html=True)
        if st.button("Clear All Files", key="clear_files",
                     use_container_width=True):
            st.session_state.uploaded_files_meta = {}
            st.session_state.findings    = []
            st.session_state.waived_notes = {}
            st.rerun()
    else:
        st.markdown(
            '<div class="info-box">No files loaded - app runs '
            'with 40 demo findings.</div>',
            unsafe_allow_html=True,
        )

    st.divider()

    # -- Check Configuration ---
    st.markdown(
        '<div style="font-size:0.7rem;font-weight:700;color:#8ab0e8;'
        'text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.35rem">'
        'Check Configuration</div>', unsafe_allow_html=True,
    )

    # SUG-001: call get_checks() to trigger YAML hot-reload each render
    _live_checks = get_checks()
    n_en = len(st.session_state.enabled_ids)
    st.markdown(
        f'<div style="font-size:0.7rem;color:#7880a8;margin-bottom:0.45rem">'
        f'<span style="color:#8ab0e8;font-weight:700">{n_en}</span>'
        f' / {len(_live_checks)} checks active'
        f'<span style="color:#404868;font-size:0.6rem"> (checks.yaml auto-reloads)</span></div>',
        unsafe_allow_html=True,
    )

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Enable All", key="enable_all", use_container_width=True):
            st.session_state.enabled_ids = set(c["id"] for c in CHECKS)
            st.rerun()
    with c2:
        if st.button("Disable All", key="disable_all", use_container_width=True):
            st.session_state.enabled_ids = set()
            st.rerun()

    sel_layer = st.selectbox("Layer", ["All"] + sorted(LAYERS), key="layer_filter_sel")
    sel_cat   = st.selectbox("Category", ["All"] + sorted(CATEGORIES), key="cat_filter_sel")
    srch      = st.text_input("Search", placeholder="Check ID or keyword...",
                              key="check_search_input")

    filtered_checks = [
        c for c in CHECKS
        if (sel_layer == "All" or c["layer"] == sel_layer)
        and (sel_cat  == "All" or c["cat"]   == sel_cat)
        and (not srch or srch.lower() in c["label"].lower()
             or srch.lower() in c["id"].lower())
    ]

    with st.expander(f"Toggle Checks  ({len(filtered_checks)} shown)", expanded=False):
        for c in filtered_checks:
            is_on   = c["id"] in st.session_state.enabled_ids
            new_val = st.checkbox(
                f"**{c['id']}**  {c['label'][:46]}{'...' if len(c['label'])>46 else ''}",
                value=is_on, key=f"chk_{c['id']}",
                help=(f"Layer: {c['layer']}  |  Domain: {c['domain']}  |  "
                      f"Sev: {c['sev']}  |  Source: {c['source']}"),
            )
            if new_val != is_on:
                if new_val:
                    st.session_state.enabled_ids.add(c["id"])
                else:
                    st.session_state.enabled_ids.discard(c["id"])

    st.divider()

    # -- Run + Download ---
    if st.session_state.last_run_ts:
        st.markdown(
            f'<div style="font-size:0.67rem;color:#505878;margin-bottom:0.35rem">'
            f'Last run: <span style="color:#7880a8">{st.session_state.last_run_ts}</span>'
            f' (#{st.session_state.run_count})</div>',
            unsafe_allow_html=True,
        )

    if st.button("Run Validation", type="primary",
                 use_container_width=True,
                 disabled=st.session_state.is_running, key="run_btn"):
        run_validation()
        st.rerun()

    if st.session_state.findings:
        st.divider()
        report_html = make_html_report(
            findings    = st.session_state.findings,
            files_meta  = st.session_state.uploaded_files_meta,
            enabled_ids = st.session_state.enabled_ids,
        )
        st.download_button(
            label="Download HTML Report",
            data=report_html.encode("utf-8"),
            file_name=f"clinical_integrity_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
            mime="text/html",
            use_container_width=True,
            key="dl_report",
        )
        # SUG-005: Excel export
        try:
            excel_bytes = make_excel_report(
                findings    = st.session_state.findings,
                files_meta  = st.session_state.uploaded_files_meta,
                enabled_ids = st.session_state.enabled_ids,
            )
            st.download_button(
                label="Download Excel Report",
                data=excel_bytes,
                file_name=f"clinical_integrity_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
                key="dl_excel",
            )
        except Exception as _exc:
            st.caption(f"Excel export unavailable: {_exc}")

# ---------------------------------------------------------------------------
# MAIN HEADER + SCORECARDS
# ---------------------------------------------------------------------------
st.markdown(
    f'<div class="header-glow"><div class="suite-title">Clinical Integrity Suite</div>'
    f'<div class="suite-subtitle">SDTM Beyond-P21 &nbsp;|&nbsp; v7.0 &nbsp;|&nbsp; '
    f'{len(CHECKS)} Checks &nbsp;|&nbsp; 35+ Domains &nbsp;|&nbsp; FDA JumpStart</div></div>',
    unsafe_allow_html=True,
)

findings_all = st.session_state.findings
active       = _active_findings()
by_risk      = _count_by(active, "risk")

m1,m2,m3,m4,m5,m6 = st.columns(6)
m1.metric("Active",     len(active))
m2.metric("Blockers",   by_risk.get("submission-blocker",0))
m3.metric("Medical",    by_risk.get("medical-concern",0))
m4.metric("Structural", by_risk.get("structural",0))
m5.metric("Advisory",   by_risk.get("advisory",0))
m6.metric("Waived",     len([f for f in findings_all if f.get("waived")]))

st.divider()

# ---------------------------------------------------------------------------
# TABS
# ---------------------------------------------------------------------------
tab_dash,tab_rep,tab_subj,tab_dom,tab_reg,tab_files = st.tabs([
    "Dashboard",
    "Integrity Report",
    "Subject View",
    "Domain Map",
    "Check Registry",
    "Files",
])

# -- Dashboard ----------------------------------------------------------------
with tab_dash:
    if not active:
        st.markdown("""
        <div style="text-align:center;padding:5rem 2rem">
          <div class="empty-state-title">SDTM Clinical Integrity Suite</div>
          <div class="empty-state-sub">
            Upload SDTM datasets in the sidebar, then click Run Validation.<br>
            Or click Run Validation now to load 40 demo findings instantly.
          </div>
        </div>""", unsafe_allow_html=True)
    else:
        by_sev   = _count_by(active,"sev")
        by_dom   = _count_dom(active)
        by_cat   = _count_by(active,"cat")
        by_layer = _count_by(active,"layer")

        cl,cr = st.columns(2)
        with cl:
            st.markdown("**Findings by Risk Category**")
            df = pd.DataFrame([{"Category":RISK_LABELS.get(k,k),"Count":v}
                               for k,v in sorted(by_risk.items(),key=lambda x:-x[1])])
            if not df.empty: st.bar_chart(df.set_index("Category")["Count"], color="#5898ff")

        with cr:
            st.markdown("**Findings by Severity**")
            df = pd.DataFrame([{"Severity":k,"Count":v}
                               for k,v in sorted(by_sev.items(),key=lambda x:-x[1])])
            if not df.empty: st.bar_chart(df.set_index("Severity")["Count"], color="#ff9060")

        cl2,cr2 = st.columns([2,1])
        with cl2:
            st.markdown("**Findings by SDTM Domain**")
            df = pd.DataFrame([{"Domain":k,"Count":v}
                               for k,v in sorted(by_dom.items(),key=lambda x:-x[1])[:18]])
            if not df.empty: st.bar_chart(df.set_index("Domain")["Count"], color="#58b8ff")

        with cr2:
            st.markdown("**By Layer**")
            df = pd.DataFrame([{"Layer":k,"Count":v}
                               for k,v in sorted(by_layer.items(),key=lambda x:-x[1])])
            if not df.empty: st.bar_chart(df.set_index("Layer")["Count"], color="#70d098")

        st.markdown("**Top Finding Categories**")
        df = pd.DataFrame([{"Category":k,"Count":v}
                           for k,v in sorted(by_cat.items(),key=lambda x:-x[1])[:10]])
        if not df.empty: st.bar_chart(df.set_index("Category")["Count"], color="#c878ff")

# -- Integrity Report ---------------------------------------------------------
with tab_rep:
    if not findings_all:
        st.info("Run validation to see findings.")
    else:
        # SUG-004: Dependency warnings panel
        dep_warns = [f for f in findings_all if f.get("dep_warning")]
        if dep_warns:
            st.divider()
            st.markdown(
                '<div style="font-size:0.7rem;color:#606888;text-transform:uppercase;'
                'letter-spacing:0.1em;margin-bottom:0.4rem">'
                'Domain Dependency Warnings (SUG-004)</div>',
                unsafe_allow_html=True,
            )
            for w in dep_warns[:20]:
                st.markdown(
                    f'<div style="background:#0c0d16;border:1px solid #252840;'
                    f'border-left:3px solid #6898ff;border-radius:4px;'
                    f'padding:0.5rem 0.8rem;margin-bottom:0.35rem;font-size:0.72rem">'
                    f'<span style="color:#6898ff;font-weight:700">[NOTICE]</span> '
                    f'<span style="color:#78a8ff">{w["checkId"]}</span> '
                    f'<span style="color:#a8b4cc">{w["label"][:55]}...</span><br>'
                    f'<span style="color:#5a6484">{w["detail"]}</span></div>',
                    unsafe_allow_html=True,
                )


        fc1,fc2,fc3 = st.columns([1,1,2])
        with fc1:
            risk_filter = st.selectbox(
                "Filter by Risk",
                ["All","submission-blocker","medical-concern","structural","advisory"],
                format_func=lambda x: "All Findings" if x=="All" else RISK_LABELS.get(x,x),
                key="risk_filter_sel",
            )
        with fc2:
            hide_waived = st.checkbox("Hide waived", value=False, key="hide_waived")
        with fc3:
            df_f = _findings_to_df(
                [f for f in findings_all if not(hide_waived and f.get("waived"))],
                risk_filter,
            )
            n_w = len([f for f in findings_all if f.get("waived")])
            st.markdown(
                f'<div style="font-size:0.74rem;color:#7880a8;padding-top:0.45rem">'
                f'<span style="color:#c0c8e8;font-weight:700">{len(df_f)}</span>'
                f' shown &nbsp;|&nbsp; Total: {len(findings_all)}'
                f' &nbsp;|&nbsp; Waived: {n_w}</div>',
                unsafe_allow_html=True,
            )

        root_groups,standalone = {},[]
        for f in findings_all:
            if (risk_filter=="All" or f.get("risk")==risk_filter) and \
               not(hide_waived and f.get("waived")):
                if f.get("root"): root_groups.setdefault(f["root"],[]).append(f)
                else:             standalone.append(f)

        if root_groups:
            st.divider()
            st.markdown('<div class="section-label">Root-Cause Clusters</div>',
                        unsafe_allow_html=True)
            for root,rf in root_groups.items():
                worst = _worst_risk([f["risk"] for f in rf])
                with st.expander(
                    f"Root: {root}  --  {len(rf)} findings  --  {RISK_LABELS.get(worst,worst)}",
                    expanded=False):
                    for f in rf: _render_finding_card(f)

        if standalone:
            sm = {}
            for f in standalone:
                k = "GLOBAL" if f["subj"]=="ALL" else f["subj"]
                sm.setdefault(k,[]).append(f)
            st.divider()
            st.markdown('<div class="section-label">Subject Groups</div>',
                        unsafe_allow_html=True)
            for subj,sf in sorted(sm.items(),
                    key=lambda x:(0 if _worst_risk([f["risk"] for f in x[1]])=="medical-concern" else 1, x[0])):
                worst = _worst_risk([f["risk"] for f in sf])
                doms  = ", ".join(list(dict.fromkeys(f["domain"].split("/")[0] for f in sf))[:5])
                with st.expander(
                    f"{subj}  --  {len(sf)} finding{'s' if len(sf)>1 else ''}  --  {doms}",
                    expanded=False):
                    for f in sf: _render_finding_card(f)

        st.divider()
        st.markdown('<div class="section-label">Full Findings Table</div>',
                    unsafe_allow_html=True)
        st.dataframe(df_f, use_container_width=True, hide_index=True, height=380)

# -- Subject View -------------------------------------------------------------
with tab_subj:
    if not active:
        st.info("Run validation to see subject data.")
    else:
        srch_s = st.text_input("Filter by Subject ID", placeholder="e.g. 001-007",
                               key="subj_search_main")
        df_s   = _subject_summary(findings_all)
        if srch_s:
            df_s = df_s[df_s["Subject"].str.contains(srch_s,case=False,na=False)]
        st.markdown(
            f'<div style="font-size:0.7rem;color:#7880a8;margin-bottom:0.35rem">'
            f'<span style="color:#8ab0e8;font-weight:700">{len(df_s)}</span>'
            f' subjects with active findings</div>',
            unsafe_allow_html=True,
        )
        st.dataframe(df_s, use_container_width=True, hide_index=True, height=460)

        if srch_s:
            matches = [f for f in active if srch_s.lower() in (f["subj"] or "").lower()]
            if matches:
                st.divider()
                st.markdown(f'<div class="section-label">Detail: "{srch_s}"</div>',
                            unsafe_allow_html=True)
                for f in matches: _render_finding_card(f)

# -- Domain Map ---------------------------------------------------------------
with tab_dom:
    st.markdown(
        '<div style="font-family:Orbitron,monospace;font-size:0.92rem;'
        'font-weight:700;color:#a0b8e0;margin-bottom:0.25rem">'
        'Domain Coverage Matrix</div>', unsafe_allow_html=True,
    )
    st.markdown(
        f'<div style="font-size:0.7rem;color:#606888;margin-bottom:0.7rem">'
        f'{len(CHECKS)} checks across 35+ SDTM domains</div>', unsafe_allow_html=True,
    )
    df_dm = _domain_map_df(findings_all)

    def _style_domain(row):
        if row["Active Findings"] > 0:
            return ["color:#ff9090;font-weight:bold"] * len(row)
        return ["color:#8090b8"] * len(row)

    st.dataframe(df_dm.style.apply(_style_domain,axis=1),
                 use_container_width=True, hide_index=True, height=520)

# -- Check Registry -----------------------------------------------------------
with tab_reg:
    st.markdown(
        '<div style="font-family:Orbitron,monospace;font-size:0.92rem;'
        'font-weight:700;color:#a0b8e0;margin-bottom:0.5rem">'
        'Full Check Registry</div>', unsafe_allow_html=True,
    )
    rc1,rc2,rc3 = st.columns([2,1,1])
    with rc1:
        srch_r = st.text_input("Search", placeholder="Check ID or keyword...",
                               key="reg_search")
    with rc2:
        lr = st.selectbox("Layer", ["All"] + sorted(LAYERS), key="reg_layer")
    with rc3:
        cr = st.selectbox("Category", ["All"] + sorted(CATEGORIES), key="reg_cat")

    reg_ch = [c for c in CHECKS
              if (not srch_r or srch_r.lower() in c["label"].lower()
                  or srch_r.lower() in c["id"].lower())
              and (lr=="All" or c["layer"]==lr)
              and (cr=="All" or c["cat"]==cr)]

    df_r = pd.DataFrame([{
        "ID":c["id"],"Layer":c["layer"],"Category":c["cat"],"Domain":c["domain"],
        "Severity":c["sev"],"Risk":RISK_LABELS.get(c["risk"],c["risk"]),
        "Description":c["label"],"Source":c["source"],
        "Enabled":"ON" if c["id"] in st.session_state.enabled_ids else "OFF",
    } for c in reg_ch])

    st.markdown(
        f'<div style="font-size:0.7rem;color:#7880a8;margin-bottom:0.35rem">'
        f'<span style="color:#8ab0e8;font-weight:700">{len(df_r)}</span>'
        f' of {len(CHECKS)} checks shown</div>', unsafe_allow_html=True,
    )
    st.dataframe(df_r, use_container_width=True, hide_index=True, height=500)

# -- Files --------------------------------------------------------------------
with tab_files:
    st.markdown(
        '<div style="font-family:Orbitron,monospace;font-size:0.92rem;'
        'font-weight:700;color:#a0b8e0;margin-bottom:0.5rem">'
        'Loaded Files</div>', unsafe_allow_html=True,
    )
    df_fi = _files_to_df(st.session_state.uploaded_files_meta)
    if df_fi.empty:
        st.markdown('<div class="info-box">No files loaded. '
                    'Upload datasets via the sidebar.</div>', unsafe_allow_html=True)
    else:
        st.dataframe(df_fi, use_container_width=True, hide_index=True)
        st.divider()
        st.markdown('<div class="section-label">Variable Preview</div>',
                    unsafe_allow_html=True)
        sel_f = st.selectbox("Select file",
                             list(st.session_state.uploaded_files_meta.keys()),
                             key="file_preview_sel")
        if sel_f:
            m  = st.session_state.uploaded_files_meta[sel_f]
            dt = m.get("data",[])
            if dt:
                st.dataframe(pd.DataFrame(dt[:50]),
                             use_container_width=True, hide_index=True, height=300)
            else:
                st.markdown('<div class="info-box">No row data for this file type.'
                            ' SAS7BDAT and XPT show variable names only.</div>',
                            unsafe_allow_html=True)
