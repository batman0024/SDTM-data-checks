"""
modules/reporter.py
SUG-005: Excel (.xlsx) export added alongside the existing HTML report.

make_html_report()  - returns HTML string (unchanged API)
make_excel_report() - returns bytes of .xlsx workbook
"""

import io
import datetime

RISK_LABEL = {
    "submission-blocker": "Submission Blocker",
    "medical-concern":    "Medical Concern",
    "structural":         "Structural Error",
    "advisory":           "Advisory",
}
RISK_C = {
    "submission-blocker": "#ff3a3a",
    "medical-concern":    "#e05c5c",
    "structural":         "#e08a2e",
    "advisory":           "#4080ff",
}
SEV_C = {
    "REJECT":   "#ff3a3a",
    "CRITICAL": "#e05c5c",
    "ERROR":    "#e08a2e",
    "WARNING":  "#c4b400",
    "NOTICE":   "#4080ff",
}

def _e(s: str) -> str:
    if not s:
        return ""
    return (str(s)
            .replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))

def _bar(obj: dict, cmap: dict = None) -> str:
    if not obj:
        return "<p style='color:#2a2e45;font-size:10px'>No data</p>"
    mx  = max(obj.values()) if obj else 1
    out = ""
    for k, v in sorted(obj.items(), key=lambda x: -x[1]):
        pct = int(v / mx * 100) if mx else 0
        c   = (cmap or {}).get(k, "#4080ff")
        out += (
            f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">'
            f'<div style="width:130px;font-size:10px;color:#7a7e98;text-align:right;'
            f'flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{_e(str(k)[:18])}</div>'
            f'<div style="flex:1;background:#0f1018;border-radius:2px;height:14px;'
            f'overflow:hidden;border:1px solid #16182a">'
            f'<div style="height:100%;width:{pct}%;background:{c};border-radius:2px"></div></div>'
            f'<div style="width:24px;font-size:10px;color:#7a7e98">{v}</div></div>'
        )
    return out


# ---------------------------------------------------------------------------
# HTML REPORT  (unchanged from v5.1)
# ---------------------------------------------------------------------------
def make_html_report(findings: list, files_meta: dict, enabled_ids: set) -> str:
    now    = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    active = [f for f in findings if not f.get("waived")]
    waived = [f for f in findings if f.get("waived")]
    by_risk: dict = {}
    by_sev:  dict = {}
    by_dom:  dict = {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"], 0) + 1
        by_sev[f["sev"]]   = by_sev.get(f["sev"],   0) + 1
        d = f["domain"].split("/")[0]
        by_dom[d]          = by_dom.get(d, 0) + 1

    def sc(label, val, color):
        return (
            f'<div style="background:#0d0f18;border:1px solid {color}22;border-radius:5px;'
            f'padding:12px 10px;text-align:center">'
            f'<div style="font-size:22px;font-weight:700;color:{color};font-family:sans-serif">{val}</div>'
            f'<div style="font-size:9px;color:#2a2e45;text-transform:uppercase;letter-spacing:.07em;margin-top:2px">{label}</div></div>'
        )
    scores = (
        sc("Active",    len(active),                             "#b0b5c8") +
        sc("Blockers",  by_risk.get("submission-blocker", 0),   "#ff3a3a") +
        sc("Medical",   by_risk.get("medical-concern",    0),   "#e05c5c") +
        sc("Structural",by_risk.get("structural",         0),   "#e08a2e") +
        sc("Advisory",  by_risk.get("advisory",           0),   "#4080ff") +
        sc("Waived",    len(waived),                             "#30a060")
    )

    def tbl(flist):
        if not flist:
            return "<p style='color:#2a2e45;font-size:10px;padding:12px'>No findings.</p>"
        rows = ""
        for f in flist[:500]:
            sc2 = SEV_C.get(f.get("sev",""),  "#666")
            rc  = RISK_C.get(f.get("risk",""), "#666")
            rl  = RISK_LABEL.get(f.get("risk",""), f.get("risk",""))
            ab  = (
                '<span style="font-size:8px;background:rgba(32,128,80,.3);color:#3a9060;'
                'border:1px solid #1a5030;border-radius:2px;padding:0 3px">ACTUAL</span>'
                if f.get("actual") else
                '<span style="font-size:8px;background:rgba(64,128,255,.15);color:#4080ff;'
                'border:1px solid #1a2a5a;border-radius:2px;padding:0 3px">DEMO</span>'
            )
            rt  = (f' <span style="font-size:9px;color:#3a3e58">Root: {_e(f.get("root",""))}</span>'
                   if f.get("root") else "")
            wn  = f.get("waiver_note","")
            wn_td = (f' <span style="color:#30a060;font-size:9px">Waived: {_e(wn)}</span>'
                     if wn else "")
            rows += (
                f'<tr>'
                f'<td style="font-size:9px;color:#3a3e58">{_e(f.get("fid",""))}</td>'
                f'<td><span style="border:1px solid {sc2};color:{sc2};font-size:9px;'
                f'padding:1px 4px;border-radius:2px">{_e(f.get("sev",""))}</span></td>'
                f'<td style="color:{rc};font-size:10px">{_e(rl)}</td>'
                f'<td style="color:#4080ff;font-weight:600">'
                f'{"GLOBAL" if f.get("subj")=="ALL" else f.get("subj","")}</td>'
                f'<td style="color:#3a3e58;font-size:10px">{_e(f.get("domain",""))}</td>'
                f'<td>{_e(f.get("label",""))} {ab}{rt}</td>'
                f'<td style="color:#7a7e98;font-size:10px">{_e(f.get("detail",""))}{wn_td}</td>'
                f'<td style="font-size:9px;color:#2a2e45">{_e(f.get("source",""))}</td>'
                f'</tr>'
            )
        cols = ["ID","Sev","Risk","Subject","Domain","Check","Detail","Source"]
        th   = "".join(
            f'<th style="background:#0e0e18;border:1px solid #16182a;padding:7px 9px;'
            f'text-align:left;color:#4080ff;font-size:10px;text-transform:uppercase">{col}</th>'
            for col in cols
        )
        return (
            f'<table style="width:100%;border-collapse:collapse;font-size:11px">'
            f'<thead><tr>{th}</tr></thead><tbody>{rows}</tbody></table>'
        )

    fr = ""
    for fname, m in files_meta.items():
        vs  = ", ".join((m.get("variables") or [])[:6])
        if len(m.get("variables") or []) > 6:
            vs += " ..."
        fr += (
            f'<tr><td style="color:#4080ff">{_e(fname)}</td>'
            f'<td>{_e(m.get("type",""))}</td>'
            f'<td style="text-align:right">{m.get("rows",0)}</td>'
            f'<td style="text-align:right">{m.get("cols",0)}</td>'
            f'<td style="text-align:right">{m.get("size",0):,}</td>'
            f'<td style="font-size:10px;color:#3a3e58">{_e(vs)}</td>'
            f'<td style="color:#e05c5c;font-size:10px">{_e(m.get("parse_error",""))}</td></tr>'
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8">
<title>Clinical Integrity Report - SDTM Suite v6.0</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#09090e;color:#b0b5c8;font-family:"Courier New",monospace;
     font-size:12px;line-height:1.6;padding:32px 24px}}
.page{{max-width:1200px;margin:0 auto}}
h1{{font-family:sans-serif;font-size:22px;font-weight:800;color:#d0d5e8;margin-bottom:4px}}
h2{{font-family:sans-serif;font-size:15px;font-weight:700;color:#d0d5e8;
    margin:28px 0 12px;padding-bottom:7px;border-bottom:1px solid #16182a}}
table{{width:100%;border-collapse:collapse}}
th{{background:#0e0e18;border:1px solid #16182a;padding:7px 9px;text-align:left;
    color:#4080ff;font-size:10px;text-transform:uppercase}}
td{{border:1px solid #16182a;padding:7px 9px;vertical-align:top}}
tr:hover td{{background:rgba(64,128,255,.02)}}
.g6{{display:grid;grid-template-columns:repeat(6,1fr);gap:9px;margin-bottom:20px}}
.g2{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}}
.cb{{background:#0c0c14;border:1px solid #16182a;border-radius:5px;padding:14px}}
.cl{{font-size:9px;color:#2a2e45;text-transform:uppercase;letter-spacing:.1em;margin-bottom:9px}}
</style>
</head>
<body><div class="page">
<div style="font-size:9px;color:#2a2e45;letter-spacing:.1em;text-transform:uppercase;margin-bottom:10px">
  SDTM Clinical Integrity Suite v6.0 - Beyond-P21 Validation Engine
</div>
<h1>Clinical Integrity Report</h1>
<div style="font-size:11px;color:#3a3e58;margin-bottom:20px">
  Generated: {now} &bull; {len(findings)} total findings &bull;
  {len(active)} active &bull; {len(waived)} waived &bull; {len(enabled_ids)} checks enabled
</div>
<h2>Executive Summary</h2>
<div class="g6">{scores}</div>
<h2>Findings by Risk and Severity</h2>
<div class="g2">
  <div class="cb"><div class="cl">By Risk Category</div>{_bar(by_risk, RISK_C)}</div>
  <div class="cb"><div class="cl">By Severity Level</div>{_bar(by_sev, SEV_C)}</div>
</div>
<div class="cb" style="margin-bottom:20px">
  <div class="cl">By SDTM Domain</div>{_bar(by_dom)}
</div>
<h2>Medical Concerns and Submission Blockers \
({by_risk.get("medical-concern",0)+by_risk.get("submission-blocker",0)})</h2>
{tbl([f for f in active if f["risk"] in ("medical-concern","submission-blocker")])}
<h2>Structural Errors and Advisory \
({by_risk.get("structural",0)+by_risk.get("advisory",0)})</h2>
{tbl([f for f in active if f["risk"] in ("structural","advisory")])}
<h2>All Active Findings ({len(active)})</h2>
{tbl(active)}
<h2>Waived Findings ({len(waived)})</h2>
<div style="opacity:.5">{tbl(waived)}</div>
<h2>Loaded Files ({len(files_meta)})</h2>
<table><thead><tr>
<th>Filename</th><th>Type</th><th>Rows</th><th>Cols</th>
<th>Size</th><th>Variables</th><th>Error</th>
</tr></thead><tbody>
{fr if fr else '<tr><td colspan="7" style="color:#2a2e45;text-align:center;padding:14px">No files loaded</td></tr>'}
</tbody></table>
<div style="margin-top:36px;padding-top:14px;border-top:1px solid #16182a;
            font-size:9px;color:#2a2e45;text-align:center">
  SDTM Clinical Integrity Suite v6.0 &bull; Beyond-P21 &bull;
  Sources: FDA TCG 2024, SDTMIG v3.4, PharmaSUG 2012-2024,
  ICH E2A/E3/E6/E14, CDISC CT, RECIST 1.1, FDA DILI
</div>
</div></body></html>"""


# ---------------------------------------------------------------------------
# SUG-005: EXCEL REPORT
# ---------------------------------------------------------------------------
def make_excel_report(findings: list, files_meta: dict,
                      enabled_ids: set) -> bytes:
    """
    Generate a multi-sheet Excel workbook with:
      Sheet 1: Summary       - scorecards + counts by risk/severity/domain
      Sheet 2: All Findings  - full sortable table (risk-colour coded rows)
      Sheet 3: Medical Conc. - medical-concern + submission-blocker only
      Sheet 4: Structural    - structural + advisory only
      Sheet 5: Waived        - waived findings with cSDRG notes
      Sheet 6: Files         - loaded file metadata

    Returns bytes suitable for st.download_button(data=...).
    Requires xlsxwriter (pip install xlsxwriter).
    Falls back to openpyxl if xlsxwriter not available.
    """
    try:
        import xlsxwriter
        return _make_xlsx_xlsxwriter(findings, files_meta, enabled_ids)
    except ImportError:
        return _make_xlsx_openpyxl(findings, files_meta, enabled_ids)


def _make_xlsx_xlsxwriter(findings, files_meta, enabled_ids) -> bytes:
    """Full-featured Excel with conditional formatting via xlsxwriter."""
    import xlsxwriter as xl

    buf = io.BytesIO()
    wb  = xl.Workbook(buf, {"in_memory": True})
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # --- Formats ---
    hdr_fmt = wb.add_format({
        "bold": True, "font_color": "#FFFFFF",
        "bg_color": "#0a1840", "border": 1,
        "font_name": "Courier New", "font_size": 9,
        "text_wrap": True, "valign": "vcenter",
    })
    title_fmt = wb.add_format({
        "bold": True, "font_size": 14,
        "font_color": "#60a0ff", "font_name": "Calibri",
    })
    meta_fmt = wb.add_format({
        "font_size": 9, "font_color": "#808080", "font_name": "Courier New",
    })
    cell_fmt = wb.add_format({
        "font_name": "Courier New", "font_size": 9,
        "border": 1, "text_wrap": True, "valign": "top",
    })
    # Risk-coloured row formats
    risk_fmts = {
        "submission-blocker": wb.add_format({
            "font_name":"Courier New","font_size":9,"border":1,
            "text_wrap":True,"valign":"top",
            "bg_color":"#2a0808","font_color":"#ff8080",
        }),
        "medical-concern": wb.add_format({
            "font_name":"Courier New","font_size":9,"border":1,
            "text_wrap":True,"valign":"top",
            "bg_color":"#200a0a","font_color":"#ffb0b0",
        }),
        "structural": wb.add_format({
            "font_name":"Courier New","font_size":9,"border":1,
            "text_wrap":True,"valign":"top",
            "bg_color":"#1a1200","font_color":"#ffd090",
        }),
        "advisory": wb.add_format({
            "font_name":"Courier New","font_size":9,"border":1,
            "text_wrap":True,"valign":"top",
            "bg_color":"#08081a","font_color":"#a0b8ff",
        }),
    }
    waived_fmt = wb.add_format({
        "font_name":"Courier New","font_size":9,"border":1,
        "text_wrap":True,"valign":"top",
        "bg_color":"#0a1a0a","font_color":"#70d090",
        "italic":True,
    })
    score_val_fmt = wb.add_format({
        "font_name":"Calibri","font_size":18,"bold":True,
        "align":"center","valign":"vcenter","border":1,
    })
    score_lbl_fmt = wb.add_format({
        "font_name":"Calibri","font_size":8,"italic":True,
        "align":"center","valign":"vcenter","border":1,
        "font_color":"#808080",
    })

    active = [f for f in findings if not f.get("waived")]
    waived = [f for f in findings if f.get("waived")]
    by_risk: dict = {}
    by_sev:  dict = {}
    by_dom:  dict = {}
    for f in active:
        by_risk[f["risk"]] = by_risk.get(f["risk"], 0) + 1
        by_sev[f["sev"]]   = by_sev.get(f["sev"],   0) + 1
        d = f["domain"].split("/")[0]
        by_dom[d]          = by_dom.get(d, 0) + 1

    COLS = ["ID","Severity","Risk","Subject","Domain","Layer","Category",
            "Check Description","Finding Detail","Source","Actual/Demo","Waived","Waiver Note"]

    def write_headers(ws, cols, row=0):
        for ci, h in enumerate(cols):
            ws.write(row, ci, h, hdr_fmt)

    def write_finding_row(ws, row, f):
        risk = f.get("risk","structural")
        fmt  = waived_fmt if f.get("waived") else risk_fmts.get(risk, cell_fmt)
        data = [
            f.get("fid",""),
            f.get("sev",""),
            RISK_LABEL.get(risk, risk),
            "GLOBAL" if f.get("subj","") == "ALL" else f.get("subj",""),
            f.get("domain","").split("/")[0],
            f.get("layer",""),
            f.get("cat",""),
            f.get("label",""),
            f.get("detail",""),
            f.get("source",""),
            "ACTUAL" if f.get("actual") else "DEMO",
            "YES" if f.get("waived") else "",
            f.get("waiver_note",""),
        ]
        for ci, v in enumerate(data):
            ws.write(row, ci, v, fmt)

    col_widths = [8, 9, 18, 12, 8, 14, 18, 50, 60, 20, 8, 7, 40]

    def set_col_widths(ws, widths):
        for ci, w in enumerate(widths):
            ws.set_column(ci, ci, w)

    # ---- Sheet 1: Summary ----
    ws_sum = wb.add_worksheet("Summary")
    ws_sum.set_tab_color("#1a3a8a")
    ws_sum.hide_gridlines(2)
    ws_sum.write(0, 0, "SDTM Clinical Integrity Suite v6.0", title_fmt)
    ws_sum.write(1, 0, f"Generated: {now}  |  Checks enabled: {len(enabled_ids)}  |  Files: {len(files_meta)}", meta_fmt)

    scorecard = [
        ("Active Findings",    len(active),                           "#c0c8e8", "#0a0a18"),
        ("Submission Blockers",by_risk.get("submission-blocker",0),   "#ff6060", "#2a0808"),
        ("Medical Concerns",   by_risk.get("medical-concern",0),      "#ff8080", "#200a0a"),
        ("Structural Errors",  by_risk.get("structural",0),           "#ffb060", "#1a1200"),
        ("Advisory",           by_risk.get("advisory",0),             "#7098ff", "#08081a"),
        ("Waived",             len(waived),                            "#60c080", "#0a1a0a"),
    ]
    ws_sum.set_row(3, 36)
    ws_sum.set_row(4, 18)
    for ci, (lbl, val, fc, bg) in enumerate(scorecard):
        ws_sum.set_column(ci, ci, 18)
        vf = wb.add_format({"font_name":"Calibri","font_size":20,"bold":True,
                            "align":"center","valign":"vcenter","border":1,
                            "font_color":fc,"bg_color":bg})
        lf = wb.add_format({"font_name":"Calibri","font_size":8,"italic":True,
                            "align":"center","valign":"vcenter","border":1,
                            "font_color":"#808080","bg_color":bg})
        ws_sum.write(3, ci, val, vf)
        ws_sum.write(4, ci, lbl, lf)

    # By Risk table
    ws_sum.write(6, 0, "By Risk Category", hdr_fmt)
    ws_sum.write(6, 1, "Count", hdr_fmt)
    for ri, (k, v) in enumerate(sorted(by_risk.items(), key=lambda x: -x[1]), 7):
        rf = wb.add_format({"font_name":"Courier New","font_size":9,"border":1,
                            "font_color": RISK_C.get(k,"#ffffff")})
        ws_sum.write(ri, 0, RISK_LABEL.get(k,k), rf)
        ws_sum.write(ri, 1, v, rf)

    # By Severity
    ws_sum.write(6, 3, "By Severity", hdr_fmt)
    ws_sum.write(6, 4, "Count", hdr_fmt)
    for ri, (k, v) in enumerate(sorted(by_sev.items(), key=lambda x: -x[1]), 7):
        sf = wb.add_format({"font_name":"Courier New","font_size":9,"border":1,
                            "font_color": SEV_C.get(k,"#ffffff")})
        ws_sum.write(ri, 3, k, sf)
        ws_sum.write(ri, 4, v, sf)

    # By Domain
    ws_sum.write(6, 6, "By SDTM Domain", hdr_fmt)
    ws_sum.write(6, 7, "Count", hdr_fmt)
    for ri, (k, v) in enumerate(sorted(by_dom.items(), key=lambda x: -x[1])[:20], 7):
        ws_sum.write(ri, 6, k, cell_fmt)
        ws_sum.write(ri, 7, v, cell_fmt)

    def _write_findings_sheet(ws, flist, tab_color):
        ws.set_tab_color(tab_color)
        ws.freeze_panes(1, 0)
        ws.autofilter(0, 0, max(len(flist), 1), len(COLS)-1)
        write_headers(ws, COLS)
        set_col_widths(ws, col_widths)
        for ri, f in enumerate(flist, 1):
            write_finding_row(ws, ri, f)

    # ---- Sheets 2-5 ----
    _write_findings_sheet(wb.add_worksheet("All Findings"),        active, "#1a3a8a")
    _write_findings_sheet(wb.add_worksheet("Medical + Blockers"),
                          [f for f in active if f["risk"] in ("medical-concern","submission-blocker")],
                          "#8a1a1a")
    _write_findings_sheet(wb.add_worksheet("Structural + Advisory"),
                          [f for f in active if f["risk"] in ("structural","advisory")],
                          "#8a5a1a")
    _write_findings_sheet(wb.add_worksheet("Waived"), waived, "#1a8a3a")

    # ---- Sheet 6: Files ----
    ws_files = wb.add_worksheet("Files")
    ws_files.set_tab_color("#3a3a3a")
    file_cols = ["Filename","Type","Rows","Cols","Size (bytes)","Variables (preview)","Parse Error"]
    write_headers(ws_files, file_cols)
    for ci, w in enumerate([30,14,8,6,12,50,30]):
        ws_files.set_column(ci, ci, w)
    for ri, (fname, m) in enumerate(files_meta.items(), 1):
        vs = ", ".join((m.get("variables") or [])[:6])
        ws_files.write(ri, 0, fname,                      cell_fmt)
        ws_files.write(ri, 1, m.get("type",""),           cell_fmt)
        ws_files.write(ri, 2, m.get("rows",0),            cell_fmt)
        ws_files.write(ri, 3, m.get("cols",0),            cell_fmt)
        ws_files.write(ri, 4, m.get("size",0),            cell_fmt)
        ws_files.write(ri, 5, vs,                         cell_fmt)
        ws_files.write(ri, 6, m.get("parse_error",""),    cell_fmt)

    wb.close()
    buf.seek(0)
    return buf.read()


def _make_xlsx_openpyxl(findings, files_meta, enabled_ids) -> bytes:
    """Fallback Excel using openpyxl (less formatting but always available)."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb  = openpyxl.Workbook()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    thin = Side(style="thin", color="333344")
    bdr  = Border(left=thin, right=thin, top=thin, bottom=thin)

    def hdr_cell(ws, row, col, val):
        c = ws.cell(row=row, column=col, value=val)
        c.font      = Font(name="Courier New", bold=True, color="AABBDD", size=9)
        c.fill      = PatternFill("solid", fgColor="0a1840")
        c.border    = bdr
        c.alignment = Alignment(wrap_text=True, vertical="center")

    RISK_BG = {
        "submission-blocker": "2a0808",
        "medical-concern":    "200a0a",
        "structural":         "1a1200",
        "advisory":           "08081a",
    }
    RISK_FC = {
        "submission-blocker": "ff8080",
        "medical-concern":    "ffb0b0",
        "structural":         "ffd090",
        "advisory":           "a0b8ff",
    }

    def data_cell(ws, row, col, val, risk="structural", waived=False):
        c = ws.cell(row=row, column=col, value=val)
        bg = "0a1a0a" if waived else RISK_BG.get(risk, "0a0a18")
        fc = "70d090" if waived else RISK_FC.get(risk, "b0b8d0")
        c.font      = Font(name="Courier New", size=9, color=fc)
        c.fill      = PatternFill("solid", fgColor=bg)
        c.border    = bdr
        c.alignment = Alignment(wrap_text=True, vertical="top")

    active = [f for f in findings if not f.get("waived")]
    waived = [f for f in findings if f.get("waived")]

    COLS = ["ID","Severity","Risk","Subject","Domain","Layer","Category",
            "Check Description","Finding Detail","Source","Actual/Demo","Waived","Waiver Note"]

    def write_sheet(ws, flist, title):
        ws.title = title
        for ci, col in enumerate(COLS, 1):
            hdr_cell(ws, 1, ci, col)
        for ri, f in enumerate(flist, 2):
            risk    = f.get("risk","structural")
            is_wv   = f.get("waived", False)
            row_data = [
                f.get("fid",""),
                f.get("sev",""),
                RISK_LABEL.get(risk, risk),
                "GLOBAL" if f.get("subj","") == "ALL" else f.get("subj",""),
                f.get("domain","").split("/")[0],
                f.get("layer",""),
                f.get("cat",""),
                f.get("label",""),
                f.get("detail",""),
                f.get("source",""),
                "ACTUAL" if f.get("actual") else "DEMO",
                "YES" if is_wv else "",
                f.get("waiver_note",""),
            ]
            for ci, val in enumerate(row_data, 1):
                data_cell(ws, ri, ci, val, risk, is_wv)

    # Summary sheet
    ws0 = wb.active
    ws0.title = "Summary"
    ws0["A1"] = f"SDTM Clinical Integrity Suite v6.0 | {now}"
    ws0["A1"].font = Font(name="Calibri", bold=True, size=13, color="60a0ff")
    ws0["A2"] = f"Active: {len(active)}  |  Waived: {len(waived)}  |  Files: {len(files_meta)}"

    write_sheet(wb.create_sheet("All Findings"), active, "All Findings")
    write_sheet(wb.create_sheet("Medical+Blockers"),
                [f for f in active if f["risk"] in ("medical-concern","submission-blocker")],
                "Medical+Blockers")
    write_sheet(wb.create_sheet("Structural+Advisory"),
                [f for f in active if f["risk"] in ("structural","advisory")],
                "Structural+Advisory")
    write_sheet(wb.create_sheet("Waived"), waived, "Waived")

    ws_f = wb.create_sheet("Files")
    for ci, h in enumerate(["Filename","Type","Rows","Cols","Size","Variables","Error"], 1):
        hdr_cell(ws_f, 1, ci, h)
    for ri, (fname, m) in enumerate(files_meta.items(), 2):
        vs = ", ".join((m.get("variables") or [])[:6])
        for ci, val in enumerate([
            fname, m.get("type",""), m.get("rows",0), m.get("cols",0),
            m.get("size",0), vs, m.get("parse_error","")
        ], 1):
            ws_f.cell(row=ri, column=ci, value=val)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()
